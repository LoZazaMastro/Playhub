import asyncio
import gc
import pickle
import random
import struct
import sys
import weakref
import zlib
from unittest import mock

import pytest

import aiohttp
from aiohttp._websocket import helpers as _websocket_helpers
from aiohttp._websocket.helpers import (
    PACK_CLOSE_CODE,
    PACK_LEN1,
    PACK_LEN2,
    PACK_LEN3,
    websocket_mask,
)
from aiohttp._websocket.models import WS_DEFLATE_TRAILING
from aiohttp._websocket.reader import WebSocketDataQueue
from aiohttp._websocket.reader_py import (
    MSG_SIZE_OVERHEAD,
    WebSocketDataQueue as PyWebSocketDataQueue,
    WebSocketReader as PyWebSocketReader,
)
from aiohttp.base_protocol import BaseProtocol
from aiohttp.compression_utils import ZLibBackend
from aiohttp.helpers import DEFAULT_CHUNK_SIZE
from aiohttp.http import HttpParser, WebSocketError, WSCloseCode, WSMessage, WSMsgType
from aiohttp.http_websocket import WebSocketReader
from aiohttp.streams import EofStream


class PatchableWebSocketReader(WebSocketReader):
    """WebSocketReader subclass that allows for patching parse_frame."""

    def parse_frame(
        self, data: bytes
    ) -> list[tuple[bool, int, bytes | bytearray, int]]:
        # This method is overridden to allow for patching in tests.
        frames: list[tuple[bool, int, bytes | bytearray, int]] = []

        def _handle_frame(
            fin: bool,
            opcode: int,
            payload: bytes | bytearray,
            compressed: int,
        ) -> None:
            # This method is overridden to allow for patching in tests.
            frames.append((fin, opcode, payload, compressed))

        with mock.patch.object(self, "_handle_frame", _handle_frame):
            self._feed_data(data)
        return frames


def build_frame(
    message, opcode, use_mask=False, noheader=False, is_fin=True, ZLibBackend=None
):
    # Send a frame over the websocket with message as its payload.
    compress = False
    if ZLibBackend:
        compress = True
        compressobj = ZLibBackend.compressobj(wbits=-9)
        message = compressobj.compress(message)
        message = message + compressobj.flush(ZLibBackend.Z_SYNC_FLUSH)
        if message.endswith(WS_DEFLATE_TRAILING):
            message = message[:-4]
    msg_length = len(message)
    if use_mask:  # pragma: no cover
        mask_bit = 0x80
    else:
        mask_bit = 0

    if is_fin:
        header_first_byte = 0x80 | opcode
    else:
        header_first_byte = opcode

    if compress:
        header_first_byte |= 0x40

    if msg_length < 126:
        header = PACK_LEN1(header_first_byte, msg_length | mask_bit)
    elif msg_length < (1 << 16):  # pragma: no cover
        header = PACK_LEN2(header_first_byte, 126 | mask_bit, msg_length)
    else:
        header = PACK_LEN3(header_first_byte, 127 | mask_bit, msg_length)

    if use_mask:  # pragma: no cover
        mask = random.randrange(0, 0xFFFFFFFF)
        mask = mask.to_bytes(4, "big")
        message = bytearray(message)
        websocket_mask(mask, message)
        if noheader:
            return message
        else:
            return header + mask + message
    else:
        if noheader:
            return message
        else:
            return header + message


def build_close_frame(code=1000, message=b"", noheader=False):
    # Close the websocket, sending the specified code and message.
    if isinstance(message, str):  # pragma: no cover
        message = message.encode("utf-8")
    return build_frame(
        PACK_CLOSE_CODE(code) + message, opcode=WSMsgType.CLOSE, noheader=noheader
    )


@pytest.fixture()
def protocol(loop: asyncio.AbstractEventLoop) -> BaseProtocol:
    parser = mock.create_autospec(HttpParser, spec_set=True, instance=True)
    transport = mock.Mock(spec_set=asyncio.Transport)
    protocol = BaseProtocol(loop, parser=parser)
    protocol.connection_made(transport)
    return protocol


@pytest.fixture()
def out(loop: asyncio.AbstractEventLoop) -> WebSocketDataQueue:
    return WebSocketDataQueue(mock.Mock(_reading_paused=False), 2**16, loop=loop)


@pytest.fixture()
def out_low_limit(
    loop: asyncio.AbstractEventLoop, protocol: BaseProtocol
) -> WebSocketDataQueue:
    return WebSocketDataQueue(protocol, 16, loop=loop)


@pytest.fixture()
def parser_low_limit(
    out_low_limit: WebSocketDataQueue,
) -> PatchableWebSocketReader:
    return PatchableWebSocketReader(
        out_low_limit, 4 * 1024 * 1024, compress=True, decode_text=True
    )


@pytest.fixture()
def parser(out: WebSocketDataQueue) -> PatchableWebSocketReader:
    return PatchableWebSocketReader(
        out, 4 * 1024 * 1024, compress=True, decode_text=True
    )


def test_feed_data_remembers_exception(parser: WebSocketReader) -> None:
    """Verify that feed_data remembers an exception was already raised internally."""
    error, data = parser.feed_data(struct.pack("!BB", 0b01100000, 0b00000000))
    assert error is True
    assert data == b""

    error, data = parser.feed_data(b"")
    assert error is True
    assert data == b""


def test_parse_frame(parser: PatchableWebSocketReader) -> None:
    parser.parse_frame(struct.pack("!BB", 0b00000001, 0b00000001))
    res = parser.parse_frame(b"1")
    fin, opcode, payload, compress = res[0]

    assert (0, 1, b"1", 0) == (fin, opcode, payload, not not compress)


def test_parse_frame_length0(parser: PatchableWebSocketReader) -> None:
    fin, opcode, payload, compress = parser.parse_frame(
        struct.pack("!BB", 0b00000001, 0b00000000)
    )[0]

    assert (0, 1, b"", 0) == (fin, opcode, payload, not not compress)


def test_parse_frame_length2(parser: PatchableWebSocketReader) -> None:
    parser.parse_frame(struct.pack("!BB", 0b00000001, 126))
    parser.parse_frame(struct.pack("!H", 4))
    res = parser.parse_frame(b"1234")
    fin, opcode, payload, compress = res[0]

    assert (0, 1, b"1234", 0) == (fin, opcode, payload, not not compress)


def test_parse_frame_length2_multi_byte(parser: PatchableWebSocketReader) -> None:
    """Ensure a multi-byte length is parsed correctly."""
    expected_payload = b"1" * 32768
    parser.parse_frame(struct.pack("!BB", 0b00000001, 126))
    parser.parse_frame(struct.pack("!H", 32768))
    res = parser.parse_frame(b"1" * 32768)
    fin, opcode, payload, compress = res[0]

    assert (0, 1, expected_payload, 0) == (fin, opcode, payload, not not compress)


def test_parse_frame_length2_multi_byte_multi_packet(
    parser: PatchableWebSocketReader,
) -> None:
    """Ensure a multi-byte length with multiple packets is parsed correctly."""
    expected_payload = b"1" * 32768
    assert parser.parse_frame(struct.pack("!BB", 0b00000001, 126)) == []
    assert parser.parse_frame(struct.pack("!H", 32768)) == []
    assert parser.parse_frame(b"1" * 8192) == []
    assert parser.parse_frame(b"1" * 8192) == []
    assert parser.parse_frame(b"1" * 8192) == []
    res = parser.parse_frame(b"1" * 8192)
    fin, opcode, payload, compress = res[0]
    assert len(payload) == 32768
    assert (0, 1, expected_payload, 0) == (fin, opcode, payload, not not compress)


def test_parse_frame_length4(parser: PatchableWebSocketReader) -> None:
    parser.parse_frame(struct.pack("!BB", 0b00000001, 127))
    parser.parse_frame(struct.pack("!Q", 4))
    fin, opcode, payload, compress = parser.parse_frame(b"1234")[0]

    assert (0, 1, b"1234", 0) == (fin, opcode, payload, compress)


def test_parse_frame_mask(parser: PatchableWebSocketReader) -> None:
    parser.parse_frame(struct.pack("!BB", 0b00000001, 0b10000001))
    parser.parse_frame(b"0001")
    fin, opcode, payload, compress = parser.parse_frame(b"1")[0]

    assert (0, 1, b"\x01", 0) == (fin, opcode, payload, compress)


def test_parse_frame_header_reversed_bits(
    out: WebSocketDataQueue, parser: PatchableWebSocketReader
) -> None:
    with pytest.raises(WebSocketError):
        parser.parse_frame(struct.pack("!BB", 0b01100000, 0b00000000))
        raise out.exception()


def test_parse_frame_header_control_frame(
    out: WebSocketDataQueue, parser: PatchableWebSocketReader
) -> None:
    with pytest.raises(WebSocketError):
        parser.parse_frame(struct.pack("!BB", 0b00001000, 0b00000000))
        raise out.exception()


def test_parse_frame_header_new_data_err(parser: PatchableWebSocketReader) -> None:
    with pytest.raises(WebSocketError) as msg:
        parser._feed_data(struct.pack("!BB", 0b00000000, 0b00000000))
    assert msg.value.code == WSCloseCode.PROTOCOL_ERROR
    assert str(msg.value) == "Continuation frame for non started message"


def test_parse_frame_header_payload_size(
    out: WebSocketDataQueue, parser: PatchableWebSocketReader
) -> None:
    with pytest.raises(WebSocketError):
        parser.parse_frame(struct.pack("!BB", 0b10001000, 0b01111110))
        raise out.exception()


# Protractor event loop will call feed_data with bytearray. Since
# asyncio technically supports memoryview as well, we should test that.
@pytest.mark.parametrize(
    argnames="data",
    argvalues=[b"", bytearray(b""), memoryview(b"")],
    ids=["bytes", "bytearray", "memoryview"],
)
def test_ping_frame(
    out: WebSocketDataQueue,
    parser: PatchableWebSocketReader,
    data: bytes | bytearray | memoryview,
) -> None:
    parser._handle_frame(True, WSMsgType.PING, b"data", 0)
    res = out._buffer[0]
    assert res == ((WSMsgType.PING, b"data", ""), 4)


def test_pong_frame(out: WebSocketDataQueue, parser: PatchableWebSocketReader) -> None:
    parser._handle_frame(True, WSMsgType.PONG, b"data", 0)
    res = out._buffer[0]
    assert res == ((WSMsgType.PONG, b"data", ""), 4)


def test_close_frame(out: WebSocketDataQueue, parser: PatchableWebSocketReader) -> None:
    parser._handle_frame(True, WSMsgType.CLOSE, b"", 0)
    res = out._buffer[0]
    assert res == ((WSMsgType.CLOSE, 0, ""), 0)


def test_close_frame_info(
    out: WebSocketDataQueue, parser: PatchableWebSocketReader
) -> None:
    parser._handle_frame(True, WSMsgType.CLOSE, b"0112345", 0)
    res = out._buffer[0]
    assert res == (WSMessage(WSMsgType.CLOSE, 12337, "12345"), 0)


def test_close_frame_invalid(
    out: WebSocketDataQueue, parser: PatchableWebSocketReader
) -> None:
    with pytest.raises(WebSocketError) as ctx:
        parser._handle_frame(True, WSMsgType.CLOSE, b"1", 0)
    assert ctx.value.code == WSCloseCode.PROTOCOL_ERROR


def test_close_frame_invalid_2(
    out: WebSocketDataQueue, parser: PatchableWebSocketReader
) -> None:
    data = build_close_frame(code=1)

    with pytest.raises(WebSocketError) as ctx:
        parser._feed_data(data)

    assert ctx.value.code == WSCloseCode.PROTOCOL_ERROR


def test_close_frame_unicode_err(parser: PatchableWebSocketReader) -> None:
    data = build_close_frame(code=1000, message=b"\xf4\x90\x80\x80")

    with pytest.raises(WebSocketError) as ctx:
        parser._feed_data(data)

    assert ctx.value.code == WSCloseCode.INVALID_TEXT


def test_unknown_frame(
    out: WebSocketDataQueue, parser: PatchableWebSocketReader
) -> None:
    with pytest.raises(WebSocketError):
        parser._handle_frame(True, WSMsgType.CONTINUATION, b"", 0)


def test_simple_text(out: WebSocketDataQueue, parser: PatchableWebSocketReader) -> None:
    data = build_frame(b"text", WSMsgType.TEXT)
    parser._feed_data(data)
    res = out._buffer[0]
    assert res == ((WSMsgType.TEXT, "text", ""), 4)


def test_simple_text_unicode_err(parser: PatchableWebSocketReader) -> None:
    data = build_frame(b"\xf4\x90\x80\x80", WSMsgType.TEXT)

    with pytest.raises(WebSocketError) as ctx:
        parser._feed_data(data)

    assert ctx.value.code == WSCloseCode.INVALID_TEXT


def test_simple_binary(
    out: WebSocketDataQueue, parser: PatchableWebSocketReader
) -> None:
    data = build_frame(b"binary", WSMsgType.BINARY)
    parser._feed_data(data)
    res = out._buffer[0]
    assert res == ((WSMsgType.BINARY, b"binary", ""), 6)


def test_one_byte_at_a_time(
    out: WebSocketDataQueue, parser: PatchableWebSocketReader
) -> None:
    """Send one byte at a time to the parser."""
    data = build_frame(b"binary", WSMsgType.BINARY)
    for i in range(len(data)):
        parser._feed_data(data[i : i + 1])
    res = out._buffer[0]
    assert res == ((WSMsgType.BINARY, b"binary", ""), 6)


def test_fragmentation_header(
    out: WebSocketDataQueue, parser: PatchableWebSocketReader
) -> None:
    data = build_frame(b"a", WSMsgType.TEXT)
    parser._feed_data(data[:1])
    parser._feed_data(data[1:])

    res = out._buffer[0]
    assert res == (WSMessage(WSMsgType.TEXT, "a", ""), 1)


def test_large_message(
    out: WebSocketDataQueue, parser: PatchableWebSocketReader
) -> None:
    large_payload = b"b" * 131072
    data = build_frame(large_payload, WSMsgType.BINARY)
    parser._feed_data(data)

    res = out._buffer[0]
    assert res == ((WSMsgType.BINARY, large_payload, ""), 131072)


def test_large_masked_message(
    out: WebSocketDataQueue, parser: PatchableWebSocketReader
) -> None:
    large_payload = b"b" * 131072
    data = build_frame(large_payload, WSMsgType.BINARY, use_mask=True)
    parser._feed_data(data)

    res = out._buffer[0]
    assert res == ((WSMsgType.BINARY, large_payload, ""), 131072)


def test_fragmented_masked_message(
    out: WebSocketDataQueue, parser: PatchableWebSocketReader
) -> None:
    large_payload = b"b" * 100
    data = build_frame(large_payload, WSMsgType.BINARY, use_mask=True)
    for i in range(len(data)):
        parser._feed_data(data[i : i + 1])

    res = out._buffer[0]
    assert res == ((WSMsgType.BINARY, large_payload, ""), 100)


def test_large_fragmented_masked_message(
    out: WebSocketDataQueue, parser: PatchableWebSocketReader
) -> None:
    large_payload = b"b" * 131072
    data = build_frame(large_payload, WSMsgType.BINARY, use_mask=True)
    for i in range(0, len(data), 16384):
        parser._feed_data(data[i : i + 16384])
    res = out._buffer[0]
    assert res == ((WSMsgType.BINARY, large_payload, ""), 131072)


def test_continuation(
    out: WebSocketDataQueue, parser: PatchableWebSocketReader
) -> None:
    data1 = build_frame(b"line1", WSMsgType.TEXT, is_fin=False)
    parser._feed_data(data1)

    data2 = build_frame(b"line2", WSMsgType.CONTINUATION)
    parser._feed_data(data2)

    res = out._buffer[0]
    assert res == (WSMessage(WSMsgType.TEXT, "line1line2", ""), 10)


def test_continuation_with_ping(
    out: WebSocketDataQueue, parser: PatchableWebSocketReader
) -> None:
    data1 = build_frame(b"line1", WSMsgType.TEXT, is_fin=False)
    parser._feed_data(data1)

    data2 = build_frame(b"", WSMsgType.PING)
    parser._feed_data(data2)

    data3 = build_frame(b"line2", WSMsgType.CONTINUATION)
    parser._feed_data(data3)

    res = out._buffer[0]
    assert res == (WSMessage(WSMsgType.PING, b"", ""), 0)
    res = out._buffer[1]
    assert res == (WSMessage(WSMsgType.TEXT, "line1line2", ""), 10)


def test_continuation_err(
    out: WebSocketDataQueue, parser: PatchableWebSocketReader
) -> None:
    parser._handle_frame(False, WSMsgType.TEXT, b"line1", 0)
    with pytest.raises(WebSocketError):
        parser._handle_frame(True, WSMsgType.TEXT, b"line2", 0)


def test_continuation_non_fin_err(
    out: WebSocketDataQueue, parser: PatchableWebSocketReader
) -> None:
    # https://datatracker.ietf.org/doc/html/rfc6455#section-5.4
    parser._handle_frame(False, WSMsgType.TEXT, b"line1", 0)
    with pytest.raises(WebSocketError) as ctx:
        parser._handle_frame(False, WSMsgType.TEXT, b"line2", 0)
    assert ctx.value.code == WSCloseCode.PROTOCOL_ERROR


def test_continuation_with_close(
    out: WebSocketDataQueue, parser: WebSocketReader
) -> None:
    parser._handle_frame(False, WSMsgType.TEXT, b"line1", 0)
    parser._handle_frame(
        False,
        WSMsgType.CLOSE,
        build_close_frame(1002, b"test", noheader=True),
        False,
    )
    parser._handle_frame(True, WSMsgType.CONTINUATION, b"line2", 0)
    res = out._buffer[0]
    assert res == (WSMessage(WSMsgType.CLOSE, 1002, "test"), 0)
    res = out._buffer[1]
    assert res == (WSMessage(WSMsgType.TEXT, "line1line2", ""), 10)


def test_continuation_with_close_unicode_err(
    out: WebSocketDataQueue, parser: PatchableWebSocketReader
) -> None:
    parser._handle_frame(False, WSMsgType.TEXT, b"line1", 0)
    with pytest.raises(WebSocketError) as ctx:
        parser._handle_frame(
            False,
            WSMsgType.CLOSE,
            build_close_frame(1000, b"\xf4\x90\x80\x80", noheader=True),
            0,
        )
    parser._handle_frame(True, WSMsgType.CONTINUATION, b"line2", 0)
    assert ctx.value.code == WSCloseCode.INVALID_TEXT


def test_continuation_with_close_bad_code(
    out: WebSocketDataQueue, parser: PatchableWebSocketReader
) -> None:
    parser._handle_frame(False, WSMsgType.TEXT, b"line1", 0)
    with pytest.raises(WebSocketError) as ctx:

        parser._handle_frame(
            False, WSMsgType.CLOSE, build_close_frame(1, b"test", noheader=True), 0
        )
    assert ctx.value.code == WSCloseCode.PROTOCOL_ERROR
    parser._handle_frame(True, WSMsgType.CONTINUATION, b"line2", 0)


def test_continuation_with_close_bad_payload(
    out: WebSocketDataQueue, parser: PatchableWebSocketReader
) -> None:
    parser._handle_frame(False, WSMsgType.TEXT, b"line1", 0)
    with pytest.raises(WebSocketError) as ctx:
        parser._handle_frame(False, WSMsgType.CLOSE, b"1", 0)
    assert ctx.value.code == WSCloseCode.PROTOCOL_ERROR
    parser._handle_frame(True, WSMsgType.CONTINUATION, b"line2", 0)


def test_continuation_with_close_empty(
    out: WebSocketDataQueue, parser: PatchableWebSocketReader
) -> None:
    parser._handle_frame(False, WSMsgType.TEXT, b"line1", 0)
    parser._handle_frame(False, WSMsgType.CLOSE, b"", 0)
    parser._handle_frame(True, WSMsgType.CONTINUATION, b"line2", 0)

    res = out._buffer[0]
    assert res == (WSMessage(WSMsgType.CLOSE, 0, ""), 0)
    res = out._buffer[1]
    assert res == (WSMessage(WSMsgType.TEXT, "line1line2", ""), 10)


websocket_mask_data = b"some very long data for masking by websocket"
websocket_mask_mask = b"1234"
websocket_mask_masked = (
    b"B]^Q\x11DVFH\x12_[_U\x13PPFR\x14W]A\x14\\S@_X\\T\x14SK\x13CTP@[RYV@"
)


def test_websocket_mask_python() -> None:
    message = bytearray(websocket_mask_data)
    _websocket_helpers._websocket_mask_python(websocket_mask_mask, message)
    assert message == websocket_mask_masked


@pytest.mark.skipif(
    not hasattr(_websocket_helpers, "_websocket_mask_cython"), reason="Requires Cython"
)
def test_websocket_mask_cython() -> None:
    message = bytearray(websocket_mask_data)
    _websocket_helpers._websocket_mask_cython(websocket_mask_mask, message)  # type: ignore[attr-defined]
    assert message == websocket_mask_masked
    assert (
        _websocket_helpers.websocket_mask is _websocket_helpers._websocket_mask_cython  # type: ignore[attr-defined]
    )


def test_websocket_mask_python_empty() -> None:
    message = bytearray()
    _websocket_helpers._websocket_mask_python(websocket_mask_mask, message)
    assert message == bytearray()


@pytest.mark.skipif(
    not hasattr(_websocket_helpers, "_websocket_mask_cython"), reason="Requires Cython"
)
def test_websocket_mask_cython_empty() -> None:
    message = bytearray()
    _websocket_helpers._websocket_mask_cython(websocket_mask_mask, message)  # type: ignore[attr-defined]
    assert message == bytearray()


def test_msgtype_aliases() -> None:
    assert aiohttp.WSMsgType.TEXT == aiohttp.WSMsgType.text
    assert aiohttp.WSMsgType.BINARY == aiohttp.WSMsgType.binary
    assert aiohttp.WSMsgType.PING == aiohttp.WSMsgType.ping
    assert aiohttp.WSMsgType.PONG == aiohttp.WSMsgType.pong
    assert aiohttp.WSMsgType.CLOSE == aiohttp.WSMsgType.close
    assert aiohttp.WSMsgType.CLOSED == aiohttp.WSMsgType.closed
    assert aiohttp.WSMsgType.ERROR == aiohttp.WSMsgType.error


def test_parse_compress_frame_single(parser: PatchableWebSocketReader) -> None:
    parser.parse_frame(struct.pack("!BB", 0b11000001, 0b00000001))
    res = parser.parse_frame(b"1")
    fin, opcode, payload, compress = res[0]

    assert (1, 1, b"1", True) == (fin, opcode, payload, not not compress)


def test_parse_compress_frame_multi(parser: PatchableWebSocketReader) -> None:
    parser.parse_frame(struct.pack("!BB", 0b01000001, 126))
    parser.parse_frame(struct.pack("!H", 4))
    res = parser.parse_frame(b"1234")
    fin, opcode, payload, compress = res[0]
    assert (0, 1, b"1234", True) == (fin, opcode, payload, not not compress)

    parser.parse_frame(struct.pack("!BB", 0b10000001, 126))
    parser.parse_frame(struct.pack("!H", 4))
    res = parser.parse_frame(b"1234")
    fin, opcode, payload, compress = res[0]
    assert (1, 1, b"1234", True) == (fin, opcode, payload, not not compress)

    parser.parse_frame(struct.pack("!BB", 0b10000001, 126))
    parser.parse_frame(struct.pack("!H", 4))
    res = parser.parse_frame(b"1234")
    fin, opcode, payload, compress = res[0]
    assert (1, 1, b"1234", False) == (fin, opcode, payload, not not compress)


@pytest.mark.parametrize("ping_rsv1", (0x00, 0x40), ids=("rsv1 clear", "rsv1 set"))
def test_compressed_continuation_with_ping(
    out: WebSocketDataQueue, parser: PatchableWebSocketReader, ping_rsv1: int
) -> None:
    # A control frame may be interleaved between the fragments of a data
    # message. The continuation must still be decompressed, and RSV1 on
    # the control frame must not disturb that.
    # https://datatracker.ietf.org/doc/html/rfc6455#section-5.4
    message = b"hello compressed world " * 4
    compressobj = ZLibBackend.compressobj(wbits=-9)
    compressed = compressobj.compress(message)
    compressed += compressobj.flush(ZLibBackend.Z_SYNC_FLUSH)
    assert compressed.endswith(WS_DEFLATE_TRAILING)
    compressed = compressed[:-4]
    half = len(compressed) // 2

    # first fragment: compressed binary, RSV1 set, not final
    parser.feed_data(PACK_LEN1(0x40 | WSMsgType.BINARY, half) + compressed[:half])
    # interleaved ping
    parser.feed_data(PACK_LEN1(0x80 | ping_rsv1 | WSMsgType.PING, 0))
    # final continuation fragment
    parser.feed_data(
        PACK_LEN1(0x80 | WSMsgType.CONTINUATION, len(compressed) - half)
        + compressed[half:]
    )

    assert out._buffer[0] == (WSMessage(WSMsgType.PING, b"", ""), 0)
    assert out._buffer[1] == (WSMessage(WSMsgType.BINARY, message, ""), len(message))


def test_compressed_frame_after_control_frame(
    out: WebSocketDataQueue, parser: PatchableWebSocketReader
) -> None:
    # A control frame arriving before the first data frame must not
    # latch the per-message compression state.
    # https://github.com/aio-libs/aiohttp/issues/13274
    parser.feed_data(PACK_LEN1(0x80 | WSMsgType.PONG, 0))
    parser.feed_data(build_frame(b"hello", WSMsgType.TEXT, ZLibBackend=ZLibBackend))

    assert out._buffer[0] == (WSMessage(WSMsgType.PONG, b"", ""), 0)
    assert out._buffer[1] == (WSMessage(WSMsgType.TEXT, "hello", ""), 5)


# A complete raw-deflate member: BFINAL set, empty fixed-Huffman block,
# decoding to nothing.
EMPTY_DEFLATE_MEMBER = b"\x03\x00"


@pytest.mark.usefixtures("parametrize_zlib_backend")
def test_compressed_multi_block_message(out: WebSocketDataQueue) -> None:
    """Blocks that leave BFINAL unset stay a single member."""
    reader = WebSocketReader(out, 4 * 1024 * 1024, compress=True, decode_text=True)
    compressobj = zlib.compressobj(wbits=-15)
    payload = b"".join(
        compressobj.compress(b"block %d " % i)
        + compressobj.flush(ZLibBackend.Z_SYNC_FLUSH)
        for i in range(50)
    ).removesuffix(WS_DEFLATE_TRAILING)
    expected = b"".join(b"block %d " % i for i in range(50))

    # FIN | RSV1 (compressed) | BINARY
    error, _ = reader.feed_data(
        PACK_LEN2(0x80 | 0x40 | WSMsgType.BINARY, 126, len(payload)) + payload
    )

    assert error is False
    assert out._buffer[0] == (
        WSMessage(WSMsgType.BINARY, expected, ""),
        len(expected),
    )


@pytest.mark.usefixtures("parametrize_zlib_backend")
def test_compressed_multi_member_message(out: WebSocketDataQueue) -> None:
    """Concatenated BFINAL members decode.

    A block following a BFINAL one starts a fresh deflate member, so this must
    keep working well below the member limit.
    """
    reader = WebSocketReader(out, 4 * 1024 * 1024, compress=True, decode_text=True)
    payload = b""
    for i in range(50):
        compressobj = zlib.compressobj(wbits=-15)
        payload += compressobj.compress(b"part %d " % i) + compressobj.flush()
    expected = b"".join(b"part %d " % i for i in range(50))

    error, _ = reader.feed_data(
        PACK_LEN2(0x80 | 0x40 | WSMsgType.BINARY, 126, len(payload)) + payload
    )

    assert error is False
    assert out._buffer[0] == (
        WSMessage(WSMsgType.BINARY, expected, ""),
        len(expected),
    )


@pytest.mark.usefixtures("parametrize_zlib_backend")
def test_compressed_member_flood_rejected(out: WebSocketDataQueue) -> None:
    """Past the member limit the message is rejected, not decoded.

    The reader hands the whole assembled message to one synchronous
    decompress_sync() call. Empty members produce no output for max_msg_size
    to bound, so must be limited by member count.
    """
    max_msg_size = 262144
    reader = WebSocketReader(out, max_msg_size, compress=True, decode_text=True)
    payload = EMPTY_DEFLATE_MEMBER * (2 * max_msg_size // 256)

    with pytest.raises(WebSocketError) as ctx:
        reader._feed_data(
            PACK_LEN2(0x80 | 0x40 | WSMsgType.BINARY, 126, len(payload)) + payload
        )

    assert ctx.value.code == WSCloseCode.MESSAGE_TOO_BIG


@pytest.mark.parametrize("opcode", (WSMsgType.PING, WSMsgType.PONG, WSMsgType.CLOSE))
def test_control_frame_with_rsv1(
    out: WebSocketDataQueue, parser: PatchableWebSocketReader, opcode: WSMsgType
) -> None:
    # RSV1 on control frames is ignored for interop.
    # https://datatracker.ietf.org/doc/html/rfc7692#section-6.1
    parser._feed_data(PACK_LEN1(0xC0 | opcode, 0))
    parser._feed_data(build_frame(b"hello", WSMsgType.TEXT, ZLibBackend=ZLibBackend))

    assert out._buffer[0][0].type is opcode
    assert out._buffer[1] == (WSMessage(WSMsgType.TEXT, "hello", ""), 5)


@pytest.mark.parametrize("opcode", (WSMsgType.PING, WSMsgType.PONG, WSMsgType.CLOSE))
def test_control_frame_with_rsv1_no_compress(
    out: WebSocketDataQueue, opcode: WSMsgType
) -> None:
    # RSV1 is still rejected when compression was not negotiated.
    parser_no_compress = PatchableWebSocketReader(
        out, 0, compress=False, decode_text=True
    )
    with pytest.raises(WebSocketError) as ctx:
        parser_no_compress._feed_data(PACK_LEN1(0xC0 | opcode, 0))

    assert ctx.value.code == WSCloseCode.PROTOCOL_ERROR


def test_parse_compress_error_frame(parser: PatchableWebSocketReader) -> None:
    parser.parse_frame(struct.pack("!BB", 0b01000001, 0b00000001))
    parser.parse_frame(b"1")

    with pytest.raises(WebSocketError) as ctx:
        parser.parse_frame(struct.pack("!BB", 0b11000001, 0b00000001))
        parser.parse_frame(b"1")

    assert ctx.value.code == WSCloseCode.PROTOCOL_ERROR


@pytest.mark.usefixtures("parametrize_zlib_backend")
async def test_parse_no_compress_frame_single(
    loop: asyncio.AbstractEventLoop, out: WebSocketDataQueue
) -> None:
    parser_no_compress = PatchableWebSocketReader(
        out, 0, compress=False, decode_text=True
    )
    with pytest.raises(WebSocketError) as ctx:
        parser_no_compress.parse_frame(struct.pack("!BB", 0b11000001, 0b00000001))
        parser_no_compress.parse_frame(b"1")

    assert ctx.value.code == WSCloseCode.PROTOCOL_ERROR


def test_msg_too_large(out) -> None:
    parser = WebSocketReader(out, 256, compress=False, decode_text=True)
    data = build_frame(b"text" * 256, WSMsgType.TEXT)
    with pytest.raises(WebSocketError) as ctx:
        parser._feed_data(data)
    assert ctx.value.code == WSCloseCode.MESSAGE_TOO_BIG


def test_msg_too_large_not_fin(out) -> None:
    parser = WebSocketReader(out, 256, compress=False, decode_text=True)
    data = build_frame(b"text" * 256, WSMsgType.TEXT, is_fin=False)
    with pytest.raises(WebSocketError) as ctx:
        parser._feed_data(data)
    assert ctx.value.code == WSCloseCode.MESSAGE_TOO_BIG


def test_compressed_msg_too_large(out) -> None:
    parser = WebSocketReader(out, 256, compress=True, decode_text=True)
    data = build_frame(b"aaa" * 256, WSMsgType.TEXT, ZLibBackend=ZLibBackend)
    with pytest.raises(WebSocketError) as ctx:
        parser._feed_data(data)
    assert ctx.value.code == WSCloseCode.MESSAGE_TOO_BIG


@pytest.mark.parametrize("fin", (0x80, 0x00), ids=("fin", "non-fin"))
def test_msg_too_large_at_header(out: WebSocketDataQueue, fin: int) -> None:
    max_msg_size = 256
    parser = WebSocketReader(out, max_msg_size, compress=False, decode_text=True)

    # Header alone: TEXT, 64-bit length, declares 1 MiB of payload.
    header = PACK_LEN3(fin | WSMsgType.TEXT, 127, 1024 * 1024)
    with pytest.raises(
        WebSocketError, match=r"^Message size 1048576 exceeds limit 256$"
    ) as ctx:
        parser._feed_data(header)
    assert ctx.value.code == WSCloseCode.MESSAGE_TOO_BIG


def test_msg_too_large_across_fragments(out: WebSocketDataQueue) -> None:
    # Individual fragments fit under max_msg_size but accumulate past it.
    max_msg_size = 256
    parser = WebSocketReader(out, max_msg_size, compress=False, decode_text=True)

    first = build_frame(b"a" * 100, WSMsgType.TEXT, is_fin=False)
    parser._feed_data(first)
    middle = build_frame(b"b" * 100, WSMsgType.CONTINUATION, is_fin=False)
    parser._feed_data(middle)

    # Third 100-byte fragment would push the accumulated total to 300.
    last = build_frame(b"c" * 100, WSMsgType.CONTINUATION, is_fin=False)
    with pytest.raises(
        WebSocketError, match=r"^Message size 300 exceeds limit 256$"
    ) as ctx:
        parser._feed_data(last)
    assert ctx.value.code == WSCloseCode.MESSAGE_TOO_BIG


def test_msg_too_large_text_after_non_fin_text(out: WebSocketDataQueue) -> None:
    # Protocol-violating sequence: a fresh TEXT arrives while a fragmented
    # message is still open.
    max_msg_size = 256
    parser = WebSocketReader(out, max_msg_size, compress=False, decode_text=True)

    first = build_frame(b"a" * 200, WSMsgType.TEXT, is_fin=False)
    parser._feed_data(first)

    # Second TEXT header alone announces 100 bytes; 100 + 200 partial = 300.
    second_header = PACK_LEN1(WSMsgType.TEXT, 100)
    with pytest.raises(
        WebSocketError, match=r"^Message size 300 exceeds limit 256$"
    ) as ctx:
        parser._feed_data(second_header)
    assert ctx.value.code == WSCloseCode.MESSAGE_TOO_BIG


def test_msg_too_large_declared_length_near_ssize_t_max(
    out: WebSocketDataQueue,
) -> None:
    # Regression test: the header-time size check compares
    # `payload_bytes_to_read + len(partial)` against max_msg_size. In the
    # compiled Cython reader payload_bytes_to_read is a signed Py_ssize_t C
    # value, and RFC 6455 allows a declared length up to 2**63-1, so a naive
    # addition can wrap around to a negative number and bypass the limit
    # entirely once anything is already buffered in `partial`.
    max_msg_size = 4 * 1024 * 1024
    parser = WebSocketReader(out, max_msg_size, compress=False, decode_text=True)

    # Buffer one byte in `partial` via a non-fin fragment.
    first = build_frame(b"a", WSMsgType.TEXT, is_fin=False)
    parser._feed_data(first)

    # Continuation header alone declares the largest length RFC 6455
    # allows: 2**63-1.
    header = PACK_LEN3(WSMsgType.CONTINUATION, 127, 2**63 - 1)
    with pytest.raises(
        WebSocketError,
        match=rf"^Message size {2**63} exceeds limit {max_msg_size}$",
    ) as ctx:
        parser._feed_data(header)
    assert ctx.value.code == WSCloseCode.MESSAGE_TOO_BIG


@pytest.mark.parametrize(
    "declared",
    (sys.maxsize + 1, 2**64 - 1),
    ids=("ssize_t_max_plus_one", "uint64_max"),
)
@pytest.mark.parametrize(
    "max_msg_size", (4 * 1024 * 1024, 0), ids=("bounded", "unbounded")
)
def test_msg_too_large_declared_length_above_ssize_t_max(
    out: WebSocketDataQueue, max_msg_size: int, declared: int
) -> None:
    # RFC 6455 allows an unsigned 64-bit declared length, which does not fit
    # the signed Py_ssize_t payload_bytes_to_read of the compiled reader:
    # anything above sys.maxsize (2**31-1 on the 32-bit builds) has to be
    # rejected before it is stored there, or storing it raises OverflowError
    # and escapes as an abnormal closure instead of MESSAGE_TOO_BIG. Such a
    # frame can never be buffered, so an unlimited max_msg_size is checked
    # too.
    parser = WebSocketReader(out, max_msg_size, compress=False, decode_text=True)

    header = PACK_LEN3(0x80 | WSMsgType.TEXT, 127, declared)
    with pytest.raises(
        WebSocketError,
        match=rf"^Message size {declared} exceeds limit {max_msg_size or sys.maxsize}$",
    ) as ctx:
        parser._feed_data(header)
    assert ctx.value.code == WSCloseCode.MESSAGE_TOO_BIG


def test_msg_too_large_above_ssize_t_max_reports_buffered_fragments(
    out: WebSocketDataQueue,
) -> None:
    # The reported size adds what is already buffered, so the message reads the
    # same whether the declared length is caught by the Py_ssize_t range check
    # or by the max_msg_size comparison below it.
    max_msg_size = 4 * 1024 * 1024
    parser = WebSocketReader(out, max_msg_size, compress=False, decode_text=True)

    parser._feed_data(build_frame(b"a", WSMsgType.TEXT, is_fin=False))

    header = PACK_LEN3(WSMsgType.CONTINUATION, 127, 2**64 - 1)
    with pytest.raises(
        WebSocketError, match=rf"^Message size {2**64} exceeds limit {max_msg_size}$"
    ) as ctx:
        parser._feed_data(header)
    assert ctx.value.code == WSCloseCode.MESSAGE_TOO_BIG


@pytest.mark.parametrize(
    "opcode",
    (0x3, 0x4, 0x5, 0x6, 0x7, 0xB, 0xC, 0xD, 0xE, 0xF),
    ids=lambda v: f"0x{v:x}",
)
def test_reserved_opcode_rejected_at_header(
    out: WebSocketDataQueue, opcode: int
) -> None:
    # RFC 6455 reserves opcodes 0x3-0x7 (non-control) and 0xB-0xF (control).
    parser = WebSocketReader(out, max_msg_size=256, compress=False, decode_text=True)

    header = PACK_LEN3(0x80 | opcode, 127, 1024 * 1024)
    with pytest.raises(WebSocketError, match=rf"^Unexpected opcode={opcode}$") as ctx:
        parser._feed_data(header)
    assert ctx.value.code == WSCloseCode.PROTOCOL_ERROR


class TestWebSocketError:
    def test_ctor(self) -> None:
        err = WebSocketError(WSCloseCode.PROTOCOL_ERROR, "Something invalid")
        assert err.code == WSCloseCode.PROTOCOL_ERROR
        assert str(err) == "Something invalid"

    def test_pickle(self) -> None:
        err = WebSocketError(WSCloseCode.PROTOCOL_ERROR, "Something invalid")
        err.foo = "bar"
        for proto in range(pickle.HIGHEST_PROTOCOL + 1):
            pickled = pickle.dumps(err, proto)
            err2 = pickle.loads(pickled)
            assert err2.code == WSCloseCode.PROTOCOL_ERROR
            assert str(err2) == "Something invalid"
            assert err2.foo == "bar"


def test_flow_control_binary(
    protocol: BaseProtocol,
    out_low_limit: WebSocketDataQueue,
    parser_low_limit: PatchableWebSocketReader,
) -> None:
    large_payload = b"b" * (1 + 16 * 2)
    large_payload_size = len(large_payload)
    parser_low_limit._handle_frame(True, WSMsgType.BINARY, large_payload, 0)
    res = out_low_limit._buffer[0]
    assert res == (WSMessage(WSMsgType.BINARY, large_payload, ""), large_payload_size)
    assert protocol._reading_paused is True


def test_flow_control_multi_byte_text(
    protocol: BaseProtocol,
    out_low_limit: WebSocketDataQueue,
    parser_low_limit: PatchableWebSocketReader,
) -> None:
    large_payload_text = "𒀁" * (1 + 16 * 2)
    large_payload = large_payload_text.encode("utf-8")
    large_payload_size = len(large_payload)
    parser_low_limit._handle_frame(True, WSMsgType.TEXT, large_payload, 0)
    res = out_low_limit._buffer[0]
    assert res == (
        WSMessage(WSMsgType.TEXT, large_payload_text, ""),
        large_payload_size,
    )
    assert protocol._reading_paused is True


async def test_incomplete_frame_retained_objects_stay_bounded(
    protocol: BaseProtocol,
) -> None:
    """Reads fold into one buffer past the cap, bounding the object count.

    Uses the pure-Python reader so the internals are reachable.
    """
    max_msg_size = 64 * 1024
    loop = asyncio.get_running_loop()
    out = PyWebSocketDataQueue(protocol, 2**16, loop=loop)
    parser = PyWebSocketReader(out, max_msg_size, compress=False, decode_text=False)

    payload_len = 32 * 1024
    parser.feed_data(PACK_LEN2(0x80 | WSMsgType.BINARY, 126, payload_len))

    # Two bytes per read runs past the cap; the list folds and stays bounded.
    for _ in range(payload_len // 2 - 1):
        parser.feed_data(b"xx")
        assert len(parser._payload_fragments) <= parser._max_fragments

    parser.feed_data(b"xx")
    msg = await out.read()
    assert msg.data == b"x" * payload_len
    assert len(parser._payload_fragments) == 0
    assert len(parser._payload_buffer) == 0


def _fold_cap(max_msg_size: int) -> int:
    """The fragment count the reader folds at (single source of truth)."""
    return PyWebSocketReader(
        mock.Mock(), max_msg_size, compress=False, decode_text=False
    )._max_fragments


@pytest.mark.parametrize("mask", [False, True])
async def test_frame_split_across_many_reads_is_delivered_intact(
    protocol: BaseProtocol, mask: bool
) -> None:
    """A frame arriving two bytes per read (past the fold cap) is delivered whole."""
    max_msg_size = 64 * 1024
    loop = asyncio.get_running_loop()
    out = WebSocketDataQueue(protocol, 2**16, loop=loop)
    parser = WebSocketReader(out, max_msg_size, compress=False, decode_text=False)

    payload = bytes(range(256)) * 32  # 8 KiB of varied, distinctive bytes
    frame = build_frame(payload, WSMsgType.BINARY, use_mask=mask)

    # Guard the reads stay past the fold cap even if the cap constants change.
    assert len(frame) // 2 > _fold_cap(max_msg_size)
    chunks = [frame[i : i + 2] for i in range(0, len(frame), 2)]
    for chunk in chunks[:-1]:
        parser.feed_data(chunk)
        assert not out._buffer
        assert protocol._reading_paused is False

    parser.feed_data(chunks[-1])
    msg = await out.read()
    assert msg.data == payload


async def test_consecutive_folded_frames_do_not_bleed(
    protocol: BaseProtocol,
) -> None:
    """Two frames folded on one reader stay independent (buffer detached, not cleared)."""
    max_msg_size = 64 * 1024
    loop = asyncio.get_running_loop()
    out = WebSocketDataQueue(protocol, 2**16, loop=loop)
    parser = WebSocketReader(out, max_msg_size, compress=False, decode_text=False)

    first = bytes(range(256)) * 32  # 8 KiB
    second = bytes(reversed(range(256))) * 24  # 6 KiB, distinct content

    for payload in (first, second):
        frame = build_frame(payload, WSMsgType.BINARY, use_mask=True)
        assert len(frame) // 2 > _fold_cap(max_msg_size)  # reads exceed the cap
        for i in range(0, len(frame), 2):
            parser.feed_data(frame[i : i + 2])
        # .clear() would deliver frame 1 empty; buffer reuse would corrupt frame 2.
        msg = await out.read()
        assert msg.data == payload


async def test_fragmented_message_survives_fold(protocol: BaseProtocol) -> None:
    """A multi-frame message whose frames each fold reassembles correctly.

    A non-final folded frame hands a bytearray to ``self._partial += payload``.
    """
    max_msg_size = 64 * 1024
    loop = asyncio.get_running_loop()
    out = WebSocketDataQueue(protocol, 2**16, loop=loop)
    parser = WebSocketReader(out, max_msg_size, compress=False, decode_text=False)

    first = bytes(range(256)) * 32  # 8 KiB
    second = bytes(reversed(range(256))) * 24  # 6 KiB
    frames = [
        build_frame(first, WSMsgType.BINARY, is_fin=False, use_mask=True),
        build_frame(second, WSMsgType.CONTINUATION, is_fin=True, use_mask=True),
    ]
    for frame in frames:
        assert len(frame) // 2 > _fold_cap(max_msg_size)
        for i in range(0, len(frame), 2):
            parser.feed_data(frame[i : i + 2])

    msg = await out.read()
    assert msg.data == first + second


async def test_compressed_frame_survives_fold(protocol: BaseProtocol) -> None:
    """A PMCE frame folded past the cap still decompresses (folded bytearray path)."""
    max_msg_size = 64 * 1024
    loop = asyncio.get_running_loop()
    out = WebSocketDataQueue(protocol, 2**16, loop=loop)
    parser = WebSocketReader(out, max_msg_size, compress=True, decode_text=False)

    # Incompressible, so the deflated frame stays large enough to fold.
    rng = random.Random(0)
    payload = bytes(rng.getrandbits(8) for _ in range(8 * 1024))
    frame = build_frame(
        payload, WSMsgType.BINARY, ZLibBackend=ZLibBackend, use_mask=True
    )
    assert len(frame) // 2 > _fold_cap(max_msg_size)

    for i in range(0, len(frame), 2):
        parser.feed_data(frame[i : i + 2])
    msg = await out.read()
    assert msg.data == payload


async def test_frame_split_under_cap_uses_list_without_folding(
    protocol: BaseProtocol,
) -> None:
    """A frame under the cap stays in the list, never folds, never pauses."""
    max_msg_size = 64 * 1024
    loop = asyncio.get_running_loop()
    out = PyWebSocketDataQueue(protocol, 2**16, loop=loop)
    parser = PyWebSocketReader(out, max_msg_size, compress=False, decode_text=False)

    payload_len = 32 * 1024
    parser.feed_data(PACK_LEN2(0x80 | WSMsgType.BINARY, 126, payload_len))
    reads = payload_len // 4096
    assert reads < parser._max_fragments  # stays under the cap: no fold
    for _ in range(reads):
        parser.feed_data(b"x" * 4096)
        assert protocol._reading_paused is False
        assert len(parser._payload_buffer) == 0  # never folded

    msg = await out.read()
    assert msg.data == b"x" * payload_len


async def test_max_msg_size_zero_opts_out_of_the_fold(
    protocol: BaseProtocol,
) -> None:
    """max_msg_size=0 disables every limit, including the fold."""
    loop = asyncio.get_running_loop()
    out = PyWebSocketDataQueue(protocol, 2**16, loop=loop)
    parser = PyWebSocketReader(out, 0, compress=False, decode_text=False)
    assert parser._max_fragments == 0

    payload_len = 4096  # well past the 1024 floor
    parser.feed_data(PACK_LEN2(0x80 | WSMsgType.BINARY, 126, payload_len))
    for _ in range(payload_len - 1):
        parser.feed_data(b"x")
    # No fold: every read accumulates in the list, the buffer is untouched.
    assert len(parser._payload_fragments) == payload_len - 1
    assert len(parser._payload_buffer) == 0

    parser.feed_data(b"x")
    msg = await out.read()
    assert msg.data == b"x" * payload_len


def _compressed_burst(payload: bytes, count: int) -> bytes:
    """`count` complete, independently deflated BINARY messages in one read."""
    return (
        build_frame(payload, WSMsgType.BINARY, ZLibBackend=ZLibBackend, use_mask=True)
        * count
    )


async def test_empty_messages_apply_backpressure(protocol: BaseProtocol) -> None:
    # Zero-length messages are not free: each one is a queued object. They used
    # to add nothing to the queue's byte counter, so a peer could stream empty
    # frames forever without the transport ever being paused.
    loop = asyncio.get_running_loop()
    out = WebSocketDataQueue(protocol, 2**16, loop=loop)
    parser = WebSocketReader(out, 4 * 1024 * 1024, compress=False, decode_text=True)

    sent = 10000
    parser.feed_data(build_frame(b"", WSMsgType.TEXT, use_mask=True) * sent)

    assert protocol._reading_paused is True
    assert len(out._buffer) < sent
    # Overshoot is capped at the one message that crossed the mark.
    assert out._size <= out._limit + MSG_SIZE_OVERHEAD


async def test_compressed_burst_stops_at_high_water(protocol: BaseProtocol) -> None:
    # permessage-deflate reaches ~1000:1, so a single read can carry dozens of
    # complete frames that each inflate to max_msg_size. pause_reading() only
    # stops the transport from delivering more data; the parser has to stop
    # too, or the whole read is inflated into the queue in one go.
    loop = asyncio.get_running_loop()
    out = WebSocketDataQueue(protocol, 2**16, loop=loop)
    parser = WebSocketReader(out, 1024 * 1024, compress=True, decode_text=False)

    payload = b"\0" * (512 * 1024)
    burst = _compressed_burst(payload, 32)
    assert len(burst) < 2**16  # the whole burst is one plausible socket read

    parser.feed_data(burst)

    assert protocol._reading_paused is True
    # Overshoot is capped at the one message that crossed the mark, not the
    # 16 MiB the peer asked us to inflate.
    assert len(out._buffer) == 1


async def test_read_arriving_over_high_water_inflates_nothing(
    protocol: BaseProtocol,
) -> None:
    # pause_reading() does not retract a read already in flight (the proactor
    # transport completes its outstanding overlapped read, and a transport
    # without flow control ignores the pause entirely). Such a read must not
    # buy the peer one more inflated message before the parser stops again.
    loop = asyncio.get_running_loop()
    out = WebSocketDataQueue(protocol, 2**16, loop=loop)
    parser = WebSocketReader(out, 1024 * 1024, compress=True, decode_text=False)

    payload = b"\0" * (512 * 1024)
    parser.feed_data(_compressed_burst(payload, 2))
    assert len(out._buffer) == 1

    # Lands while the queue is still over the mark and nothing has drained.
    parser.feed_data(_compressed_burst(payload, 2))
    assert len(out._buffer) == 1

    # All four are still delivered once the application catches up.
    for _ in range(4):
        msg = await asyncio.wait_for(out.read(), 5)
        assert msg.data == payload


async def test_backpressure_does_not_drop_stashed_frames(
    protocol: BaseProtocol,
) -> None:
    # The frames the parser stopped short of must still be delivered as the
    # application drains the queue, with no further socket data to drive it.
    loop = asyncio.get_running_loop()
    out = WebSocketDataQueue(protocol, 2**16, loop=loop)
    parser = WebSocketReader(out, 1024 * 1024, compress=True, decode_text=False)

    payload = b"\0" * (512 * 1024)
    parser.feed_data(_compressed_burst(payload, 32))

    for _ in range(32):
        msg = await asyncio.wait_for(out.read(), 5)
        assert msg.data == payload

    assert not out._buffer
    # feed_data() adds MSG_SIZE_OVERHEAD and _read_from_buffer() subtracts it;
    # _size is an unsigned int under Cython, so if those ever drift the
    # subtraction wraps to ~4G rather than going negative. _size < _limit is
    # then permanently false and the connection wedges silently: the transport
    # is never resumed and the stalled parser is never driven again.
    assert out._size == 0
    assert protocol._reading_paused is False


async def test_drain_resumes_parsing_in_batches(protocol: BaseProtocol) -> None:
    # The parser is re-driven only at the low-water mark. Each resume
    # re-slices the whole unparsed tail, so re-driving on every pop would
    # make draining a burst of tiny messages quadratic in its size.
    loop = asyncio.get_running_loop()
    out = WebSocketDataQueue(protocol, 2**16, loop=loop)
    parser = WebSocketReader(out, 1024 * 1024, compress=False, decode_text=True)

    sent = 8000
    parser.feed_data(build_frame(b"", WSMsgType.TEXT, use_mask=True) * sent)
    stalled = len(out._buffer)
    assert stalled < sent

    # Above the low-water mark a pop must not re-drive the parser.
    await asyncio.wait_for(out.read(), 5)
    assert len(out._buffer) == stalled - 1

    # The pop that reaches the low-water mark refills the queue in one batch.
    low_water_msgs = (out._limit // 2) // MSG_SIZE_OVERHEAD
    for _ in range(stalled - 1 - low_water_msgs):
        await asyncio.wait_for(out.read(), 5)
    assert len(out._buffer) > low_water_msgs
    assert out._size > out._limit


async def test_transport_stays_paused_while_stash_remains(
    protocol: BaseProtocol,
) -> None:
    # Resuming the transport before the stash is exhausted would admit a
    # fresh socket read into the tail for every couple of messages drained,
    # moving the memory bound from the queue into the tail.
    loop = asyncio.get_running_loop()
    out = WebSocketDataQueue(protocol, 2**16, loop=loop)
    parser = WebSocketReader(out, 1024 * 1024, compress=False, decode_text=True)

    sent = 8000
    parser.feed_data(build_frame(b"", WSMsgType.TEXT, use_mask=True) * sent)
    assert protocol._reading_paused is True

    count = 0
    while out._stalled_reader is not None:
        await asyncio.wait_for(out.read(), 5)
        count += 1
        if out._stalled_reader is not None:
            assert protocol._reading_paused is True, f"resumed after {count} pops"
    assert count < sent

    # The pop that exhausted the stash resumed the transport.
    assert protocol._reading_paused is False


async def test_read_ending_on_frame_boundary_does_not_stall(
    protocol: BaseProtocol,
) -> None:
    # A read that crosses the high-water mark but ends exactly on a frame
    # boundary leaves nothing stashed, so the parser must not arm the stall;
    # ordinary backpressure then resumes at the queue limit, not the low-water
    # mark reserved for draining a stash.
    loop = asyncio.get_running_loop()
    out = WebSocketDataQueue(protocol, 1024, loop=loop)
    parser = WebSocketReader(out, 1024 * 1024, compress=False, decode_text=True)

    # 17 empty frames * MSG_SIZE_OVERHEAD crosses out._limit (2048); the whole
    # burst is complete frames, so parsing ends with an empty tail.
    parser.feed_data(build_frame(b"", WSMsgType.TEXT, use_mask=True) * 17)
    assert out._size > out._limit
    assert protocol._reading_paused is True
    assert out._stalled_reader is None, "empty-tail read must not arm the stall"

    # Draining back under the limit resumes well above _limit // 2, so the
    # low-water mark reserved for stashes is not in play.
    await asyncio.wait_for(out.read(), 5)
    await asyncio.wait_for(out.read(), 5)
    assert out._limit // 2 < out._size < out._limit
    assert protocol._reading_paused is False


async def test_backpressure_stash_survives_eof(protocol: BaseProtocol) -> None:
    # A peer that bursts and then disconnects must not lose the tail: at EOF
    # there is no resume to ride on, so draining has to keep driving the parser.
    loop = asyncio.get_running_loop()
    out = WebSocketDataQueue(protocol, 2**16, loop=loop)
    parser = WebSocketReader(out, 1024 * 1024, compress=True, decode_text=False)

    payload = b"\0" * (512 * 1024)
    parser.feed_data(_compressed_burst(payload, 8))
    parser.feed_eof()

    for _ in range(8):
        msg = await asyncio.wait_for(out.read(), 5)
        assert msg.data == payload

    with pytest.raises(EofStream):
        await asyncio.wait_for(out.read(), 5)


async def test_stalled_reader_reference_released_after_drain(
    protocol: BaseProtocol,
) -> None:
    # The queue holds the reader back only while parsing is stalled. Keeping it
    # any longer would leave reader <-> queue as a cycle outliving the
    # connection, reclaimable only by the collector rather than by refcounting.
    loop = asyncio.get_running_loop()
    out = WebSocketDataQueue(protocol, 2**16, loop=loop)
    parser = WebSocketReader(out, 1024 * 1024, compress=True, decode_text=False)

    payload = b"\0" * (512 * 1024)
    parser.feed_data(_compressed_burst(payload, 4))
    stalled = out._stalled_reader
    assert stalled is not None and stalled() is parser

    for _ in range(4):
        await asyncio.wait_for(out.read(), 5)

    assert out._stalled_reader is None


async def test_set_exception_still_delivers_stashed_frames(
    protocol: BaseProtocol,
) -> None:
    # set_exception() is also the transport-died hook (WebSocketResponse._cancel).
    # _read_from_buffer() only raises once the buffer is empty, so complete
    # frames the parser stopped short of must still be delivered first, exactly
    # as they were before the parser learned to stall.
    loop = asyncio.get_running_loop()
    out = WebSocketDataQueue(protocol, DEFAULT_CHUNK_SIZE, loop=loop)
    parser = WebSocketReader(out, 1024 * 1024, compress=False, decode_text=True)

    sent = 8000
    parser.feed_data(build_frame(b"", WSMsgType.TEXT, use_mask=True) * sent)
    stalled = len(out._buffer)
    assert stalled < sent

    out.set_exception(ConnectionResetError())

    for _ in range(sent):
        await asyncio.wait_for(out.read(), 5)
    with pytest.raises(ConnectionResetError):
        await out.read()


async def test_parse_error_abandons_the_stash(protocol: BaseProtocol) -> None:
    # A parse error poisons the reader, so re-driving it from a drain is a
    # no-op and the error surfaces once the buffer is empty.
    loop = asyncio.get_running_loop()
    out = WebSocketDataQueue(protocol, 2**16, loop=loop)
    parser = WebSocketReader(out, 1024 * 1024, compress=True, decode_text=False)

    payload = b"\0" * (512 * 1024)
    # The reserved opcode sits behind the stash, so it is only reached on a
    # drain-driven resume.
    parser.feed_data(
        _compressed_burst(payload, 3) + build_frame(b"", 0x3, use_mask=True)
    )
    stalled = out._stalled_reader
    assert stalled is not None and stalled() is parser

    for _ in range(3):
        await asyncio.wait_for(out.read(), 5)
    with pytest.raises(WebSocketError):
        await asyncio.wait_for(out.read(), 5)


async def test_queue_does_not_keep_stalled_reader_alive(
    protocol: BaseProtocol,
) -> None:
    # The one case feed_eof() cannot clean up: the connection dies while
    # parsing is stalled, then the application drops the response without
    # draining. The queue's link back must be weak or reader <-> queue
    # survives as a cycle that only the collector can reclaim.
    loop = asyncio.get_running_loop()
    out = WebSocketDataQueue(protocol, 2**16, loop=loop)
    parser = WebSocketReader(out, 1024 * 1024, compress=True, decode_text=False)

    parser.feed_data(_compressed_burst(b"\0" * (512 * 1024), 4))
    parser.feed_eof()
    # `parser` deliberately never appears in an assert: pytest's assertion
    # rewriting keeps temporaries for the failure message, and a lingering
    # reference to it would mask the very thing under test.
    stalled = out._stalled_reader
    assert stalled is not None

    ref = weakref.ref(parser)
    del parser, stalled
    # `out` deliberately stays alive across the collection: a strong link back
    # would keep the reader reachable from a live root, so this proves the link
    # is weak rather than merely testing reclamation timing. Collect instead of
    # disabling the gc -- PyPy has no refcounting to reclaim eagerly, and can
    # need more than one pass to clear the weakref.
    for _ in range(3):
        gc.collect()

    assert ref() is None, "queue kept the stalled reader alive"


def _queue_with_collected_reader(
    protocol: BaseProtocol, loop: asyncio.AbstractEventLoop, *, eof: bool
) -> WebSocketDataQueue:
    """A queue whose reader stalled on a burst and was then collected."""
    out = WebSocketDataQueue(protocol, 2**16, loop=loop)
    parser = WebSocketReader(out, 1024 * 1024, compress=True, decode_text=False)
    parser.feed_data(_compressed_burst(b"\0" * (512 * 1024), 4))
    if eof:
        parser.feed_eof()
    del parser
    for _ in range(3):
        gc.collect()
    return out


async def test_collected_stalled_reader_surfaces_contract_error(
    protocol: BaseProtocol, caplog: pytest.LogCaptureFixture
) -> None:
    # Every strong reference to the reader was dropped while it was stalled,
    # so the stash is gone. Whatever was already queued is still delivered,
    # then the contract violation surfaces instead of a silent short stream.
    # It is also logged, for callers that stop reading before the exception.
    loop = asyncio.get_running_loop()
    out = _queue_with_collected_reader(protocol, loop, eof=True)

    for _ in range(len(out._buffer)):
        await asyncio.wait_for(out.read(), 5)
    assert "must hold a strong reference" in caplog.text
    with pytest.raises(RuntimeError, match="must hold a strong reference"):
        await out.read()


async def test_collected_stalled_reader_preserves_existing_exception(
    protocol: BaseProtocol,
) -> None:
    # set_exception() is also the transport-died hook; losing the reader on
    # top of that must not replace the real cause with the contract error.
    loop = asyncio.get_running_loop()
    out = _queue_with_collected_reader(protocol, loop, eof=False)
    out.set_exception(ConnectionResetError())

    for _ in range(len(out._buffer)):
        await asyncio.wait_for(out.read(), 5)
    with pytest.raises(ConnectionResetError):
        await out.read()


async def test_burst_under_high_water_is_parsed_in_one_read(
    protocol: BaseProtocol,
) -> None:
    # Ordinary pipelined traffic that fits under the mark must not be stalled
    # or split across reads by the backpressure check.
    loop = asyncio.get_running_loop()
    out = WebSocketDataQueue(protocol, 2**16, loop=loop)
    parser = WebSocketReader(out, 1024 * 1024, compress=False, decode_text=True)

    parser.feed_data(build_frame(b"hello", WSMsgType.TEXT, use_mask=True) * 50)

    assert len(out._buffer) == 50
    assert protocol._reading_paused is False
