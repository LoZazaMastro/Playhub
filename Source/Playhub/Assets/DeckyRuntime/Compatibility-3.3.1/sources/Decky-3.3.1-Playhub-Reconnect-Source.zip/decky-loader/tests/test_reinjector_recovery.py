"""Fault recovery of the real Decky coroutine, without opening Steam or Decky."""
import ast
import asyncio
from pathlib import Path
import types
import unittest
from unittest.mock import AsyncMock, Mock
from traceback import format_exc

ROOT = Path(__file__).resolve().parents[1]


class Disconnected(ConnectionError):
    pass


def method():
    tree = ast.parse((ROOT / "backend/decky_loader/main.py").read_text(encoding="utf-8"))
    return next(node for node in ast.walk(tree) if isinstance(node, ast.AsyncFunctionDef) and node.name == "loader_reinjector")


class ReinjectorTests(unittest.IsolatedAsyncioTestCase):
    async def run_case(self, failure=None, count=1):
        owner = types.SimpleNamespace(reinject=True, js_ctx_tab=None, inject_javascript=AsyncMock(), handle_crash=AsyncMock())
        tabs = []
        delays = []
        opened = asyncio.Event()
        class Tab:
            def __init__(self, fail): self.fail = fail; self.closed = 0; self.title = "SharedJSContext"
            async def open_websocket(self):
                opened.set()
                if self.fail == "open": raise Disconnected("endpoint replaced")
                if self.fail == "cancel": await asyncio.Future()
            async def enable(self):
                if self.fail == "enable": raise Disconnected("endpoint replaced")
            async def close_websocket(self):
                self.closed += 1
                if self.fail == "cleanup": raise RuntimeError("fixture cleanup")
            async def listen_for_message(self):
                if self.fail in ("listen", "cleanup"): raise Disconnected("endpoint replaced")
                owner.reinject = False
                if False: yield None
            async def has_global_var(self, *args): return False
        async def discover():
            if failure == "discover" and len(tabs) == 0:
                tabs.append(None); raise Disconnected("debugger replacing target")
            tab = Tab(failure if len(tabs) < count else None)
            tabs.append(tab); return tab
        async def backoff(seconds):
            delays.append(seconds); await asyncio.sleep(0)
        namespace = {"get_gamepadui_tab": discover, "client_exceptions": types.SimpleNamespace(
            ClientConnectorError=Disconnected, ServerDisconnectedError=Disconnected), "logger": Mock(),
            "format_exc": format_exc, "sleep": backoff, "wait_for": asyncio.wait_for,
            "CancelledError": asyncio.CancelledError}
        exec(compile(ast.Module(body=[method()], type_ignores=[]), "main.py", "exec"), namespace)
        task = asyncio.create_task(namespace["loader_reinjector"](owner))
        if failure == "cancel":
            await opened.wait(); task.cancel()
            with self.assertRaises(asyncio.CancelledError): await task
        else:
            await asyncio.wait_for(task, 1)
        return owner, [tab for tab in tabs if tab is not None], delays

    async def test_open_race_recovers_without_counting_a_webhelper_crash(self):
        owner, tabs, _ = await self.run_case("open")
        owner.handle_crash.assert_awaited_once()  # Only the final normal disconnect.
        self.assertEqual(len(tabs), 2); self.assertTrue(all(tab.closed == 1 for tab in tabs))
        self.assertIsNone(owner.js_ctx_tab)
        self.assertEqual(owner.inject_javascript.await_count, 1)

    async def test_enable_race_recovers_and_closes_both_tabs(self):
        owner, tabs, _ = await self.run_case("enable")
        self.assertEqual(len(tabs), 2); self.assertTrue(all(tab.closed == 1 for tab in tabs))
        self.assertEqual(owner.inject_javascript.await_count, 1)

    async def test_discovery_race_retries_instead_of_losing_the_worker(self):
        owner, tabs, delays = await self.run_case("discover")
        self.assertEqual(len(tabs), 1); self.assertEqual(owner.inject_javascript.await_count, 1)
        self.assertGreaterEqual(len(delays), 1)

    async def test_injected_disconnect_retains_existing_crash_guard(self):
        owner, tabs, _ = await self.run_case("listen")
        self.assertEqual(len(tabs), 2); self.assertEqual(owner.handle_crash.await_count, 2)

    async def test_failed_close_cannot_kill_reconnect(self):
        owner, tabs, _ = await self.run_case("cleanup")
        self.assertEqual(len(tabs), 2); self.assertEqual(owner.inject_javascript.await_count, 2)

    async def test_cancel_during_handshake_closes_owned_tab_and_does_not_retry(self):
        owner, tabs, delays = await self.run_case("cancel")
        self.assertEqual(len(tabs), 1); self.assertEqual(tabs[0].closed, 1)
        self.assertEqual(delays, []); owner.handle_crash.assert_not_called()

    async def test_repeated_races_have_bounded_backoff(self):
        owner, tabs, delays = await self.run_case("open", 6)
        self.assertEqual(len(tabs), 7)
        self.assertEqual(delays[:6], [.25, .5, 1.0, 2.0, 2.0, 2.0])
        self.assertEqual(owner.inject_javascript.await_count, 1)


if __name__ == "__main__":
    unittest.main()
