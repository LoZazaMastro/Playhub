var GamepadButton;
(function (GamepadButton) {
    GamepadButton[GamepadButton["INVALID"] = 0] = "INVALID";
    GamepadButton[GamepadButton["OK"] = 1] = "OK";
    GamepadButton[GamepadButton["CANCEL"] = 2] = "CANCEL";
    GamepadButton[GamepadButton["SECONDARY"] = 3] = "SECONDARY";
    GamepadButton[GamepadButton["OPTIONS"] = 4] = "OPTIONS";
    GamepadButton[GamepadButton["BUMPER_LEFT"] = 5] = "BUMPER_LEFT";
    GamepadButton[GamepadButton["BUMPER_RIGHT"] = 6] = "BUMPER_RIGHT";
    GamepadButton[GamepadButton["TRIGGER_LEFT"] = 7] = "TRIGGER_LEFT";
    GamepadButton[GamepadButton["TRIGGER_RIGHT"] = 8] = "TRIGGER_RIGHT";
    GamepadButton[GamepadButton["DIR_UP"] = 9] = "DIR_UP";
    GamepadButton[GamepadButton["DIR_DOWN"] = 10] = "DIR_DOWN";
    GamepadButton[GamepadButton["DIR_LEFT"] = 11] = "DIR_LEFT";
    GamepadButton[GamepadButton["DIR_RIGHT"] = 12] = "DIR_RIGHT";
    GamepadButton[GamepadButton["SELECT"] = 13] = "SELECT";
    GamepadButton[GamepadButton["START"] = 14] = "START";
    GamepadButton[GamepadButton["LSTICK_CLICK"] = 15] = "LSTICK_CLICK";
    GamepadButton[GamepadButton["RSTICK_CLICK"] = 16] = "RSTICK_CLICK";
    GamepadButton[GamepadButton["LSTICK_TOUCH"] = 17] = "LSTICK_TOUCH";
    GamepadButton[GamepadButton["RSTICK_TOUCH"] = 18] = "RSTICK_TOUCH";
    GamepadButton[GamepadButton["LPAD_TOUCH"] = 19] = "LPAD_TOUCH";
    GamepadButton[GamepadButton["LPAD_CLICK"] = 20] = "LPAD_CLICK";
    GamepadButton[GamepadButton["RPAD_TOUCH"] = 21] = "RPAD_TOUCH";
    GamepadButton[GamepadButton["RPAD_CLICK"] = 22] = "RPAD_CLICK";
    GamepadButton[GamepadButton["REAR_LEFT_UPPER"] = 23] = "REAR_LEFT_UPPER";
    GamepadButton[GamepadButton["REAR_LEFT_LOWER"] = 24] = "REAR_LEFT_LOWER";
    GamepadButton[GamepadButton["REAR_RIGHT_UPPER"] = 25] = "REAR_RIGHT_UPPER";
    GamepadButton[GamepadButton["REAR_RIGHT_LOWER"] = 26] = "REAR_RIGHT_LOWER";
    GamepadButton[GamepadButton["STEAM_GUIDE"] = 27] = "STEAM_GUIDE";
    GamepadButton[GamepadButton["STEAM_QUICK_MENU"] = 28] = "STEAM_QUICK_MENU";
})(GamepadButton || (GamepadButton = {}));
var EFocusSource;
(function (EFocusSource) {
    EFocusSource[EFocusSource["GAMEPAD"] = 0] = "GAMEPAD";
    EFocusSource[EFocusSource["KEYBOARD"] = 1] = "KEYBOARD";
    EFocusSource[EFocusSource["APPLICATION"] = 2] = "APPLICATION";
    EFocusSource[EFocusSource["BROWSER"] = 3] = "BROWSER";
})(EFocusSource || (EFocusSource = {}));
var NavEntryPositionPreferences;
(function (NavEntryPositionPreferences) {
    NavEntryPositionPreferences[NavEntryPositionPreferences["FIRST"] = 0] = "FIRST";
    NavEntryPositionPreferences[NavEntryPositionPreferences["LAST"] = 1] = "LAST";
    NavEntryPositionPreferences[NavEntryPositionPreferences["MAINTAIN_X"] = 2] = "MAINTAIN_X";
    NavEntryPositionPreferences[NavEntryPositionPreferences["MAINTAIN_Y"] = 3] = "MAINTAIN_Y";
    NavEntryPositionPreferences[NavEntryPositionPreferences["PREFERRED_CHILD"] = 4] = "PREFERRED_CHILD";
})(NavEntryPositionPreferences || (NavEntryPositionPreferences = {}));

export { EFocusSource as E, GamepadButton as G, NavEntryPositionPreferences as N };
//# sourceMappingURL=chunk-C7f0gL0I.js.map
