import { i as useDeckyState, u as useTranslation, k as FaExclamationTriangle, T as TranslationHelper, l as TranslationClass, m as useSetting, h as Store, W as WarnThirdPartyType, n as FaShapes, o as FaExclamation, p as checkForUpdates, q as doUpdate, s as WithSuspense, B as BranchSelect, t as FaLock, v as FaEyeSlash, w as FaBan, x as requestMultiplePluginInstalls, I as InstallType, c as FaDownload, r as requestPluginInstall, a as FaRecycle, y as FaEllipsisH, g as getPluginList, z as getPluginDisplayName, A as enablePlugin, D as DeckyIcon, C as FaPlug, E as FaCode, G as FaFlask } from './chunk-BRlI6dAn.js';
import { T as Toggle, C as Carousel, R as ReorderableList, S as SidebarNavigation } from './chunk-DDBhefN9.js';
import { F as Field, C as ConfirmModal, n as Dropdown, w as showModal, T as TextField, q as Focusable, a7 as updaterFieldClasses, D as DialogButton, a5 as gamepadDialogClasses, G as ProgressBarWithInfo, I as Spinner, h as DialogBody, i as DialogControlsSection, j as DialogControlsSectionHeader, s as showContextMenu, r as Menu, u as MenuItem } from './chunk-sIGTtP5a.js';
import { L as Logger } from './chunk-St9casVY.js';
import { f as findSP } from './chunk-DxhJXJ98.js';
import { N as NavEntryPositionPreferences } from './chunk-C7f0gL0I.js';

const NotificationSettings = () => {
    const { notificationSettings } = useDeckyState();
    const notificationService = DeckyPluginLoader.notificationService;
    const { t } = useTranslation();
    return (SP_JSX.jsxs(SP_JSX.Fragment, { children: [SP_JSX.jsx(Field, { label: t('SettingsGeneralIndex.notifications.decky_updates_label'), children: SP_JSX.jsx(Toggle, { value: notificationSettings.deckyUpdates, onChange: (deckyUpdates) => {
                        notificationService.update({ ...notificationSettings, deckyUpdates });
                    } }) }), SP_JSX.jsx(Field, { label: t('SettingsGeneralIndex.notifications.plugin_updates_label'), children: SP_JSX.jsx(Toggle, { value: notificationSettings.pluginUpdates, onChange: (pluginUpdates) => {
                        notificationService.update({ ...notificationSettings, pluginUpdates });
                    } }) })] }));
};

const WarnThirdParty = ({ seconds = 5, type, onOK, onCancel, closeModal }) => {
    const [waitTimer, setWaitTimer] = SP_REACT.useState(seconds);
    SP_REACT.useEffect(() => {
        // exit early when we reach 0
        if (waitTimer <= 0)
            return;
        // save intervalId to clear the interval when the
        // component re-renders
        const intervalId = setInterval(() => {
            setWaitTimer(waitTimer - 1);
        }, 1000);
        // clear interval on re-render to avoid memory leaks
        return () => clearInterval(intervalId);
        // add waitTimer as a dependency to re-rerun the effect
        // when we update it
    }, [waitTimer]);
    return (SP_JSX.jsx(ConfirmModal, { bOKDisabled: waitTimer > 0, closeModal: closeModal, onOK: async () => {
            await onOK();
        }, onCancel: async () => {
            await onCancel();
        }, strTitle: SP_JSX.jsxs("div", { children: [SP_JSX.jsx(FaExclamationTriangle, {}), SP_JSX.jsx(TranslationHelper, { transClass: TranslationClass.WARN_THIRD_PARTY, transText: "title", warnType: type })] }), strOKButtonText: waitTimer > 0 ? (SP_JSX.jsx("div", { children: SP_JSX.jsx(TranslationHelper, { transClass: TranslationClass.WARN_THIRD_PARTY, transText: "button_processing", i18nArgs: {
                    timer: waitTimer,
                } }) })) : (SP_JSX.jsx("div", { children: SP_JSX.jsx(TranslationHelper, { transClass: TranslationClass.WARN_THIRD_PARTY, transText: "button_idle" }) })), children: SP_JSX.jsx("span", { style: { color: 'red' }, children: SP_JSX.jsx("div", { children: SP_JSX.jsx(TranslationHelper, { transClass: TranslationClass.WARN_THIRD_PARTY, transText: "desc", warnType: type }) }) }) }));
};

const logger = new Logger('StoreSelect');
const StoreSelect = () => {
    const [selectedStore, setSelectedStore] = useSetting('store', Store.Default);
    const [selectedStoreURL, setSelectedStoreURL] = useSetting('store-url', null);
    const [acceptedWarning, setAcceptedWarning] = useSetting('store_select.warn.third_party', false);
    const waitTime = acceptedWarning ? 0 : 5;
    const { t } = useTranslation();
    const tStores = [
        t('StoreSelect.store_channel.default'),
        t('StoreSelect.store_channel.testing'),
        t('StoreSelect.store_channel.custom'),
    ];
    // Returns numerical values from 0 to 2 (with current branch setup as of 8/28/22)
    // 0 being Default, 1 being Testing and 2 being Custom
    return (SP_JSX.jsxs(SP_JSX.Fragment, { children: [SP_JSX.jsx(Field, { label: t('StoreSelect.store_channel.label'), childrenContainerWidth: 'fixed', children: SP_JSX.jsx(Dropdown, { rgOptions: Object.values(Store)
                        .filter((store) => typeof store == 'number')
                        .map((store) => ({
                        label: tStores[store],
                        data: store,
                    })), selectedOption: selectedStore, onChange: async (newVal) => {
                        await setSelectedStore(newVal.data);
                        logger.log('switching stores!');
                    } }) }), selectedStore == Store.Custom &&
                showModal(SP_JSX.jsx(WarnThirdParty, { type: WarnThirdPartyType.REPO, seconds: waitTime, onOK: () => {
                        setAcceptedWarning(true);
                    }, onCancel: () => setSelectedStore(Store.Default) })) && (SP_JSX.jsx(Field, { label: t('StoreSelect.custom_store.label'), indentLevel: 1, description: SP_JSX.jsx(TextField, { label: t('StoreSelect.custom_store.url_label'), value: selectedStoreURL || undefined, onChange: (e) => setSelectedStoreURL(e?.target.value || null) }), icon: SP_JSX.jsx(FaShapes, { style: { display: 'block' } }) }))] }));
};

const InlinePatchNotes = ({ date, title, children, onClick }) => {
    return (SP_JSX.jsxs(Focusable, { className: updaterFieldClasses.PatchNotes, onActivate: onClick, children: [SP_JSX.jsx("div", { className: updaterFieldClasses.PostedTime, children: date }), SP_JSX.jsx("div", { className: updaterFieldClasses.EventDetailTitle, children: title }), SP_JSX.jsx("div", { className: updaterFieldClasses.EventDetailsBody, children: children })] }));
};

const MarkdownRenderer = SP_REACT.lazy(() => import('./chunk-DYsvEvWn.js'));
function PatchNotesModal({ versionInfo, closeModal }) {
    const SP = findSP();
    const { t } = useTranslation();
    return (SP_JSX.jsxs(SP_JSX.Fragment, { children: [SP_JSX.jsx("style", { children: `
.steam-focus {
	outline-offset: 3px;
	outline: 2px solid rgba(255, 255, 255, 0.6);
	animation: pulseOutline 1.2s infinite ease-in-out;
}

@keyframes pulseOutline {
  0% {
    outline: 2px solid rgba(255, 255, 255, 0.6);
  }
  50% {
    outline: 2px solid rgba(255, 255, 255, 1);
  }
  100% {
    outline: 2px solid rgba(255, 255, 255, 0.6);
  }
}` }), SP_JSX.jsx(Focusable, { onCancelButton: closeModal, children: SP_JSX.jsx(Carousel, { fnItemRenderer: (id) => (SP_JSX.jsx(Focusable, { style: {
                            marginTop: '40px',
                            height: 'calc( 100% - 40px )',
                            overflowY: 'scroll',
                            display: 'flex',
                            justifyContent: 'center',
                            margin: '30px',
                            padding: '0 15px',
                            backgroundColor: 'rgba(37, 40, 46, 0.5)',
                        }, children: SP_JSX.jsxs("div", { children: [SP_JSX.jsx("h1", { children: versionInfo?.all?.[id]?.name || 'Invalid Update Name' }), versionInfo?.all?.[id]?.body ? (SP_JSX.jsx(WithSuspense, { children: SP_JSX.jsx(MarkdownRenderer, { onDismiss: closeModal, children: versionInfo.all[id].body }) })) : (t('Updater.no_patch_notes_desc'))] }) })), fnGetId: (id) => id, nNumItems: versionInfo?.all?.length, nHeight: SP.innerHeight - 40, nItemHeight: SP.innerHeight - 40, nItemMarginX: 0, initialColumn: 0, autoFocus: true, fnGetColumnWidth: () => SP.innerWidth - SP.innerWidth * (10 / 100), name: t('Updater.decky_updates') }) })] }));
}
function UpdaterSettings() {
    const { isLoaderUpdating, versionInfo, setVersionInfo } = useDeckyState();
    const [checkingForUpdates, setCheckingForUpdates] = SP_REACT.useState(false);
    const [updateProgress, setUpdateProgress] = SP_REACT.useState(-1);
    const [reloading, setReloading] = SP_REACT.useState(false);
    const { t } = useTranslation();
    SP_REACT.useEffect(() => {
        const a = DeckyBackend.addEventListener('updater/update_download_percentage', (percentage) => {
            setUpdateProgress(percentage);
        });
        const b = DeckyBackend.addEventListener('updater/finish_download', () => {
            setUpdateProgress(0);
            setReloading(true);
        });
        return () => {
            DeckyBackend.removeEventListener('updater/update_download_percentage', a);
            DeckyBackend.removeEventListener('updater/finish_download', b);
        };
    }, []);
    const showPatchNotes = SP_REACT.useCallback(() => {
        showModal(SP_JSX.jsx(PatchNotesModal, { versionInfo: versionInfo }));
    }, [versionInfo]);
    return (SP_JSX.jsxs(SP_JSX.Fragment, { children: [SP_JSX.jsx(Field, { onOptionsActionDescription: versionInfo?.all ? t('Updater.patch_notes_desc') : undefined, onOptionsButton: versionInfo?.all ? showPatchNotes : undefined, label: t('Updater.updates.label'), description: checkingForUpdates || versionInfo?.remote?.tag_name != versionInfo?.current || !versionInfo?.remote ? ('') : (SP_JSX.jsxs("span", { children: [t('Updater.updates.lat_version', { ver: versionInfo?.current }), " "] })), icon: versionInfo?.remote &&
                    versionInfo?.remote?.tag_name != versionInfo?.current && (SP_JSX.jsx(FaExclamation, { color: "var(--gpColor-Yellow)", style: { display: 'block' } })), childrenContainerWidth: 'fixed', children: updateProgress == -1 && !isLoaderUpdating ? (SP_JSX.jsx(DialogButton, { disabled: !versionInfo?.updatable || checkingForUpdates, onClick: !versionInfo?.remote || versionInfo?.remote?.tag_name == versionInfo?.current
                        ? async () => {
                            setCheckingForUpdates(true);
                            const verInfo = await checkForUpdates();
                            setVersionInfo(verInfo);
                            setCheckingForUpdates(false);
                        }
                        : async () => {
                            setUpdateProgress(0);
                            doUpdate();
                        }, children: checkingForUpdates
                        ? t('Updater.updates.checking')
                        : !versionInfo?.remote || versionInfo?.remote?.tag_name == versionInfo?.current
                            ? t('Updater.updates.check_button')
                            : t('Updater.updates.install_button') })) : (SP_JSX.jsxs("div", { id: "decky-hide-left", children: [SP_JSX.jsx("style", { children: `
              #decky-hide-left .${gamepadDialogClasses.FieldLeftColumn} {
                display: none;
              }
              ` }), SP_JSX.jsx(ProgressBarWithInfo, { layout: "inline", bottomSeparator: "none", nProgress: updateProgress, indeterminate: reloading, sOperationText: reloading ? t('Updater.updates.reloading') : t('Updater.updates.updating') })] })) }), versionInfo?.remote && versionInfo?.remote?.tag_name != versionInfo?.current && (SP_JSX.jsx(InlinePatchNotes, { title: versionInfo?.remote.name, date: new Intl.RelativeTimeFormat('en-US', {
                    numeric: 'auto',
                }).format(Math.ceil((new Date(versionInfo.remote.published_at).getTime() - new Date().getTime()) / 86400000), 'day'), onClick: showPatchNotes, children: SP_JSX.jsx(SP_REACT.Suspense, { fallback: SP_JSX.jsx(Spinner, { style: { width: '24', height: '24' } }), children: SP_JSX.jsx(MarkdownRenderer, { children: versionInfo?.remote.body }) }) }))] }));
}

function GeneralSettings({ isDeveloper, setIsDeveloper, }) {
    const { versionInfo, sortPlugins, setSortPlugins } = useDeckyState();
    const [_, setSortPluginsSetting] = useSetting('sortPlugins', false);
    const { t } = useTranslation();
    return (SP_JSX.jsxs(DialogBody, { children: [SP_JSX.jsxs(DialogControlsSection, { children: [SP_JSX.jsx(DialogControlsSectionHeader, { children: t('SettingsGeneralIndex.updates.header') }), SP_JSX.jsx(UpdaterSettings, {})] }), SP_JSX.jsxs(DialogControlsSection, { children: [SP_JSX.jsx(DialogControlsSectionHeader, { children: t('SettingsGeneralIndex.beta.header') }), SP_JSX.jsx(BranchSelect, {}), SP_JSX.jsx(StoreSelect, {})] }), SP_JSX.jsxs(DialogControlsSection, { children: [SP_JSX.jsx(DialogControlsSectionHeader, { children: t('SettingsGeneralIndex.notifications.header') }), SP_JSX.jsx(NotificationSettings, {})] }), SP_JSX.jsxs(DialogControlsSection, { children: [SP_JSX.jsx(DialogControlsSectionHeader, { children: t('SettingsGeneralIndex.other.header') }), SP_JSX.jsx(Field, { label: t('SettingsGeneralIndex.developer_mode.label'), children: SP_JSX.jsx(Toggle, { value: isDeveloper, onChange: (toggleValue) => {
                                setIsDeveloper(toggleValue);
                            } }) }), SP_JSX.jsx(Field, { label: t('SettingsGeneralIndex.sort_plugins.label'), children: SP_JSX.jsx(Toggle, { value: sortPlugins, onChange: (toggleValue) => {
                                setSortPlugins(toggleValue);
                                setSortPluginsSetting(toggleValue);
                            } }) })] }), SP_JSX.jsxs(DialogControlsSection, { children: [SP_JSX.jsx(DialogControlsSectionHeader, { children: t('SettingsGeneralIndex.about.header') }), SP_JSX.jsx(Field, { label: t('SettingsGeneralIndex.about.decky_version'), focusable: true, children: SP_JSX.jsxs("div", { style: { color: 'var(--gpSystemLighterGrey)' }, children: [versionInfo?.current, " (", versionInfo?.repo, "#", versionInfo?.gitBranch, ")"] }) })] })] }));
}

const PluginListLabel = ({ name, frozen, hidden, version, disabled }) => {
    const { t } = useTranslation();
    return (SP_JSX.jsxs("div", { style: { display: 'flex', flexDirection: 'column', gap: '6px' }, children: [SP_JSX.jsxs("div", { children: [name, version && (SP_JSX.jsxs(SP_JSX.Fragment, { children: [' - ', SP_JSX.jsxs("span", { style: { color: frozen ? '#67707b' : 'inherit' }, children: [frozen && (SP_JSX.jsxs(SP_JSX.Fragment, { children: [SP_JSX.jsx(FaLock, {}), ' '] })), version] })] }))] }), hidden && (SP_JSX.jsxs("div", { style: {
                    fontSize: '0.8rem',
                    color: '#dcdedf',
                    display: 'flex',
                    alignItems: 'center',
                    gap: '10px',
                }, children: [SP_JSX.jsx(FaEyeSlash, {}), t('PluginListLabel.hidden')] })), disabled && (SP_JSX.jsxs("div", { style: {
                    fontSize: '0.8rem',
                    color: '#dcdedf',
                    display: 'flex',
                    alignItems: 'center',
                    gap: '10px',
                }, children: [SP_JSX.jsx(FaBan, {}), t('PluginListLabel.disabled')] }))] }));
};

async function reinstallPlugin(pluginName, currentVersion) {
    const serverData = await getPluginList();
    const remotePlugin = serverData?.find((x) => x.name == pluginName);
    if (remotePlugin && remotePlugin.versions?.length > 0) {
        const currentVersionData = remotePlugin.versions.find((version) => version.name == currentVersion);
        if (currentVersionData)
            requestPluginInstall(pluginName, currentVersionData, InstallType.REINSTALL);
    }
}
const reloadPluginBackend = DeckyBackend.callable('loader/reload_plugin');
function PluginInteractables(props) {
    const { t } = useTranslation();
    // nothing to display without this data...
    if (!props.entry.data) {
        return null;
    }
    const { name, update, version, onHide, onShow, hidden, onFreeze, onUnfreeze, frozen, isDeveloper, disabled } = props.entry.data;
    const showCtxMenu = (e) => {
        showContextMenu(SP_JSX.jsxs(Menu, { label: t('PluginListIndex.plugin_actions'), children: [!disabled && (SP_JSX.jsx(MenuItem, { onSelected: async () => {
                        try {
                            await reloadPluginBackend(name);
                        }
                        catch (err) {
                            console.error(`Error Reloading Plugin Backend for ${getPluginDisplayName(name, version)}`, err);
                        }
                    }, children: t('PluginListIndex.reload') })), SP_JSX.jsx(MenuItem, { onSelected: () => DeckyPluginLoader.uninstallPlugin(name, t('PluginLoader.plugin_uninstall.title', { name }), t('PluginLoader.plugin_uninstall.button'), t('PluginLoader.plugin_uninstall.desc', { name })), children: t('PluginListIndex.uninstall') }), disabled ? (SP_JSX.jsx(MenuItem, { onSelected: () => enablePlugin(name), children: t('PluginListIndex.enable') })) : (SP_JSX.jsx(MenuItem, { onSelected: () => DeckyPluginLoader.disablePlugin(name, t('PluginLoader.plugin_disable.title', { name }), t('PluginLoader.plugin_disable.button'), t('PluginLoader.plugin_disable.desc', { name })), children: t('PluginListIndex.disable') })), !disabled &&
                    (hidden ? (SP_JSX.jsx(MenuItem, { onSelected: onShow, children: t('PluginListIndex.show') })) : (SP_JSX.jsx(MenuItem, { onSelected: onHide, children: t('PluginListIndex.hide') }))), frozen ? (SP_JSX.jsx(MenuItem, { onSelected: onUnfreeze, children: t('PluginListIndex.unfreeze') })) : (isDeveloper && SP_JSX.jsx(MenuItem, { onSelected: onFreeze, children: t('PluginListIndex.freeze') }))] }), e.currentTarget ?? window);
    };
    return (SP_JSX.jsxs(Focusable, { navEntryPreferPosition: NavEntryPositionPreferences.MAINTAIN_X, style: { display: 'flex' }, children: [update ? (SP_JSX.jsx(DialogButton, { style: { height: '40px', minWidth: '60px', marginRight: '10px' }, onClick: () => requestPluginInstall(name, update, InstallType.UPDATE), onOKButton: () => requestPluginInstall(name, update, InstallType.UPDATE), children: SP_JSX.jsxs("div", { style: { display: 'flex', minWidth: '180px', justifyContent: 'space-between', alignItems: 'center' }, children: [t('PluginListIndex.update_to', { name: update.name }), SP_JSX.jsx(FaDownload, { style: { paddingLeft: '1rem' } })] }) })) : (SP_JSX.jsx(DialogButton, { style: { height: '40px', minWidth: '60px', marginRight: '10px' }, onClick: () => reinstallPlugin(name, version), onOKButton: () => reinstallPlugin(name, version), children: SP_JSX.jsxs("div", { style: { display: 'flex', minWidth: '180px', justifyContent: 'space-between', alignItems: 'center' }, children: [t('PluginListIndex.reinstall'), SP_JSX.jsx(FaRecycle, { style: { paddingLeft: '1rem' } })] }) })), SP_JSX.jsx(DialogButton, { style: {
                    height: '40px',
                    width: '40px',
                    padding: '10px 12px',
                    minWidth: '40px',
                    display: 'flex',
                    flexDirection: 'column',
                    justifyContent: 'center',
                }, onClick: showCtxMenu, onOKButton: showCtxMenu, children: SP_JSX.jsx(FaEllipsisH, {}) })] }));
}
function PluginList({ isDeveloper }) {
    const { installedPlugins, disabledPlugins, updates, pluginOrder, setPluginOrder, frozenPlugins, hiddenPlugins, sortPlugins, } = useDeckyState();
    const [_, setPluginOrderSetting] = useSetting('pluginOrder', installedPlugins.map((plugin) => plugin.name));
    const { t } = useTranslation();
    SP_REACT.useEffect(() => {
        DeckyPluginLoader.checkPluginUpdates();
    }, [installedPlugins, frozenPlugins]);
    const [pluginEntries, setPluginEntries] = SP_REACT.useState([]);
    const hiddenPluginsService = DeckyPluginLoader.hiddenPluginsService;
    const frozenPluginsService = DeckyPluginLoader.frozenPluginsService;
    const sortedPlugins = SP_REACT.useMemo(() => {
        return sortPlugins
            ? [...installedPlugins].sort((a, b) => a.name.localeCompare(b.name, undefined, { sensitivity: 'base' }))
            : installedPlugins;
    }, [installedPlugins, sortPlugins]);
    SP_REACT.useEffect(() => {
        setPluginEntries(installedPlugins.map(({ name, version }) => {
            const frozen = frozenPlugins.includes(name);
            const hidden = hiddenPlugins.includes(name);
            return {
                label: (SP_JSX.jsx(PluginListLabel, { name: name, frozen: frozen, hidden: hidden, version: version, disabled: disabledPlugins.find((p) => p.name == name) !== undefined })),
                position: sortPlugins ? sortedPlugins.findIndex((p) => p.name === name) : pluginOrder.indexOf(name),
                data: {
                    name,
                    disabled: disabledPlugins.some((disabledPlugin) => disabledPlugin.name === name),
                    frozen,
                    hidden,
                    isDeveloper,
                    version,
                    update: updates?.get(name),
                    onFreeze: () => frozenPluginsService.update([...frozenPlugins, name]),
                    onUnfreeze: () => frozenPluginsService.update(frozenPlugins.filter((pluginName) => name !== pluginName)),
                    onHide: () => hiddenPluginsService.update([...hiddenPlugins, name]),
                    onShow: () => hiddenPluginsService.update(hiddenPlugins.filter((pluginName) => name !== pluginName)),
                },
            };
        }));
    }, [installedPlugins, updates, hiddenPlugins, disabledPlugins, sortPlugins, sortedPlugins]);
    if (installedPlugins.length === 0) {
        return (SP_JSX.jsx("div", { children: SP_JSX.jsx("p", { children: t('PluginListIndex.no_plugin') }) }));
    }
    function onSave(entries) {
        if (sortPlugins) {
            return;
        }
        const newOrder = entries.map((entry) => entry.data.name);
        console.log(newOrder);
        setPluginOrder(newOrder);
        setPluginOrderSetting(newOrder);
    }
    return (SP_JSX.jsxs(DialogBody, { children: [updates && updates.size > 0 && (SP_JSX.jsxs(DialogButton, { onClick: () => requestMultiplePluginInstalls([...updates.entries()].map(([plugin, selectedVer]) => ({
                    installType: InstallType.UPDATE,
                    plugin,
                    selectedVer,
                }))), style: {
                    position: 'absolute',
                    top: '57px',
                    right: '2.8vw',
                    width: 'auto',
                    display: 'flex',
                    alignItems: 'center',
                }, children: [t('PluginListIndex.update_all', { count: updates.size }), SP_JSX.jsx(FaDownload, { style: { paddingLeft: '1rem' } })] })), SP_JSX.jsx(DialogControlsSection, { style: { marginTop: 0 }, children: SP_JSX.jsx(ReorderableList, { entries: pluginEntries, onSave: onSave, interactables: PluginInteractables, disableReordering: sortPlugins }) })] }));
}

const DeveloperSettings = SP_REACT.lazy(() => import('./chunk-C--ZC6oZ.js'));
const TestingMenu = SP_REACT.lazy(() => import('./chunk-DkB-DI94.js'));
function SettingsPage() {
    const [isDeveloper, setIsDeveloper] = useSetting('developer.enabled', false);
    const { t } = useTranslation();
    const pages = [
        {
            title: t('SettingsIndex.general_title'),
            content: SP_JSX.jsx(GeneralSettings, { isDeveloper: isDeveloper, setIsDeveloper: setIsDeveloper }),
            route: '/decky/settings/general',
            icon: SP_JSX.jsx(DeckyIcon, {}),
        },
        {
            title: t('SettingsIndex.plugins_title'),
            content: SP_JSX.jsx(PluginList, { isDeveloper: isDeveloper }),
            route: '/decky/settings/plugins',
            icon: SP_JSX.jsx(FaPlug, {}),
        },
        {
            title: t('SettingsIndex.developer_title'),
            content: (SP_JSX.jsx(WithSuspense, { children: SP_JSX.jsx(DeveloperSettings, {}) })),
            route: '/decky/settings/developer',
            icon: SP_JSX.jsx(FaCode, {}),
            visible: isDeveloper,
        },
        {
            title: t('SettingsIndex.testing_title'),
            content: (SP_JSX.jsx(WithSuspense, { children: SP_JSX.jsx(TestingMenu, {}) })),
            route: '/decky/settings/testing',
            icon: SP_JSX.jsx(FaFlask, {}),
            visible: isDeveloper,
        },
    ];
    return SP_JSX.jsx(SidebarNavigation, { pages: pages });
}

var index = /*#__PURE__*/Object.freeze({
    __proto__: null,
    default: SettingsPage
});

export { WarnThirdParty as W, index as i };
//# sourceMappingURL=chunk-CrvrCQZp.js.map
