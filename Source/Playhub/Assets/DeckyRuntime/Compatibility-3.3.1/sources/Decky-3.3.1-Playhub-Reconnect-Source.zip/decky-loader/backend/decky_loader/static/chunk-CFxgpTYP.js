const bgStyle1 = 'background: #16a085; color: black;';
const log = (name, ...args) => {
    console.log(`%c @decky/ui %c ${name} %c`, bgStyle1, 'background: #1abc9c; color: black;', 'background: transparent;', ...args);
};
const group = (name, ...args) => {
    console.group(`%c @decky/ui %c ${name} %c`, bgStyle1, 'background: #1abc9c; color: black;', 'background: transparent;', ...args);
};
const groupEnd = (name, ...args) => {
    console.groupEnd();
    if (args?.length > 0)
        console.log(`^ %c @decky/ui %c ${name} %c`, bgStyle1, 'background: #1abc9c; color: black;', 'background: transparent;', ...args);
};
const debug = (name, ...args) => {
    console.debug(`%c @decky/ui %c ${name} %c`, bgStyle1, 'background: #1abc9c; color: black;', 'color: blue;', ...args);
};
const warn = (name, ...args) => {
    console.warn(`%c @decky/ui %c ${name} %c`, bgStyle1, 'background: #ffbb00; color: black;', 'color: blue;', ...args);
};
const error = (name, ...args) => {
    console.error(`%c @decky/ui %c ${name} %c`, bgStyle1, 'background: #FF0000;', 'background: transparent;', ...args);
};
class Logger {
    constructor(name) {
        this.name = name;
        this.name = name;
    }
    log(...args) {
        log(this.name, ...args);
    }
    debug(...args) {
        debug(this.name, ...args);
    }
    warn(...args) {
        warn(this.name, ...args);
    }
    error(...args) {
        error(this.name, ...args);
    }
    group(...args) {
        group(this.name, ...args);
    }
    groupEnd(...args) {
        groupEnd(this.name, ...args);
    }
}

const logger = new Logger('Webpack');
let modules = new Map();
function initModuleCache() {
    const startTime = performance.now();
    logger.group('Webpack Module Init');
    const id = Symbol("@decky/ui");
    let webpackRequire;
    window.webpackChunksteamui.push([
        [id],
        {},
        (r) => {
            webpackRequire = r;
        },
    ]);
    logger.log('Initializing all modules. Errors here likely do not matter, as they are usually just failing module side effects.');
    for (let id of Object.keys(webpackRequire.m)) {
        try {
            const module = webpackRequire(id);
            if (module) {
                modules.set(id, module);
            }
        }
        catch (e) {
            logger.debug('Ignoring require error for module', id, e);
        }
    }
    logger.groupEnd(`Modules initialized in ${performance.now() - startTime}ms...`);
}
initModuleCache();
const findModule = (filter) => {
    for (const m of modules.values()) {
        if (m.default && filter(m.default))
            return m.default;
        if (filter(m))
            return m;
    }
};
const findModuleDetailsByExport = (filter, minExports) => {
    for (const [id, m] of modules) {
        if (!m)
            continue;
        for (const mod of [m.default, m]) {
            if (typeof mod !== 'object')
                continue;
            if (mod == window)
                continue;
            if (minExports && Object.keys(mod).length < minExports)
                continue;
            for (let exportName in mod) {
                if (mod?.[exportName]) {
                    try {
                        const filterRes = filter(mod[exportName], exportName);
                        if (filterRes) {
                            return [mod, mod[exportName], exportName, id];
                        }
                        else {
                            continue;
                        }
                    }
                    catch (e) {
                        logger.warn("Webpack filter threw exception: ", e, "Filter: ", filter);
                    }
                }
            }
        }
    }
    return [undefined, undefined, undefined, undefined];
};
const findModuleByExport = (filter, minExports) => {
    return findModuleDetailsByExport(filter, minExports)?.[0];
};
const findModuleExport = (filter, minExports) => {
    return findModuleDetailsByExport(filter, minExports)?.[1];
};
const findModuleChild = (filter) => {
    logger.warn("findModuleChild is deprecated and will be removed soon. Use findModuleExport instead. Used in:", new Error().stack?.substring(5));
    for (const m of modules.values()) {
        for (const mod of [m.default, m]) {
            const filterRes = filter(mod);
            if (filterRes) {
                return filterRes;
            }
            else {
                continue;
            }
        }
    }
};
const findAllModules = (filter) => {
    logger.warn("findAllModules is deprecated and will be removed soon. Use createModuleMapping instead. Used in:", new Error().stack?.substring(5));
    const out = [];
    for (const m of modules.values()) {
        if (m.default && filter(m.default))
            out.push(m.default);
        if (filter(m))
            out.push(m);
    }
    return out;
};
const createModuleMapping = (filter) => {
    const mapping = new Map();
    for (const [id, m] of modules) {
        if (m.default && filter(m.default))
            mapping.set(id, m.default);
        if (filter(m))
            mapping.set(id, m);
    }
    return mapping;
};
const CommonUIModule = findModule((m) => {
    if (typeof m !== 'object')
        return false;
    for (let prop in m) {
        if (m[prop]?.contextType?._currentValue && Object.keys(m).length > 60)
            return true;
    }
    return false;
});
const IconsModule = findModuleByExport((e) => e?.toString && /Spinner\),children:\[\(0,\w+\.jsx\)\("path",\{d:"M18 /.test(e.toString?.()) || /Spinner\)}\)?,.\.createElement\(\"path\",{d:\"M18 /.test(e.toString?.()));
const ReactRouter = findModuleByExport((e) => e.computeRootMatch);

var webpack = /*#__PURE__*/Object.freeze({
    __proto__: null,
    CommonUIModule: CommonUIModule,
    IconsModule: IconsModule,
    ReactRouter: ReactRouter,
    createModuleMapping: createModuleMapping,
    findAllModules: findAllModules,
    findModule: findModule,
    findModuleByExport: findModuleByExport,
    findModuleChild: findModuleChild,
    findModuleDetailsByExport: findModuleDetailsByExport,
    findModuleExport: findModuleExport,
    modules: modules
});

export { CommonUIModule as C, IconsModule as I, Logger as L, ReactRouter as R, findModuleByExport as a, findModule as b, findModuleDetailsByExport as c, findModuleChild as d, findAllModules as e, findModuleExport as f, createModuleMapping as g, modules as m, webpack as w };
//# sourceMappingURL=chunk-CFxgpTYP.js.map
