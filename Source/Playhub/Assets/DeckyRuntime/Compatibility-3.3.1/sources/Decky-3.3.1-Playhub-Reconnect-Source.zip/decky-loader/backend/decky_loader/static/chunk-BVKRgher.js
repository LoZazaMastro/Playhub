import { T as TranslationHelper, l as TranslationClass, O as FaReact, P as getSetting } from './chunk-BRlI6dAn.js';
import { L as Logger } from './chunk-St9casVY.js';
import { s as sleep } from './chunk-DxhJXJ98.js';
import './chunk-CFxgpTYP.js';
import './chunk-sIGTtP5a.js';

const logger = new Logger('DeveloperMode');
let removeSettingsObserver = () => { };
async function setShowValveInternal(show) {
    if (show) {
        const mobx = window.settingsStore[Object.getOwnPropertySymbols(window.settingsStore).find((x) => x.toString() == 'Symbol(mobx administration)')];
        removeSettingsObserver = (mobx.observe_ || mobx.observe).call(mobx, (e) => {
            e.newValue.bIsValveEmail = true;
        });
        window.settingsStore.m_Settings.bIsValveEmail = true;
        logger.log('Enabled Valve Internal menu');
    }
    else {
        removeSettingsObserver();
        window.settingsStore.m_Settings.bIsValveEmail = false;
        logger.log('Disabled Valve Internal menu');
    }
}
async function setShouldConnectToReactDevTools(enable) {
    DeckyPluginLoader.toaster.toast({
        title: enable ? (SP_JSX.jsx(TranslationHelper, { transClass: TranslationClass.DEVELOPER, transText: 'enabling' })) : (SP_JSX.jsx(TranslationHelper, { transClass: TranslationClass.DEVELOPER, transText: 'disabling' })),
        body: SP_JSX.jsx(TranslationHelper, { transClass: TranslationClass.DEVELOPER, transText: '5secreload' }),
        icon: SP_JSX.jsx(FaReact, {}),
    });
    await sleep(5000);
    return enable ? DeckyBackend.call('utilities/enable_rdt') : DeckyBackend.call('utilities/disable_rdt');
}
async function startup() {
    const isValveInternalEnabled = await getSetting('developer.valve_internal', false);
    const isRDTEnabled = await getSetting('developer.rdt.enabled', false);
    if (isValveInternalEnabled)
        setShowValveInternal(isValveInternalEnabled);
    if ((isRDTEnabled && !window.deckyHasConnectedRDT) || (!isRDTEnabled && window.deckyHasConnectedRDT))
        setShouldConnectToReactDevTools(isRDTEnabled);
}

export { setShouldConnectToReactDevTools, setShowValveInternal, startup };
//# sourceMappingURL=chunk-BVKRgher.js.map
