const log = (name, ...args) => {
    console.log(`%c Decky %c ${name} %c`, 'background: #16a085; color: black;', 'background: #1abc9c; color: black;', 'background: transparent;', ...args);
};
const debug = (name, ...args) => {
    console.debug(`%c Decky %c ${name} %c`, 'background: #16a085; color: black;', 'background: #1abc9c; color: black;', 'color: blue;', ...args);
};
const warn = (name, ...args) => {
    console.warn(`%c Decky %c ${name} %c`, 'background: #16a085; color: black;', 'background: #ffbb00; color: black;', 'color: blue;', ...args);
};
const error = (name, ...args) => {
    console.error(`%c Decky %c ${name} %c`, 'background: #16a085; color: black;', 'background: #FF0000;', 'background: transparent;', ...args);
};
class Logger {
    constructor(name) {
        this.name = name;
        this.name = name;
    }
    log(...args) {
        log(this.name, ...args);
    }
    debug(...args) {
        debug(this.name, ...args);
    }
    warn(...args) {
        warn(this.name, ...args);
    }
    error(...args) {
        error(this.name, ...args);
    }
}

export { Logger as L };
//# sourceMappingURL=chunk-St9casVY.js.map
