import { f as findModuleExport, C as CommonUIModule } from './chunk-CFxgpTYP.js';
import { au as createPropListRegex, q as Focusable, F as Field } from './chunk-sIGTtP5a.js';
import { G as GamepadButton } from './chunk-C7f0gL0I.js';

const Carousel = findModuleExport((e) => e.render?.toString().includes('setFocusedColumn:'));

const sidebarNavigationRegex = createPropListRegex(["pages", "fnSetNavigateToPage", "disableRouteReporting"]);
const SidebarNavigation = findModuleExport((e) => e?.toString && sidebarNavigationRegex.test(e.toString?.()));

const Toggle = Object.values(CommonUIModule).find((mod) => mod?.render?.toString?.()?.includes('.ToggleOff)'));

function ReorderableList(props) {
    if (props.animate === undefined)
        props.animate = true;
    const [entryList, setEntryList] = SP_REACT.useState([...props.entries].sort((a, b) => a.position - b.position));
    const [reorderEnabled, setReorderEnabled] = SP_REACT.useState(false);
    SP_REACT.useEffect(() => {
        setEntryList([...props.entries].sort((a, b) => a.position - b.position));
    }, [props.entries]);
    SP_REACT.useEffect(() => {
        if (props.disableReordering && reorderEnabled) {
            setReorderEnabled(false);
            props.onSave(entryList);
        }
    }, [props.disableReordering, reorderEnabled, entryList]);
    function toggleReorderEnabled() {
        if (props.disableReordering)
            return;
        let newReorderValue = !reorderEnabled;
        setReorderEnabled(newReorderValue);
        if (!newReorderValue) {
            props.onSave(entryList);
        }
    }
    function saveOnBackout(e) {
        const event = e;
        if (event.detail.button == GamepadButton.CANCEL && reorderEnabled) {
            setReorderEnabled(!reorderEnabled);
            props.onSave(entryList);
        }
    }
    return (SP_JSX.jsx(SP_REACT.Fragment, { children: SP_JSX.jsx("div", { style: {
                width: 'inherit',
                height: 'inherit',
                flex: '1 1 1px',
                scrollPadding: '48px 0px',
                display: 'flex',
                flexDirection: 'column',
                justifyContent: 'flex-start',
                alignContent: 'stretch',
            }, children: SP_JSX.jsx(Focusable, { style: { display: 'flex', flexDirection: 'column', gap: '6px' }, onSecondaryButton: props.disableReordering ? undefined : toggleReorderEnabled, onSecondaryActionDescription: props.disableReordering ? undefined : reorderEnabled ? 'Save Order' : 'Reorder', onClick: props.disableReordering ? undefined : toggleReorderEnabled, onButtonDown: saveOnBackout, children: entryList.map((entry) => (SP_JSX.jsx(ReorderableItem, { animate: props.animate, listData: entryList, entryData: entry, reorderEntryFunc: setEntryList, reorderEnabled: reorderEnabled, fieldProps: props.fieldProps, children: props.interactables ? SP_JSX.jsx(props.interactables, { entry: entry }) : null }))) }) }) }));
}
function ReorderableItem(props) {
    const [isSelected, _setIsSelected] = SP_REACT.useState(false);
    const [isSelectedLastFrame, setIsSelectedLastFrame] = SP_REACT.useState(false);
    const listEntries = props.listData;
    function onReorder(e) {
        if (!props.reorderEnabled)
            return;
        const event = e;
        const currentIdx = listEntries.findIndex((entryData) => entryData === props.entryData);
        const currentIdxValue = listEntries[currentIdx];
        if (currentIdx < 0)
            return;
        let targetPosition = -1;
        if (event.detail.button == GamepadButton.DIR_DOWN) {
            targetPosition = currentIdxValue.position + 1;
        }
        else if (event.detail.button == GamepadButton.DIR_UP) {
            targetPosition = currentIdxValue.position - 1;
        }
        if (targetPosition >= listEntries.length || targetPosition < 0)
            return;
        let otherToUpdate = listEntries.find((entryData) => entryData.position === targetPosition);
        if (!otherToUpdate)
            return;
        let currentPosition = currentIdxValue.position;
        currentIdxValue.position = otherToUpdate.position;
        otherToUpdate.position = currentPosition;
        props.reorderEntryFunc([...listEntries].sort((a, b) => a.position - b.position));
    }
    async function setIsSelected(val) {
        _setIsSelected(val);
        for (let i = 0; i < 3; i++)
            await new Promise((res) => requestAnimationFrame(res));
        setIsSelectedLastFrame(val);
    }
    return (SP_JSX.jsx("div", { style: props.animate
            ? {
                transition: isSelected || isSelectedLastFrame
                    ? ''
                    : 'transform 0.3s cubic-bezier(0.25, 1, 0.5, 1), opacity 0.3s cubic-bezier(0.25, 1, 0.5, 1)',
                transform: !props.reorderEnabled || isSelected ? 'scale(1)' : 'scale(0.9)',
                opacity: !props.reorderEnabled || isSelected ? 1 : 0.7,
            }
            : {}, children: SP_JSX.jsx(Field, { label: props.entryData.label, ...props.fieldProps, focusable: !props.children, onButtonDown: onReorder, onGamepadBlur: () => setIsSelected(false), onGamepadFocus: () => setIsSelected(true), children: SP_JSX.jsx(Focusable, { style: { display: 'flex', width: '100%', position: 'relative' }, children: props.children }) }) }));
}

export { Carousel as C, ReorderableList as R, SidebarNavigation as S, Toggle as T };
//# sourceMappingURL=chunk-DDBhefN9.js.map
