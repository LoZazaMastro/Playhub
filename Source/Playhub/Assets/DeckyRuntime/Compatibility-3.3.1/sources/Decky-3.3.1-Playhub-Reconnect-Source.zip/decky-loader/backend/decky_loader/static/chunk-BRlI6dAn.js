import { L as Logger$1 } from './chunk-St9casVY.js';
import { b as findModule, f as findModuleExport, a as findModuleByExport } from './chunk-CFxgpTYP.js';
import { D as DialogButton, s as showContextMenu, r as Menu, M as Marquee, u as MenuItem, m as DialogCheckbox, h as DialogBody, i as DialogControlsSection, q as Focusable, T as TextField, a as ControlsList, K as ToggleField, n as Dropdown, J as SteamSpinner, d as DialogFooter, F as Field, A as ProgressBar, C as ConfirmModal, N as Navigation, Z as QuickAccessTab, I as Spinner, ar as staticClasses, E as ErrorBoundary, P as PanelSection, z as PanelSectionRow, B as ButtonItem, a2 as replacePatch, $ as callOriginal, V as EUIMode, aB as getReactRoot, a1 as afterPatch, aD as findInTree, aE as findInReactTree, aL as createReactTreePatcher, aQ as findClassModule, aI as injectFCTrampoline, Y as ESteamNotificationAction, w as showModal, a3 as quickAccessMenuClasses, x as ModalRoot } from './chunk-sIGTtP5a.js';
import { j as joinClassNames, s as sleep, f as findSP } from './chunk-DxhJXJ98.js';

function _mergeNamespaces(n, m) {
  m.forEach(function (e) {
    e && typeof e !== 'string' && !Array.isArray(e) && Object.keys(e).forEach(function (k) {
      if (k !== 'default' && !(k in n)) {
        var d = Object.getOwnPropertyDescriptor(e, k);
        Object.defineProperty(n, k, d.get ? d : {
          enumerable: true,
          get: function () { return e[k]; }
        });
      }
    });
  });
  return Object.freeze(n);
}

const isString$1 = obj => typeof obj === 'string';
const defer = () => {
  let res;
  let rej;
  const promise = new Promise((resolve, reject) => {
    res = resolve;
    rej = reject;
  });
  promise.resolve = res;
  promise.reject = rej;
  return promise;
};
const makeString = object => {
  if (object == null) return '';
  return '' + object;
};
const copy = (a, s, t) => {
  a.forEach(m => {
    if (s[m]) t[m] = s[m];
  });
};
const lastOfPathSeparatorRegExp = /###/g;
const cleanKey = key => key && key.indexOf('###') > -1 ? key.replace(lastOfPathSeparatorRegExp, '.') : key;
const canNotTraverseDeeper = object => !object || isString$1(object);
const getLastOfPath = (object, path, Empty) => {
  const stack = !isString$1(path) ? path : path.split('.');
  let stackIndex = 0;
  while (stackIndex < stack.length - 1) {
    if (canNotTraverseDeeper(object)) return {};
    const key = cleanKey(stack[stackIndex]);
    if (!object[key] && Empty) object[key] = new Empty();
    if (Object.prototype.hasOwnProperty.call(object, key)) {
      object = object[key];
    } else {
      object = {};
    }
    ++stackIndex;
  }
  if (canNotTraverseDeeper(object)) return {};
  return {
    obj: object,
    k: cleanKey(stack[stackIndex])
  };
};
const setPath = (object, path, newValue) => {
  const {
    obj,
    k
  } = getLastOfPath(object, path, Object);
  if (obj !== undefined || path.length === 1) {
    obj[k] = newValue;
    return;
  }
  let e = path[path.length - 1];
  let p = path.slice(0, path.length - 1);
  let last = getLastOfPath(object, p, Object);
  while (last.obj === undefined && p.length) {
    e = `${p[p.length - 1]}.${e}`;
    p = p.slice(0, p.length - 1);
    last = getLastOfPath(object, p, Object);
    if (last?.obj && typeof last.obj[`${last.k}.${e}`] !== 'undefined') {
      last.obj = undefined;
    }
  }
  last.obj[`${last.k}.${e}`] = newValue;
};
const pushPath = (object, path, newValue, concat) => {
  const {
    obj,
    k
  } = getLastOfPath(object, path, Object);
  obj[k] = obj[k] || [];
  obj[k].push(newValue);
};
const getPath = (object, path) => {
  const {
    obj,
    k
  } = getLastOfPath(object, path);
  if (!obj) return undefined;
  if (!Object.prototype.hasOwnProperty.call(obj, k)) return undefined;
  return obj[k];
};
const getPathWithDefaults = (data, defaultData, key) => {
  const value = getPath(data, key);
  if (value !== undefined) {
    return value;
  }
  return getPath(defaultData, key);
};
const deepExtend = (target, source, overwrite) => {
  for (const prop in source) {
    if (prop !== '__proto__' && prop !== 'constructor') {
      if (prop in target) {
        if (isString$1(target[prop]) || target[prop] instanceof String || isString$1(source[prop]) || source[prop] instanceof String) {
          if (overwrite) target[prop] = source[prop];
        } else {
          deepExtend(target[prop], source[prop], overwrite);
        }
      } else {
        target[prop] = source[prop];
      }
    }
  }
  return target;
};
const regexEscape = str => str.replace(/[\-\[\]\/\{\}\(\)\*\+\?\.\\\^\$\|]/g, '\\$&');
var _entityMap = {
  '&': '&amp;',
  '<': '&lt;',
  '>': '&gt;',
  '"': '&quot;',
  "'": '&#39;',
  '/': '&#x2F;'
};
const escape = data => {
  if (isString$1(data)) {
    return data.replace(/[&<>"'\/]/g, s => _entityMap[s]);
  }
  return data;
};
class RegExpCache {
  constructor(capacity) {
    this.capacity = capacity;
    this.regExpMap = new Map();
    this.regExpQueue = [];
  }
  getRegExp(pattern) {
    const regExpFromCache = this.regExpMap.get(pattern);
    if (regExpFromCache !== undefined) {
      return regExpFromCache;
    }
    const regExpNew = new RegExp(pattern);
    if (this.regExpQueue.length === this.capacity) {
      this.regExpMap.delete(this.regExpQueue.shift());
    }
    this.regExpMap.set(pattern, regExpNew);
    this.regExpQueue.push(pattern);
    return regExpNew;
  }
}
const chars = [' ', ',', '?', '!', ';'];
const looksLikeObjectPathRegExpCache = new RegExpCache(20);
const looksLikeObjectPath = (key, nsSeparator, keySeparator) => {
  nsSeparator = nsSeparator || '';
  keySeparator = keySeparator || '';
  const possibleChars = chars.filter(c => nsSeparator.indexOf(c) < 0 && keySeparator.indexOf(c) < 0);
  if (possibleChars.length === 0) return true;
  const r = looksLikeObjectPathRegExpCache.getRegExp(`(${possibleChars.map(c => c === '?' ? '\\?' : c).join('|')})`);
  let matched = !r.test(key);
  if (!matched) {
    const ki = key.indexOf(keySeparator);
    if (ki > 0 && !r.test(key.substring(0, ki))) {
      matched = true;
    }
  }
  return matched;
};
const deepFind = (obj, path, keySeparator = '.') => {
  if (!obj) return undefined;
  if (obj[path]) {
    if (!Object.prototype.hasOwnProperty.call(obj, path)) return undefined;
    return obj[path];
  }
  const tokens = path.split(keySeparator);
  let current = obj;
  for (let i = 0; i < tokens.length;) {
    if (!current || typeof current !== 'object') {
      return undefined;
    }
    let next;
    let nextPath = '';
    for (let j = i; j < tokens.length; ++j) {
      if (j !== i) {
        nextPath += keySeparator;
      }
      nextPath += tokens[j];
      next = current[nextPath];
      if (next !== undefined) {
        if (['string', 'number', 'boolean'].indexOf(typeof next) > -1 && j < tokens.length - 1) {
          continue;
        }
        i += j - i + 1;
        break;
      }
    }
    current = next;
  }
  return current;
};
const getCleanedCode = code => code?.replace('_', '-');

const consoleLogger = {
  type: 'logger',
  log(args) {
    this.output('log', args);
  },
  warn(args) {
    this.output('warn', args);
  },
  error(args) {
    this.output('error', args);
  },
  output(type, args) {
    console?.[type]?.apply?.(console, args);
  }
};
class Logger {
  constructor(concreteLogger, options = {}) {
    this.init(concreteLogger, options);
  }
  init(concreteLogger, options = {}) {
    this.prefix = options.prefix || 'i18next:';
    this.logger = concreteLogger || consoleLogger;
    this.options = options;
    this.debug = options.debug;
  }
  log(...args) {
    return this.forward(args, 'log', '', true);
  }
  warn(...args) {
    return this.forward(args, 'warn', '', true);
  }
  error(...args) {
    return this.forward(args, 'error', '');
  }
  deprecate(...args) {
    return this.forward(args, 'warn', 'WARNING DEPRECATED: ', true);
  }
  forward(args, lvl, prefix, debugOnly) {
    if (debugOnly && !this.debug) return null;
    if (isString$1(args[0])) args[0] = `${prefix}${this.prefix} ${args[0]}`;
    return this.logger[lvl](args);
  }
  create(moduleName) {
    return new Logger(this.logger, {
      ...{
        prefix: `${this.prefix}:${moduleName}:`
      },
      ...this.options
    });
  }
  clone(options) {
    options = options || this.options;
    options.prefix = options.prefix || this.prefix;
    return new Logger(this.logger, options);
  }
}
var baseLogger = new Logger();

class EventEmitter {
  constructor() {
    this.observers = {};
  }
  on(events, listener) {
    events.split(' ').forEach(event => {
      if (!this.observers[event]) this.observers[event] = new Map();
      const numListeners = this.observers[event].get(listener) || 0;
      this.observers[event].set(listener, numListeners + 1);
    });
    return this;
  }
  off(event, listener) {
    if (!this.observers[event]) return;
    if (!listener) {
      delete this.observers[event];
      return;
    }
    this.observers[event].delete(listener);
  }
  emit(event, ...args) {
    if (this.observers[event]) {
      const cloned = Array.from(this.observers[event].entries());
      cloned.forEach(([observer, numTimesAdded]) => {
        for (let i = 0; i < numTimesAdded; i++) {
          observer(...args);
        }
      });
    }
    if (this.observers['*']) {
      const cloned = Array.from(this.observers['*'].entries());
      cloned.forEach(([observer, numTimesAdded]) => {
        for (let i = 0; i < numTimesAdded; i++) {
          observer.apply(observer, [event, ...args]);
        }
      });
    }
  }
}

class ResourceStore extends EventEmitter {
  constructor(data, options = {
    ns: ['translation'],
    defaultNS: 'translation'
  }) {
    super();
    this.data = data || {};
    this.options = options;
    if (this.options.keySeparator === undefined) {
      this.options.keySeparator = '.';
    }
    if (this.options.ignoreJSONStructure === undefined) {
      this.options.ignoreJSONStructure = true;
    }
  }
  addNamespaces(ns) {
    if (this.options.ns.indexOf(ns) < 0) {
      this.options.ns.push(ns);
    }
  }
  removeNamespaces(ns) {
    const index = this.options.ns.indexOf(ns);
    if (index > -1) {
      this.options.ns.splice(index, 1);
    }
  }
  getResource(lng, ns, key, options = {}) {
    const keySeparator = options.keySeparator !== undefined ? options.keySeparator : this.options.keySeparator;
    const ignoreJSONStructure = options.ignoreJSONStructure !== undefined ? options.ignoreJSONStructure : this.options.ignoreJSONStructure;
    let path;
    if (lng.indexOf('.') > -1) {
      path = lng.split('.');
    } else {
      path = [lng, ns];
      if (key) {
        if (Array.isArray(key)) {
          path.push(...key);
        } else if (isString$1(key) && keySeparator) {
          path.push(...key.split(keySeparator));
        } else {
          path.push(key);
        }
      }
    }
    const result = getPath(this.data, path);
    if (!result && !ns && !key && lng.indexOf('.') > -1) {
      lng = path[0];
      ns = path[1];
      key = path.slice(2).join('.');
    }
    if (result || !ignoreJSONStructure || !isString$1(key)) return result;
    return deepFind(this.data?.[lng]?.[ns], key, keySeparator);
  }
  addResource(lng, ns, key, value, options = {
    silent: false
  }) {
    const keySeparator = options.keySeparator !== undefined ? options.keySeparator : this.options.keySeparator;
    let path = [lng, ns];
    if (key) path = path.concat(keySeparator ? key.split(keySeparator) : key);
    if (lng.indexOf('.') > -1) {
      path = lng.split('.');
      value = ns;
      ns = path[1];
    }
    this.addNamespaces(ns);
    setPath(this.data, path, value);
    if (!options.silent) this.emit('added', lng, ns, key, value);
  }
  addResources(lng, ns, resources, options = {
    silent: false
  }) {
    for (const m in resources) {
      if (isString$1(resources[m]) || Array.isArray(resources[m])) this.addResource(lng, ns, m, resources[m], {
        silent: true
      });
    }
    if (!options.silent) this.emit('added', lng, ns, resources);
  }
  addResourceBundle(lng, ns, resources, deep, overwrite, options = {
    silent: false,
    skipCopy: false
  }) {
    let path = [lng, ns];
    if (lng.indexOf('.') > -1) {
      path = lng.split('.');
      deep = resources;
      resources = ns;
      ns = path[1];
    }
    this.addNamespaces(ns);
    let pack = getPath(this.data, path) || {};
    if (!options.skipCopy) resources = JSON.parse(JSON.stringify(resources));
    if (deep) {
      deepExtend(pack, resources, overwrite);
    } else {
      pack = {
        ...pack,
        ...resources
      };
    }
    setPath(this.data, path, pack);
    if (!options.silent) this.emit('added', lng, ns, resources);
  }
  removeResourceBundle(lng, ns) {
    if (this.hasResourceBundle(lng, ns)) {
      delete this.data[lng][ns];
    }
    this.removeNamespaces(ns);
    this.emit('removed', lng, ns);
  }
  hasResourceBundle(lng, ns) {
    return this.getResource(lng, ns) !== undefined;
  }
  getResourceBundle(lng, ns) {
    if (!ns) ns = this.options.defaultNS;
    return this.getResource(lng, ns);
  }
  getDataByLanguage(lng) {
    return this.data[lng];
  }
  hasLanguageSomeTranslations(lng) {
    const data = this.getDataByLanguage(lng);
    const n = data && Object.keys(data) || [];
    return !!n.find(v => data[v] && Object.keys(data[v]).length > 0);
  }
  toJSON() {
    return this.data;
  }
}

var postProcessor = {
  processors: {},
  addPostProcessor(module) {
    this.processors[module.name] = module;
  },
  handle(processors, value, key, options, translator) {
    processors.forEach(processor => {
      value = this.processors[processor]?.process(value, key, options, translator) ?? value;
    });
    return value;
  }
};

const PATH_KEY = Symbol('i18next/PATH_KEY');
function createProxy() {
  const state = [];
  const handler = Object.create(null);
  let proxy;
  handler.get = (target, key) => {
    proxy?.revoke?.();
    if (key === PATH_KEY) return state;
    state.push(key);
    proxy = Proxy.revocable(target, handler);
    return proxy.proxy;
  };
  return Proxy.revocable(Object.create(null), handler).proxy;
}
function keysFromSelector(selector, opts) {
  const {
    [PATH_KEY]: path
  } = selector(createProxy());
  return path.join(opts?.keySeparator ?? '.');
}

const checkedLoadedFor = {};
const shouldHandleAsObject = res => !isString$1(res) && typeof res !== 'boolean' && typeof res !== 'number';
class Translator extends EventEmitter {
  constructor(services, options = {}) {
    super();
    copy(['resourceStore', 'languageUtils', 'pluralResolver', 'interpolator', 'backendConnector', 'i18nFormat', 'utils'], services, this);
    this.options = options;
    if (this.options.keySeparator === undefined) {
      this.options.keySeparator = '.';
    }
    this.logger = baseLogger.create('translator');
  }
  changeLanguage(lng) {
    if (lng) this.language = lng;
  }
  exists(key, o = {
    interpolation: {}
  }) {
    const opt = {
      ...o
    };
    if (key == null) return false;
    const resolved = this.resolve(key, opt);
    if (resolved?.res === undefined) return false;
    const isObject = shouldHandleAsObject(resolved.res);
    if (opt.returnObjects === false && isObject) {
      return false;
    }
    return true;
  }
  extractFromKey(key, opt) {
    let nsSeparator = opt.nsSeparator !== undefined ? opt.nsSeparator : this.options.nsSeparator;
    if (nsSeparator === undefined) nsSeparator = ':';
    const keySeparator = opt.keySeparator !== undefined ? opt.keySeparator : this.options.keySeparator;
    let namespaces = opt.ns || this.options.defaultNS || [];
    const wouldCheckForNsInKey = nsSeparator && key.indexOf(nsSeparator) > -1;
    const seemsNaturalLanguage = !this.options.userDefinedKeySeparator && !opt.keySeparator && !this.options.userDefinedNsSeparator && !opt.nsSeparator && !looksLikeObjectPath(key, nsSeparator, keySeparator);
    if (wouldCheckForNsInKey && !seemsNaturalLanguage) {
      const m = key.match(this.interpolator.nestingRegexp);
      if (m && m.length > 0) {
        return {
          key,
          namespaces: isString$1(namespaces) ? [namespaces] : namespaces
        };
      }
      const parts = key.split(nsSeparator);
      if (nsSeparator !== keySeparator || nsSeparator === keySeparator && this.options.ns.indexOf(parts[0]) > -1) namespaces = parts.shift();
      key = parts.join(keySeparator);
    }
    return {
      key,
      namespaces: isString$1(namespaces) ? [namespaces] : namespaces
    };
  }
  translate(keys, o, lastKey) {
    let opt = typeof o === 'object' ? {
      ...o
    } : o;
    if (typeof opt !== 'object' && this.options.overloadTranslationOptionHandler) {
      opt = this.options.overloadTranslationOptionHandler(arguments);
    }
    if (typeof opt === 'object') opt = {
      ...opt
    };
    if (!opt) opt = {};
    if (keys == null) return '';
    if (typeof keys === 'function') keys = keysFromSelector(keys, {
      ...this.options,
      ...opt
    });
    if (!Array.isArray(keys)) keys = [String(keys)];
    const returnDetails = opt.returnDetails !== undefined ? opt.returnDetails : this.options.returnDetails;
    const keySeparator = opt.keySeparator !== undefined ? opt.keySeparator : this.options.keySeparator;
    const {
      key,
      namespaces
    } = this.extractFromKey(keys[keys.length - 1], opt);
    const namespace = namespaces[namespaces.length - 1];
    let nsSeparator = opt.nsSeparator !== undefined ? opt.nsSeparator : this.options.nsSeparator;
    if (nsSeparator === undefined) nsSeparator = ':';
    const lng = opt.lng || this.language;
    const appendNamespaceToCIMode = opt.appendNamespaceToCIMode || this.options.appendNamespaceToCIMode;
    if (lng?.toLowerCase() === 'cimode') {
      if (appendNamespaceToCIMode) {
        if (returnDetails) {
          return {
            res: `${namespace}${nsSeparator}${key}`,
            usedKey: key,
            exactUsedKey: key,
            usedLng: lng,
            usedNS: namespace,
            usedParams: this.getUsedParamsDetails(opt)
          };
        }
        return `${namespace}${nsSeparator}${key}`;
      }
      if (returnDetails) {
        return {
          res: key,
          usedKey: key,
          exactUsedKey: key,
          usedLng: lng,
          usedNS: namespace,
          usedParams: this.getUsedParamsDetails(opt)
        };
      }
      return key;
    }
    const resolved = this.resolve(keys, opt);
    let res = resolved?.res;
    const resUsedKey = resolved?.usedKey || key;
    const resExactUsedKey = resolved?.exactUsedKey || key;
    const noObject = ['[object Number]', '[object Function]', '[object RegExp]'];
    const joinArrays = opt.joinArrays !== undefined ? opt.joinArrays : this.options.joinArrays;
    const handleAsObjectInI18nFormat = !this.i18nFormat || this.i18nFormat.handleAsObject;
    const needsPluralHandling = opt.count !== undefined && !isString$1(opt.count);
    const hasDefaultValue = Translator.hasDefaultValue(opt);
    const defaultValueSuffix = needsPluralHandling ? this.pluralResolver.getSuffix(lng, opt.count, opt) : '';
    const defaultValueSuffixOrdinalFallback = opt.ordinal && needsPluralHandling ? this.pluralResolver.getSuffix(lng, opt.count, {
      ordinal: false
    }) : '';
    const needsZeroSuffixLookup = needsPluralHandling && !opt.ordinal && opt.count === 0;
    const defaultValue = needsZeroSuffixLookup && opt[`defaultValue${this.options.pluralSeparator}zero`] || opt[`defaultValue${defaultValueSuffix}`] || opt[`defaultValue${defaultValueSuffixOrdinalFallback}`] || opt.defaultValue;
    let resForObjHndl = res;
    if (handleAsObjectInI18nFormat && !res && hasDefaultValue) {
      resForObjHndl = defaultValue;
    }
    const handleAsObject = shouldHandleAsObject(resForObjHndl);
    const resType = Object.prototype.toString.apply(resForObjHndl);
    if (handleAsObjectInI18nFormat && resForObjHndl && handleAsObject && noObject.indexOf(resType) < 0 && !(isString$1(joinArrays) && Array.isArray(resForObjHndl))) {
      if (!opt.returnObjects && !this.options.returnObjects) {
        if (!this.options.returnedObjectHandler) {
          this.logger.warn('accessing an object - but returnObjects options is not enabled!');
        }
        const r = this.options.returnedObjectHandler ? this.options.returnedObjectHandler(resUsedKey, resForObjHndl, {
          ...opt,
          ns: namespaces
        }) : `key '${key} (${this.language})' returned an object instead of string.`;
        if (returnDetails) {
          resolved.res = r;
          resolved.usedParams = this.getUsedParamsDetails(opt);
          return resolved;
        }
        return r;
      }
      if (keySeparator) {
        const resTypeIsArray = Array.isArray(resForObjHndl);
        const copy = resTypeIsArray ? [] : {};
        const newKeyToUse = resTypeIsArray ? resExactUsedKey : resUsedKey;
        for (const m in resForObjHndl) {
          if (Object.prototype.hasOwnProperty.call(resForObjHndl, m)) {
            const deepKey = `${newKeyToUse}${keySeparator}${m}`;
            if (hasDefaultValue && !res) {
              copy[m] = this.translate(deepKey, {
                ...opt,
                defaultValue: shouldHandleAsObject(defaultValue) ? defaultValue[m] : undefined,
                ...{
                  joinArrays: false,
                  ns: namespaces
                }
              });
            } else {
              copy[m] = this.translate(deepKey, {
                ...opt,
                ...{
                  joinArrays: false,
                  ns: namespaces
                }
              });
            }
            if (copy[m] === deepKey) copy[m] = resForObjHndl[m];
          }
        }
        res = copy;
      }
    } else if (handleAsObjectInI18nFormat && isString$1(joinArrays) && Array.isArray(res)) {
      res = res.join(joinArrays);
      if (res) res = this.extendTranslation(res, keys, opt, lastKey);
    } else {
      let usedDefault = false;
      let usedKey = false;
      if (!this.isValidLookup(res) && hasDefaultValue) {
        usedDefault = true;
        res = defaultValue;
      }
      if (!this.isValidLookup(res)) {
        usedKey = true;
        res = key;
      }
      const missingKeyNoValueFallbackToKey = opt.missingKeyNoValueFallbackToKey || this.options.missingKeyNoValueFallbackToKey;
      const resForMissing = missingKeyNoValueFallbackToKey && usedKey ? undefined : res;
      const updateMissing = hasDefaultValue && defaultValue !== res && this.options.updateMissing;
      if (usedKey || usedDefault || updateMissing) {
        this.logger.log(updateMissing ? 'updateKey' : 'missingKey', lng, namespace, key, updateMissing ? defaultValue : res);
        if (keySeparator) {
          const fk = this.resolve(key, {
            ...opt,
            keySeparator: false
          });
          if (fk && fk.res) this.logger.warn('Seems the loaded translations were in flat JSON format instead of nested. Either set keySeparator: false on init or make sure your translations are published in nested format.');
        }
        let lngs = [];
        const fallbackLngs = this.languageUtils.getFallbackCodes(this.options.fallbackLng, opt.lng || this.language);
        if (this.options.saveMissingTo === 'fallback' && fallbackLngs && fallbackLngs[0]) {
          for (let i = 0; i < fallbackLngs.length; i++) {
            lngs.push(fallbackLngs[i]);
          }
        } else if (this.options.saveMissingTo === 'all') {
          lngs = this.languageUtils.toResolveHierarchy(opt.lng || this.language);
        } else {
          lngs.push(opt.lng || this.language);
        }
        const send = (l, k, specificDefaultValue) => {
          const defaultForMissing = hasDefaultValue && specificDefaultValue !== res ? specificDefaultValue : resForMissing;
          if (this.options.missingKeyHandler) {
            this.options.missingKeyHandler(l, namespace, k, defaultForMissing, updateMissing, opt);
          } else if (this.backendConnector?.saveMissing) {
            this.backendConnector.saveMissing(l, namespace, k, defaultForMissing, updateMissing, opt);
          }
          this.emit('missingKey', l, namespace, k, res);
        };
        if (this.options.saveMissing) {
          if (this.options.saveMissingPlurals && needsPluralHandling) {
            lngs.forEach(language => {
              const suffixes = this.pluralResolver.getSuffixes(language, opt);
              if (needsZeroSuffixLookup && opt[`defaultValue${this.options.pluralSeparator}zero`] && suffixes.indexOf(`${this.options.pluralSeparator}zero`) < 0) {
                suffixes.push(`${this.options.pluralSeparator}zero`);
              }
              suffixes.forEach(suffix => {
                send([language], key + suffix, opt[`defaultValue${suffix}`] || defaultValue);
              });
            });
          } else {
            send(lngs, key, defaultValue);
          }
        }
      }
      res = this.extendTranslation(res, keys, opt, resolved, lastKey);
      if (usedKey && res === key && this.options.appendNamespaceToMissingKey) {
        res = `${namespace}${nsSeparator}${key}`;
      }
      if ((usedKey || usedDefault) && this.options.parseMissingKeyHandler) {
        res = this.options.parseMissingKeyHandler(this.options.appendNamespaceToMissingKey ? `${namespace}${nsSeparator}${key}` : key, usedDefault ? res : undefined, opt);
      }
    }
    if (returnDetails) {
      resolved.res = res;
      resolved.usedParams = this.getUsedParamsDetails(opt);
      return resolved;
    }
    return res;
  }
  extendTranslation(res, key, opt, resolved, lastKey) {
    if (this.i18nFormat?.parse) {
      res = this.i18nFormat.parse(res, {
        ...this.options.interpolation.defaultVariables,
        ...opt
      }, opt.lng || this.language || resolved.usedLng, resolved.usedNS, resolved.usedKey, {
        resolved
      });
    } else if (!opt.skipInterpolation) {
      if (opt.interpolation) this.interpolator.init({
        ...opt,
        ...{
          interpolation: {
            ...this.options.interpolation,
            ...opt.interpolation
          }
        }
      });
      const skipOnVariables = isString$1(res) && (opt?.interpolation?.skipOnVariables !== undefined ? opt.interpolation.skipOnVariables : this.options.interpolation.skipOnVariables);
      let nestBef;
      if (skipOnVariables) {
        const nb = res.match(this.interpolator.nestingRegexp);
        nestBef = nb && nb.length;
      }
      let data = opt.replace && !isString$1(opt.replace) ? opt.replace : opt;
      if (this.options.interpolation.defaultVariables) data = {
        ...this.options.interpolation.defaultVariables,
        ...data
      };
      res = this.interpolator.interpolate(res, data, opt.lng || this.language || resolved.usedLng, opt);
      if (skipOnVariables) {
        const na = res.match(this.interpolator.nestingRegexp);
        const nestAft = na && na.length;
        if (nestBef < nestAft) opt.nest = false;
      }
      if (!opt.lng && resolved && resolved.res) opt.lng = this.language || resolved.usedLng;
      if (opt.nest !== false) res = this.interpolator.nest(res, (...args) => {
        if (lastKey?.[0] === args[0] && !opt.context) {
          this.logger.warn(`It seems you are nesting recursively key: ${args[0]} in key: ${key[0]}`);
          return null;
        }
        return this.translate(...args, key);
      }, opt);
      if (opt.interpolation) this.interpolator.reset();
    }
    const postProcess = opt.postProcess || this.options.postProcess;
    const postProcessorNames = isString$1(postProcess) ? [postProcess] : postProcess;
    if (res != null && postProcessorNames?.length && opt.applyPostProcessor !== false) {
      res = postProcessor.handle(postProcessorNames, res, key, this.options && this.options.postProcessPassResolved ? {
        i18nResolved: {
          ...resolved,
          usedParams: this.getUsedParamsDetails(opt)
        },
        ...opt
      } : opt, this);
    }
    return res;
  }
  resolve(keys, opt = {}) {
    let found;
    let usedKey;
    let exactUsedKey;
    let usedLng;
    let usedNS;
    if (isString$1(keys)) keys = [keys];
    keys.forEach(k => {
      if (this.isValidLookup(found)) return;
      const extracted = this.extractFromKey(k, opt);
      const key = extracted.key;
      usedKey = key;
      let namespaces = extracted.namespaces;
      if (this.options.fallbackNS) namespaces = namespaces.concat(this.options.fallbackNS);
      const needsPluralHandling = opt.count !== undefined && !isString$1(opt.count);
      const needsZeroSuffixLookup = needsPluralHandling && !opt.ordinal && opt.count === 0;
      const needsContextHandling = opt.context !== undefined && (isString$1(opt.context) || typeof opt.context === 'number') && opt.context !== '';
      const codes = opt.lngs ? opt.lngs : this.languageUtils.toResolveHierarchy(opt.lng || this.language, opt.fallbackLng);
      namespaces.forEach(ns => {
        if (this.isValidLookup(found)) return;
        usedNS = ns;
        if (!checkedLoadedFor[`${codes[0]}-${ns}`] && this.utils?.hasLoadedNamespace && !this.utils?.hasLoadedNamespace(usedNS)) {
          checkedLoadedFor[`${codes[0]}-${ns}`] = true;
          this.logger.warn(`key "${usedKey}" for languages "${codes.join(', ')}" won't get resolved as namespace "${usedNS}" was not yet loaded`, 'This means something IS WRONG in your setup. You access the t function before i18next.init / i18next.loadNamespace / i18next.changeLanguage was done. Wait for the callback or Promise to resolve before accessing it!!!');
        }
        codes.forEach(code => {
          if (this.isValidLookup(found)) return;
          usedLng = code;
          const finalKeys = [key];
          if (this.i18nFormat?.addLookupKeys) {
            this.i18nFormat.addLookupKeys(finalKeys, key, code, ns, opt);
          } else {
            let pluralSuffix;
            if (needsPluralHandling) pluralSuffix = this.pluralResolver.getSuffix(code, opt.count, opt);
            const zeroSuffix = `${this.options.pluralSeparator}zero`;
            const ordinalPrefix = `${this.options.pluralSeparator}ordinal${this.options.pluralSeparator}`;
            if (needsPluralHandling) {
              if (opt.ordinal && pluralSuffix.indexOf(ordinalPrefix) === 0) {
                finalKeys.push(key + pluralSuffix.replace(ordinalPrefix, this.options.pluralSeparator));
              }
              finalKeys.push(key + pluralSuffix);
              if (needsZeroSuffixLookup) {
                finalKeys.push(key + zeroSuffix);
              }
            }
            if (needsContextHandling) {
              const contextKey = `${key}${this.options.contextSeparator || '_'}${opt.context}`;
              finalKeys.push(contextKey);
              if (needsPluralHandling) {
                if (opt.ordinal && pluralSuffix.indexOf(ordinalPrefix) === 0) {
                  finalKeys.push(contextKey + pluralSuffix.replace(ordinalPrefix, this.options.pluralSeparator));
                }
                finalKeys.push(contextKey + pluralSuffix);
                if (needsZeroSuffixLookup) {
                  finalKeys.push(contextKey + zeroSuffix);
                }
              }
            }
          }
          let possibleKey;
          while (possibleKey = finalKeys.pop()) {
            if (!this.isValidLookup(found)) {
              exactUsedKey = possibleKey;
              found = this.getResource(code, ns, possibleKey, opt);
            }
          }
        });
      });
    });
    return {
      res: found,
      usedKey,
      exactUsedKey,
      usedLng,
      usedNS
    };
  }
  isValidLookup(res) {
    return res !== undefined && !(!this.options.returnNull && res === null) && !(!this.options.returnEmptyString && res === '');
  }
  getResource(code, ns, key, options = {}) {
    if (this.i18nFormat?.getResource) return this.i18nFormat.getResource(code, ns, key, options);
    return this.resourceStore.getResource(code, ns, key, options);
  }
  getUsedParamsDetails(options = {}) {
    const optionsKeys = ['defaultValue', 'ordinal', 'context', 'replace', 'lng', 'lngs', 'fallbackLng', 'ns', 'keySeparator', 'nsSeparator', 'returnObjects', 'returnDetails', 'joinArrays', 'postProcess', 'interpolation'];
    const useOptionsReplaceForData = options.replace && !isString$1(options.replace);
    let data = useOptionsReplaceForData ? options.replace : options;
    if (useOptionsReplaceForData && typeof options.count !== 'undefined') {
      data.count = options.count;
    }
    if (this.options.interpolation.defaultVariables) {
      data = {
        ...this.options.interpolation.defaultVariables,
        ...data
      };
    }
    if (!useOptionsReplaceForData) {
      data = {
        ...data
      };
      for (const key of optionsKeys) {
        delete data[key];
      }
    }
    return data;
  }
  static hasDefaultValue(options) {
    const prefix = 'defaultValue';
    for (const option in options) {
      if (Object.prototype.hasOwnProperty.call(options, option) && prefix === option.substring(0, prefix.length) && undefined !== options[option]) {
        return true;
      }
    }
    return false;
  }
}

class LanguageUtil {
  constructor(options) {
    this.options = options;
    this.supportedLngs = this.options.supportedLngs || false;
    this.logger = baseLogger.create('languageUtils');
  }
  getScriptPartFromCode(code) {
    code = getCleanedCode(code);
    if (!code || code.indexOf('-') < 0) return null;
    const p = code.split('-');
    if (p.length === 2) return null;
    p.pop();
    if (p[p.length - 1].toLowerCase() === 'x') return null;
    return this.formatLanguageCode(p.join('-'));
  }
  getLanguagePartFromCode(code) {
    code = getCleanedCode(code);
    if (!code || code.indexOf('-') < 0) return code;
    const p = code.split('-');
    return this.formatLanguageCode(p[0]);
  }
  formatLanguageCode(code) {
    if (isString$1(code) && code.indexOf('-') > -1) {
      let formattedCode;
      try {
        formattedCode = Intl.getCanonicalLocales(code)[0];
      } catch (e) {}
      if (formattedCode && this.options.lowerCaseLng) {
        formattedCode = formattedCode.toLowerCase();
      }
      if (formattedCode) return formattedCode;
      if (this.options.lowerCaseLng) {
        return code.toLowerCase();
      }
      return code;
    }
    return this.options.cleanCode || this.options.lowerCaseLng ? code.toLowerCase() : code;
  }
  isSupportedCode(code) {
    if (this.options.load === 'languageOnly' || this.options.nonExplicitSupportedLngs) {
      code = this.getLanguagePartFromCode(code);
    }
    return !this.supportedLngs || !this.supportedLngs.length || this.supportedLngs.indexOf(code) > -1;
  }
  getBestMatchFromCodes(codes) {
    if (!codes) return null;
    let found;
    codes.forEach(code => {
      if (found) return;
      const cleanedLng = this.formatLanguageCode(code);
      if (!this.options.supportedLngs || this.isSupportedCode(cleanedLng)) found = cleanedLng;
    });
    if (!found && this.options.supportedLngs) {
      codes.forEach(code => {
        if (found) return;
        const lngScOnly = this.getScriptPartFromCode(code);
        if (this.isSupportedCode(lngScOnly)) return found = lngScOnly;
        const lngOnly = this.getLanguagePartFromCode(code);
        if (this.isSupportedCode(lngOnly)) return found = lngOnly;
        found = this.options.supportedLngs.find(supportedLng => {
          if (supportedLng === lngOnly) return supportedLng;
          if (supportedLng.indexOf('-') < 0 && lngOnly.indexOf('-') < 0) return;
          if (supportedLng.indexOf('-') > 0 && lngOnly.indexOf('-') < 0 && supportedLng.substring(0, supportedLng.indexOf('-')) === lngOnly) return supportedLng;
          if (supportedLng.indexOf(lngOnly) === 0 && lngOnly.length > 1) return supportedLng;
        });
      });
    }
    if (!found) found = this.getFallbackCodes(this.options.fallbackLng)[0];
    return found;
  }
  getFallbackCodes(fallbacks, code) {
    if (!fallbacks) return [];
    if (typeof fallbacks === 'function') fallbacks = fallbacks(code);
    if (isString$1(fallbacks)) fallbacks = [fallbacks];
    if (Array.isArray(fallbacks)) return fallbacks;
    if (!code) return fallbacks.default || [];
    let found = fallbacks[code];
    if (!found) found = fallbacks[this.getScriptPartFromCode(code)];
    if (!found) found = fallbacks[this.formatLanguageCode(code)];
    if (!found) found = fallbacks[this.getLanguagePartFromCode(code)];
    if (!found) found = fallbacks.default;
    return found || [];
  }
  toResolveHierarchy(code, fallbackCode) {
    const fallbackCodes = this.getFallbackCodes((fallbackCode === false ? [] : fallbackCode) || this.options.fallbackLng || [], code);
    const codes = [];
    const addCode = c => {
      if (!c) return;
      if (this.isSupportedCode(c)) {
        codes.push(c);
      } else {
        this.logger.warn(`rejecting language code not found in supportedLngs: ${c}`);
      }
    };
    if (isString$1(code) && (code.indexOf('-') > -1 || code.indexOf('_') > -1)) {
      if (this.options.load !== 'languageOnly') addCode(this.formatLanguageCode(code));
      if (this.options.load !== 'languageOnly' && this.options.load !== 'currentOnly') addCode(this.getScriptPartFromCode(code));
      if (this.options.load !== 'currentOnly') addCode(this.getLanguagePartFromCode(code));
    } else if (isString$1(code)) {
      addCode(this.formatLanguageCode(code));
    }
    fallbackCodes.forEach(fc => {
      if (codes.indexOf(fc) < 0) addCode(this.formatLanguageCode(fc));
    });
    return codes;
  }
}

const suffixesOrder = {
  zero: 0,
  one: 1,
  two: 2,
  few: 3,
  many: 4,
  other: 5
};
const dummyRule = {
  select: count => count === 1 ? 'one' : 'other',
  resolvedOptions: () => ({
    pluralCategories: ['one', 'other']
  })
};
class PluralResolver {
  constructor(languageUtils, options = {}) {
    this.languageUtils = languageUtils;
    this.options = options;
    this.logger = baseLogger.create('pluralResolver');
    this.pluralRulesCache = {};
  }
  addRule(lng, obj) {
    this.rules[lng] = obj;
  }
  clearCache() {
    this.pluralRulesCache = {};
  }
  getRule(code, options = {}) {
    const cleanedCode = getCleanedCode(code === 'dev' ? 'en' : code);
    const type = options.ordinal ? 'ordinal' : 'cardinal';
    const cacheKey = JSON.stringify({
      cleanedCode,
      type
    });
    if (cacheKey in this.pluralRulesCache) {
      return this.pluralRulesCache[cacheKey];
    }
    let rule;
    try {
      rule = new Intl.PluralRules(cleanedCode, {
        type
      });
    } catch (err) {
      if (!Intl) {
        this.logger.error('No Intl support, please use an Intl polyfill!');
        return dummyRule;
      }
      if (!code.match(/-|_/)) return dummyRule;
      const lngPart = this.languageUtils.getLanguagePartFromCode(code);
      rule = this.getRule(lngPart, options);
    }
    this.pluralRulesCache[cacheKey] = rule;
    return rule;
  }
  needsPlural(code, options = {}) {
    let rule = this.getRule(code, options);
    if (!rule) rule = this.getRule('dev', options);
    return rule?.resolvedOptions().pluralCategories.length > 1;
  }
  getPluralFormsOfKey(code, key, options = {}) {
    return this.getSuffixes(code, options).map(suffix => `${key}${suffix}`);
  }
  getSuffixes(code, options = {}) {
    let rule = this.getRule(code, options);
    if (!rule) rule = this.getRule('dev', options);
    if (!rule) return [];
    return rule.resolvedOptions().pluralCategories.sort((pluralCategory1, pluralCategory2) => suffixesOrder[pluralCategory1] - suffixesOrder[pluralCategory2]).map(pluralCategory => `${this.options.prepend}${options.ordinal ? `ordinal${this.options.prepend}` : ''}${pluralCategory}`);
  }
  getSuffix(code, count, options = {}) {
    const rule = this.getRule(code, options);
    if (rule) {
      return `${this.options.prepend}${options.ordinal ? `ordinal${this.options.prepend}` : ''}${rule.select(count)}`;
    }
    this.logger.warn(`no plural rule found for: ${code}`);
    return this.getSuffix('dev', count, options);
  }
}

const deepFindWithDefaults = (data, defaultData, key, keySeparator = '.', ignoreJSONStructure = true) => {
  let path = getPathWithDefaults(data, defaultData, key);
  if (!path && ignoreJSONStructure && isString$1(key)) {
    path = deepFind(data, key, keySeparator);
    if (path === undefined) path = deepFind(defaultData, key, keySeparator);
  }
  return path;
};
const regexSafe = val => val.replace(/\$/g, '$$$$');
class Interpolator {
  constructor(options = {}) {
    this.logger = baseLogger.create('interpolator');
    this.options = options;
    this.format = options?.interpolation?.format || (value => value);
    this.init(options);
  }
  init(options = {}) {
    if (!options.interpolation) options.interpolation = {
      escapeValue: true
    };
    const {
      escape: escape$1,
      escapeValue,
      useRawValueToEscape,
      prefix,
      prefixEscaped,
      suffix,
      suffixEscaped,
      formatSeparator,
      unescapeSuffix,
      unescapePrefix,
      nestingPrefix,
      nestingPrefixEscaped,
      nestingSuffix,
      nestingSuffixEscaped,
      nestingOptionsSeparator,
      maxReplaces,
      alwaysFormat
    } = options.interpolation;
    this.escape = escape$1 !== undefined ? escape$1 : escape;
    this.escapeValue = escapeValue !== undefined ? escapeValue : true;
    this.useRawValueToEscape = useRawValueToEscape !== undefined ? useRawValueToEscape : false;
    this.prefix = prefix ? regexEscape(prefix) : prefixEscaped || '{{';
    this.suffix = suffix ? regexEscape(suffix) : suffixEscaped || '}}';
    this.formatSeparator = formatSeparator || ',';
    this.unescapePrefix = unescapeSuffix ? '' : unescapePrefix || '-';
    this.unescapeSuffix = this.unescapePrefix ? '' : unescapeSuffix || '';
    this.nestingPrefix = nestingPrefix ? regexEscape(nestingPrefix) : nestingPrefixEscaped || regexEscape('$t(');
    this.nestingSuffix = nestingSuffix ? regexEscape(nestingSuffix) : nestingSuffixEscaped || regexEscape(')');
    this.nestingOptionsSeparator = nestingOptionsSeparator || ',';
    this.maxReplaces = maxReplaces || 1000;
    this.alwaysFormat = alwaysFormat !== undefined ? alwaysFormat : false;
    this.resetRegExp();
  }
  reset() {
    if (this.options) this.init(this.options);
  }
  resetRegExp() {
    const getOrResetRegExp = (existingRegExp, pattern) => {
      if (existingRegExp?.source === pattern) {
        existingRegExp.lastIndex = 0;
        return existingRegExp;
      }
      return new RegExp(pattern, 'g');
    };
    this.regexp = getOrResetRegExp(this.regexp, `${this.prefix}(.+?)${this.suffix}`);
    this.regexpUnescape = getOrResetRegExp(this.regexpUnescape, `${this.prefix}${this.unescapePrefix}(.+?)${this.unescapeSuffix}${this.suffix}`);
    this.nestingRegexp = getOrResetRegExp(this.nestingRegexp, `${this.nestingPrefix}((?:[^()"']+|"[^"]*"|'[^']*'|\\((?:[^()]|"[^"]*"|'[^']*')*\\))*?)${this.nestingSuffix}`);
  }
  interpolate(str, data, lng, options) {
    let match;
    let value;
    let replaces;
    const defaultData = this.options && this.options.interpolation && this.options.interpolation.defaultVariables || {};
    const handleFormat = key => {
      if (key.indexOf(this.formatSeparator) < 0) {
        const path = deepFindWithDefaults(data, defaultData, key, this.options.keySeparator, this.options.ignoreJSONStructure);
        return this.alwaysFormat ? this.format(path, undefined, lng, {
          ...options,
          ...data,
          interpolationkey: key
        }) : path;
      }
      const p = key.split(this.formatSeparator);
      const k = p.shift().trim();
      const f = p.join(this.formatSeparator).trim();
      return this.format(deepFindWithDefaults(data, defaultData, k, this.options.keySeparator, this.options.ignoreJSONStructure), f, lng, {
        ...options,
        ...data,
        interpolationkey: k
      });
    };
    this.resetRegExp();
    const missingInterpolationHandler = options?.missingInterpolationHandler || this.options.missingInterpolationHandler;
    const skipOnVariables = options?.interpolation?.skipOnVariables !== undefined ? options.interpolation.skipOnVariables : this.options.interpolation.skipOnVariables;
    const todos = [{
      regex: this.regexpUnescape,
      safeValue: val => regexSafe(val)
    }, {
      regex: this.regexp,
      safeValue: val => this.escapeValue ? regexSafe(this.escape(val)) : regexSafe(val)
    }];
    todos.forEach(todo => {
      replaces = 0;
      while (match = todo.regex.exec(str)) {
        const matchedVar = match[1].trim();
        value = handleFormat(matchedVar);
        if (value === undefined) {
          if (typeof missingInterpolationHandler === 'function') {
            const temp = missingInterpolationHandler(str, match, options);
            value = isString$1(temp) ? temp : '';
          } else if (options && Object.prototype.hasOwnProperty.call(options, matchedVar)) {
            value = '';
          } else if (skipOnVariables) {
            value = match[0];
            continue;
          } else {
            this.logger.warn(`missed to pass in variable ${matchedVar} for interpolating ${str}`);
            value = '';
          }
        } else if (!isString$1(value) && !this.useRawValueToEscape) {
          value = makeString(value);
        }
        const safeValue = todo.safeValue(value);
        str = str.replace(match[0], safeValue);
        if (skipOnVariables) {
          todo.regex.lastIndex += value.length;
          todo.regex.lastIndex -= match[0].length;
        } else {
          todo.regex.lastIndex = 0;
        }
        replaces++;
        if (replaces >= this.maxReplaces) {
          break;
        }
      }
    });
    return str;
  }
  nest(str, fc, options = {}) {
    let match;
    let value;
    let clonedOptions;
    const handleHasOptions = (key, inheritedOptions) => {
      const sep = this.nestingOptionsSeparator;
      if (key.indexOf(sep) < 0) return key;
      const c = key.split(new RegExp(`${sep}[ ]*{`));
      let optionsString = `{${c[1]}`;
      key = c[0];
      optionsString = this.interpolate(optionsString, clonedOptions);
      const matchedSingleQuotes = optionsString.match(/'/g);
      const matchedDoubleQuotes = optionsString.match(/"/g);
      if ((matchedSingleQuotes?.length ?? 0) % 2 === 0 && !matchedDoubleQuotes || matchedDoubleQuotes.length % 2 !== 0) {
        optionsString = optionsString.replace(/'/g, '"');
      }
      try {
        clonedOptions = JSON.parse(optionsString);
        if (inheritedOptions) clonedOptions = {
          ...inheritedOptions,
          ...clonedOptions
        };
      } catch (e) {
        this.logger.warn(`failed parsing options string in nesting for key ${key}`, e);
        return `${key}${sep}${optionsString}`;
      }
      if (clonedOptions.defaultValue && clonedOptions.defaultValue.indexOf(this.prefix) > -1) delete clonedOptions.defaultValue;
      return key;
    };
    while (match = this.nestingRegexp.exec(str)) {
      let formatters = [];
      clonedOptions = {
        ...options
      };
      clonedOptions = clonedOptions.replace && !isString$1(clonedOptions.replace) ? clonedOptions.replace : clonedOptions;
      clonedOptions.applyPostProcessor = false;
      delete clonedOptions.defaultValue;
      const keyEndIndex = /{.*}/.test(match[1]) ? match[1].lastIndexOf('}') + 1 : match[1].indexOf(this.formatSeparator);
      if (keyEndIndex !== -1) {
        formatters = match[1].slice(keyEndIndex).split(this.formatSeparator).map(elem => elem.trim()).filter(Boolean);
        match[1] = match[1].slice(0, keyEndIndex);
      }
      value = fc(handleHasOptions.call(this, match[1].trim(), clonedOptions), clonedOptions);
      if (value && match[0] === str && !isString$1(value)) return value;
      if (!isString$1(value)) value = makeString(value);
      if (!value) {
        this.logger.warn(`missed to resolve ${match[1]} for nesting ${str}`);
        value = '';
      }
      if (formatters.length) {
        value = formatters.reduce((v, f) => this.format(v, f, options.lng, {
          ...options,
          interpolationkey: match[1].trim()
        }), value.trim());
      }
      str = str.replace(match[0], value);
      this.regexp.lastIndex = 0;
    }
    return str;
  }
}

const parseFormatStr = formatStr => {
  let formatName = formatStr.toLowerCase().trim();
  const formatOptions = {};
  if (formatStr.indexOf('(') > -1) {
    const p = formatStr.split('(');
    formatName = p[0].toLowerCase().trim();
    const optStr = p[1].substring(0, p[1].length - 1);
    if (formatName === 'currency' && optStr.indexOf(':') < 0) {
      if (!formatOptions.currency) formatOptions.currency = optStr.trim();
    } else if (formatName === 'relativetime' && optStr.indexOf(':') < 0) {
      if (!formatOptions.range) formatOptions.range = optStr.trim();
    } else {
      const opts = optStr.split(';');
      opts.forEach(opt => {
        if (opt) {
          const [key, ...rest] = opt.split(':');
          const val = rest.join(':').trim().replace(/^'+|'+$/g, '');
          const trimmedKey = key.trim();
          if (!formatOptions[trimmedKey]) formatOptions[trimmedKey] = val;
          if (val === 'false') formatOptions[trimmedKey] = false;
          if (val === 'true') formatOptions[trimmedKey] = true;
          if (!isNaN(val)) formatOptions[trimmedKey] = parseInt(val, 10);
        }
      });
    }
  }
  return {
    formatName,
    formatOptions
  };
};
const createCachedFormatter = fn => {
  const cache = {};
  return (v, l, o) => {
    let optForCache = o;
    if (o && o.interpolationkey && o.formatParams && o.formatParams[o.interpolationkey] && o[o.interpolationkey]) {
      optForCache = {
        ...optForCache,
        [o.interpolationkey]: undefined
      };
    }
    const key = l + JSON.stringify(optForCache);
    let frm = cache[key];
    if (!frm) {
      frm = fn(getCleanedCode(l), o);
      cache[key] = frm;
    }
    return frm(v);
  };
};
const createNonCachedFormatter = fn => (v, l, o) => fn(getCleanedCode(l), o)(v);
class Formatter {
  constructor(options = {}) {
    this.logger = baseLogger.create('formatter');
    this.options = options;
    this.init(options);
  }
  init(services, options = {
    interpolation: {}
  }) {
    this.formatSeparator = options.interpolation.formatSeparator || ',';
    const cf = options.cacheInBuiltFormats ? createCachedFormatter : createNonCachedFormatter;
    this.formats = {
      number: cf((lng, opt) => {
        const formatter = new Intl.NumberFormat(lng, {
          ...opt
        });
        return val => formatter.format(val);
      }),
      currency: cf((lng, opt) => {
        const formatter = new Intl.NumberFormat(lng, {
          ...opt,
          style: 'currency'
        });
        return val => formatter.format(val);
      }),
      datetime: cf((lng, opt) => {
        const formatter = new Intl.DateTimeFormat(lng, {
          ...opt
        });
        return val => formatter.format(val);
      }),
      relativetime: cf((lng, opt) => {
        const formatter = new Intl.RelativeTimeFormat(lng, {
          ...opt
        });
        return val => formatter.format(val, opt.range || 'day');
      }),
      list: cf((lng, opt) => {
        const formatter = new Intl.ListFormat(lng, {
          ...opt
        });
        return val => formatter.format(val);
      })
    };
  }
  add(name, fc) {
    this.formats[name.toLowerCase().trim()] = fc;
  }
  addCached(name, fc) {
    this.formats[name.toLowerCase().trim()] = createCachedFormatter(fc);
  }
  format(value, format, lng, options = {}) {
    const formats = format.split(this.formatSeparator);
    if (formats.length > 1 && formats[0].indexOf('(') > 1 && formats[0].indexOf(')') < 0 && formats.find(f => f.indexOf(')') > -1)) {
      const lastIndex = formats.findIndex(f => f.indexOf(')') > -1);
      formats[0] = [formats[0], ...formats.splice(1, lastIndex)].join(this.formatSeparator);
    }
    const result = formats.reduce((mem, f) => {
      const {
        formatName,
        formatOptions
      } = parseFormatStr(f);
      if (this.formats[formatName]) {
        let formatted = mem;
        try {
          const valOptions = options?.formatParams?.[options.interpolationkey] || {};
          const l = valOptions.locale || valOptions.lng || options.locale || options.lng || lng;
          formatted = this.formats[formatName](mem, l, {
            ...formatOptions,
            ...options,
            ...valOptions
          });
        } catch (error) {
          this.logger.warn(error);
        }
        return formatted;
      } else {
        this.logger.warn(`there was no format function for ${formatName}`);
      }
      return mem;
    }, value);
    return result;
  }
}

const removePending = (q, name) => {
  if (q.pending[name] !== undefined) {
    delete q.pending[name];
    q.pendingCount--;
  }
};
class Connector extends EventEmitter {
  constructor(backend, store, services, options = {}) {
    super();
    this.backend = backend;
    this.store = store;
    this.services = services;
    this.languageUtils = services.languageUtils;
    this.options = options;
    this.logger = baseLogger.create('backendConnector');
    this.waitingReads = [];
    this.maxParallelReads = options.maxParallelReads || 10;
    this.readingCalls = 0;
    this.maxRetries = options.maxRetries >= 0 ? options.maxRetries : 5;
    this.retryTimeout = options.retryTimeout >= 1 ? options.retryTimeout : 350;
    this.state = {};
    this.queue = [];
    this.backend?.init?.(services, options.backend, options);
  }
  queueLoad(languages, namespaces, options, callback) {
    const toLoad = {};
    const pending = {};
    const toLoadLanguages = {};
    const toLoadNamespaces = {};
    languages.forEach(lng => {
      let hasAllNamespaces = true;
      namespaces.forEach(ns => {
        const name = `${lng}|${ns}`;
        if (!options.reload && this.store.hasResourceBundle(lng, ns)) {
          this.state[name] = 2;
        } else if (this.state[name] < 0) ; else if (this.state[name] === 1) {
          if (pending[name] === undefined) pending[name] = true;
        } else {
          this.state[name] = 1;
          hasAllNamespaces = false;
          if (pending[name] === undefined) pending[name] = true;
          if (toLoad[name] === undefined) toLoad[name] = true;
          if (toLoadNamespaces[ns] === undefined) toLoadNamespaces[ns] = true;
        }
      });
      if (!hasAllNamespaces) toLoadLanguages[lng] = true;
    });
    if (Object.keys(toLoad).length || Object.keys(pending).length) {
      this.queue.push({
        pending,
        pendingCount: Object.keys(pending).length,
        loaded: {},
        errors: [],
        callback
      });
    }
    return {
      toLoad: Object.keys(toLoad),
      pending: Object.keys(pending),
      toLoadLanguages: Object.keys(toLoadLanguages),
      toLoadNamespaces: Object.keys(toLoadNamespaces)
    };
  }
  loaded(name, err, data) {
    const s = name.split('|');
    const lng = s[0];
    const ns = s[1];
    if (err) this.emit('failedLoading', lng, ns, err);
    if (!err && data) {
      this.store.addResourceBundle(lng, ns, data, undefined, undefined, {
        skipCopy: true
      });
    }
    this.state[name] = err ? -1 : 2;
    if (err && data) this.state[name] = 0;
    const loaded = {};
    this.queue.forEach(q => {
      pushPath(q.loaded, [lng], ns);
      removePending(q, name);
      if (err) q.errors.push(err);
      if (q.pendingCount === 0 && !q.done) {
        Object.keys(q.loaded).forEach(l => {
          if (!loaded[l]) loaded[l] = {};
          const loadedKeys = q.loaded[l];
          if (loadedKeys.length) {
            loadedKeys.forEach(n => {
              if (loaded[l][n] === undefined) loaded[l][n] = true;
            });
          }
        });
        q.done = true;
        if (q.errors.length) {
          q.callback(q.errors);
        } else {
          q.callback();
        }
      }
    });
    this.emit('loaded', loaded);
    this.queue = this.queue.filter(q => !q.done);
  }
  read(lng, ns, fcName, tried = 0, wait = this.retryTimeout, callback) {
    if (!lng.length) return callback(null, {});
    if (this.readingCalls >= this.maxParallelReads) {
      this.waitingReads.push({
        lng,
        ns,
        fcName,
        tried,
        wait,
        callback
      });
      return;
    }
    this.readingCalls++;
    const resolver = (err, data) => {
      this.readingCalls--;
      if (this.waitingReads.length > 0) {
        const next = this.waitingReads.shift();
        this.read(next.lng, next.ns, next.fcName, next.tried, next.wait, next.callback);
      }
      if (err && data && tried < this.maxRetries) {
        setTimeout(() => {
          this.read.call(this, lng, ns, fcName, tried + 1, wait * 2, callback);
        }, wait);
        return;
      }
      callback(err, data);
    };
    const fc = this.backend[fcName].bind(this.backend);
    if (fc.length === 2) {
      try {
        const r = fc(lng, ns);
        if (r && typeof r.then === 'function') {
          r.then(data => resolver(null, data)).catch(resolver);
        } else {
          resolver(null, r);
        }
      } catch (err) {
        resolver(err);
      }
      return;
    }
    return fc(lng, ns, resolver);
  }
  prepareLoading(languages, namespaces, options = {}, callback) {
    if (!this.backend) {
      this.logger.warn('No backend was added via i18next.use. Will not load resources.');
      return callback && callback();
    }
    if (isString$1(languages)) languages = this.languageUtils.toResolveHierarchy(languages);
    if (isString$1(namespaces)) namespaces = [namespaces];
    const toLoad = this.queueLoad(languages, namespaces, options, callback);
    if (!toLoad.toLoad.length) {
      if (!toLoad.pending.length) callback();
      return null;
    }
    toLoad.toLoad.forEach(name => {
      this.loadOne(name);
    });
  }
  load(languages, namespaces, callback) {
    this.prepareLoading(languages, namespaces, {}, callback);
  }
  reload(languages, namespaces, callback) {
    this.prepareLoading(languages, namespaces, {
      reload: true
    }, callback);
  }
  loadOne(name, prefix = '') {
    const s = name.split('|');
    const lng = s[0];
    const ns = s[1];
    this.read(lng, ns, 'read', undefined, undefined, (err, data) => {
      if (err) this.logger.warn(`${prefix}loading namespace ${ns} for language ${lng} failed`, err);
      if (!err && data) this.logger.log(`${prefix}loaded namespace ${ns} for language ${lng}`, data);
      this.loaded(name, err, data);
    });
  }
  saveMissing(languages, namespace, key, fallbackValue, isUpdate, options = {}, clb = () => {}) {
    if (this.services?.utils?.hasLoadedNamespace && !this.services?.utils?.hasLoadedNamespace(namespace)) {
      this.logger.warn(`did not save key "${key}" as the namespace "${namespace}" was not yet loaded`, 'This means something IS WRONG in your setup. You access the t function before i18next.init / i18next.loadNamespace / i18next.changeLanguage was done. Wait for the callback or Promise to resolve before accessing it!!!');
      return;
    }
    if (key === undefined || key === null || key === '') return;
    if (this.backend?.create) {
      const opts = {
        ...options,
        isUpdate
      };
      const fc = this.backend.create.bind(this.backend);
      if (fc.length < 6) {
        try {
          let r;
          if (fc.length === 5) {
            r = fc(languages, namespace, key, fallbackValue, opts);
          } else {
            r = fc(languages, namespace, key, fallbackValue);
          }
          if (r && typeof r.then === 'function') {
            r.then(data => clb(null, data)).catch(clb);
          } else {
            clb(null, r);
          }
        } catch (err) {
          clb(err);
        }
      } else {
        fc(languages, namespace, key, fallbackValue, clb, opts);
      }
    }
    if (!languages || !languages[0]) return;
    this.store.addResource(languages[0], namespace, key, fallbackValue);
  }
}

const get = () => ({
  debug: false,
  initAsync: true,
  ns: ['translation'],
  defaultNS: ['translation'],
  fallbackLng: ['dev'],
  fallbackNS: false,
  supportedLngs: false,
  nonExplicitSupportedLngs: false,
  load: 'all',
  preload: false,
  simplifyPluralSuffix: true,
  keySeparator: '.',
  nsSeparator: ':',
  pluralSeparator: '_',
  contextSeparator: '_',
  partialBundledLanguages: false,
  saveMissing: false,
  updateMissing: false,
  saveMissingTo: 'fallback',
  saveMissingPlurals: true,
  missingKeyHandler: false,
  missingInterpolationHandler: false,
  postProcess: false,
  postProcessPassResolved: false,
  returnNull: false,
  returnEmptyString: true,
  returnObjects: false,
  joinArrays: false,
  returnedObjectHandler: false,
  parseMissingKeyHandler: false,
  appendNamespaceToMissingKey: false,
  appendNamespaceToCIMode: false,
  overloadTranslationOptionHandler: args => {
    let ret = {};
    if (typeof args[1] === 'object') ret = args[1];
    if (isString$1(args[1])) ret.defaultValue = args[1];
    if (isString$1(args[2])) ret.tDescription = args[2];
    if (typeof args[2] === 'object' || typeof args[3] === 'object') {
      const options = args[3] || args[2];
      Object.keys(options).forEach(key => {
        ret[key] = options[key];
      });
    }
    return ret;
  },
  interpolation: {
    escapeValue: true,
    format: value => value,
    prefix: '{{',
    suffix: '}}',
    formatSeparator: ',',
    unescapePrefix: '-',
    nestingPrefix: '$t(',
    nestingSuffix: ')',
    nestingOptionsSeparator: ',',
    maxReplaces: 1000,
    skipOnVariables: true
  },
  cacheInBuiltFormats: true
});
const transformOptions = options => {
  if (isString$1(options.ns)) options.ns = [options.ns];
  if (isString$1(options.fallbackLng)) options.fallbackLng = [options.fallbackLng];
  if (isString$1(options.fallbackNS)) options.fallbackNS = [options.fallbackNS];
  if (options.supportedLngs?.indexOf?.('cimode') < 0) {
    options.supportedLngs = options.supportedLngs.concat(['cimode']);
  }
  if (typeof options.initImmediate === 'boolean') options.initAsync = options.initImmediate;
  return options;
};

const noop = () => {};
const bindMemberFunctions = inst => {
  const mems = Object.getOwnPropertyNames(Object.getPrototypeOf(inst));
  mems.forEach(mem => {
    if (typeof inst[mem] === 'function') {
      inst[mem] = inst[mem].bind(inst);
    }
  });
};
class I18n extends EventEmitter {
  constructor(options = {}, callback) {
    super();
    this.options = transformOptions(options);
    this.services = {};
    this.logger = baseLogger;
    this.modules = {
      external: []
    };
    bindMemberFunctions(this);
    if (callback && !this.isInitialized && !options.isClone) {
      if (!this.options.initAsync) {
        this.init(options, callback);
        return this;
      }
      setTimeout(() => {
        this.init(options, callback);
      }, 0);
    }
  }
  init(options = {}, callback) {
    this.isInitializing = true;
    if (typeof options === 'function') {
      callback = options;
      options = {};
    }
    if (options.defaultNS == null && options.ns) {
      if (isString$1(options.ns)) {
        options.defaultNS = options.ns;
      } else if (options.ns.indexOf('translation') < 0) {
        options.defaultNS = options.ns[0];
      }
    }
    const defOpts = get();
    this.options = {
      ...defOpts,
      ...this.options,
      ...transformOptions(options)
    };
    this.options.interpolation = {
      ...defOpts.interpolation,
      ...this.options.interpolation
    };
    if (options.keySeparator !== undefined) {
      this.options.userDefinedKeySeparator = options.keySeparator;
    }
    if (options.nsSeparator !== undefined) {
      this.options.userDefinedNsSeparator = options.nsSeparator;
    }
    const createClassOnDemand = ClassOrObject => {
      if (!ClassOrObject) return null;
      if (typeof ClassOrObject === 'function') return new ClassOrObject();
      return ClassOrObject;
    };
    if (!this.options.isClone) {
      if (this.modules.logger) {
        baseLogger.init(createClassOnDemand(this.modules.logger), this.options);
      } else {
        baseLogger.init(null, this.options);
      }
      let formatter;
      if (this.modules.formatter) {
        formatter = this.modules.formatter;
      } else {
        formatter = Formatter;
      }
      const lu = new LanguageUtil(this.options);
      this.store = new ResourceStore(this.options.resources, this.options);
      const s = this.services;
      s.logger = baseLogger;
      s.resourceStore = this.store;
      s.languageUtils = lu;
      s.pluralResolver = new PluralResolver(lu, {
        prepend: this.options.pluralSeparator,
        simplifyPluralSuffix: this.options.simplifyPluralSuffix
      });
      const usingLegacyFormatFunction = this.options.interpolation.format && this.options.interpolation.format !== defOpts.interpolation.format;
      if (usingLegacyFormatFunction) {
        this.logger.deprecate(`init: you are still using the legacy format function, please use the new approach: https://www.i18next.com/translation-function/formatting`);
      }
      if (formatter && (!this.options.interpolation.format || this.options.interpolation.format === defOpts.interpolation.format)) {
        s.formatter = createClassOnDemand(formatter);
        if (s.formatter.init) s.formatter.init(s, this.options);
        this.options.interpolation.format = s.formatter.format.bind(s.formatter);
      }
      s.interpolator = new Interpolator(this.options);
      s.utils = {
        hasLoadedNamespace: this.hasLoadedNamespace.bind(this)
      };
      s.backendConnector = new Connector(createClassOnDemand(this.modules.backend), s.resourceStore, s, this.options);
      s.backendConnector.on('*', (event, ...args) => {
        this.emit(event, ...args);
      });
      if (this.modules.languageDetector) {
        s.languageDetector = createClassOnDemand(this.modules.languageDetector);
        if (s.languageDetector.init) s.languageDetector.init(s, this.options.detection, this.options);
      }
      if (this.modules.i18nFormat) {
        s.i18nFormat = createClassOnDemand(this.modules.i18nFormat);
        if (s.i18nFormat.init) s.i18nFormat.init(this);
      }
      this.translator = new Translator(this.services, this.options);
      this.translator.on('*', (event, ...args) => {
        this.emit(event, ...args);
      });
      this.modules.external.forEach(m => {
        if (m.init) m.init(this);
      });
    }
    this.format = this.options.interpolation.format;
    if (!callback) callback = noop;
    if (this.options.fallbackLng && !this.services.languageDetector && !this.options.lng) {
      const codes = this.services.languageUtils.getFallbackCodes(this.options.fallbackLng);
      if (codes.length > 0 && codes[0] !== 'dev') this.options.lng = codes[0];
    }
    if (!this.services.languageDetector && !this.options.lng) {
      this.logger.warn('init: no languageDetector is used and no lng is defined');
    }
    const storeApi = ['getResource', 'hasResourceBundle', 'getResourceBundle', 'getDataByLanguage'];
    storeApi.forEach(fcName => {
      this[fcName] = (...args) => this.store[fcName](...args);
    });
    const storeApiChained = ['addResource', 'addResources', 'addResourceBundle', 'removeResourceBundle'];
    storeApiChained.forEach(fcName => {
      this[fcName] = (...args) => {
        this.store[fcName](...args);
        return this;
      };
    });
    const deferred = defer();
    const load = () => {
      const finish = (err, t) => {
        this.isInitializing = false;
        if (this.isInitialized && !this.initializedStoreOnce) this.logger.warn('init: i18next is already initialized. You should call init just once!');
        this.isInitialized = true;
        if (!this.options.isClone) this.logger.log('initialized', this.options);
        this.emit('initialized', this.options);
        deferred.resolve(t);
        callback(err, t);
      };
      if (this.languages && !this.isInitialized) return finish(null, this.t.bind(this));
      this.changeLanguage(this.options.lng, finish);
    };
    if (this.options.resources || !this.options.initAsync) {
      load();
    } else {
      setTimeout(load, 0);
    }
    return deferred;
  }
  loadResources(language, callback = noop) {
    let usedCallback = callback;
    const usedLng = isString$1(language) ? language : this.language;
    if (typeof language === 'function') usedCallback = language;
    if (!this.options.resources || this.options.partialBundledLanguages) {
      if (usedLng?.toLowerCase() === 'cimode' && (!this.options.preload || this.options.preload.length === 0)) return usedCallback();
      const toLoad = [];
      const append = lng => {
        if (!lng) return;
        if (lng === 'cimode') return;
        const lngs = this.services.languageUtils.toResolveHierarchy(lng);
        lngs.forEach(l => {
          if (l === 'cimode') return;
          if (toLoad.indexOf(l) < 0) toLoad.push(l);
        });
      };
      if (!usedLng) {
        const fallbacks = this.services.languageUtils.getFallbackCodes(this.options.fallbackLng);
        fallbacks.forEach(l => append(l));
      } else {
        append(usedLng);
      }
      this.options.preload?.forEach?.(l => append(l));
      this.services.backendConnector.load(toLoad, this.options.ns, e => {
        if (!e && !this.resolvedLanguage && this.language) this.setResolvedLanguage(this.language);
        usedCallback(e);
      });
    } else {
      usedCallback(null);
    }
  }
  reloadResources(lngs, ns, callback) {
    const deferred = defer();
    if (typeof lngs === 'function') {
      callback = lngs;
      lngs = undefined;
    }
    if (typeof ns === 'function') {
      callback = ns;
      ns = undefined;
    }
    if (!lngs) lngs = this.languages;
    if (!ns) ns = this.options.ns;
    if (!callback) callback = noop;
    this.services.backendConnector.reload(lngs, ns, err => {
      deferred.resolve();
      callback(err);
    });
    return deferred;
  }
  use(module) {
    if (!module) throw new Error('You are passing an undefined module! Please check the object you are passing to i18next.use()');
    if (!module.type) throw new Error('You are passing a wrong module! Please check the object you are passing to i18next.use()');
    if (module.type === 'backend') {
      this.modules.backend = module;
    }
    if (module.type === 'logger' || module.log && module.warn && module.error) {
      this.modules.logger = module;
    }
    if (module.type === 'languageDetector') {
      this.modules.languageDetector = module;
    }
    if (module.type === 'i18nFormat') {
      this.modules.i18nFormat = module;
    }
    if (module.type === 'postProcessor') {
      postProcessor.addPostProcessor(module);
    }
    if (module.type === 'formatter') {
      this.modules.formatter = module;
    }
    if (module.type === '3rdParty') {
      this.modules.external.push(module);
    }
    return this;
  }
  setResolvedLanguage(l) {
    if (!l || !this.languages) return;
    if (['cimode', 'dev'].indexOf(l) > -1) return;
    for (let li = 0; li < this.languages.length; li++) {
      const lngInLngs = this.languages[li];
      if (['cimode', 'dev'].indexOf(lngInLngs) > -1) continue;
      if (this.store.hasLanguageSomeTranslations(lngInLngs)) {
        this.resolvedLanguage = lngInLngs;
        break;
      }
    }
    if (!this.resolvedLanguage && this.languages.indexOf(l) < 0 && this.store.hasLanguageSomeTranslations(l)) {
      this.resolvedLanguage = l;
      this.languages.unshift(l);
    }
  }
  changeLanguage(lng, callback) {
    this.isLanguageChangingTo = lng;
    const deferred = defer();
    this.emit('languageChanging', lng);
    const setLngProps = l => {
      this.language = l;
      this.languages = this.services.languageUtils.toResolveHierarchy(l);
      this.resolvedLanguage = undefined;
      this.setResolvedLanguage(l);
    };
    const done = (err, l) => {
      if (l) {
        if (this.isLanguageChangingTo === lng) {
          setLngProps(l);
          this.translator.changeLanguage(l);
          this.isLanguageChangingTo = undefined;
          this.emit('languageChanged', l);
          this.logger.log('languageChanged', l);
        }
      } else {
        this.isLanguageChangingTo = undefined;
      }
      deferred.resolve((...args) => this.t(...args));
      if (callback) callback(err, (...args) => this.t(...args));
    };
    const setLng = lngs => {
      if (!lng && !lngs && this.services.languageDetector) lngs = [];
      const fl = isString$1(lngs) ? lngs : lngs && lngs[0];
      const l = this.store.hasLanguageSomeTranslations(fl) ? fl : this.services.languageUtils.getBestMatchFromCodes(isString$1(lngs) ? [lngs] : lngs);
      if (l) {
        if (!this.language) {
          setLngProps(l);
        }
        if (!this.translator.language) this.translator.changeLanguage(l);
        this.services.languageDetector?.cacheUserLanguage?.(l);
      }
      this.loadResources(l, err => {
        done(err, l);
      });
    };
    if (!lng && this.services.languageDetector && !this.services.languageDetector.async) {
      setLng(this.services.languageDetector.detect());
    } else if (!lng && this.services.languageDetector && this.services.languageDetector.async) {
      if (this.services.languageDetector.detect.length === 0) {
        this.services.languageDetector.detect().then(setLng);
      } else {
        this.services.languageDetector.detect(setLng);
      }
    } else {
      setLng(lng);
    }
    return deferred;
  }
  getFixedT(lng, ns, keyPrefix) {
    const fixedT = (key, opts, ...rest) => {
      let o;
      if (typeof opts !== 'object') {
        o = this.options.overloadTranslationOptionHandler([key, opts].concat(rest));
      } else {
        o = {
          ...opts
        };
      }
      o.lng = o.lng || fixedT.lng;
      o.lngs = o.lngs || fixedT.lngs;
      o.ns = o.ns || fixedT.ns;
      if (o.keyPrefix !== '') o.keyPrefix = o.keyPrefix || keyPrefix || fixedT.keyPrefix;
      const keySeparator = this.options.keySeparator || '.';
      let resultKey;
      if (o.keyPrefix && Array.isArray(key)) {
        resultKey = key.map(k => {
          if (typeof k === 'function') k = keysFromSelector(k, {
            ...this.options,
            ...opts
          });
          return `${o.keyPrefix}${keySeparator}${k}`;
        });
      } else {
        if (typeof key === 'function') key = keysFromSelector(key, {
          ...this.options,
          ...opts
        });
        resultKey = o.keyPrefix ? `${o.keyPrefix}${keySeparator}${key}` : key;
      }
      return this.t(resultKey, o);
    };
    if (isString$1(lng)) {
      fixedT.lng = lng;
    } else {
      fixedT.lngs = lng;
    }
    fixedT.ns = ns;
    fixedT.keyPrefix = keyPrefix;
    return fixedT;
  }
  t(...args) {
    return this.translator?.translate(...args);
  }
  exists(...args) {
    return this.translator?.exists(...args);
  }
  setDefaultNamespace(ns) {
    this.options.defaultNS = ns;
  }
  hasLoadedNamespace(ns, options = {}) {
    if (!this.isInitialized) {
      this.logger.warn('hasLoadedNamespace: i18next was not initialized', this.languages);
      return false;
    }
    if (!this.languages || !this.languages.length) {
      this.logger.warn('hasLoadedNamespace: i18n.languages were undefined or empty', this.languages);
      return false;
    }
    const lng = options.lng || this.resolvedLanguage || this.languages[0];
    const fallbackLng = this.options ? this.options.fallbackLng : false;
    const lastLng = this.languages[this.languages.length - 1];
    if (lng.toLowerCase() === 'cimode') return true;
    const loadNotPending = (l, n) => {
      const loadState = this.services.backendConnector.state[`${l}|${n}`];
      return loadState === -1 || loadState === 0 || loadState === 2;
    };
    if (options.precheck) {
      const preResult = options.precheck(this, loadNotPending);
      if (preResult !== undefined) return preResult;
    }
    if (this.hasResourceBundle(lng, ns)) return true;
    if (!this.services.backendConnector.backend || this.options.resources && !this.options.partialBundledLanguages) return true;
    if (loadNotPending(lng, ns) && (!fallbackLng || loadNotPending(lastLng, ns))) return true;
    return false;
  }
  loadNamespaces(ns, callback) {
    const deferred = defer();
    if (!this.options.ns) {
      if (callback) callback();
      return Promise.resolve();
    }
    if (isString$1(ns)) ns = [ns];
    ns.forEach(n => {
      if (this.options.ns.indexOf(n) < 0) this.options.ns.push(n);
    });
    this.loadResources(err => {
      deferred.resolve();
      if (callback) callback(err);
    });
    return deferred;
  }
  loadLanguages(lngs, callback) {
    const deferred = defer();
    if (isString$1(lngs)) lngs = [lngs];
    const preloaded = this.options.preload || [];
    const newLngs = lngs.filter(lng => preloaded.indexOf(lng) < 0 && this.services.languageUtils.isSupportedCode(lng));
    if (!newLngs.length) {
      if (callback) callback();
      return Promise.resolve();
    }
    this.options.preload = preloaded.concat(newLngs);
    this.loadResources(err => {
      deferred.resolve();
      if (callback) callback(err);
    });
    return deferred;
  }
  dir(lng) {
    if (!lng) lng = this.resolvedLanguage || (this.languages?.length > 0 ? this.languages[0] : this.language);
    if (!lng) return 'rtl';
    try {
      const l = new Intl.Locale(lng);
      if (l && l.getTextInfo) {
        const ti = l.getTextInfo();
        if (ti && ti.direction) return ti.direction;
      }
    } catch (e) {}
    const rtlLngs = ['ar', 'shu', 'sqr', 'ssh', 'xaa', 'yhd', 'yud', 'aao', 'abh', 'abv', 'acm', 'acq', 'acw', 'acx', 'acy', 'adf', 'ads', 'aeb', 'aec', 'afb', 'ajp', 'apc', 'apd', 'arb', 'arq', 'ars', 'ary', 'arz', 'auz', 'avl', 'ayh', 'ayl', 'ayn', 'ayp', 'bbz', 'pga', 'he', 'iw', 'ps', 'pbt', 'pbu', 'pst', 'prp', 'prd', 'ug', 'ur', 'ydd', 'yds', 'yih', 'ji', 'yi', 'hbo', 'men', 'xmn', 'fa', 'jpr', 'peo', 'pes', 'prs', 'dv', 'sam', 'ckb'];
    const languageUtils = this.services?.languageUtils || new LanguageUtil(get());
    if (lng.toLowerCase().indexOf('-latn') > 1) return 'ltr';
    return rtlLngs.indexOf(languageUtils.getLanguagePartFromCode(lng)) > -1 || lng.toLowerCase().indexOf('-arab') > 1 ? 'rtl' : 'ltr';
  }
  static createInstance(options = {}, callback) {
    return new I18n(options, callback);
  }
  cloneInstance(options = {}, callback = noop) {
    const forkResourceStore = options.forkResourceStore;
    if (forkResourceStore) delete options.forkResourceStore;
    const mergedOptions = {
      ...this.options,
      ...options,
      ...{
        isClone: true
      }
    };
    const clone = new I18n(mergedOptions);
    if (options.debug !== undefined || options.prefix !== undefined) {
      clone.logger = clone.logger.clone(options);
    }
    const membersToCopy = ['store', 'services', 'language'];
    membersToCopy.forEach(m => {
      clone[m] = this[m];
    });
    clone.services = {
      ...this.services
    };
    clone.services.utils = {
      hasLoadedNamespace: clone.hasLoadedNamespace.bind(clone)
    };
    if (forkResourceStore) {
      const clonedData = Object.keys(this.store.data).reduce((prev, l) => {
        prev[l] = {
          ...this.store.data[l]
        };
        prev[l] = Object.keys(prev[l]).reduce((acc, n) => {
          acc[n] = {
            ...prev[l][n]
          };
          return acc;
        }, prev[l]);
        return prev;
      }, {});
      clone.store = new ResourceStore(clonedData, mergedOptions);
      clone.services.resourceStore = clone.store;
    }
    clone.translator = new Translator(clone.services, mergedOptions);
    clone.translator.on('*', (event, ...args) => {
      clone.emit(event, ...args);
    });
    clone.init(mergedOptions, callback);
    clone.translator.options = mergedOptions;
    clone.translator.backendConnector.services.utils = {
      hasLoadedNamespace: clone.hasLoadedNamespace.bind(clone)
    };
    return clone;
  }
  toJSON() {
    return {
      options: this.options,
      store: this.store,
      language: this.language,
      languages: this.languages,
      resolvedLanguage: this.resolvedLanguage
    };
  }
}
const instance = I18n.createInstance();
instance.createInstance = I18n.createInstance;

function _typeof$2(o) { "@babel/helpers - typeof"; return _typeof$2 = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (o) { return typeof o; } : function (o) { return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o; }, _typeof$2(o); }
function hasXMLHttpRequest() {
  return typeof XMLHttpRequest === 'function' || (typeof XMLHttpRequest === "undefined" ? "undefined" : _typeof$2(XMLHttpRequest)) === 'object';
}
function isPromise(maybePromise) {
  return !!maybePromise && typeof maybePromise.then === 'function';
}
function makePromise(maybePromise) {
  if (isPromise(maybePromise)) {
    return maybePromise;
  }
  return Promise.resolve(maybePromise);
}

var commonjsGlobal = typeof globalThis !== 'undefined' ? globalThis : typeof window !== 'undefined' ? window : typeof global !== 'undefined' ? global : typeof self !== 'undefined' ? self : {};

function getDefaultExportFromCjs (x) {
	return x && x.__esModule && Object.prototype.hasOwnProperty.call(x, 'default') ? x['default'] : x;
}

function commonjsRequire(path) {
	throw new Error('Could not dynamically require "' + path + '". Please configure the dynamicRequireTargets or/and ignoreDynamicRequires option of @rollup/plugin-commonjs appropriately for this require call to work.');
}

var getFetch$1 = {exports: {}};

var browserPonyfill = {exports: {}};

var hasRequiredBrowserPonyfill;

function requireBrowserPonyfill () {
	if (hasRequiredBrowserPonyfill) return browserPonyfill.exports;
	hasRequiredBrowserPonyfill = 1;
	(function (module, exports) {
		// Save global object in a variable
		var __global__ =
		(typeof globalThis !== 'undefined' && globalThis) ||
		(typeof self !== 'undefined' && self) ||
		(typeof commonjsGlobal !== 'undefined' && commonjsGlobal);
		// Create an object that extends from __global__ without the fetch function
		var __globalThis__ = (function () {
		function F() {
		this.fetch = false;
		this.DOMException = __global__.DOMException;
		}
		F.prototype = __global__; // Needed for feature detection on whatwg-fetch's code
		return new F();
		})();
		// Wraps whatwg-fetch with a function scope to hijack the global object
		// "globalThis" that's going to be patched
		(function(globalThis) {

		((function (exports) {

		  var global =
		    (typeof globalThis !== 'undefined' && globalThis) ||
		    (typeof self !== 'undefined' && self) ||
		    (typeof global !== 'undefined' && global);

		  var support = {
		    searchParams: 'URLSearchParams' in global,
		    iterable: 'Symbol' in global && 'iterator' in Symbol,
		    blob:
		      'FileReader' in global &&
		      'Blob' in global &&
		      (function() {
		        try {
		          new Blob();
		          return true
		        } catch (e) {
		          return false
		        }
		      })(),
		    formData: 'FormData' in global,
		    arrayBuffer: 'ArrayBuffer' in global
		  };

		  function isDataView(obj) {
		    return obj && DataView.prototype.isPrototypeOf(obj)
		  }

		  if (support.arrayBuffer) {
		    var viewClasses = [
		      '[object Int8Array]',
		      '[object Uint8Array]',
		      '[object Uint8ClampedArray]',
		      '[object Int16Array]',
		      '[object Uint16Array]',
		      '[object Int32Array]',
		      '[object Uint32Array]',
		      '[object Float32Array]',
		      '[object Float64Array]'
		    ];

		    var isArrayBufferView =
		      ArrayBuffer.isView ||
		      function(obj) {
		        return obj && viewClasses.indexOf(Object.prototype.toString.call(obj)) > -1
		      };
		  }

		  function normalizeName(name) {
		    if (typeof name !== 'string') {
		      name = String(name);
		    }
		    if (/[^a-z0-9\-#$%&'*+.^_`|~!]/i.test(name) || name === '') {
		      throw new TypeError('Invalid character in header field name: "' + name + '"')
		    }
		    return name.toLowerCase()
		  }

		  function normalizeValue(value) {
		    if (typeof value !== 'string') {
		      value = String(value);
		    }
		    return value
		  }

		  // Build a destructive iterator for the value list
		  function iteratorFor(items) {
		    var iterator = {
		      next: function() {
		        var value = items.shift();
		        return {done: value === undefined, value: value}
		      }
		    };

		    if (support.iterable) {
		      iterator[Symbol.iterator] = function() {
		        return iterator
		      };
		    }

		    return iterator
		  }

		  function Headers(headers) {
		    this.map = {};

		    if (headers instanceof Headers) {
		      headers.forEach(function(value, name) {
		        this.append(name, value);
		      }, this);
		    } else if (Array.isArray(headers)) {
		      headers.forEach(function(header) {
		        this.append(header[0], header[1]);
		      }, this);
		    } else if (headers) {
		      Object.getOwnPropertyNames(headers).forEach(function(name) {
		        this.append(name, headers[name]);
		      }, this);
		    }
		  }

		  Headers.prototype.append = function(name, value) {
		    name = normalizeName(name);
		    value = normalizeValue(value);
		    var oldValue = this.map[name];
		    this.map[name] = oldValue ? oldValue + ', ' + value : value;
		  };

		  Headers.prototype['delete'] = function(name) {
		    delete this.map[normalizeName(name)];
		  };

		  Headers.prototype.get = function(name) {
		    name = normalizeName(name);
		    return this.has(name) ? this.map[name] : null
		  };

		  Headers.prototype.has = function(name) {
		    return this.map.hasOwnProperty(normalizeName(name))
		  };

		  Headers.prototype.set = function(name, value) {
		    this.map[normalizeName(name)] = normalizeValue(value);
		  };

		  Headers.prototype.forEach = function(callback, thisArg) {
		    for (var name in this.map) {
		      if (this.map.hasOwnProperty(name)) {
		        callback.call(thisArg, this.map[name], name, this);
		      }
		    }
		  };

		  Headers.prototype.keys = function() {
		    var items = [];
		    this.forEach(function(value, name) {
		      items.push(name);
		    });
		    return iteratorFor(items)
		  };

		  Headers.prototype.values = function() {
		    var items = [];
		    this.forEach(function(value) {
		      items.push(value);
		    });
		    return iteratorFor(items)
		  };

		  Headers.prototype.entries = function() {
		    var items = [];
		    this.forEach(function(value, name) {
		      items.push([name, value]);
		    });
		    return iteratorFor(items)
		  };

		  if (support.iterable) {
		    Headers.prototype[Symbol.iterator] = Headers.prototype.entries;
		  }

		  function consumed(body) {
		    if (body.bodyUsed) {
		      return Promise.reject(new TypeError('Already read'))
		    }
		    body.bodyUsed = true;
		  }

		  function fileReaderReady(reader) {
		    return new Promise(function(resolve, reject) {
		      reader.onload = function() {
		        resolve(reader.result);
		      };
		      reader.onerror = function() {
		        reject(reader.error);
		      };
		    })
		  }

		  function readBlobAsArrayBuffer(blob) {
		    var reader = new FileReader();
		    var promise = fileReaderReady(reader);
		    reader.readAsArrayBuffer(blob);
		    return promise
		  }

		  function readBlobAsText(blob) {
		    var reader = new FileReader();
		    var promise = fileReaderReady(reader);
		    reader.readAsText(blob);
		    return promise
		  }

		  function readArrayBufferAsText(buf) {
		    var view = new Uint8Array(buf);
		    var chars = new Array(view.length);

		    for (var i = 0; i < view.length; i++) {
		      chars[i] = String.fromCharCode(view[i]);
		    }
		    return chars.join('')
		  }

		  function bufferClone(buf) {
		    if (buf.slice) {
		      return buf.slice(0)
		    } else {
		      var view = new Uint8Array(buf.byteLength);
		      view.set(new Uint8Array(buf));
		      return view.buffer
		    }
		  }

		  function Body() {
		    this.bodyUsed = false;

		    this._initBody = function(body) {
		      /*
		        fetch-mock wraps the Response object in an ES6 Proxy to
		        provide useful test harness features such as flush. However, on
		        ES5 browsers without fetch or Proxy support pollyfills must be used;
		        the proxy-pollyfill is unable to proxy an attribute unless it exists
		        on the object before the Proxy is created. This change ensures
		        Response.bodyUsed exists on the instance, while maintaining the
		        semantic of setting Request.bodyUsed in the constructor before
		        _initBody is called.
		      */
		      this.bodyUsed = this.bodyUsed;
		      this._bodyInit = body;
		      if (!body) {
		        this._bodyText = '';
		      } else if (typeof body === 'string') {
		        this._bodyText = body;
		      } else if (support.blob && Blob.prototype.isPrototypeOf(body)) {
		        this._bodyBlob = body;
		      } else if (support.formData && FormData.prototype.isPrototypeOf(body)) {
		        this._bodyFormData = body;
		      } else if (support.searchParams && URLSearchParams.prototype.isPrototypeOf(body)) {
		        this._bodyText = body.toString();
		      } else if (support.arrayBuffer && support.blob && isDataView(body)) {
		        this._bodyArrayBuffer = bufferClone(body.buffer);
		        // IE 10-11 can't handle a DataView body.
		        this._bodyInit = new Blob([this._bodyArrayBuffer]);
		      } else if (support.arrayBuffer && (ArrayBuffer.prototype.isPrototypeOf(body) || isArrayBufferView(body))) {
		        this._bodyArrayBuffer = bufferClone(body);
		      } else {
		        this._bodyText = body = Object.prototype.toString.call(body);
		      }

		      if (!this.headers.get('content-type')) {
		        if (typeof body === 'string') {
		          this.headers.set('content-type', 'text/plain;charset=UTF-8');
		        } else if (this._bodyBlob && this._bodyBlob.type) {
		          this.headers.set('content-type', this._bodyBlob.type);
		        } else if (support.searchParams && URLSearchParams.prototype.isPrototypeOf(body)) {
		          this.headers.set('content-type', 'application/x-www-form-urlencoded;charset=UTF-8');
		        }
		      }
		    };

		    if (support.blob) {
		      this.blob = function() {
		        var rejected = consumed(this);
		        if (rejected) {
		          return rejected
		        }

		        if (this._bodyBlob) {
		          return Promise.resolve(this._bodyBlob)
		        } else if (this._bodyArrayBuffer) {
		          return Promise.resolve(new Blob([this._bodyArrayBuffer]))
		        } else if (this._bodyFormData) {
		          throw new Error('could not read FormData body as blob')
		        } else {
		          return Promise.resolve(new Blob([this._bodyText]))
		        }
		      };

		      this.arrayBuffer = function() {
		        if (this._bodyArrayBuffer) {
		          var isConsumed = consumed(this);
		          if (isConsumed) {
		            return isConsumed
		          }
		          if (ArrayBuffer.isView(this._bodyArrayBuffer)) {
		            return Promise.resolve(
		              this._bodyArrayBuffer.buffer.slice(
		                this._bodyArrayBuffer.byteOffset,
		                this._bodyArrayBuffer.byteOffset + this._bodyArrayBuffer.byteLength
		              )
		            )
		          } else {
		            return Promise.resolve(this._bodyArrayBuffer)
		          }
		        } else {
		          return this.blob().then(readBlobAsArrayBuffer)
		        }
		      };
		    }

		    this.text = function() {
		      var rejected = consumed(this);
		      if (rejected) {
		        return rejected
		      }

		      if (this._bodyBlob) {
		        return readBlobAsText(this._bodyBlob)
		      } else if (this._bodyArrayBuffer) {
		        return Promise.resolve(readArrayBufferAsText(this._bodyArrayBuffer))
		      } else if (this._bodyFormData) {
		        throw new Error('could not read FormData body as text')
		      } else {
		        return Promise.resolve(this._bodyText)
		      }
		    };

		    if (support.formData) {
		      this.formData = function() {
		        return this.text().then(decode)
		      };
		    }

		    this.json = function() {
		      return this.text().then(JSON.parse)
		    };

		    return this
		  }

		  // HTTP methods whose capitalization should be normalized
		  var methods = ['DELETE', 'GET', 'HEAD', 'OPTIONS', 'POST', 'PUT'];

		  function normalizeMethod(method) {
		    var upcased = method.toUpperCase();
		    return methods.indexOf(upcased) > -1 ? upcased : method
		  }

		  function Request(input, options) {
		    if (!(this instanceof Request)) {
		      throw new TypeError('Please use the "new" operator, this DOM object constructor cannot be called as a function.')
		    }

		    options = options || {};
		    var body = options.body;

		    if (input instanceof Request) {
		      if (input.bodyUsed) {
		        throw new TypeError('Already read')
		      }
		      this.url = input.url;
		      this.credentials = input.credentials;
		      if (!options.headers) {
		        this.headers = new Headers(input.headers);
		      }
		      this.method = input.method;
		      this.mode = input.mode;
		      this.signal = input.signal;
		      if (!body && input._bodyInit != null) {
		        body = input._bodyInit;
		        input.bodyUsed = true;
		      }
		    } else {
		      this.url = String(input);
		    }

		    this.credentials = options.credentials || this.credentials || 'same-origin';
		    if (options.headers || !this.headers) {
		      this.headers = new Headers(options.headers);
		    }
		    this.method = normalizeMethod(options.method || this.method || 'GET');
		    this.mode = options.mode || this.mode || null;
		    this.signal = options.signal || this.signal;
		    this.referrer = null;

		    if ((this.method === 'GET' || this.method === 'HEAD') && body) {
		      throw new TypeError('Body not allowed for GET or HEAD requests')
		    }
		    this._initBody(body);

		    if (this.method === 'GET' || this.method === 'HEAD') {
		      if (options.cache === 'no-store' || options.cache === 'no-cache') {
		        // Search for a '_' parameter in the query string
		        var reParamSearch = /([?&])_=[^&]*/;
		        if (reParamSearch.test(this.url)) {
		          // If it already exists then set the value with the current time
		          this.url = this.url.replace(reParamSearch, '$1_=' + new Date().getTime());
		        } else {
		          // Otherwise add a new '_' parameter to the end with the current time
		          var reQueryString = /\?/;
		          this.url += (reQueryString.test(this.url) ? '&' : '?') + '_=' + new Date().getTime();
		        }
		      }
		    }
		  }

		  Request.prototype.clone = function() {
		    return new Request(this, {body: this._bodyInit})
		  };

		  function decode(body) {
		    var form = new FormData();
		    body
		      .trim()
		      .split('&')
		      .forEach(function(bytes) {
		        if (bytes) {
		          var split = bytes.split('=');
		          var name = split.shift().replace(/\+/g, ' ');
		          var value = split.join('=').replace(/\+/g, ' ');
		          form.append(decodeURIComponent(name), decodeURIComponent(value));
		        }
		      });
		    return form
		  }

		  function parseHeaders(rawHeaders) {
		    var headers = new Headers();
		    // Replace instances of \r\n and \n followed by at least one space or horizontal tab with a space
		    // https://tools.ietf.org/html/rfc7230#section-3.2
		    var preProcessedHeaders = rawHeaders.replace(/\r?\n[\t ]+/g, ' ');
		    // Avoiding split via regex to work around a common IE11 bug with the core-js 3.6.0 regex polyfill
		    // https://github.com/github/fetch/issues/748
		    // https://github.com/zloirock/core-js/issues/751
		    preProcessedHeaders
		      .split('\r')
		      .map(function(header) {
		        return header.indexOf('\n') === 0 ? header.substr(1, header.length) : header
		      })
		      .forEach(function(line) {
		        var parts = line.split(':');
		        var key = parts.shift().trim();
		        if (key) {
		          var value = parts.join(':').trim();
		          headers.append(key, value);
		        }
		      });
		    return headers
		  }

		  Body.call(Request.prototype);

		  function Response(bodyInit, options) {
		    if (!(this instanceof Response)) {
		      throw new TypeError('Please use the "new" operator, this DOM object constructor cannot be called as a function.')
		    }
		    if (!options) {
		      options = {};
		    }

		    this.type = 'default';
		    this.status = options.status === undefined ? 200 : options.status;
		    this.ok = this.status >= 200 && this.status < 300;
		    this.statusText = options.statusText === undefined ? '' : '' + options.statusText;
		    this.headers = new Headers(options.headers);
		    this.url = options.url || '';
		    this._initBody(bodyInit);
		  }

		  Body.call(Response.prototype);

		  Response.prototype.clone = function() {
		    return new Response(this._bodyInit, {
		      status: this.status,
		      statusText: this.statusText,
		      headers: new Headers(this.headers),
		      url: this.url
		    })
		  };

		  Response.error = function() {
		    var response = new Response(null, {status: 0, statusText: ''});
		    response.type = 'error';
		    return response
		  };

		  var redirectStatuses = [301, 302, 303, 307, 308];

		  Response.redirect = function(url, status) {
		    if (redirectStatuses.indexOf(status) === -1) {
		      throw new RangeError('Invalid status code')
		    }

		    return new Response(null, {status: status, headers: {location: url}})
		  };

		  exports.DOMException = global.DOMException;
		  try {
		    new exports.DOMException();
		  } catch (err) {
		    exports.DOMException = function(message, name) {
		      this.message = message;
		      this.name = name;
		      var error = Error(message);
		      this.stack = error.stack;
		    };
		    exports.DOMException.prototype = Object.create(Error.prototype);
		    exports.DOMException.prototype.constructor = exports.DOMException;
		  }

		  function fetch(input, init) {
		    return new Promise(function(resolve, reject) {
		      var request = new Request(input, init);

		      if (request.signal && request.signal.aborted) {
		        return reject(new exports.DOMException('Aborted', 'AbortError'))
		      }

		      var xhr = new XMLHttpRequest();

		      function abortXhr() {
		        xhr.abort();
		      }

		      xhr.onload = function() {
		        var options = {
		          status: xhr.status,
		          statusText: xhr.statusText,
		          headers: parseHeaders(xhr.getAllResponseHeaders() || '')
		        };
		        options.url = 'responseURL' in xhr ? xhr.responseURL : options.headers.get('X-Request-URL');
		        var body = 'response' in xhr ? xhr.response : xhr.responseText;
		        setTimeout(function() {
		          resolve(new Response(body, options));
		        }, 0);
		      };

		      xhr.onerror = function() {
		        setTimeout(function() {
		          reject(new TypeError('Network request failed'));
		        }, 0);
		      };

		      xhr.ontimeout = function() {
		        setTimeout(function() {
		          reject(new TypeError('Network request failed'));
		        }, 0);
		      };

		      xhr.onabort = function() {
		        setTimeout(function() {
		          reject(new exports.DOMException('Aborted', 'AbortError'));
		        }, 0);
		      };

		      function fixUrl(url) {
		        try {
		          return url === '' && global.location.href ? global.location.href : url
		        } catch (e) {
		          return url
		        }
		      }

		      xhr.open(request.method, fixUrl(request.url), true);

		      if (request.credentials === 'include') {
		        xhr.withCredentials = true;
		      } else if (request.credentials === 'omit') {
		        xhr.withCredentials = false;
		      }

		      if ('responseType' in xhr) {
		        if (support.blob) {
		          xhr.responseType = 'blob';
		        } else if (
		          support.arrayBuffer &&
		          request.headers.get('Content-Type') &&
		          request.headers.get('Content-Type').indexOf('application/octet-stream') !== -1
		        ) {
		          xhr.responseType = 'arraybuffer';
		        }
		      }

		      if (init && typeof init.headers === 'object' && !(init.headers instanceof Headers)) {
		        Object.getOwnPropertyNames(init.headers).forEach(function(name) {
		          xhr.setRequestHeader(name, normalizeValue(init.headers[name]));
		        });
		      } else {
		        request.headers.forEach(function(value, name) {
		          xhr.setRequestHeader(name, value);
		        });
		      }

		      if (request.signal) {
		        request.signal.addEventListener('abort', abortXhr);

		        xhr.onreadystatechange = function() {
		          // DONE (success or failure)
		          if (xhr.readyState === 4) {
		            request.signal.removeEventListener('abort', abortXhr);
		          }
		        };
		      }

		      xhr.send(typeof request._bodyInit === 'undefined' ? null : request._bodyInit);
		    })
		  }

		  fetch.polyfill = true;

		  if (!global.fetch) {
		    global.fetch = fetch;
		    global.Headers = Headers;
		    global.Request = Request;
		    global.Response = Response;
		  }

		  exports.Headers = Headers;
		  exports.Request = Request;
		  exports.Response = Response;
		  exports.fetch = fetch;

		  return exports;

		}))({});
		})(__globalThis__);
		// This is a ponyfill, so...
		__globalThis__.fetch.ponyfill = true;
		delete __globalThis__.fetch.polyfill;
		// Choose between native implementation (__global__) or custom implementation (__globalThis__)
		var ctx = __global__.fetch ? __global__ : __globalThis__;
		exports = ctx.fetch; // To enable: import fetch from 'cross-fetch'
		exports.default = ctx.fetch; // For TypeScript consumers without esModuleInterop.
		exports.fetch = ctx.fetch; // To enable: import {fetch} from 'cross-fetch'
		exports.Headers = ctx.Headers;
		exports.Request = ctx.Request;
		exports.Response = ctx.Response;
		module.exports = exports; 
	} (browserPonyfill, browserPonyfill.exports));
	return browserPonyfill.exports;
}

(function (module, exports) {
	var fetchApi;
	if (typeof fetch === 'function') {
	  if (typeof commonjsGlobal !== 'undefined' && commonjsGlobal.fetch) {
	    fetchApi = commonjsGlobal.fetch;
	  } else if (typeof window !== 'undefined' && window.fetch) {
	    fetchApi = window.fetch;
	  } else {
	    fetchApi = fetch;
	  }
	}

	if (typeof commonjsRequire !== 'undefined' && typeof window === 'undefined') {
	  var f = fetchApi || requireBrowserPonyfill();
	  if (f.default) f = f.default;
	  exports.default = f;
	  module.exports = exports.default;
	} 
} (getFetch$1, getFetch$1.exports));

var getFetchExports = getFetch$1.exports;
var getFetch = /*@__PURE__*/getDefaultExportFromCjs(getFetchExports);

var fetchNode = /*#__PURE__*/_mergeNamespaces({
  __proto__: null,
  default: getFetch
}, [getFetchExports]);

function ownKeys$2(e, r) { var t = Object.keys(e); if (Object.getOwnPropertySymbols) { var o = Object.getOwnPropertySymbols(e); r && (o = o.filter(function (r) { return Object.getOwnPropertyDescriptor(e, r).enumerable; })), t.push.apply(t, o); } return t; }
function _objectSpread$2(e) { for (var r = 1; r < arguments.length; r++) { var t = null != arguments[r] ? arguments[r] : {}; r % 2 ? ownKeys$2(Object(t), !0).forEach(function (r) { _defineProperty$2(e, r, t[r]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys$2(Object(t)).forEach(function (r) { Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r)); }); } return e; }
function _defineProperty$2(obj, key, value) { key = _toPropertyKey$2(key); if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }
function _toPropertyKey$2(t) { var i = _toPrimitive$2(t, "string"); return "symbol" == _typeof$1(i) ? i : i + ""; }
function _toPrimitive$2(t, r) { if ("object" != _typeof$1(t) || !t) return t; var e = t[Symbol.toPrimitive]; if (void 0 !== e) { var i = e.call(t, r || "default"); if ("object" != _typeof$1(i)) return i; throw new TypeError("@@toPrimitive must return a primitive value."); } return ("string" === r ? String : Number)(t); }
function _typeof$1(o) { "@babel/helpers - typeof"; return _typeof$1 = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (o) { return typeof o; } : function (o) { return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o; }, _typeof$1(o); }
var fetchApi;
if (typeof fetch === 'function') {
  if (typeof global !== 'undefined' && global.fetch) {
    fetchApi = global.fetch;
  } else if (typeof window !== 'undefined' && window.fetch) {
    fetchApi = window.fetch;
  } else {
    fetchApi = fetch;
  }
}
var XmlHttpRequestApi;
if (hasXMLHttpRequest()) {
  if (typeof global !== 'undefined' && global.XMLHttpRequest) {
    XmlHttpRequestApi = global.XMLHttpRequest;
  } else if (typeof window !== 'undefined' && window.XMLHttpRequest) {
    XmlHttpRequestApi = window.XMLHttpRequest;
  }
}
var ActiveXObjectApi;
if (typeof ActiveXObject === 'function') {
  if (typeof global !== 'undefined' && global.ActiveXObject) {
    ActiveXObjectApi = global.ActiveXObject;
  } else if (typeof window !== 'undefined' && window.ActiveXObject) {
    ActiveXObjectApi = window.ActiveXObject;
  }
}
if (!fetchApi && fetchNode && !XmlHttpRequestApi && !ActiveXObjectApi) fetchApi = getFetch || fetchNode;
if (typeof fetchApi !== 'function') fetchApi = undefined;
var addQueryString = function addQueryString(url, params) {
  if (params && _typeof$1(params) === 'object') {
    var queryString = '';
    for (var paramName in params) {
      queryString += '&' + encodeURIComponent(paramName) + '=' + encodeURIComponent(params[paramName]);
    }
    if (!queryString) return url;
    url = url + (url.indexOf('?') !== -1 ? '&' : '?') + queryString.slice(1);
  }
  return url;
};
var fetchIt = function fetchIt(url, fetchOptions, callback, altFetch) {
  var resolver = function resolver(response) {
    if (!response.ok) return callback(response.statusText || 'Error', {
      status: response.status
    });
    response.text().then(function (data) {
      callback(null, {
        status: response.status,
        data: data
      });
    }).catch(callback);
  };
  if (altFetch) {
    var altResponse = altFetch(url, fetchOptions);
    if (altResponse instanceof Promise) {
      altResponse.then(resolver).catch(callback);
      return;
    }
  }
  if (typeof fetch === 'function') {
    fetch(url, fetchOptions).then(resolver).catch(callback);
  } else {
    fetchApi(url, fetchOptions).then(resolver).catch(callback);
  }
};
var omitFetchOptions = false;
var requestWithFetch = function requestWithFetch(options, url, payload, callback) {
  if (options.queryStringParams) {
    url = addQueryString(url, options.queryStringParams);
  }
  var headers = _objectSpread$2({}, typeof options.customHeaders === 'function' ? options.customHeaders() : options.customHeaders);
  if (typeof window === 'undefined' && typeof global !== 'undefined' && typeof global.process !== 'undefined' && global.process.versions && global.process.versions.node) {
    headers['User-Agent'] = "i18next-http-backend (node/".concat(global.process.version, "; ").concat(global.process.platform, " ").concat(global.process.arch, ")");
  }
  if (payload) headers['Content-Type'] = 'application/json';
  var reqOptions = typeof options.requestOptions === 'function' ? options.requestOptions(payload) : options.requestOptions;
  var fetchOptions = _objectSpread$2({
    method: payload ? 'POST' : 'GET',
    body: payload ? options.stringify(payload) : undefined,
    headers: headers
  }, omitFetchOptions ? {} : reqOptions);
  var altFetch = typeof options.alternateFetch === 'function' && options.alternateFetch.length >= 1 ? options.alternateFetch : undefined;
  try {
    fetchIt(url, fetchOptions, callback, altFetch);
  } catch (e) {
    if (!reqOptions || Object.keys(reqOptions).length === 0 || !e.message || e.message.indexOf('not implemented') < 0) {
      return callback(e);
    }
    try {
      Object.keys(reqOptions).forEach(function (opt) {
        delete fetchOptions[opt];
      });
      fetchIt(url, fetchOptions, callback, altFetch);
      omitFetchOptions = true;
    } catch (err) {
      callback(err);
    }
  }
};
var requestWithXmlHttpRequest = function requestWithXmlHttpRequest(options, url, payload, callback) {
  if (payload && _typeof$1(payload) === 'object') {
    payload = addQueryString('', payload).slice(1);
  }
  if (options.queryStringParams) {
    url = addQueryString(url, options.queryStringParams);
  }
  try {
    var x;
    if (XmlHttpRequestApi) {
      x = new XmlHttpRequestApi();
    } else {
      x = new ActiveXObjectApi('MSXML2.XMLHTTP.3.0');
    }
    x.open(payload ? 'POST' : 'GET', url, 1);
    if (!options.crossDomain) {
      x.setRequestHeader('X-Requested-With', 'XMLHttpRequest');
    }
    x.withCredentials = !!options.withCredentials;
    if (payload) {
      x.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
    }
    if (x.overrideMimeType) {
      x.overrideMimeType('application/json');
    }
    var h = options.customHeaders;
    h = typeof h === 'function' ? h() : h;
    if (h) {
      for (var i in h) {
        x.setRequestHeader(i, h[i]);
      }
    }
    x.onreadystatechange = function () {
      x.readyState > 3 && callback(x.status >= 400 ? x.statusText : null, {
        status: x.status,
        data: x.responseText
      });
    };
    x.send(payload);
  } catch (e) {
    console && console.log(e);
  }
};
var request = function request(options, url, payload, callback) {
  if (typeof payload === 'function') {
    callback = payload;
    payload = undefined;
  }
  callback = callback || function () {};
  if (fetchApi && url.indexOf('file:') !== 0) {
    return requestWithFetch(options, url, payload, callback);
  }
  if (hasXMLHttpRequest() || typeof ActiveXObject === 'function') {
    return requestWithXmlHttpRequest(options, url, payload, callback);
  }
  callback(new Error('No fetch and no xhr implementation found!'));
};

function _typeof(o) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (o) { return typeof o; } : function (o) { return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o; }, _typeof(o); }
function ownKeys$1(e, r) { var t = Object.keys(e); if (Object.getOwnPropertySymbols) { var o = Object.getOwnPropertySymbols(e); r && (o = o.filter(function (r) { return Object.getOwnPropertyDescriptor(e, r).enumerable; })), t.push.apply(t, o); } return t; }
function _objectSpread$1(e) { for (var r = 1; r < arguments.length; r++) { var t = null != arguments[r] ? arguments[r] : {}; r % 2 ? ownKeys$1(Object(t), !0).forEach(function (r) { _defineProperty$1(e, r, t[r]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys$1(Object(t)).forEach(function (r) { Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r)); }); } return e; }
function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }
function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, _toPropertyKey$1(descriptor.key), descriptor); } }
function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); Object.defineProperty(Constructor, "prototype", { writable: false }); return Constructor; }
function _defineProperty$1(obj, key, value) { key = _toPropertyKey$1(key); if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }
function _toPropertyKey$1(t) { var i = _toPrimitive$1(t, "string"); return "symbol" == _typeof(i) ? i : i + ""; }
function _toPrimitive$1(t, r) { if ("object" != _typeof(t) || !t) return t; var e = t[Symbol.toPrimitive]; if (void 0 !== e) { var i = e.call(t, r || "default"); if ("object" != _typeof(i)) return i; throw new TypeError("@@toPrimitive must return a primitive value."); } return ("string" === r ? String : Number)(t); }
var getDefaults$1 = function getDefaults() {
  return {
    loadPath: '/locales/{{lng}}/{{ns}}.json',
    addPath: '/locales/add/{{lng}}/{{ns}}',
    parse: function parse(data) {
      return JSON.parse(data);
    },
    stringify: JSON.stringify,
    parsePayload: function parsePayload(namespace, key, fallbackValue) {
      return _defineProperty$1({}, key, fallbackValue || '');
    },
    parseLoadPayload: function parseLoadPayload(languages, namespaces) {
      return undefined;
    },
    request: request,
    reloadInterval: typeof window !== 'undefined' ? false : 60 * 60 * 1000,
    customHeaders: {},
    queryStringParams: {},
    crossDomain: false,
    withCredentials: false,
    overrideMimeType: false,
    requestOptions: {
      mode: 'cors',
      credentials: 'same-origin',
      cache: 'default'
    }
  };
};
var Backend = function () {
  function Backend(services) {
    var options = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
    var allOptions = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};
    _classCallCheck(this, Backend);
    this.services = services;
    this.options = options;
    this.allOptions = allOptions;
    this.type = 'backend';
    this.init(services, options, allOptions);
  }
  return _createClass(Backend, [{
    key: "init",
    value: function init(services) {
      var _this = this;
      var options = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
      var allOptions = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};
      this.services = services;
      this.options = _objectSpread$1(_objectSpread$1(_objectSpread$1({}, getDefaults$1()), this.options || {}), options);
      this.allOptions = allOptions;
      if (this.services && this.options.reloadInterval) {
        var timer = setInterval(function () {
          return _this.reload();
        }, this.options.reloadInterval);
        if (_typeof(timer) === 'object' && typeof timer.unref === 'function') timer.unref();
      }
    }
  }, {
    key: "readMulti",
    value: function readMulti(languages, namespaces, callback) {
      this._readAny(languages, languages, namespaces, namespaces, callback);
    }
  }, {
    key: "read",
    value: function read(language, namespace, callback) {
      this._readAny([language], language, [namespace], namespace, callback);
    }
  }, {
    key: "_readAny",
    value: function _readAny(languages, loadUrlLanguages, namespaces, loadUrlNamespaces, callback) {
      var _this2 = this;
      var loadPath = this.options.loadPath;
      if (typeof this.options.loadPath === 'function') {
        loadPath = this.options.loadPath(languages, namespaces);
      }
      loadPath = makePromise(loadPath);
      loadPath.then(function (resolvedLoadPath) {
        if (!resolvedLoadPath) return callback(null, {});
        var url = _this2.services.interpolator.interpolate(resolvedLoadPath, {
          lng: languages.join('+'),
          ns: namespaces.join('+')
        });
        _this2.loadUrl(url, callback, loadUrlLanguages, loadUrlNamespaces);
      });
    }
  }, {
    key: "loadUrl",
    value: function loadUrl(url, callback, languages, namespaces) {
      var _this3 = this;
      var lng = typeof languages === 'string' ? [languages] : languages;
      var ns = typeof namespaces === 'string' ? [namespaces] : namespaces;
      var payload = this.options.parseLoadPayload(lng, ns);
      this.options.request(this.options, url, payload, function (err, res) {
        if (res && (res.status >= 500 && res.status < 600 || !res.status)) return callback('failed loading ' + url + '; status code: ' + res.status, true);
        if (res && res.status >= 400 && res.status < 500) return callback('failed loading ' + url + '; status code: ' + res.status, false);
        if (!res && err && err.message && err.message.indexOf('Failed to fetch') > -1) return callback('failed loading ' + url + ': ' + err.message, true);
        if (err) return callback(err, false);
        var ret, parseErr;
        try {
          if (typeof res.data === 'string') {
            ret = _this3.options.parse(res.data, languages, namespaces);
          } else {
            ret = res.data;
          }
        } catch (e) {
          parseErr = 'failed parsing ' + url + ' to json';
        }
        if (parseErr) return callback(parseErr, false);
        callback(null, ret);
      });
    }
  }, {
    key: "create",
    value: function create(languages, namespace, key, fallbackValue, callback) {
      var _this4 = this;
      if (!this.options.addPath) return;
      if (typeof languages === 'string') languages = [languages];
      var payload = this.options.parsePayload(namespace, key, fallbackValue);
      var finished = 0;
      var dataArray = [];
      var resArray = [];
      languages.forEach(function (lng) {
        var addPath = _this4.options.addPath;
        if (typeof _this4.options.addPath === 'function') {
          addPath = _this4.options.addPath(lng, namespace);
        }
        var url = _this4.services.interpolator.interpolate(addPath, {
          lng: lng,
          ns: namespace
        });
        _this4.options.request(_this4.options, url, payload, function (data, res) {
          finished += 1;
          dataArray.push(data);
          resArray.push(res);
          if (finished === languages.length) {
            if (typeof callback === 'function') callback(dataArray, resArray);
          }
        });
      });
    }
  }, {
    key: "reload",
    value: function reload() {
      var _this5 = this;
      var _this$services = this.services,
        backendConnector = _this$services.backendConnector,
        languageUtils = _this$services.languageUtils,
        logger = _this$services.logger;
      var currentLanguage = backendConnector.language;
      if (currentLanguage && currentLanguage.toLowerCase() === 'cimode') return;
      var toLoad = [];
      var append = function append(lng) {
        var lngs = languageUtils.toResolveHierarchy(lng);
        lngs.forEach(function (l) {
          if (toLoad.indexOf(l) < 0) toLoad.push(l);
        });
      };
      append(currentLanguage);
      if (this.allOptions.preload) this.allOptions.preload.forEach(function (l) {
        return append(l);
      });
      toLoad.forEach(function (lng) {
        _this5.allOptions.ns.forEach(function (ns) {
          backendConnector.read(lng, ns, 'read', null, null, function (err, data) {
            if (err) logger.warn("loading namespace ".concat(ns, " for language ").concat(lng, " failed"), err);
            if (!err && data) logger.log("loaded namespace ".concat(ns, " for language ").concat(lng), data);
            backendConnector.loaded("".concat(lng, "|").concat(ns), err, data);
          });
        });
      });
    }
  }]);
}();
Backend.type = 'backend';

const warn = (i18n, code, msg, rest) => {
  const args = [msg, {
    code,
    ...(rest || {})
  }];
  if (i18n?.services?.logger?.forward) {
    return i18n.services.logger.forward(args, 'warn', 'react-i18next::', true);
  }
  if (isString(args[0])) args[0] = `react-i18next:: ${args[0]}`;
  if (i18n?.services?.logger?.warn) {
    i18n.services.logger.warn(...args);
  } else if (console?.warn) {
    console.warn(...args);
  }
};
const alreadyWarned = {};
const warnOnce = (i18n, code, msg, rest) => {
  if (isString(msg) && alreadyWarned[msg]) return;
  if (isString(msg)) alreadyWarned[msg] = new Date();
  warn(i18n, code, msg, rest);
};
const loadedClb = (i18n, cb) => () => {
  if (i18n.isInitialized) {
    cb();
  } else {
    const initialized = () => {
      setTimeout(() => {
        i18n.off('initialized', initialized);
      }, 0);
      cb();
    };
    i18n.on('initialized', initialized);
  }
};
const loadNamespaces = (i18n, ns, cb) => {
  i18n.loadNamespaces(ns, loadedClb(i18n, cb));
};
const loadLanguages = (i18n, lng, ns, cb) => {
  if (isString(ns)) ns = [ns];
  if (i18n.options.preload && i18n.options.preload.indexOf(lng) > -1) return loadNamespaces(i18n, ns, cb);
  ns.forEach(n => {
    if (i18n.options.ns.indexOf(n) < 0) i18n.options.ns.push(n);
  });
  i18n.loadLanguages(lng, loadedClb(i18n, cb));
};
const hasLoadedNamespace = (ns, i18n, options = {}) => {
  if (!i18n.languages || !i18n.languages.length) {
    warnOnce(i18n, 'NO_LANGUAGES', 'i18n.languages were undefined or empty', {
      languages: i18n.languages
    });
    return true;
  }
  return i18n.hasLoadedNamespace(ns, {
    lng: options.lng,
    precheck: (i18nInstance, loadNotPending) => {
      if (options.bindI18n && options.bindI18n.indexOf('languageChanging') > -1 && i18nInstance.services.backendConnector.backend && i18nInstance.isLanguageChangingTo && !loadNotPending(i18nInstance.isLanguageChangingTo, ns)) return false;
    }
  });
};
const isString = obj => typeof obj === 'string';
const isObject = obj => typeof obj === 'object' && obj !== null;

const matchHtmlEntity = /&(?:amp|#38|lt|#60|gt|#62|apos|#39|quot|#34|nbsp|#160|copy|#169|reg|#174|hellip|#8230|#x2F|#47);/g;
const htmlEntities = {
  '&amp;': '&',
  '&#38;': '&',
  '&lt;': '<',
  '&#60;': '<',
  '&gt;': '>',
  '&#62;': '>',
  '&apos;': "'",
  '&#39;': "'",
  '&quot;': '"',
  '&#34;': '"',
  '&nbsp;': ' ',
  '&#160;': ' ',
  '&copy;': '©',
  '&#169;': '©',
  '&reg;': '®',
  '&#174;': '®',
  '&hellip;': '…',
  '&#8230;': '…',
  '&#x2F;': '/',
  '&#47;': '/'
};
const unescapeHtmlEntity = m => htmlEntities[m];
const unescape = text => text.replace(matchHtmlEntity, unescapeHtmlEntity);

let defaultOptions = {
  bindI18n: 'languageChanged',
  bindI18nStore: '',
  transEmptyNodeValue: '',
  transSupportBasicHtmlNodes: true,
  transWrapTextNodes: '',
  transKeepBasicHtmlNodesFor: ['br', 'strong', 'i', 'p'],
  useSuspense: true,
  unescape
};
const setDefaults = (options = {}) => {
  defaultOptions = {
    ...defaultOptions,
    ...options
  };
};
const getDefaults = () => defaultOptions;

let i18nInstance;
const setI18n = instance => {
  i18nInstance = instance;
};
const getI18n = () => i18nInstance;

const initReactI18next = {
  type: '3rdParty',
  init(instance) {
    setDefaults(instance.options.react);
    setI18n(instance);
  }
};

const I18nContext = SP_REACT.createContext();
class ReportNamespaces {
  constructor() {
    this.usedNamespaces = {};
  }
  addUsedNamespaces(namespaces) {
    namespaces.forEach(ns => {
      if (!this.usedNamespaces[ns]) this.usedNamespaces[ns] = true;
    });
  }
  getUsedNamespaces() {
    return Object.keys(this.usedNamespaces);
  }
}

const usePrevious = (value, ignore) => {
  const ref = SP_REACT.useRef();
  SP_REACT.useEffect(() => {
    ref.current = value;
  }, [value, ignore]);
  return ref.current;
};
const alwaysNewT = (i18n, language, namespace, keyPrefix) => i18n.getFixedT(language, namespace, keyPrefix);
const useMemoizedT = (i18n, language, namespace, keyPrefix) => SP_REACT.useCallback(alwaysNewT(i18n, language, namespace, keyPrefix), [i18n, language, namespace, keyPrefix]);
const useTranslation = (ns, props = {}) => {
  const {
    i18n: i18nFromProps
  } = props;
  const {
    i18n: i18nFromContext,
    defaultNS: defaultNSFromContext
  } = SP_REACT.useContext(I18nContext) || {};
  const i18n = i18nFromProps || i18nFromContext || getI18n();
  if (i18n && !i18n.reportNamespaces) i18n.reportNamespaces = new ReportNamespaces();
  if (!i18n) {
    warnOnce(i18n, 'NO_I18NEXT_INSTANCE', 'useTranslation: You will need to pass in an i18next instance by using initReactI18next');
    const notReadyT = (k, optsOrDefaultValue) => {
      if (isString(optsOrDefaultValue)) return optsOrDefaultValue;
      if (isObject(optsOrDefaultValue) && isString(optsOrDefaultValue.defaultValue)) return optsOrDefaultValue.defaultValue;
      return Array.isArray(k) ? k[k.length - 1] : k;
    };
    const retNotReady = [notReadyT, {}, false];
    retNotReady.t = notReadyT;
    retNotReady.i18n = {};
    retNotReady.ready = false;
    return retNotReady;
  }
  if (i18n.options.react?.wait) warnOnce(i18n, 'DEPRECATED_OPTION', 'useTranslation: It seems you are still using the old wait option, you may migrate to the new useSuspense behaviour.');
  const i18nOptions = {
    ...getDefaults(),
    ...i18n.options.react,
    ...props
  };
  const {
    useSuspense,
    keyPrefix
  } = i18nOptions;
  let namespaces = ns || defaultNSFromContext || i18n.options?.defaultNS;
  namespaces = isString(namespaces) ? [namespaces] : namespaces || ['translation'];
  i18n.reportNamespaces.addUsedNamespaces?.(namespaces);
  const ready = (i18n.isInitialized || i18n.initializedStoreOnce) && namespaces.every(n => hasLoadedNamespace(n, i18n, i18nOptions));
  const memoGetT = useMemoizedT(i18n, props.lng || null, i18nOptions.nsMode === 'fallback' ? namespaces : namespaces[0], keyPrefix);
  const getT = () => memoGetT;
  const getNewT = () => alwaysNewT(i18n, props.lng || null, i18nOptions.nsMode === 'fallback' ? namespaces : namespaces[0], keyPrefix);
  const [t, setT] = SP_REACT.useState(getT);
  let joinedNS = namespaces.join();
  if (props.lng) joinedNS = `${props.lng}${joinedNS}`;
  const previousJoinedNS = usePrevious(joinedNS);
  const isMounted = SP_REACT.useRef(true);
  SP_REACT.useEffect(() => {
    const {
      bindI18n,
      bindI18nStore
    } = i18nOptions;
    isMounted.current = true;
    if (!ready && !useSuspense) {
      if (props.lng) {
        loadLanguages(i18n, props.lng, namespaces, () => {
          if (isMounted.current) setT(getNewT);
        });
      } else {
        loadNamespaces(i18n, namespaces, () => {
          if (isMounted.current) setT(getNewT);
        });
      }
    }
    if (ready && previousJoinedNS && previousJoinedNS !== joinedNS && isMounted.current) {
      setT(getNewT);
    }
    const boundReset = () => {
      if (isMounted.current) setT(getNewT);
    };
    if (bindI18n) i18n?.on(bindI18n, boundReset);
    if (bindI18nStore) i18n?.store.on(bindI18nStore, boundReset);
    return () => {
      isMounted.current = false;
      if (i18n && bindI18n) bindI18n?.split(' ').forEach(e => i18n.off(e, boundReset));
      if (bindI18nStore && i18n) bindI18nStore.split(' ').forEach(e => i18n.store.off(e, boundReset));
    };
  }, [i18n, joinedNS]);
  SP_REACT.useEffect(() => {
    if (isMounted.current && ready) {
      setT(getT);
    }
  }, [i18n, keyPrefix, ready]);
  const ret = [t, i18n, ready];
  ret.t = t;
  ret.i18n = i18n;
  ret.ready = ready;
  if (ready) return ret;
  if (!ready && !useSuspense) return ret;
  throw new Promise(resolve => {
    if (props.lng) {
      loadLanguages(i18n, props.lng, namespaces, () => resolve());
    } else {
      loadNamespaces(i18n, namespaces, () => resolve());
    }
  });
};

const Translation = ({
  ns,
  children,
  ...options
}) => {
  const [t, i18n, ready] = useTranslation(ns, options);
  return children(t, {
    i18n,
    lng: i18n.language
  }, ready);
};

var DefaultContext = {
  color: undefined,
  size: undefined,
  className: undefined,
  style: undefined,
  attr: undefined
};
var IconContext = SP_REACT.createContext && /*#__PURE__*/SP_REACT.createContext(DefaultContext);

var _excluded = ["attr", "size", "title"];
function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }
function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } } return target; }
function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }
function ownKeys(e, r) { var t = Object.keys(e); if (Object.getOwnPropertySymbols) { var o = Object.getOwnPropertySymbols(e); r && (o = o.filter(function (r) { return Object.getOwnPropertyDescriptor(e, r).enumerable; })), t.push.apply(t, o); } return t; }
function _objectSpread(e) { for (var r = 1; r < arguments.length; r++) { var t = null != arguments[r] ? arguments[r] : {}; r % 2 ? ownKeys(Object(t), !0).forEach(function (r) { _defineProperty(e, r, t[r]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function (r) { Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r)); }); } return e; }
function _defineProperty(obj, key, value) { key = _toPropertyKey(key); if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }
function _toPropertyKey(t) { var i = _toPrimitive(t, "string"); return "symbol" == typeof i ? i : i + ""; }
function _toPrimitive(t, r) { if ("object" != typeof t || !t) return t; var e = t[Symbol.toPrimitive]; if (void 0 !== e) { var i = e.call(t, r || "default"); if ("object" != typeof i) return i; throw new TypeError("@@toPrimitive must return a primitive value."); } return ("string" === r ? String : Number)(t); }
function Tree2Element(tree) {
  return tree && tree.map((node, i) => /*#__PURE__*/SP_REACT.createElement(node.tag, _objectSpread({
    key: i
  }, node.attr), Tree2Element(node.child)));
}
function GenIcon(data) {
  return props => /*#__PURE__*/SP_REACT.createElement(IconBase, _extends({
    attr: _objectSpread({}, data.attr)
  }, props), Tree2Element(data.child));
}
function IconBase(props) {
  var elem = conf => {
    var {
        attr,
        size,
        title
      } = props,
      svgProps = _objectWithoutProperties(props, _excluded);
    var computedSize = size || conf.size || "1em";
    var className;
    if (conf.className) className = conf.className;
    if (props.className) className = (className ? className + " " : "") + props.className;
    return /*#__PURE__*/SP_REACT.createElement("svg", _extends({
      stroke: "currentColor",
      fill: "currentColor",
      strokeWidth: "0"
    }, conf.attr, attr, svgProps, {
      className: className,
      style: _objectSpread(_objectSpread({
        color: props.color || conf.color
      }, conf.style), props.style),
      height: computedSize,
      width: computedSize,
      xmlns: "http://www.w3.org/2000/svg"
    }), title && /*#__PURE__*/SP_REACT.createElement("title", null, title), props.children);
  };
  return IconContext !== undefined ? /*#__PURE__*/SP_REACT.createElement(IconContext.Consumer, null, conf => elem(conf)) : elem(DefaultContext);
}

// THIS FILE IS AUTO GENERATED
function FaChrome (props) {
  return GenIcon({"tag":"svg","attr":{"viewBox":"0 0 496 512"},"child":[{"tag":"path","attr":{"d":"M131.5 217.5L55.1 100.1c47.6-59.2 119-91.8 192-92.1 42.3-.3 85.5 10.5 124.8 33.2 43.4 25.2 76.4 61.4 97.4 103L264 133.4c-58.1-3.4-113.4 29.3-132.5 84.1zm32.9 38.5c0 46.2 37.4 83.6 83.6 83.6s83.6-37.4 83.6-83.6-37.4-83.6-83.6-83.6-83.6 37.3-83.6 83.6zm314.9-89.2L339.6 174c37.9 44.3 38.5 108.2 6.6 157.2L234.1 503.6c46.5 2.5 94.4-7.7 137.8-32.9 107.4-62 150.9-192 107.4-303.9zM133.7 303.6L40.4 120.1C14.9 159.1 0 205.9 0 256c0 124 90.8 226.7 209.5 244.9l63.7-124.8c-57.6 10.8-113.2-20.8-139.5-72.5z"},"child":[]}]})(props);
}function FaReact (props) {
  return GenIcon({"tag":"svg","attr":{"viewBox":"0 0 512 512"},"child":[{"tag":"path","attr":{"d":"M418.2 177.2c-5.4-1.8-10.8-3.5-16.2-5.1.9-3.7 1.7-7.4 2.5-11.1 12.3-59.6 4.2-107.5-23.1-123.3-26.3-15.1-69.2.6-112.6 38.4-4.3 3.7-8.5 7.6-12.5 11.5-2.7-2.6-5.5-5.2-8.3-7.7-45.5-40.4-91.1-57.4-118.4-41.5-26.2 15.2-34 60.3-23 116.7 1.1 5.6 2.3 11.1 3.7 16.7-6.4 1.8-12.7 3.8-18.6 5.9C38.3 196.2 0 225.4 0 255.6c0 31.2 40.8 62.5 96.3 81.5 4.5 1.5 9 3 13.6 4.3-1.5 6-2.8 11.9-4 18-10.5 55.5-2.3 99.5 23.9 114.6 27 15.6 72.4-.4 116.6-39.1 3.5-3.1 7-6.3 10.5-9.7 4.4 4.3 9 8.4 13.6 12.4 42.8 36.8 85.1 51.7 111.2 36.6 27-15.6 35.8-62.9 24.4-120.5-.9-4.4-1.9-8.9-3-13.5 3.2-.9 6.3-1.9 9.4-2.9 57.7-19.1 99.5-50 99.5-81.7 0-30.3-39.4-59.7-93.8-78.4zM282.9 92.3c37.2-32.4 71.9-45.1 87.7-36 16.9 9.7 23.4 48.9 12.8 100.4-.7 3.4-1.4 6.7-2.3 10-22.2-5-44.7-8.6-67.3-10.6-13-18.6-27.2-36.4-42.6-53.1 3.9-3.7 7.7-7.2 11.7-10.7zM167.2 307.5c5.1 8.7 10.3 17.4 15.8 25.9-15.6-1.7-31.1-4.2-46.4-7.5 4.4-14.4 9.9-29.3 16.3-44.5 4.6 8.8 9.3 17.5 14.3 26.1zm-30.3-120.3c14.4-3.2 29.7-5.8 45.6-7.8-5.3 8.3-10.5 16.8-15.4 25.4-4.9 8.5-9.7 17.2-14.2 26-6.3-14.9-11.6-29.5-16-43.6zm27.4 68.9c6.6-13.8 13.8-27.3 21.4-40.6s15.8-26.2 24.4-38.9c15-1.1 30.3-1.7 45.9-1.7s31 .6 45.9 1.7c8.5 12.6 16.6 25.5 24.3 38.7s14.9 26.7 21.7 40.4c-6.7 13.8-13.9 27.4-21.6 40.8-7.6 13.3-15.7 26.2-24.2 39-14.9 1.1-30.4 1.6-46.1 1.6s-30.9-.5-45.6-1.4c-8.7-12.7-16.9-25.7-24.6-39s-14.8-26.8-21.5-40.6zm180.6 51.2c5.1-8.8 9.9-17.7 14.6-26.7 6.4 14.5 12 29.2 16.9 44.3-15.5 3.5-31.2 6.2-47 8 5.4-8.4 10.5-17 15.5-25.6zm14.4-76.5c-4.7-8.8-9.5-17.6-14.5-26.2-4.9-8.5-10-16.9-15.3-25.2 16.1 2 31.5 4.7 45.9 8-4.6 14.8-10 29.2-16.1 43.4zM256.2 118.3c10.5 11.4 20.4 23.4 29.6 35.8-19.8-.9-39.7-.9-59.5 0 9.8-12.9 19.9-24.9 29.9-35.8zM140.2 57c16.8-9.8 54.1 4.2 93.4 39 2.5 2.2 5 4.6 7.6 7-15.5 16.7-29.8 34.5-42.9 53.1-22.6 2-45 5.5-67.2 10.4-1.3-5.1-2.4-10.3-3.5-15.5-9.4-48.4-3.2-84.9 12.6-94zm-24.5 263.6c-4.2-1.2-8.3-2.5-12.4-3.9-21.3-6.7-45.5-17.3-63-31.2-10.1-7-16.9-17.8-18.8-29.9 0-18.3 31.6-41.7 77.2-57.6 5.7-2 11.5-3.8 17.3-5.5 6.8 21.7 15 43 24.5 63.6-9.6 20.9-17.9 42.5-24.8 64.5zm116.6 98c-16.5 15.1-35.6 27.1-56.4 35.3-11.1 5.3-23.9 5.8-35.3 1.3-15.9-9.2-22.5-44.5-13.5-92 1.1-5.6 2.3-11.2 3.7-16.7 22.4 4.8 45 8.1 67.9 9.8 13.2 18.7 27.7 36.6 43.2 53.4-3.2 3.1-6.4 6.1-9.6 8.9zm24.5-24.3c-10.2-11-20.4-23.2-30.3-36.3 9.6.4 19.5.6 29.5.6 10.3 0 20.4-.2 30.4-.7-9.2 12.7-19.1 24.8-29.6 36.4zm130.7 30c-.9 12.2-6.9 23.6-16.5 31.3-15.9 9.2-49.8-2.8-86.4-34.2-4.2-3.6-8.4-7.5-12.7-11.5 15.3-16.9 29.4-34.8 42.2-53.6 22.9-1.9 45.7-5.4 68.2-10.5 1 4.1 1.9 8.2 2.7 12.2 4.9 21.6 5.7 44.1 2.5 66.3zm18.2-107.5c-2.8.9-5.6 1.8-8.5 2.6-7-21.8-15.6-43.1-25.5-63.8 9.6-20.4 17.7-41.4 24.5-62.9 5.2 1.5 10.2 3.1 15 4.7 46.6 16 79.3 39.8 79.3 58 0 19.6-34.9 44.9-84.8 61.4zm-149.7-15c25.3 0 45.8-20.5 45.8-45.8s-20.5-45.8-45.8-45.8c-25.3 0-45.8 20.5-45.8 45.8s20.5 45.8 45.8 45.8z"},"child":[]}]})(props);
}function FaSteamSymbol (props) {
  return GenIcon({"tag":"svg","attr":{"viewBox":"0 0 448 512"},"child":[{"tag":"path","attr":{"d":"M395.5 177.5c0 33.8-27.5 61-61 61-33.8 0-61-27.3-61-61s27.3-61 61-61c33.5 0 61 27.2 61 61zm52.5.2c0 63-51 113.8-113.7 113.8L225 371.3c-4 43-40.5 76.8-84.5 76.8-40.5 0-74.7-28.8-83-67L0 358V250.7L97.2 290c15.1-9.2 32.2-13.3 52-11.5l71-101.7c.5-62.3 51.5-112.8 114-112.8C397 64 448 115 448 177.7zM203 363c0-34.7-27.8-62.5-62.5-62.5-4.5 0-9 .5-13.5 1.5l26 10.5c25.5 10.2 38 39 27.7 64.5-10.2 25.5-39.2 38-64.7 27.5-10.2-4-20.5-8.3-30.7-12.2 10.5 19.7 31.2 33.2 55.2 33.2 34.7 0 62.5-27.8 62.5-62.5zm207.5-185.3c0-42-34.3-76.2-76.2-76.2-42.3 0-76.5 34.2-76.5 76.2 0 42.2 34.3 76.2 76.5 76.2 41.9.1 76.2-33.9 76.2-76.2z"},"child":[]}]})(props);
}function FaArrowDown (props) {
  return GenIcon({"tag":"svg","attr":{"viewBox":"0 0 448 512"},"child":[{"tag":"path","attr":{"d":"M413.1 222.5l22.2 22.2c9.4 9.4 9.4 24.6 0 33.9L241 473c-9.4 9.4-24.6 9.4-33.9 0L12.7 278.6c-9.4-9.4-9.4-24.6 0-33.9l22.2-22.2c9.5-9.5 25-9.3 34.3.4L184 343.4V56c0-13.3 10.7-24 24-24h32c13.3 0 24 10.7 24 24v287.4l114.8-120.5c9.3-9.8 24.8-10 34.3-.4z"},"child":[]}]})(props);
}function FaArrowLeft (props) {
  return GenIcon({"tag":"svg","attr":{"viewBox":"0 0 448 512"},"child":[{"tag":"path","attr":{"d":"M257.5 445.1l-22.2 22.2c-9.4 9.4-24.6 9.4-33.9 0L7 273c-9.4-9.4-9.4-24.6 0-33.9L201.4 44.7c9.4-9.4 24.6-9.4 33.9 0l22.2 22.2c9.5 9.5 9.3 25-.4 34.3L136.6 216H424c13.3 0 24 10.7 24 24v32c0 13.3-10.7 24-24 24H136.6l120.5 114.8c9.8 9.3 10 24.8.4 34.3z"},"child":[]}]})(props);
}function FaArrowUp (props) {
  return GenIcon({"tag":"svg","attr":{"viewBox":"0 0 448 512"},"child":[{"tag":"path","attr":{"d":"M34.9 289.5l-22.2-22.2c-9.4-9.4-9.4-24.6 0-33.9L207 39c9.4-9.4 24.6-9.4 33.9 0l194.3 194.3c9.4 9.4 9.4 24.6 0 33.9L413 289.4c-9.5 9.5-25 9.3-34.3-.4L264 168.6V456c0 13.3-10.7 24-24 24h-32c-13.3 0-24-10.7-24-24V168.6L69.2 289.1c-9.3 9.8-24.8 10-34.3.4z"},"child":[]}]})(props);
}function FaBan (props) {
  return GenIcon({"tag":"svg","attr":{"viewBox":"0 0 512 512"},"child":[{"tag":"path","attr":{"d":"M256 8C119.034 8 8 119.033 8 256s111.034 248 248 248 248-111.034 248-248S392.967 8 256 8zm130.108 117.892c65.448 65.448 70 165.481 20.677 235.637L150.47 105.216c70.204-49.356 170.226-44.735 235.638 20.676zM125.892 386.108c-65.448-65.448-70-165.481-20.677-235.637L361.53 406.784c-70.203 49.356-170.226 44.736-235.638-20.676z"},"child":[]}]})(props);
}function FaCheck (props) {
  return GenIcon({"tag":"svg","attr":{"viewBox":"0 0 512 512"},"child":[{"tag":"path","attr":{"d":"M173.898 439.404l-166.4-166.4c-9.997-9.997-9.997-26.206 0-36.204l36.203-36.204c9.997-9.998 26.207-9.998 36.204 0L192 312.69 432.095 72.596c9.997-9.997 26.207-9.997 36.204 0l36.203 36.204c9.997 9.997 9.997 26.206 0 36.204l-294.4 294.401c-9.998 9.997-26.207 9.997-36.204-.001z"},"child":[]}]})(props);
}function FaChevronDown (props) {
  return GenIcon({"tag":"svg","attr":{"viewBox":"0 0 448 512"},"child":[{"tag":"path","attr":{"d":"M207.029 381.476L12.686 187.132c-9.373-9.373-9.373-24.569 0-33.941l22.667-22.667c9.357-9.357 24.522-9.375 33.901-.04L224 284.505l154.745-154.021c9.379-9.335 24.544-9.317 33.901.04l22.667 22.667c9.373 9.373 9.373 24.569 0 33.941L240.971 381.476c-9.373 9.372-24.569 9.372-33.942 0z"},"child":[]}]})(props);
}function FaCode (props) {
  return GenIcon({"tag":"svg","attr":{"viewBox":"0 0 640 512"},"child":[{"tag":"path","attr":{"d":"M278.9 511.5l-61-17.7c-6.4-1.8-10-8.5-8.2-14.9L346.2 8.7c1.8-6.4 8.5-10 14.9-8.2l61 17.7c6.4 1.8 10 8.5 8.2 14.9L293.8 503.3c-1.9 6.4-8.5 10.1-14.9 8.2zm-114-112.2l43.5-46.4c4.6-4.9 4.3-12.7-.8-17.2L117 256l90.6-79.7c5.1-4.5 5.5-12.3.8-17.2l-43.5-46.4c-4.5-4.8-12.1-5.1-17-.5L3.8 247.2c-5.1 4.7-5.1 12.8 0 17.5l144.1 135.1c4.9 4.6 12.5 4.4 17-.5zm327.2.6l144.1-135.1c5.1-4.7 5.1-12.8 0-17.5L492.1 112.1c-4.8-4.5-12.4-4.3-17 .5L431.6 159c-4.6 4.9-4.3 12.7.8 17.2L523 256l-90.6 79.7c-5.1 4.5-5.5 12.3-.8 17.2l43.5 46.4c4.5 4.9 12.1 5.1 17 .6z"},"child":[]}]})(props);
}function FaDownload (props) {
  return GenIcon({"tag":"svg","attr":{"viewBox":"0 0 512 512"},"child":[{"tag":"path","attr":{"d":"M216 0h80c13.3 0 24 10.7 24 24v168h87.7c17.8 0 26.7 21.5 14.1 34.1L269.7 378.3c-7.5 7.5-19.8 7.5-27.3 0L90.1 226.1c-12.6-12.6-3.7-34.1 14.1-34.1H192V24c0-13.3 10.7-24 24-24zm296 376v112c0 13.3-10.7 24-24 24H24c-13.3 0-24-10.7-24-24V376c0-13.3 10.7-24 24-24h146.7l49 49c20.1 20.1 52.5 20.1 72.6 0l49-49H488c13.3 0 24 10.7 24 24zm-124 88c0-11-9-20-20-20s-20 9-20 20 9 20 20 20 20-9 20-20zm64 0c0-11-9-20-20-20s-20 9-20 20 9 20 20 20 20-9 20-20z"},"child":[]}]})(props);
}function FaEllipsisH (props) {
  return GenIcon({"tag":"svg","attr":{"viewBox":"0 0 512 512"},"child":[{"tag":"path","attr":{"d":"M328 256c0 39.8-32.2 72-72 72s-72-32.2-72-72 32.2-72 72-72 72 32.2 72 72zm104-72c-39.8 0-72 32.2-72 72s32.2 72 72 72 72-32.2 72-72-32.2-72-72-72zm-352 0c-39.8 0-72 32.2-72 72s32.2 72 72 72 72-32.2 72-72-32.2-72-72-72z"},"child":[]}]})(props);
}function FaExclamationCircle (props) {
  return GenIcon({"tag":"svg","attr":{"viewBox":"0 0 512 512"},"child":[{"tag":"path","attr":{"d":"M504 256c0 136.997-111.043 248-248 248S8 392.997 8 256C8 119.083 119.043 8 256 8s248 111.083 248 248zm-248 50c-25.405 0-46 20.595-46 46s20.595 46 46 46 46-20.595 46-46-20.595-46-46-46zm-43.673-165.346l7.418 136c.347 6.364 5.609 11.346 11.982 11.346h48.546c6.373 0 11.635-4.982 11.982-11.346l7.418-136c.375-6.874-5.098-12.654-11.982-12.654h-63.383c-6.884 0-12.356 5.78-11.981 12.654z"},"child":[]}]})(props);
}function FaExclamationTriangle (props) {
  return GenIcon({"tag":"svg","attr":{"viewBox":"0 0 576 512"},"child":[{"tag":"path","attr":{"d":"M569.517 440.013C587.975 472.007 564.806 512 527.94 512H48.054c-36.937 0-59.999-40.055-41.577-71.987L246.423 23.985c18.467-32.009 64.72-31.951 83.154 0l239.94 416.028zM288 354c-25.405 0-46 20.595-46 46s20.595 46 46 46 46-20.595 46-46-20.595-46-46-46zm-43.673-165.346l7.418 136c.347 6.364 5.609 11.346 11.982 11.346h48.546c6.373 0 11.635-4.982 11.982-11.346l7.418-136c.375-6.874-5.098-12.654-11.982-12.654h-63.383c-6.884 0-12.356 5.78-11.981 12.654z"},"child":[]}]})(props);
}function FaExclamation (props) {
  return GenIcon({"tag":"svg","attr":{"viewBox":"0 0 192 512"},"child":[{"tag":"path","attr":{"d":"M176 432c0 44.112-35.888 80-80 80s-80-35.888-80-80 35.888-80 80-80 80 35.888 80 80zM25.26 25.199l13.6 272C39.499 309.972 50.041 320 62.83 320h66.34c12.789 0 23.331-10.028 23.97-22.801l13.6-272C167.425 11.49 156.496 0 142.77 0H49.23C35.504 0 24.575 11.49 25.26 25.199z"},"child":[]}]})(props);
}function FaEyeSlash (props) {
  return GenIcon({"tag":"svg","attr":{"viewBox":"0 0 640 512"},"child":[{"tag":"path","attr":{"d":"M320 400c-75.85 0-137.25-58.71-142.9-133.11L72.2 185.82c-13.79 17.3-26.48 35.59-36.72 55.59a32.35 32.35 0 0 0 0 29.19C89.71 376.41 197.07 448 320 448c26.91 0 52.87-4 77.89-10.46L346 397.39a144.13 144.13 0 0 1-26 2.61zm313.82 58.1l-110.55-85.44a331.25 331.25 0 0 0 81.25-102.07 32.35 32.35 0 0 0 0-29.19C550.29 135.59 442.93 64 320 64a308.15 308.15 0 0 0-147.32 37.7L45.46 3.37A16 16 0 0 0 23 6.18L3.37 31.45A16 16 0 0 0 6.18 53.9l588.36 454.73a16 16 0 0 0 22.46-2.81l19.64-25.27a16 16 0 0 0-2.82-22.45zm-183.72-142l-39.3-30.38A94.75 94.75 0 0 0 416 256a94.76 94.76 0 0 0-121.31-92.21A47.65 47.65 0 0 1 304 192a46.64 46.64 0 0 1-1.54 10l-73.61-56.89A142.31 142.31 0 0 1 320 112a143.92 143.92 0 0 1 144 144c0 21.63-5.29 41.79-13.9 60.11z"},"child":[]}]})(props);
}function FaFileArchive (props) {
  return GenIcon({"tag":"svg","attr":{"viewBox":"0 0 384 512"},"child":[{"tag":"path","attr":{"d":"M377 105L279.1 7c-4.5-4.5-10.6-7-17-7H256v128h128v-6.1c0-6.3-2.5-12.4-7-16.9zM128.4 336c-17.9 0-32.4 12.1-32.4 27 0 15 14.6 27 32.5 27s32.4-12.1 32.4-27-14.6-27-32.5-27zM224 136V0h-63.6v32h-32V0H24C10.7 0 0 10.7 0 24v464c0 13.3 10.7 24 24 24h336c13.3 0 24-10.7 24-24V160H248c-13.2 0-24-10.8-24-24zM95.9 32h32v32h-32zm32.3 384c-33.2 0-58-30.4-51.4-62.9L96.4 256v-32h32v-32h-32v-32h32v-32h-32V96h32V64h32v32h-32v32h32v32h-32v32h32v32h-32v32h22.1c5.7 0 10.7 4.1 11.8 9.7l17.3 87.7c6.4 32.4-18.4 62.6-51.4 62.6z"},"child":[]}]})(props);
}function FaFlask (props) {
  return GenIcon({"tag":"svg","attr":{"viewBox":"0 0 448 512"},"child":[{"tag":"path","attr":{"d":"M437.2 403.5L320 215V64h8c13.3 0 24-10.7 24-24V24c0-13.3-10.7-24-24-24H120c-13.3 0-24 10.7-24 24v16c0 13.3 10.7 24 24 24h8v151L10.8 403.5C-18.5 450.6 15.3 512 70.9 512h306.2c55.7 0 89.4-61.5 60.1-108.5zM137.9 320l48.2-77.6c3.7-5.2 5.8-11.6 5.8-18.4V64h64v160c0 6.9 2.2 13.2 5.8 18.4l48.2 77.6h-172z"},"child":[]}]})(props);
}function FaFolder (props) {
  return GenIcon({"tag":"svg","attr":{"viewBox":"0 0 512 512"},"child":[{"tag":"path","attr":{"d":"M464 128H272l-64-64H48C21.49 64 0 85.49 0 112v288c0 26.51 21.49 48 48 48h416c26.51 0 48-21.49 48-48V176c0-26.51-21.49-48-48-48z"},"child":[]}]})(props);
}function FaInfo (props) {
  return GenIcon({"tag":"svg","attr":{"viewBox":"0 0 192 512"},"child":[{"tag":"path","attr":{"d":"M20 424.229h20V279.771H20c-11.046 0-20-8.954-20-20V212c0-11.046 8.954-20 20-20h112c11.046 0 20 8.954 20 20v212.229h20c11.046 0 20 8.954 20 20V492c0 11.046-8.954 20-20 20H20c-11.046 0-20-8.954-20-20v-47.771c0-11.046 8.954-20 20-20zM96 0C56.235 0 24 32.235 24 72s32.235 72 72 72 72-32.235 72-72S135.764 0 96 0z"},"child":[]}]})(props);
}function FaLink (props) {
  return GenIcon({"tag":"svg","attr":{"viewBox":"0 0 512 512"},"child":[{"tag":"path","attr":{"d":"M326.612 185.391c59.747 59.809 58.927 155.698.36 214.59-.11.12-.24.25-.36.37l-67.2 67.2c-59.27 59.27-155.699 59.262-214.96 0-59.27-59.26-59.27-155.7 0-214.96l37.106-37.106c9.84-9.84 26.786-3.3 27.294 10.606.648 17.722 3.826 35.527 9.69 52.721 1.986 5.822.567 12.262-3.783 16.612l-13.087 13.087c-28.026 28.026-28.905 73.66-1.155 101.96 28.024 28.579 74.086 28.749 102.325.51l67.2-67.19c28.191-28.191 28.073-73.757 0-101.83-3.701-3.694-7.429-6.564-10.341-8.569a16.037 16.037 0 0 1-6.947-12.606c-.396-10.567 3.348-21.456 11.698-29.806l21.054-21.055c5.521-5.521 14.182-6.199 20.584-1.731a152.482 152.482 0 0 1 20.522 17.197zM467.547 44.449c-59.261-59.262-155.69-59.27-214.96 0l-67.2 67.2c-.12.12-.25.25-.36.37-58.566 58.892-59.387 154.781.36 214.59a152.454 152.454 0 0 0 20.521 17.196c6.402 4.468 15.064 3.789 20.584-1.731l21.054-21.055c8.35-8.35 12.094-19.239 11.698-29.806a16.037 16.037 0 0 0-6.947-12.606c-2.912-2.005-6.64-4.875-10.341-8.569-28.073-28.073-28.191-73.639 0-101.83l67.2-67.19c28.239-28.239 74.3-28.069 102.325.51 27.75 28.3 26.872 73.934-1.155 101.96l-13.087 13.087c-4.35 4.35-5.769 10.79-3.783 16.612 5.864 17.194 9.042 34.999 9.69 52.721.509 13.906 17.454 20.446 27.294 10.606l37.106-37.106c59.271-59.259 59.271-155.699.001-214.959z"},"child":[]}]})(props);
}function FaLock (props) {
  return GenIcon({"tag":"svg","attr":{"viewBox":"0 0 448 512"},"child":[{"tag":"path","attr":{"d":"M400 224h-24v-72C376 68.2 307.8 0 224 0S72 68.2 72 152v72H48c-26.5 0-48 21.5-48 48v192c0 26.5 21.5 48 48 48h352c26.5 0 48-21.5 48-48V272c0-26.5-21.5-48-48-48zm-104 0H152v-72c0-39.7 32.3-72 72-72s72 32.3 72 72v72z"},"child":[]}]})(props);
}function FaPlug (props) {
  return GenIcon({"tag":"svg","attr":{"viewBox":"0 0 384 512"},"child":[{"tag":"path","attr":{"d":"M320,32a32,32,0,0,0-64,0v96h64Zm48,128H16A16,16,0,0,0,0,176v32a16,16,0,0,0,16,16H32v32A160.07,160.07,0,0,0,160,412.8V512h64V412.8A160.07,160.07,0,0,0,352,256V224h16a16,16,0,0,0,16-16V176A16,16,0,0,0,368,160ZM128,32a32,32,0,0,0-64,0v96h64Z"},"child":[]}]})(props);
}function FaQuestionCircle (props) {
  return GenIcon({"tag":"svg","attr":{"viewBox":"0 0 512 512"},"child":[{"tag":"path","attr":{"d":"M504 256c0 136.997-111.043 248-248 248S8 392.997 8 256C8 119.083 119.043 8 256 8s248 111.083 248 248zM262.655 90c-54.497 0-89.255 22.957-116.549 63.758-3.536 5.286-2.353 12.415 2.715 16.258l34.699 26.31c5.205 3.947 12.621 3.008 16.665-2.122 17.864-22.658 30.113-35.797 57.303-35.797 20.429 0 45.698 13.148 45.698 32.958 0 14.976-12.363 22.667-32.534 33.976C247.128 238.528 216 254.941 216 296v4c0 6.627 5.373 12 12 12h56c6.627 0 12-5.373 12-12v-1.333c0-28.462 83.186-29.647 83.186-106.667 0-58.002-60.165-102-116.531-102zM256 338c-25.365 0-46 20.635-46 46 0 25.364 20.635 46 46 46s46-20.636 46-46c0-25.365-20.635-46-46-46z"},"child":[]}]})(props);
}function FaRecycle (props) {
  return GenIcon({"tag":"svg","attr":{"viewBox":"0 0 512 512"},"child":[{"tag":"path","attr":{"d":"M184.561 261.903c3.232 13.997-12.123 24.635-24.068 17.168l-40.736-25.455-50.867 81.402C55.606 356.273 70.96 384 96.012 384H148c6.627 0 12 5.373 12 12v40c0 6.627-5.373 12-12 12H96.115c-75.334 0-121.302-83.048-81.408-146.88l50.822-81.388-40.725-25.448c-12.081-7.547-8.966-25.961 4.879-29.158l110.237-25.45c8.611-1.988 17.201 3.381 19.189 11.99l25.452 110.237zm98.561-182.915l41.289 66.076-40.74 25.457c-12.051 7.528-9 25.953 4.879 29.158l110.237 25.45c8.672 1.999 17.215-3.438 19.189-11.99l25.45-110.237c3.197-13.844-11.99-24.719-24.068-17.168l-40.687 25.424-41.263-66.082c-37.521-60.033-125.209-60.171-162.816 0l-17.963 28.766c-3.51 5.62-1.8 13.021 3.82 16.533l33.919 21.195c5.62 3.512 13.024 1.803 16.536-3.817l17.961-28.743c12.712-20.341 41.973-19.676 54.257-.022zM497.288 301.12l-27.515-44.065c-3.511-5.623-10.916-7.334-16.538-3.821l-33.861 21.159c-5.62 3.512-7.33 10.915-3.818 16.536l27.564 44.112c13.257 21.211-2.057 48.96-27.136 48.96H320V336.02c0-14.213-17.242-21.383-27.313-11.313l-80 79.981c-6.249 6.248-6.249 16.379 0 22.627l80 79.989C302.689 517.308 320 510.3 320 495.989V448h95.88c75.274 0 121.335-82.997 81.408-146.88z"},"child":[]}]})(props);
}function FaShapes (props) {
  return GenIcon({"tag":"svg","attr":{"viewBox":"0 0 512 512"},"child":[{"tag":"path","attr":{"d":"M128,256A128,128,0,1,0,256,384,128,128,0,0,0,128,256Zm379-54.86L400.07,18.29a37.26,37.26,0,0,0-64.14,0L229,201.14C214.76,225.52,232.58,256,261.09,256H474.91C503.42,256,521.24,225.52,507,201.14ZM480,288H320a32,32,0,0,0-32,32V480a32,32,0,0,0,32,32H480a32,32,0,0,0,32-32V320A32,32,0,0,0,480,288Z"},"child":[]}]})(props);
}function FaStore (props) {
  return GenIcon({"tag":"svg","attr":{"viewBox":"0 0 616 512"},"child":[{"tag":"path","attr":{"d":"M602 118.6L537.1 15C531.3 5.7 521 0 510 0H106C95 0 84.7 5.7 78.9 15L14 118.6c-33.5 53.5-3.8 127.9 58.8 136.4 4.5.6 9.1.9 13.7.9 29.6 0 55.8-13 73.8-33.1 18 20.1 44.3 33.1 73.8 33.1 29.6 0 55.8-13 73.8-33.1 18 20.1 44.3 33.1 73.8 33.1 29.6 0 55.8-13 73.8-33.1 18.1 20.1 44.3 33.1 73.8 33.1 4.7 0 9.2-.3 13.7-.9 62.8-8.4 92.6-82.8 59-136.4zM529.5 288c-10 0-19.9-1.5-29.5-3.8V384H116v-99.8c-9.6 2.2-19.5 3.8-29.5 3.8-6 0-12.1-.4-18-1.2-5.6-.8-11.1-2.1-16.4-3.6V480c0 17.7 14.3 32 32 32h448c17.7 0 32-14.3 32-32V283.2c-5.4 1.6-10.8 2.9-16.4 3.6-6.1.8-12.1 1.2-18.2 1.2z"},"child":[]}]})(props);
}function FaTerminal (props) {
  return GenIcon({"tag":"svg","attr":{"viewBox":"0 0 640 512"},"child":[{"tag":"path","attr":{"d":"M257.981 272.971L63.638 467.314c-9.373 9.373-24.569 9.373-33.941 0L7.029 444.647c-9.357-9.357-9.375-24.522-.04-33.901L161.011 256 6.99 101.255c-9.335-9.379-9.317-24.544.04-33.901l22.667-22.667c9.373-9.373 24.569-9.373 33.941 0L257.981 239.03c9.373 9.372 9.373 24.568 0 33.941zM640 456v-32c0-13.255-10.745-24-24-24H312c-13.255 0-24 10.745-24 24v32c0 13.255 10.745 24 24 24h304c13.255 0 24-10.745 24-24z"},"child":[]}]})(props);
}function FaUserSlash (props) {
  return GenIcon({"tag":"svg","attr":{"viewBox":"0 0 640 512"},"child":[{"tag":"path","attr":{"d":"M633.8 458.1L362.3 248.3C412.1 230.7 448 183.8 448 128 448 57.3 390.7 0 320 0c-67.1 0-121.5 51.8-126.9 117.4L45.5 3.4C38.5-2 28.5-.8 23 6.2L3.4 31.4c-5.4 7-4.2 17 2.8 22.4l588.4 454.7c7 5.4 17 4.2 22.5-2.8l19.6-25.3c5.4-6.8 4.1-16.9-2.9-22.3zM96 422.4V464c0 26.5 21.5 48 48 48h350.2L207.4 290.3C144.2 301.3 96 356 96 422.4z"},"child":[]}]})(props);
}

const DeckyIcon = (props) => (SP_JSX.jsx("svg", { xmlns: "http://www.w3.org/2000/svg", height: "100%", width: "100%", viewBox: "0 0 512 456", ...props, children: SP_JSX.jsxs("g", { children: [SP_JSX.jsx("path", { style: { fill: 'none' }, d: "M154.33,72.51v49.79c11.78-0.17,23.48,2,34.42,6.39c10.93,4.39,20.89,10.91,29.28,19.18\r\n        c8.39,8.27,15.06,18.13,19.61,29c4.55,10.87,6.89,22.54,6.89,34.32c0,11.78-2.34,23.45-6.89,34.32\r\n        c-4.55,10.87-11.21,20.73-19.61,29c-8.39,8.27-18.35,14.79-29.28,19.18c-10.94,4.39-22.63,6.56-34.42,6.39v49.77\r\n        c36.78,0,72.05-14.61,98.05-40.62c26-26.01,40.61-61.28,40.61-98.05c0-36.78-14.61-72.05-40.61-98.05\r\n        C226.38,87.12,191.11,72.51,154.33,72.51z" }), SP_JSX.jsx("ellipse", { transform: "matrix(0.982 -0.1891 0.1891 0.982 -37.1795 32.9988)", style: { fill: 'none' }, cx: "154.33", cy: "211.33", rx: "69.33", ry: "69.33" }), SP_JSX.jsx("path", { style: { fill: 'none' }, d: "M430,97h-52v187h52c7.18,0,13-5.82,13-13V110C443,102.82,437.18,97,430,97z" }), SP_JSX.jsx("path", { style: { fill: 'currentColor' }, d: "M432,27h-54V0H0v361c0,52.47,42.53,95,95,95h188c52.47,0,95-42.53,95-95v-7h54c44.18,0,80-35.82,80-80V107\r\n        C512,62.82,476.18,27,432,27z M85,211.33c0-38.29,31.04-69.33,69.33-69.33c38.29,0,69.33,31.04,69.33,69.33\r\n        c0,38.29-31.04,69.33-69.33,69.33C116.04,280.67,85,249.62,85,211.33z M252.39,309.23c-26.01,26-61.28,40.62-98.05,40.62v-49.77\r\n        c11.78,0.17,23.48-2,34.42-6.39c10.93-4.39,20.89-10.91,29.28-19.18c8.39-8.27,15.06-18.13,19.61-29\r\n        c4.55-10.87,6.89-22.53,6.89-34.32c0-11.78-2.34-23.45-6.89-34.32c-4.55-10.87-11.21-20.73-19.61-29\r\n        c-8.39-8.27-18.35-14.79-29.28-19.18c-10.94-4.39-22.63-6.56-34.42-6.39V72.51c36.78,0,72.05,14.61,98.05,40.61\r\n        c26,26.01,40.61,61.28,40.61,98.05C293,247.96,278.39,283.23,252.39,309.23z M443,271c0,7.18-5.82,13-13,13h-52V97h52\r\n        c7.18,0,13,5.82,13,13V271z" })] }) }));

async function getSetting(key, def) {
    const res = await DeckyBackend.call('utilities/settings/get', key, def);
    return res;
}
async function setSetting(key, value) {
    await DeckyBackend.call('utilities/settings/set', key, value);
}

const DEFAULT_NOTIFICATION_SETTINGS = {
    deckyUpdates: true,
    pluginUpdates: true,
};
/**
 * A Service class for managing the notification settings
 *
 * It's mostly responsible for sending setting updates to the server and keeping the local state in sync.
 */
class NotificationService {
    constructor(deckyState) {
        this.deckyState = deckyState;
    }
    async init() {
        const notificationSettings = await getSetting('notificationSettings', {});
        // Adding a fallback to the default settings to be backwards compatible if we ever add new notification settings
        this.deckyState.setNotificationSettings({
            ...DEFAULT_NOTIFICATION_SETTINGS,
            ...notificationSettings,
        });
    }
    /**
     * Sends the new notification settings to the server and persists it locally in the decky state
     *
     * @param notificationSettings The new notification settings
     */
    async update(notificationSettings) {
        await setSetting('notificationSettings', notificationSettings);
        this.deckyState.setNotificationSettings(notificationSettings);
    }
    /**
     * For a specific event, returns true if a notification should be shown
     *
     * @param event The notification event that should be checked
     * @returns true if the notification should be shown
     */
    shouldNotify(event) {
        return this.deckyState.publicState().notificationSettings[event];
    }
}

class DeckyState {
    constructor() {
        this._plugins = [];
        this._disabledPlugins = [];
        this._installedPlugins = [];
        this._pluginOrder = [];
        this._sortPlugins = false;
        this._frozenPlugins = [];
        this._hiddenPlugins = [];
        this._activePlugin = null;
        this._updates = null;
        this._hasLoaderUpdate = false;
        this._isLoaderUpdating = false;
        this._versionInfo = null;
        this._notificationSettings = DEFAULT_NOTIFICATION_SETTINGS;
        this._userInfo = null;
        this.eventBus = new EventTarget();
    }
    publicState() {
        return {
            plugins: this._plugins,
            disabledPlugins: this._disabledPlugins,
            installedPlugins: this._installedPlugins,
            pluginOrder: this._pluginOrder,
            sortPlugins: this._sortPlugins,
            frozenPlugins: this._frozenPlugins,
            hiddenPlugins: this._hiddenPlugins,
            activePlugin: this._activePlugin,
            updates: this._updates,
            hasLoaderUpdate: this._hasLoaderUpdate,
            isLoaderUpdating: this._isLoaderUpdating,
            versionInfo: this._versionInfo,
            notificationSettings: this._notificationSettings,
            userInfo: this._userInfo,
        };
    }
    setVersionInfo(versionInfo) {
        this._versionInfo = versionInfo;
        this.notifyUpdate();
    }
    setPlugins(plugins) {
        this._plugins = plugins;
        this._installedPlugins = [...plugins, ...this._disabledPlugins];
        this.notifyUpdate();
    }
    setDisabledPlugins(disabledPlugins) {
        this._disabledPlugins = disabledPlugins;
        this._installedPlugins = [...this._plugins, ...disabledPlugins];
        this.notifyUpdate();
    }
    setPluginOrder(pluginOrder) {
        this._pluginOrder = pluginOrder;
        this.notifyUpdate();
    }
    setSortPlugins(sortPlugins) {
        this._sortPlugins = sortPlugins;
        this.notifyUpdate();
    }
    setFrozenPlugins(frozenPlugins) {
        this._frozenPlugins = frozenPlugins;
        this.notifyUpdate();
    }
    setHiddenPlugins(hiddenPlugins) {
        this._hiddenPlugins = hiddenPlugins;
        this.notifyUpdate();
    }
    setActivePlugin(name) {
        this._activePlugin = this._plugins.find((plugin) => plugin.name === name) ?? null;
        this.notifyUpdate();
    }
    closeActivePlugin() {
        this._activePlugin = null;
        this.notifyUpdate();
    }
    setUpdates(updates) {
        this._updates = updates;
        this.notifyUpdate();
    }
    setHasLoaderUpdate(hasUpdate) {
        this._hasLoaderUpdate = hasUpdate;
        this.notifyUpdate();
    }
    setIsLoaderUpdating(isUpdating) {
        this._isLoaderUpdating = isUpdating;
        this.notifyUpdate();
    }
    setNotificationSettings(notificationSettings) {
        this._notificationSettings = notificationSettings;
        this.notifyUpdate();
    }
    setUserInfo(userInfo) {
        this._userInfo = userInfo;
        this.notifyUpdate();
    }
    notifyUpdate() {
        this.eventBus.dispatchEvent(new Event('update'));
    }
}
const DeckyStateContext = SP_REACT.createContext(null);
const useDeckyState = () => {
    const deckyState = SP_REACT.useContext(DeckyStateContext);
    if (deckyState === null) {
        throw new Error('useDeckyState needs a parent DeckyStateContext');
    }
    return deckyState;
};
const DeckyStateContextProvider = ({ children, deckyState }) => {
    const [publicDeckyState, setPublicDeckyState] = SP_REACT.useState({ ...deckyState.publicState() });
    SP_REACT.useEffect(() => {
        function onUpdate() {
            setPublicDeckyState({ ...deckyState.publicState() });
        }
        deckyState.eventBus.addEventListener('update', onUpdate);
        return () => deckyState.eventBus.removeEventListener('update', onUpdate);
    }, []);
    const setIsLoaderUpdating = deckyState.setIsLoaderUpdating.bind(deckyState);
    const setVersionInfo = deckyState.setVersionInfo.bind(deckyState);
    const setActivePlugin = deckyState.setActivePlugin.bind(deckyState);
    const closeActivePlugin = deckyState.closeActivePlugin.bind(deckyState);
    const setPluginOrder = deckyState.setPluginOrder.bind(deckyState);
    const setDisabledPlugins = deckyState.setDisabledPlugins.bind(deckyState);
    const setSortPlugins = deckyState.setSortPlugins.bind(deckyState);
    return (SP_JSX.jsx(DeckyStateContext.Provider, { value: {
            ...publicDeckyState,
            setIsLoaderUpdating,
            setVersionInfo,
            setActivePlugin,
            closeActivePlugin,
            setPluginOrder,
            setDisabledPlugins,
            setSortPlugins,
        }, children: children }));
};

/**
 * filesize
 *
 * @copyright 2024 Jason Mulligan <jason.mulligan@avoidwork.com>
 * @license BSD-3-Clause
 * @version 10.1.2
 */
const ARRAY = "array";
const BIT = "bit";
const BITS = "bits";
const BYTE = "byte";
const BYTES = "bytes";
const EMPTY = "";
const EXPONENT = "exponent";
const FUNCTION = "function";
const IEC = "iec";
const INVALID_NUMBER = "Invalid number";
const INVALID_ROUND = "Invalid rounding method";
const JEDEC = "jedec";
const OBJECT = "object";
const PERIOD = ".";
const ROUND = "round";
const S$1 = "s";
const SI = "si";
const SI_KBIT = "kbit";
const SI_KBYTE = "kB";
const SPACE = " ";
const STRING = "string";
const ZERO = "0";
const STRINGS = {
	symbol: {
		iec: {
			bits: ["bit", "Kibit", "Mibit", "Gibit", "Tibit", "Pibit", "Eibit", "Zibit", "Yibit"],
			bytes: ["B", "KiB", "MiB", "GiB", "TiB", "PiB", "EiB", "ZiB", "YiB"]
		},
		jedec: {
			bits: ["bit", "Kbit", "Mbit", "Gbit", "Tbit", "Pbit", "Ebit", "Zbit", "Ybit"],
			bytes: ["B", "KB", "MB", "GB", "TB", "PB", "EB", "ZB", "YB"]
		}
	},
	fullform: {
		iec: ["", "kibi", "mebi", "gibi", "tebi", "pebi", "exbi", "zebi", "yobi"],
		jedec: ["", "kilo", "mega", "giga", "tera", "peta", "exa", "zetta", "yotta"]
	}
};function filesize (arg, {
	bits = false,
	pad = false,
	base = -1,
	round = 2,
	locale = EMPTY,
	localeOptions = {},
	separator = EMPTY,
	spacer = SPACE,
	symbols = {},
	standard = EMPTY,
	output = STRING,
	fullform = false,
	fullforms = [],
	exponent = -1,
	roundingMethod = ROUND,
	precision = 0
} = {}) {
	let e = exponent,
		num = Number(arg),
		result = [],
		val = 0,
		u = EMPTY;

	// Sync base & standard
	if (standard === SI) {
		base = 10;
		standard = JEDEC;
	} else if (standard === IEC || standard === JEDEC) {
		base = 2;
	} else if (base === 2) {
		standard = IEC;
	} else {
		base = 10;
		standard = JEDEC;
	}

	const ceil = base === 10 ? 1000 : 1024,
		full = fullform === true,
		neg = num < 0,
		roundingFunc = Math[roundingMethod];

	if (typeof arg !== "bigint" && isNaN(arg)) {
		throw new TypeError(INVALID_NUMBER);
	}

	if (typeof roundingFunc !== FUNCTION) {
		throw new TypeError(INVALID_ROUND);
	}

	// Flipping a negative number to determine the size
	if (neg) {
		num = -num;
	}

	// Determining the exponent
	if (e === -1 || isNaN(e)) {
		e = Math.floor(Math.log(num) / Math.log(ceil));

		if (e < 0) {
			e = 0;
		}
	}

	// Exceeding supported length, time to reduce & multiply
	if (e > 8) {
		if (precision > 0) {
			precision += 8 - e;
		}

		e = 8;
	}

	if (output === EXPONENT) {
		return e;
	}

	// Zero is now a special case because bytes divide by 1
	if (num === 0) {
		result[0] = 0;
		u = result[1] = STRINGS.symbol[standard][bits ? BITS : BYTES][e];
	} else {
		val = num / (base === 2 ? Math.pow(2, e * 10) : Math.pow(1000, e));

		if (bits) {
			val = val * 8;

			if (val >= ceil && e < 8) {
				val = val / ceil;
				e++;
			}
		}

		const p = Math.pow(10, e > 0 ? round : 0);
		result[0] = roundingFunc(val * p) / p;

		if (result[0] === ceil && e < 8 && exponent === -1) {
			result[0] = 1;
			e++;
		}

		u = result[1] = base === 10 && e === 1 ? bits ? SI_KBIT : SI_KBYTE : STRINGS.symbol[standard][bits ? BITS : BYTES][e];
	}

	// Decorating a 'diff'
	if (neg) {
		result[0] = -result[0];
	}

	// Setting optional precision
	if (precision > 0) {
		result[0] = result[0].toPrecision(precision);
	}

	// Applying custom symbol
	result[1] = symbols[result[1]] || result[1];

	if (locale === true) {
		result[0] = result[0].toLocaleString();
	} else if (locale.length > 0) {
		result[0] = result[0].toLocaleString(locale, localeOptions);
	} else if (separator.length > 0) {
		result[0] = result[0].toString().replace(PERIOD, separator);
	}

	if (pad && Number.isInteger(result[0]) === false && round > 0) {
		const x = separator || PERIOD,
			tmp = result[0].toString().split(x),
			s = tmp[1] || EMPTY,
			l = s.length,
			n = round - l;

		result[0] = `${tmp[0]}${x}${s.padEnd(l + n, ZERO)}`;
	}

	if (full) {
		result[1] = fullforms[e] ? fullforms[e] : STRINGS.fullform[standard][e] + (bits ? BIT : BYTE) + (result[0] === 1 ? EMPTY : S$1);
	}

	// Returning Array, Object, or String (default)
	return output === ARRAY ? result : output === OBJECT ? {
		value: result[0],
		symbol: result[1],
		exponent: e,
		unit: u
	} : result.join(spacer);
}

var propTypes$1 = {exports: {}};

/**
 * Copyright (c) 2013-present, Facebook, Inc.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */

var ReactPropTypesSecret_1;
var hasRequiredReactPropTypesSecret;

function requireReactPropTypesSecret () {
	if (hasRequiredReactPropTypesSecret) return ReactPropTypesSecret_1;
	hasRequiredReactPropTypesSecret = 1;

	var ReactPropTypesSecret = 'SECRET_DO_NOT_PASS_THIS_OR_YOU_WILL_BE_FIRED';

	ReactPropTypesSecret_1 = ReactPropTypesSecret;
	return ReactPropTypesSecret_1;
}

/**
 * Copyright (c) 2013-present, Facebook, Inc.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */

var factoryWithThrowingShims;
var hasRequiredFactoryWithThrowingShims;

function requireFactoryWithThrowingShims () {
	if (hasRequiredFactoryWithThrowingShims) return factoryWithThrowingShims;
	hasRequiredFactoryWithThrowingShims = 1;

	var ReactPropTypesSecret = requireReactPropTypesSecret();

	function emptyFunction() {}
	function emptyFunctionWithReset() {}
	emptyFunctionWithReset.resetWarningCache = emptyFunction;

	factoryWithThrowingShims = function() {
	  function shim(props, propName, componentName, location, propFullName, secret) {
	    if (secret === ReactPropTypesSecret) {
	      // It is still safe when called from React.
	      return;
	    }
	    var err = new Error(
	      'Calling PropTypes validators directly is not supported by the `prop-types` package. ' +
	      'Use PropTypes.checkPropTypes() to call them. ' +
	      'Read more at http://fb.me/use-check-prop-types'
	    );
	    err.name = 'Invariant Violation';
	    throw err;
	  }	  shim.isRequired = shim;
	  function getShim() {
	    return shim;
	  }	  // Important!
	  // Keep this list in sync with production version in `./factoryWithTypeCheckers.js`.
	  var ReactPropTypes = {
	    array: shim,
	    bigint: shim,
	    bool: shim,
	    func: shim,
	    number: shim,
	    object: shim,
	    string: shim,
	    symbol: shim,

	    any: shim,
	    arrayOf: getShim,
	    element: shim,
	    elementType: shim,
	    instanceOf: getShim,
	    node: shim,
	    objectOf: getShim,
	    oneOf: getShim,
	    oneOfType: getShim,
	    shape: getShim,
	    exact: getShim,

	    checkPropTypes: emptyFunctionWithReset,
	    resetWarningCache: emptyFunction
	  };

	  ReactPropTypes.PropTypes = ReactPropTypes;

	  return ReactPropTypes;
	};
	return factoryWithThrowingShims;
}

/**
 * Copyright (c) 2013-present, Facebook, Inc.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */

{
  // By explicitly using `prop-types` you are opting into new production behavior.
  // http://fb.me/prop-types-in-prod
  propTypes$1.exports = requireFactoryWithThrowingShims()();
}

var propTypesExports = propTypes$1.exports;
var PropTypes = /*@__PURE__*/getDefaultExportFromCjs(propTypesExports);

var r={grad:.9,turn:360,rad:360/(2*Math.PI)},t=function(r){return "string"==typeof r?r.length>0:"number"==typeof r},n=function(r,t,n){return void 0===t&&(t=0),void 0===n&&(n=Math.pow(10,t)),Math.round(n*r)/n+0},e=function(r,t,n){return void 0===t&&(t=0),void 0===n&&(n=1),r>n?n:r>t?r:t},u=function(r){return (r=isFinite(r)?r%360:0)>0?r:r+360},a=function(r){return {r:e(r.r,0,255),g:e(r.g,0,255),b:e(r.b,0,255),a:e(r.a)}},o=function(r){return {r:n(r.r),g:n(r.g),b:n(r.b),a:n(r.a,3)}},i=/^#([0-9a-f]{3,8})$/i,s=function(r){var t=r.toString(16);return t.length<2?"0"+t:t},h=function(r){var t=r.r,n=r.g,e=r.b,u=r.a,a=Math.max(t,n,e),o=a-Math.min(t,n,e),i=o?a===t?(n-e)/o:a===n?2+(e-t)/o:4+(t-n)/o:0;return {h:60*(i<0?i+6:i),s:a?o/a*100:0,v:a/255*100,a:u}},b=function(r){var t=r.h,n=r.s,e=r.v,u=r.a;t=t/360*6,n/=100,e/=100;var a=Math.floor(t),o=e*(1-n),i=e*(1-(t-a)*n),s=e*(1-(1-t+a)*n),h=a%6;return {r:255*[e,i,o,o,s,e][h],g:255*[s,e,e,i,o,o][h],b:255*[o,o,s,e,e,i][h],a:u}},g=function(r){return {h:u(r.h),s:e(r.s,0,100),l:e(r.l,0,100),a:e(r.a)}},d=function(r){return {h:n(r.h),s:n(r.s),l:n(r.l),a:n(r.a,3)}},f=function(r){return b((n=(t=r).s,{h:t.h,s:(n*=((e=t.l)<50?e:100-e)/100)>0?2*n/(e+n)*100:0,v:e+n,a:t.a}));var t,n,e;},c=function(r){return {h:(t=h(r)).h,s:(u=(200-(n=t.s))*(e=t.v)/100)>0&&u<200?n*e/100/(u<=100?u:200-u)*100:0,l:u/2,a:t.a};var t,n,e,u;},l=/^hsla?\(\s*([+-]?\d*\.?\d+)(deg|rad|grad|turn)?\s*,\s*([+-]?\d*\.?\d+)%\s*,\s*([+-]?\d*\.?\d+)%\s*(?:,\s*([+-]?\d*\.?\d+)(%)?\s*)?\)$/i,p=/^hsla?\(\s*([+-]?\d*\.?\d+)(deg|rad|grad|turn)?\s+([+-]?\d*\.?\d+)%\s+([+-]?\d*\.?\d+)%\s*(?:\/\s*([+-]?\d*\.?\d+)(%)?\s*)?\)$/i,v=/^rgba?\(\s*([+-]?\d*\.?\d+)(%)?\s*,\s*([+-]?\d*\.?\d+)(%)?\s*,\s*([+-]?\d*\.?\d+)(%)?\s*(?:,\s*([+-]?\d*\.?\d+)(%)?\s*)?\)$/i,m=/^rgba?\(\s*([+-]?\d*\.?\d+)(%)?\s+([+-]?\d*\.?\d+)(%)?\s+([+-]?\d*\.?\d+)(%)?\s*(?:\/\s*([+-]?\d*\.?\d+)(%)?\s*)?\)$/i,y={string:[[function(r){var t=i.exec(r);return t?(r=t[1]).length<=4?{r:parseInt(r[0]+r[0],16),g:parseInt(r[1]+r[1],16),b:parseInt(r[2]+r[2],16),a:4===r.length?n(parseInt(r[3]+r[3],16)/255,2):1}:6===r.length||8===r.length?{r:parseInt(r.substr(0,2),16),g:parseInt(r.substr(2,2),16),b:parseInt(r.substr(4,2),16),a:8===r.length?n(parseInt(r.substr(6,2),16)/255,2):1}:null:null},"hex"],[function(r){var t=v.exec(r)||m.exec(r);return t?t[2]!==t[4]||t[4]!==t[6]?null:a({r:Number(t[1])/(t[2]?100/255:1),g:Number(t[3])/(t[4]?100/255:1),b:Number(t[5])/(t[6]?100/255:1),a:void 0===t[7]?1:Number(t[7])/(t[8]?100:1)}):null},"rgb"],[function(t){var n=l.exec(t)||p.exec(t);if(!n)return null;var e,u,a=g({h:(e=n[1],u=n[2],void 0===u&&(u="deg"),Number(e)*(r[u]||1)),s:Number(n[3]),l:Number(n[4]),a:void 0===n[5]?1:Number(n[5])/(n[6]?100:1)});return f(a)},"hsl"]],object:[[function(r){var n=r.r,e=r.g,u=r.b,o=r.a,i=void 0===o?1:o;return t(n)&&t(e)&&t(u)?a({r:Number(n),g:Number(e),b:Number(u),a:Number(i)}):null},"rgb"],[function(r){var n=r.h,e=r.s,u=r.l,a=r.a,o=void 0===a?1:a;if(!t(n)||!t(e)||!t(u))return null;var i=g({h:Number(n),s:Number(e),l:Number(u),a:Number(o)});return f(i)},"hsl"],[function(r){var n=r.h,a=r.s,o=r.v,i=r.a,s=void 0===i?1:i;if(!t(n)||!t(a)||!t(o))return null;var h=function(r){return {h:u(r.h),s:e(r.s,0,100),v:e(r.v,0,100),a:e(r.a)}}({h:Number(n),s:Number(a),v:Number(o),a:Number(s)});return b(h)},"hsv"]]},N=function(r,t){for(var n=0;n<t.length;n++){var e=t[n][0](r);if(e)return [e,t[n][1]]}return [null,void 0]},x=function(r){return "string"==typeof r?N(r.trim(),y.string):"object"==typeof r&&null!==r?N(r,y.object):[null,void 0]},M=function(r,t){var n=c(r);return {h:n.h,s:e(n.s+100*t,0,100),l:n.l,a:n.a}},H=function(r){return (299*r.r+587*r.g+114*r.b)/1e3/255},$=function(r,t){var n=c(r);return {h:n.h,s:n.s,l:e(n.l+100*t,0,100),a:n.a}},j=function(){function r(r){this.parsed=x(r)[0],this.rgba=this.parsed||{r:0,g:0,b:0,a:1};}return r.prototype.isValid=function(){return null!==this.parsed},r.prototype.brightness=function(){return n(H(this.rgba),2)},r.prototype.isDark=function(){return H(this.rgba)<.5},r.prototype.isLight=function(){return H(this.rgba)>=.5},r.prototype.toHex=function(){return r=o(this.rgba),t=r.r,e=r.g,u=r.b,i=(a=r.a)<1?s(n(255*a)):"","#"+s(t)+s(e)+s(u)+i;var r,t,e,u,a,i;},r.prototype.toRgb=function(){return o(this.rgba)},r.prototype.toRgbString=function(){return r=o(this.rgba),t=r.r,n=r.g,e=r.b,(u=r.a)<1?"rgba("+t+", "+n+", "+e+", "+u+")":"rgb("+t+", "+n+", "+e+")";var r,t,n,e,u;},r.prototype.toHsl=function(){return d(c(this.rgba))},r.prototype.toHslString=function(){return r=d(c(this.rgba)),t=r.h,n=r.s,e=r.l,(u=r.a)<1?"hsla("+t+", "+n+"%, "+e+"%, "+u+")":"hsl("+t+", "+n+"%, "+e+"%)";var r,t,n,e,u;},r.prototype.toHsv=function(){return r=h(this.rgba),{h:n(r.h),s:n(r.s),v:n(r.v),a:n(r.a,3)};var r;},r.prototype.invert=function(){return w({r:255-(r=this.rgba).r,g:255-r.g,b:255-r.b,a:r.a});var r;},r.prototype.saturate=function(r){return void 0===r&&(r=.1),w(M(this.rgba,r))},r.prototype.desaturate=function(r){return void 0===r&&(r=.1),w(M(this.rgba,-r))},r.prototype.grayscale=function(){return w(M(this.rgba,-1))},r.prototype.lighten=function(r){return void 0===r&&(r=.1),w($(this.rgba,r))},r.prototype.darken=function(r){return void 0===r&&(r=.1),w($(this.rgba,-r))},r.prototype.rotate=function(r){return void 0===r&&(r=15),this.hue(this.hue()+r)},r.prototype.alpha=function(r){return "number"==typeof r?w({r:(t=this.rgba).r,g:t.g,b:t.b,a:r}):n(this.rgba.a,3);var t;},r.prototype.hue=function(r){var t=c(this.rgba);return "number"==typeof r?w({h:r,s:t.s,l:t.l,a:t.a}):n(t.h)},r.prototype.isEqual=function(r){return this.toHex()===w(r).toHex()},r}(),w=function(r){return r instanceof j?r:new j(r)},S=[],k=function(r){r.forEach(function(r){S.indexOf(r)<0&&(r(j,y),S.push(r));});};

function namesPlugin(e,f){var a={white:"#ffffff",bisque:"#ffe4c4",blue:"#0000ff",cadetblue:"#5f9ea0",chartreuse:"#7fff00",chocolate:"#d2691e",coral:"#ff7f50",antiquewhite:"#faebd7",aqua:"#00ffff",azure:"#f0ffff",whitesmoke:"#f5f5f5",papayawhip:"#ffefd5",plum:"#dda0dd",blanchedalmond:"#ffebcd",black:"#000000",gold:"#ffd700",goldenrod:"#daa520",gainsboro:"#dcdcdc",cornsilk:"#fff8dc",cornflowerblue:"#6495ed",burlywood:"#deb887",aquamarine:"#7fffd4",beige:"#f5f5dc",crimson:"#dc143c",cyan:"#00ffff",darkblue:"#00008b",darkcyan:"#008b8b",darkgoldenrod:"#b8860b",darkkhaki:"#bdb76b",darkgray:"#a9a9a9",darkgreen:"#006400",darkgrey:"#a9a9a9",peachpuff:"#ffdab9",darkmagenta:"#8b008b",darkred:"#8b0000",darkorchid:"#9932cc",darkorange:"#ff8c00",darkslateblue:"#483d8b",gray:"#808080",darkslategray:"#2f4f4f",darkslategrey:"#2f4f4f",deeppink:"#ff1493",deepskyblue:"#00bfff",wheat:"#f5deb3",firebrick:"#b22222",floralwhite:"#fffaf0",ghostwhite:"#f8f8ff",darkviolet:"#9400d3",magenta:"#ff00ff",green:"#008000",dodgerblue:"#1e90ff",grey:"#808080",honeydew:"#f0fff0",hotpink:"#ff69b4",blueviolet:"#8a2be2",forestgreen:"#228b22",lawngreen:"#7cfc00",indianred:"#cd5c5c",indigo:"#4b0082",fuchsia:"#ff00ff",brown:"#a52a2a",maroon:"#800000",mediumblue:"#0000cd",lightcoral:"#f08080",darkturquoise:"#00ced1",lightcyan:"#e0ffff",ivory:"#fffff0",lightyellow:"#ffffe0",lightsalmon:"#ffa07a",lightseagreen:"#20b2aa",linen:"#faf0e6",mediumaquamarine:"#66cdaa",lemonchiffon:"#fffacd",lime:"#00ff00",khaki:"#f0e68c",mediumseagreen:"#3cb371",limegreen:"#32cd32",mediumspringgreen:"#00fa9a",lightskyblue:"#87cefa",lightblue:"#add8e6",midnightblue:"#191970",lightpink:"#ffb6c1",mistyrose:"#ffe4e1",moccasin:"#ffe4b5",mintcream:"#f5fffa",lightslategray:"#778899",lightslategrey:"#778899",navajowhite:"#ffdead",navy:"#000080",mediumvioletred:"#c71585",powderblue:"#b0e0e6",palegoldenrod:"#eee8aa",oldlace:"#fdf5e6",paleturquoise:"#afeeee",mediumturquoise:"#48d1cc",mediumorchid:"#ba55d3",rebeccapurple:"#663399",lightsteelblue:"#b0c4de",mediumslateblue:"#7b68ee",thistle:"#d8bfd8",tan:"#d2b48c",orchid:"#da70d6",mediumpurple:"#9370db",purple:"#800080",pink:"#ffc0cb",skyblue:"#87ceeb",springgreen:"#00ff7f",palegreen:"#98fb98",red:"#ff0000",yellow:"#ffff00",slateblue:"#6a5acd",lavenderblush:"#fff0f5",peru:"#cd853f",palevioletred:"#db7093",violet:"#ee82ee",teal:"#008080",slategray:"#708090",slategrey:"#708090",aliceblue:"#f0f8ff",darkseagreen:"#8fbc8f",darkolivegreen:"#556b2f",greenyellow:"#adff2f",seagreen:"#2e8b57",seashell:"#fff5ee",tomato:"#ff6347",silver:"#c0c0c0",sienna:"#a0522d",lavender:"#e6e6fa",lightgreen:"#90ee90",orange:"#ffa500",orangered:"#ff4500",steelblue:"#4682b4",royalblue:"#4169e1",turquoise:"#40e0d0",yellowgreen:"#9acd32",salmon:"#fa8072",saddlebrown:"#8b4513",sandybrown:"#f4a460",rosybrown:"#bc8f8f",darksalmon:"#e9967a",lightgoldenrodyellow:"#fafad2",snow:"#fffafa",lightgrey:"#d3d3d3",lightgray:"#d3d3d3",dimgray:"#696969",dimgrey:"#696969",olivedrab:"#6b8e23",olive:"#808000"},r={};for(var d in a)r[a[d]]=d;var l={};e.prototype.toName=function(f){if(!(this.rgba.a||this.rgba.r||this.rgba.g||this.rgba.b))return "transparent";var d,i,n=r[this.toHex()];if(n)return n;if(null==f?void 0:f.closest){var o=this.toRgb(),t=1/0,b="black";if(!l.length)for(var c in a)l[c]=new e(a[c]).toRgb();for(var g in a){var u=(d=o,i=l[g],Math.pow(d.r-i.r,2)+Math.pow(d.g-i.g,2)+Math.pow(d.b-i.b,2));u<t&&(t=u,b=g);}return b}};f.string.push([function(f){var r=f.toLowerCase(),d="transparent"===r?"#0000":a[r];return d?new e(d).toRgb():null},"name"]);}

var glyphs = {
  '3d': /*#__PURE__*/SP_REACT.createElement("path", {
    d: "M18 14.625V3.375L9 0 0 3.375v11.25L9 18l9-3.375zM9 2.136l5.918 2.22-5.98 2.242-5.919-2.22L9 2.137zM2 13.239V5.065l6.438 2.414v8.174L2 13.24zM9.438 15.7L16 13.239V5.018l-6.563 2.46V15.7z",
    transform: "translate(15 10)",
    fillRule: "evenodd"
  }),
  acrobat: /*#__PURE__*/SP_REACT.createElement("path", {
    d: "M10.15 1.095C9.938.33 9.42-.051 8.984.005c-.528.068-1.09.382-1.314.876-.63 1.416.685 5.582.887 6.279-1.28 3.863-5.66 11.5-7.806 12.017-.045-.505.225-1.965 3.055-3.785.146-.157.315-.348.393-.472-2.392 1.168-5.492 3.044-3.628 4.448.102.079.259.146.439.213 1.426.528 3.425-1.201 5.435-5.121 2.213-.73 3.999-1.28 6.526-1.662 2.762 1.875 4.616 2.257 5.874 1.774.348-.135.898-.573 1.055-1.145-1.022 1.258-3.414.382-5.323-.82 1.763-.191 3.582-.303 4.369-.056 1 .314.965.808.954.876.079-.27.191-.708-.022-1.056-.842-1.37-4.706-.573-6.11-.427-2.212-1.336-3.74-3.717-4.358-5.436.573-2.212 1.19-3.818.742-5.413zm-.954 4.638C8.826 4.42 8.309 1.5 9.14.556c1.628.932.618 3.144.056 5.177zm3.044 6.514c-2.134.393-3.583.944-5.66 1.764.617-1.202 1.785-4.268 2.346-6.29.787 1.573 1.741 3.111 3.314 4.526z",
    transform: "translate(14 9)",
    fillRule: "evenodd"
  }),
  android: /*#__PURE__*/SP_REACT.createElement("path", {
    d: "M17.6,9.48l1.84-3.18c0.16-0.31,0.04-0.69-0.26-0.85c-0.29-0.15-0.65-0.06-0.83,0.22l-1.88,3.24 c-2.86-1.21-6.08-1.21-8.94,0L5.65,5.67c-0.19-0.29-0.58-0.38-0.87-0.2C4.5,5.65,4.41,6.01,4.56,6.3L6.4,9.48 C3.3,11.25,1.28,14.44,1,18h22C22.72,14.44,20.7,11.25,17.6,9.48z M7,15.25c-0.69,0-1.25-0.56-1.25-1.25 c0-0.69,0.56-1.25,1.25-1.25S8.25,13.31,8.25,14C8.25,14.69,7.69,15.25,7,15.25z M17,15.25c-0.69,0-1.25-0.56-1.25-1.25 c0-0.69,0.56-1.25,1.25-1.25s1.25,0.56,1.25,1.25C18.25,14.69,17.69,15.25,17,15.25z",
    transform: "translate(12 8)"
  }),
  audio: /*#__PURE__*/SP_REACT.createElement("path", {
    d: "M.25 4.75v4.5h3L7 13V1L3.25 4.75h-3zM10.375 7A3.375 3.375 0 0 0 8.5 3.977v6.037A3.355 3.355 0 0 0 10.375 7zM8.5.421v1.545A5.254 5.254 0 0 1 12.25 7a5.254 5.254 0 0 1-3.75 5.032v1.545A6.747 6.747 0 0 0 13.75 7 6.747 6.747 0 0 0 8.5.421z",
    transform: "translate(17 12)",
    fillRule: "evenodd"
  }),
  binary: /*#__PURE__*/SP_REACT.createElement("path", {
    d: "M2.338 6.112c1.192 0 1.928-1.072 1.928-2.68 0-1.56-.576-2.504-1.8-2.504C1.274.928.538 2 .538 3.608c0 1.56.576 2.504 1.8 2.504zM1.61 3.408c0-1.008.24-1.568.776-1.568.376 0 .616.336.728.888l-1.504.776v-.096zM2.418 5.2c-.368 0-.608-.32-.72-.856l1.496-.768v.056c0 1.008-.24 1.568-.776 1.568zm7.03.8l.088-.944H8.36V.896L7.272.984v.592l-1.184.112.024.824h1.16v2.544h-1.32V6zm5.199 0l.088-.944h-1.176V.896L12.47.984v.592l-1.184.112.024.824h1.16v2.544h-1.32V6zM4.25 14l.088-.944H3.162v-4.16l-1.088.088v.592L.89 9.688l.024.824h1.16v2.544H.754V14zm5.198 0l.088-.944H8.36v-4.16l-1.088.088v.592l-1.184.112.024.824h1.16v2.544h-1.32V14zm3.287.112c1.192 0 1.928-1.072 1.928-2.68 0-1.56-.576-2.504-1.8-2.504-1.192 0-1.928 1.072-1.928 2.68 0 1.56.576 2.504 1.8 2.504zm-.728-2.704c0-1.008.24-1.568.776-1.568.376 0 .616.336.728.888l-1.504.776v-.096zm.808 1.792c-.368 0-.608-.32-.72-.856l1.496-.768v.056c0 1.008-.24 1.568-.776 1.568z",
    transform: "translate(16 11)",
    fillRule: "evenodd"
  }),
  code: /*#__PURE__*/SP_REACT.createElement("path", {
    d: "M4.078 13.67c-1.875-.527-2.812-1.738-2.812-3.634V9.49C1.266 8.437.844 7.911 0 7.911V6.138c.844 0 1.266-.529 1.266-1.586v-.64c.015-.938.257-1.696.726-2.274C2.466 1.06 3.162.64 4.078.38l.492 1.375c-.656.25-.997.95-1.023 2.102v.695c0 1.167-.482 1.99-1.445 2.469.963.479 1.445 1.304 1.445 2.476v.688c.026 1.15.367 1.851 1.023 2.101l-.492 1.383zm7.844 0c1.875-.527 2.812-1.738 2.812-3.634V9.49c0-1.052.422-1.578 1.266-1.578V6.138c-.844 0-1.266-.529-1.266-1.586v-.64c-.015-.938-.257-1.696-.726-2.274-.474-.578-1.17-.998-2.086-1.258l-.492 1.375c.656.25.997.95 1.023 2.102v.695c0 1.167.482 1.99 1.445 2.469-.963.479-1.445 1.304-1.445 2.476v.688c-.026 1.15-.367 1.851-1.023 2.101l.492 1.383z",
    transform: "translate(16 13)",
    fillRule: "evenodd"
  }),
  code2: /*#__PURE__*/SP_REACT.createElement("path", {
    d: "M7.4 10.6L2.8 6l4.6-4.6L6 0 0 6l6 6 1.4-1.4zm5.2 0L17.2 6l-4.6-4.6L14 0l6 6-6 6-1.4-1.4z",
    transform: "translate(14 14)",
    fillRule: "evenodd"
  }),
  compressed: /*#__PURE__*/SP_REACT.createElement("path", {
    d: "M.25 0A.25.25 0 0 0 0 .25v1.5c0 .138.112.25.25.25h1.5A.25.25 0 0 0 2 1.75V.25A.25.25 0 0 0 1.75 0H.25zM1 17a1 1 0 0 0-1 1v6a1 1 0 0 0 1 1h2a1 1 0 0 0 1-1v-6a1 1 0 0 0-1-1H1zm0 4v3h2v-3H1zM2 2.25A.25.25 0 0 1 2.25 2h1.5a.25.25 0 0 1 .25.25v1.5a.25.25 0 0 1-.25.25h-1.5A.25.25 0 0 1 2 3.75v-1.5zM.25 4a.25.25 0 0 0-.25.25v1.5c0 .138.112.25.25.25h1.5A.25.25 0 0 0 2 5.75v-1.5A.25.25 0 0 0 1.75 4H.25zM2 6.25A.25.25 0 0 1 2.25 6h1.5a.25.25 0 0 1 .25.25v1.5a.25.25 0 0 1-.25.25h-1.5A.25.25 0 0 1 2 7.75v-1.5zM.25 8a.25.25 0 0 0-.25.25v1.5c0 .138.112.25.25.25h1.5A.25.25 0 0 0 2 9.75v-1.5A.25.25 0 0 0 1.75 8H.25zM2 10.25a.25.25 0 0 1 .25-.25h1.5a.25.25 0 0 1 .25.25v1.5a.25.25 0 0 1-.25.25h-1.5a.25.25 0 0 1-.25-.25v-1.5zM.25 12a.25.25 0 0 0-.25.25v1.5c0 .138.112.25.25.25h1.5a.25.25 0 0 0 .25-.25v-1.5a.25.25 0 0 0-.25-.25H.25zM2 14.25a.25.25 0 0 1 .25-.25h1.5a.25.25 0 0 1 .25.25v1.5a.25.25 0 0 1-.25.25h-1.5a.25.25 0 0 1-.25-.25v-1.5z",
    transform: "translate(15 1)",
    fillRule: "evenodd"
  }),
  document: /*#__PURE__*/SP_REACT.createElement("path", {
    d: "M12 4H0v2h12V4zM0 10h18V8H0v2zM0 0v2h18V0H0z",
    transform: "translate(15 15)",
    fillRule: "evenodd"
  }),
  drive: /*#__PURE__*/SP_REACT.createElement("path", {
    d: "M2.199.289A.5.5 0 0 1 2.652 0h8.696a.5.5 0 0 1 .453.289l1.867 4a.5.5 0 0 1-.453.711H.785a.5.5 0 0 1-.453-.711l1.867-4zM13 6H1a.752.752 0 0 0-.75.75v4.5c0 .412.338.75.75.75h12c.412 0 .75-.338.75-.75v-4.5A.752.752 0 0 0 13 6zm-9.75 4.5c-.825 0-1.5-.675-1.5-1.5s.675-1.5 1.5-1.5 1.5.675 1.5 1.5-.675 1.5-1.5 1.5z",
    transform: "translate(17 13)",
    fillRule: "evenodd"
  }),
  font: /*#__PURE__*/SP_REACT.createElement("path", {
    d: "M3.722 8.702l-.686 1.89c-.053.14-.094.28-.123.421-.03.135-.044.252-.044.352 0 .304.097.527.29.668.2.14.501.21.905.21h.414V13H.083v-.756h.343c.176 0 .325-.018.448-.053a.81.81 0 0 0 .334-.22c.1-.105.193-.249.281-.43.094-.182.197-.416.308-.704L5.787.15h1.406l4.07 11.136c.07.187.14.343.21.466.077.123.165.222.264.298.1.07.214.12.343.15.129.03.281.044.457.044h.237V13H7.826v-.756h.413c.72 0 1.081-.287 1.081-.862 0-.1-.014-.202-.044-.307a3.274 3.274 0 0 0-.105-.36l-.72-2.013H3.72zM7.009 4.65c-.188-.533-.36-1.031-.519-1.494a15.92 15.92 0 0 1-.378-1.354 7.12 7.12 0 0 1-.15.633 16.95 16.95 0 0 1-.395 1.283c-.082.229-.175.484-.28.765L4.063 7.796h4.061L7.009 4.65zm8.411 5.74c0 .562.117.984.351 1.265.24.275.61.413 1.108.413.363 0 .691-.059.984-.176.3-.117.551-.284.756-.5.211-.218.372-.481.483-.792.112-.31.168-.656.168-1.037V8.104l-1.152.053c-.51.023-.937.088-1.283.193-.34.1-.615.243-.826.43a1.546 1.546 0 0 0-.457.678c-.088.27-.132.58-.132.931zm2.18-6.32c-.346 0-.627.05-.844.15a1.182 1.182 0 0 0-.501.404 1.594 1.594 0 0 0-.237.624c-.041.24-.062.5-.062.782-.498 0-.879-.085-1.143-.255-.257-.17-.386-.463-.386-.879 0-.31.085-.574.255-.79.17-.218.401-.393.694-.528.299-.14.644-.243 1.037-.308a7.76 7.76 0 0 1 1.257-.097c.55 0 1.031.056 1.441.167.41.106.753.282 1.029.528.275.246.48.568.615.967.14.392.21.876.21 1.45v4.667c0 .252.021.46.062.624a.928.928 0 0 0 .194.395c.088.1.202.17.343.211.146.041.319.062.518.062h.053V13H19.7l-.281-1.547h-.15c-.187.252-.369.483-.544.694-.176.211-.37.393-.58.545-.211.152-.452.27-.721.352a3.053 3.053 0 0 1-.958.131c-.399 0-.77-.058-1.116-.175a2.369 2.369 0 0 1-.888-.519 2.516 2.516 0 0 1-.58-.896c-.14-.364-.211-.791-.211-1.284 0-.955.34-1.664 1.02-2.127.68-.462 1.707-.714 3.084-.755l1.495-.053V6.285a6.93 6.93 0 0 0-.053-.888 1.778 1.778 0 0 0-.229-.703 1.14 1.14 0 0 0-.51-.457c-.216-.111-.51-.167-.878-.167z",
    transform: "translate(13 12)",
    fillRule: "evenodd"
  }),
  image: /*#__PURE__*/SP_REACT.createElement("path", {
    d: "M13 0L9.25 5l2.85 3.8-1.6 1.2C8.81 7.75 6 4 6 4l-6 8h22L13 0z",
    transform: "translate(13 14)",
    fillRule: "evenodd"
  }),
  presentation: /*#__PURE__*/SP_REACT.createElement("path", {
    d: "M2 4H0v10c0 1.1.9 2 2 2h14v-2H2V4zm16-4H6C4.9 0 4 .9 4 2v8c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V2c0-1.1-.9-2-2-2zm0 10H6V2h12v8z",
    transform: "matrix(-1 0 0 1 34 12)",
    fillRule: "evenodd"
  }),
  settings: /*#__PURE__*/SP_REACT.createElement("path", {
    d: "M13.572 8.735c.03-.24.053-.48.053-.735s-.023-.495-.053-.735l1.583-1.237a.378.378 0 0 0 .09-.48l-1.5-2.595a.377.377 0 0 0-.457-.165l-1.868.75a5.48 5.48 0 0 0-1.268-.735L9.868.815A.366.366 0 0 0 9.5.5h-3a.366.366 0 0 0-.367.315l-.285 1.988a5.762 5.762 0 0 0-1.268.735l-1.868-.75a.366.366 0 0 0-.457.165l-1.5 2.595a.37.37 0 0 0 .09.48l1.583 1.237c-.03.24-.053.488-.053.735 0 .248.022.495.053.735L.845 9.973a.378.378 0 0 0-.09.48l1.5 2.595c.09.165.292.225.458.165l1.867-.75c.39.3.81.547 1.268.735l.285 1.987c.022.18.18.315.367.315h3a.366.366 0 0 0 .367-.315l.285-1.988a5.762 5.762 0 0 0 1.268-.734l1.867.75c.173.067.368 0 .458-.165l1.5-2.595a.378.378 0 0 0-.09-.48l-1.582-1.238zM8 10.625A2.628 2.628 0 0 1 5.375 8 2.628 2.628 0 0 1 8 5.375 2.628 2.628 0 0 1 10.625 8 2.628 2.628 0 0 1 8 10.625z",
    transform: "translate(16 11)",
    fillRule: "evenodd"
  }),
  spreadsheet: /*#__PURE__*/SP_REACT.createElement("path", {
    d: "M0 8h6V5H0v3zm0 5h6v-3H0v3zM0 3h6V0H0v3zm8 5h12V5H8v3zm0 5h12v-3H8v3zM8 0v3h12V0H8z",
    transform: "translate(14 14)",
    fillRule: "evenodd"
  }),
  vector: /*#__PURE__*/SP_REACT.createElement("path", {
    d: "M14.5 2V1a1 1 0 0 0-1-1h-3a1 1 0 0 0-1 1v1H3.937a2 2 0 1 0 0 1h3.936A9 9 0 0 0 3 11v1h2v-1a7.003 7.003 0 0 1 4.594-6.576A1 1 0 0 0 10.5 5h3a1 1 0 0 0 .906-.576A7.003 7.003 0 0 1 19 11v1h2v-1a9 9 0 0 0-4.873-8h3.936a2 2 0 1 0 0-1H14.5zm-1-1h-3v3h3V1zM2 1.5a1 1 0 1 0 0 2 1 1 0 0 0 0-2zm19 1a1 1 0 1 0 2 0 1 1 0 0 0-2 0z",
    transform: "translate(12 14)",
    fillRule: "evenodd"
  }),
  video: /*#__PURE__*/SP_REACT.createElement("path", {
    d: "M10.75 3.875V1.25A.752.752 0 0 0 10 .5H1a.752.752 0 0 0-.75.75v7.5c0 .412.338.75.75.75h9c.412 0 .75-.338.75-.75V6.125l3 3V.875l-3 3z",
    transform: "translate(17 14)"
  })
};

k([namesPlugin]);
var propTypes = {
  /** Color of icon background */
  color: PropTypes.string,

  /** Text to display in label */
  extension: PropTypes.string,

  /** Displays the corner fold */
  fold: PropTypes.bool,

  /** Color of the corner fold */
  foldColor: PropTypes.string,

  /** Color of file type icon */
  glyphColor: PropTypes.string,

  /** Color of page gradient */
  gradientColor: PropTypes.string,

  /** Opacity of page gradient */
  gradientOpacity: PropTypes.number,

  /** Color of label */
  labelColor: PropTypes.string,

  /** Color of label text */
  labelTextColor: PropTypes.string,

  /** Displays the label in all caps */
  labelUppercase: PropTypes.bool,

  /** Corner radius of the file icon */
  radius: PropTypes.number,

  /** Type of glyph icon to display */
  type: PropTypes.oneOf(['3d', 'acrobat', 'android', 'audio', 'binary', 'code', 'code2', 'compressed', 'document', 'drive', 'font', 'image', 'presentation', 'settings', 'spreadsheet', 'vector', 'video'])
};
var VIEWBOX = {
  WIDTH: 40,
  HEIGHT: 48
};
var ICON = {
  WIDTH: VIEWBOX.WIDTH,
  HEIGHT: VIEWBOX.HEIGHT,
  X_OFFSET: 0
};
var FOLD = {
  HEIGHT: 12
};
var LABEL_HEIGHT = 14;

var useId = SP_REACT.useId || function () {
  var i = 0;
  return function () {
    return i++;
  };
}();

var FileIcon = function FileIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'whitesmoke' : _ref$color,
      extension = _ref.extension,
      _ref$fold = _ref.fold,
      fold = _ref$fold === void 0 ? true : _ref$fold,
      foldColor = _ref.foldColor,
      glyphColor = _ref.glyphColor,
      _ref$gradientColor = _ref.gradientColor,
      gradientColor = _ref$gradientColor === void 0 ? 'white' : _ref$gradientColor,
      _ref$gradientOpacity = _ref.gradientOpacity,
      gradientOpacity = _ref$gradientOpacity === void 0 ? 0.25 : _ref$gradientOpacity,
      labelColor = _ref.labelColor,
      _ref$labelTextColor = _ref.labelTextColor,
      labelTextColor = _ref$labelTextColor === void 0 ? 'white' : _ref$labelTextColor,
      _ref$labelUppercase = _ref.labelUppercase,
      labelUppercase = _ref$labelUppercase === void 0 ? false : _ref$labelUppercase,
      _ref$radius = _ref.radius,
      radius = _ref$radius === void 0 ? 4 : _ref$radius,
      type = _ref.type;
  var id = useId();
  var UNIQUE_ID = typeof jest === 'undefined' ? id : '';
  return /*#__PURE__*/SP_REACT.createElement("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    viewBox: "0 0 " + VIEWBOX.WIDTH + " " + VIEWBOX.HEIGHT,
    width: "100%",
    style: {
      maxWidth: '100%'
    }
  }, /*#__PURE__*/SP_REACT.createElement("defs", null, /*#__PURE__*/SP_REACT.createElement("clipPath", {
    id: "pageRadius" + UNIQUE_ID
  }, /*#__PURE__*/SP_REACT.createElement("rect", {
    x: ICON.X_OFFSET,
    y: "0",
    rx: radius,
    ry: radius,
    width: ICON.WIDTH,
    height: ICON.HEIGHT
  })), /*#__PURE__*/SP_REACT.createElement("clipPath", {
    id: "foldCrop" + UNIQUE_ID
  }, /*#__PURE__*/SP_REACT.createElement("rect", {
    width: ICON.WIDTH,
    height: FOLD.HEIGHT,
    transform: "rotate(-45 0 " + FOLD.HEIGHT + ")"
  })), /*#__PURE__*/SP_REACT.createElement("linearGradient", {
    x1: "100%",
    y1: "0%",
    y2: "100%",
    id: "pageGradient" + UNIQUE_ID
  }, /*#__PURE__*/SP_REACT.createElement("stop", {
    stopColor: gradientColor,
    stopOpacity: gradientOpacity,
    offset: "0%"
  }), /*#__PURE__*/SP_REACT.createElement("stop", {
    stopColor: gradientColor,
    stopOpacity: "0",
    offset: "66.67%"
  }))), /*#__PURE__*/SP_REACT.createElement("g", {
    id: "file",
    clipPath: "url(#pageRadius" + UNIQUE_ID + ")"
  }, fold ? /*#__PURE__*/SP_REACT.createElement(SP_REACT.Fragment, null, /*#__PURE__*/SP_REACT.createElement("path", {
    d: "M" + ICON.X_OFFSET + " 0 h " + (ICON.WIDTH - FOLD.HEIGHT) + " L " + (ICON.WIDTH + ICON.X_OFFSET) + " " + FOLD.HEIGHT + " v " + (ICON.HEIGHT - FOLD.HEIGHT) + " H " + ICON.X_OFFSET + " Z",
    fill: color
  }), /*#__PURE__*/SP_REACT.createElement("path", {
    d: "M" + ICON.X_OFFSET + " 0 h " + (ICON.WIDTH - FOLD.HEIGHT) + " L " + (ICON.WIDTH + ICON.X_OFFSET) + " " + FOLD.HEIGHT + " v " + (ICON.HEIGHT - FOLD.HEIGHT) + " H " + ICON.X_OFFSET + " Z",
    fill: "url(#pageGradient" + UNIQUE_ID + ")"
  })) : /*#__PURE__*/SP_REACT.createElement(SP_REACT.Fragment, null, /*#__PURE__*/SP_REACT.createElement("rect", {
    x: ICON.X_OFFSET,
    y: "0",
    width: ICON.WIDTH,
    height: ICON.HEIGHT,
    fill: color
  }), /*#__PURE__*/SP_REACT.createElement("rect", {
    x: ICON.X_OFFSET,
    y: "0",
    width: ICON.WIDTH,
    height: ICON.HEIGHT,
    fill: "url(#pageGradient" + UNIQUE_ID + ")"
  }))), fold && /*#__PURE__*/SP_REACT.createElement("g", {
    transform: "translate(28 " + FOLD.HEIGHT + ") rotate(-90)"
  }, /*#__PURE__*/SP_REACT.createElement("rect", {
    width: ICON.WIDTH,
    height: ICON.HEIGHT,
    fill: foldColor || w(color).darken(0.1).toHex(),
    rx: radius,
    ry: radius,
    clipPath: "url(#foldCrop" + UNIQUE_ID + ")"
  })), extension && /*#__PURE__*/SP_REACT.createElement(SP_REACT.Fragment, null, /*#__PURE__*/SP_REACT.createElement("g", {
    id: "label" + UNIQUE_ID
  }, /*#__PURE__*/SP_REACT.createElement("rect", {
    fill: labelColor || w(color).darken(0.3).toHex(),
    x: ICON.X_OFFSET,
    y: ICON.HEIGHT - LABEL_HEIGHT,
    width: ICON.WIDTH,
    height: LABEL_HEIGHT,
    clipPath: "url(#pageRadius" + UNIQUE_ID + ")"
  })), /*#__PURE__*/SP_REACT.createElement("g", {
    id: "labelText" + UNIQUE_ID,
    transform: "translate(" + ICON.X_OFFSET + " 34)"
  }, /*#__PURE__*/SP_REACT.createElement("text", {
    x: ICON.WIDTH / 2,
    y: "10",
    fontFamily: "-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif",
    fontSize: "9",
    fill: labelTextColor,
    textAnchor: "middle",
    style: {
      fontWeight: 'bold',
      textAlign: 'center',
      pointerEvents: 'none',
      textTransform: labelUppercase ? 'uppercase' : 'none',
      userSelect: 'none'
    }
  }, extension))), type && /*#__PURE__*/SP_REACT.createElement("g", {
    transform: "translate(-4 " + (!extension ? 6 : 0) + ")",
    fill: glyphColor || w(color).darken(0.15).toHex()
  }, glyphs[type]));
};
FileIcon.propTypes = propTypes;

var defaultStyles = {
  '3dm': {
    labelColor: '#8D1A11',
    type: '3d'
  },
  '3ds': {
    labelColor: '#5FB9AD',
    type: '3d'
  },
  '3g2': {
    type: 'video'
  },
  '3gp': {
    type: 'video'
  },
  '7zip': {
    type: 'compressed'
  },
  aab: {
    type: 'android',
    labelColor: '#3DDC84'
  },
  aac: {
    type: 'audio'
  },
  aep: {
    type: 'video'
  },
  ai: {
    color: '#423325',
    gradientOpacity: 0,
    labelColor: '#423325',
    labelTextColor: '#FF7F18',
    labelUppercase: true,
    foldColor: '#FF7F18',
    radius: 2
  },
  aif: {
    type: 'audio'
  },
  aiff: {
    type: 'audio'
  },
  apk: {
    type: 'android',
    labelColor: '#3DDC84'
  },
  apkm: {
    type: 'android',
    labelColor: '#3DDC84'
  },
  apks: {
    type: 'android',
    labelColor: '#3DDC84'
  },
  asf: {
    type: 'video'
  },
  asp: {
    type: 'code'
  },
  aspx: {
    type: 'code'
  },
  avi: {
    type: 'video'
  },
  bin: {
    type: 'binary'
  },
  bmp: {
    type: 'image'
  },
  c: {
    type: 'code'
  },
  cpp: {
    type: 'code'
  },
  cs: {
    type: 'code'
  },
  css: {
    type: 'code'
  },
  csv: {
    type: 'spreadsheet'
  },
  cue: {
    type: 'document'
  },
  dll: {
    type: 'settings'
  },
  dmg: {
    type: 'drive'
  },
  doc: {
    color: '#2C5898',
    foldColor: '#254A80',
    glyphColor: 'rgba(255,255,255,0.4)',
    labelColor: '#2C5898',
    labelUppercase: true,
    type: 'document'
  },
  docx: {
    color: '#2C5898',
    foldColor: '#254A80',
    glyphColor: 'rgba(255,255,255,0.4)',
    labelColor: '#2C5898',
    labelUppercase: true,
    type: 'document'
  },
  dwg: {
    type: 'vector'
  },
  dxf: {
    type: 'vector'
  },
  eot: {
    type: 'font'
  },
  eps: {
    type: 'vector'
  },
  exe: {
    type: 'settings'
  },
  flac: {
    type: 'audio'
  },
  flv: {
    type: 'video'
  },
  fnt: {
    type: 'font'
  },
  fodp: {
    type: 'presentation'
  },
  fods: {
    type: 'spreadsheet'
  },
  fodt: {
    type: 'document'
  },
  fon: {
    type: 'font'
  },
  gif: {
    type: 'image'
  },
  gz: {
    type: 'compressed'
  },
  heic: {
    type: 'image'
  },
  htm: {
    type: 'code'
  },
  html: {
    type: 'code'
  },
  indd: {
    color: '#4B2B36',
    gradientOpacity: 0,
    labelColor: '#4B2B36',
    labelTextColor: '#FF408C',
    labelUppercase: true,
    foldColor: '#FF408C',
    radius: 2
  },
  ini: {
    type: 'settings'
  },
  java: {
    type: 'code'
  },
  jpeg: {
    type: 'image'
  },
  jpg: {
    type: 'image'
  },
  js: {
    labelColor: '#F7DF1E',
    type: 'code'
  },
  json: {
    type: 'code'
  },
  jsx: {
    labelColor: '#00D8FF',
    type: 'code'
  },
  m4a: {
    type: 'audio'
  },
  m4v: {
    type: 'video'
  },
  max: {
    labelColor: '#5FB9AD',
    type: '3d'
  },
  md: {
    type: 'document'
  },
  mid: {
    type: 'audio'
  },
  mkv: {
    type: 'video'
  },
  mov: {
    type: 'video'
  },
  mp3: {
    type: 'audio'
  },
  mp4: {
    type: 'video'
  },
  mpeg: {
    type: 'video'
  },
  mpg: {
    type: 'video'
  },
  obj: {
    type: '3d'
  },
  odp: {
    type: 'presentation'
  },
  ods: {
    type: 'spreadsheet'
  },
  odt: {
    type: 'document'
  },
  ogg: {
    type: 'audio'
  },
  ogv: {
    type: 'video'
  },
  otf: {
    type: 'font'
  },
  pdf: {
    labelColor: '#D93831',
    type: 'acrobat'
  },
  php: {
    labelColor: '#8892BE',
    type: 'code'
  },
  pkg: {
    type: '3d'
  },
  plist: {
    type: 'settings'
  },
  png: {
    type: 'image'
  },
  ppt: {
    color: '#D14423',
    foldColor: '#AB381D',
    glyphColor: 'rgba(255,255,255,0.4)',
    labelColor: '#D14423',
    labelUppercase: true,
    type: 'presentation'
  },
  pptx: {
    color: '#D14423',
    foldColor: '#AB381D',
    glyphColor: 'rgba(255,255,255,0.4)',
    labelColor: '#D14423',
    labelUppercase: true,
    type: 'presentation'
  },
  pr: {
    type: 'video'
  },
  ps: {
    type: 'vector'
  },
  psd: {
    color: '#34364E',
    gradientOpacity: 0,
    labelColor: '#34364E',
    labelTextColor: '#31C5F0',
    labelUppercase: true,
    foldColor: '#31C5F0',
    radius: 2
  },
  py: {
    labelColor: '#FFDE57',
    type: 'code'
  },
  rar: {
    type: 'compressed'
  },
  rb: {
    labelColor: '#BB271A',
    type: 'code'
  },
  rm: {
    type: 'video'
  },
  rtf: {
    type: 'document'
  },
  scss: {
    labelColor: '#C16A98',
    type: 'code'
  },
  sitx: {
    type: 'compressed'
  },
  skp: {
    type: '3d'
  },
  svg: {
    type: 'vector'
  },
  swf: {
    type: 'video'
  },
  sys: {
    type: 'settings'
  },
  tar: {
    type: 'compressed'
  },
  tex: {
    type: 'document'
  },
  tif: {
    type: 'image'
  },
  tiff: {
    type: 'image'
  },
  ts: {
    labelColor: '#3478C7',
    type: 'code'
  },
  ttf: {
    type: 'font'
  },
  txt: {
    type: 'document'
  },
  wav: {
    type: 'audio'
  },
  webm: {
    type: 'video'
  },
  wmv: {
    type: 'video'
  },
  woff: {
    type: 'font'
  },
  wpd: {
    type: 'document'
  },
  wps: {
    type: 'document'
  },
  xapk: {
    type: 'android',
    labelColor: '#3DDC84'
  },
  xlr: {
    type: 'spreadsheet'
  },
  xls: {
    color: '#1A754C',
    foldColor: '#16613F',
    glyphColor: 'rgba(255,255,255,0.4)',
    labelColor: '#1A754C',
    labelUppercase: true,
    type: 'spreadsheet'
  },
  xlsx: {
    color: '#1A754C',
    foldColor: '#16613F',
    glyphColor: 'rgba(255,255,255,0.4)',
    labelColor: '#1A754C',
    labelUppercase: true,
    type: 'spreadsheet'
  },
  yml: {
    type: 'code'
  },
  zip: {
    type: 'compressed'
  },
  zipx: {
    type: 'compressed'
  }
};

// TODO add to dfl
const dropDownControlButtonClasses = findModule((m) => m?.DropDownControlButton && m?.['duration-app-launch']);
const DropdownMultiselectItem = ({ value, onSelect, checked: defaultChecked, ...rest }) => {
    const [checked, setChecked] = SP_REACT.useState(defaultChecked);
    SP_REACT.useEffect(() => {
        onSelect?.(checked, value);
    }, [checked, onSelect, value]);
    return (SP_JSX.jsx(MenuItem, { bInteractableItem: true, onClick: () => setChecked((x) => !x), children: SP_JSX.jsx(DialogCheckbox, { style: { marginBottom: 0, padding: 0 }, className: "decky_DropdownMultiselectItem_DialogCheckbox", bottomSeparator: "none", ...rest, onClick: () => setChecked((x) => !x), onChange: (checked) => setChecked(checked), controlled: true, checked: checked }) }));
};
const DropdownMultiselect = ({ label, items, selected, onSelect }) => {
    const [itemsSelected, setItemsSelected] = SP_REACT.useState(selected);
    const { t } = useTranslation();
    const handleItemSelect = SP_REACT.useCallback((checked, value) => {
        setItemsSelected((x) => checked ? [...x.filter((y) => y !== value), value] : x.filter((y) => y !== value));
    }, []);
    SP_REACT.useEffect(() => {
        onSelect(itemsSelected);
    }, [itemsSelected, onSelect]);
    return (SP_JSX.jsxs(DialogButton, { style: {
            display: 'flex',
            alignItems: 'center',
            maxWidth: '100%',
        }, className: dropDownControlButtonClasses?.DropDownControlButton, onClick: (evt) => {
            evt.preventDefault();
            showContextMenu(SP_JSX.jsxs(Menu, { label: label, cancelText: t('DropdownMultiselect.button.back'), children: [SP_JSX.jsx("style", { children: `
              /* Inherit color from ".basiccontextmenu" */
              .decky_DropdownMultiselectItem_DialogCheckbox > .DialogToggle_Label {
                color: inherit;
              }
              ` }), SP_JSX.jsx("div", { style: { marginTop: '10px' } }), items.map((x) => (SP_JSX.jsx(DropdownMultiselectItem, { label: x.label, value: x.value, checked: itemsSelected.includes(x.value), onSelect: handleItemSelect }, x.value)))] }), evt.currentTarget ?? window);
        }, children: [SP_JSX.jsx(Marquee, { children: selected.length > 0
                    ? selected.map((x) => items[items.findIndex((v) => v.value === x)].label).join(', ')
                    : '…' }), SP_JSX.jsx("div", { style: { flexGrow: 1, minWidth: '1ch' } }), SP_JSX.jsx(FaChevronDown, { style: { height: '1em', flex: '0 0 1em' } })] }));
};

var FileErrorTypes;
(function (FileErrorTypes) {
    FileErrorTypes[FileErrorTypes["FileNotFound"] = 0] = "FileNotFound";
    FileErrorTypes[FileErrorTypes["PermissionDenied"] = 1] = "PermissionDenied";
    FileErrorTypes[FileErrorTypes["Unknown"] = 2] = "Unknown";
    FileErrorTypes[FileErrorTypes["None"] = 3] = "None";
})(FileErrorTypes || (FileErrorTypes = {}));
const FilePickerError = ({ error, rawError = null }) => {
    const [icon, setIcon] = SP_REACT.useState(SP_JSX.jsx(FaQuestionCircle, {}));
    const [text, setText] = SP_REACT.useState(null);
    const { t } = useTranslation();
    SP_REACT.useEffect(() => {
        switch (error) {
            case FileErrorTypes.FileNotFound:
                setText(t('FilePickerError.errors.file_not_found'));
                setIcon(SP_JSX.jsx(FaExclamationTriangle, {}));
                break;
            case FileErrorTypes.PermissionDenied:
                setText(t('FilePickerError.errors.perm_denied'));
                setIcon(SP_JSX.jsx(FaUserSlash, {}));
                break;
            case FileErrorTypes.Unknown:
                setText(t('FilePickerError.errors.unknown', { raw_error: rawError }));
                setIcon(SP_JSX.jsx(FaQuestionCircle, {}));
                break;
            case FileErrorTypes.None:
                setText(null);
                setIcon(SP_JSX.jsx("div", {}));
                break;
        }
    }, [error]);
    return (SP_JSX.jsx(SP_JSX.Fragment, { children: SP_JSX.jsxs("div", { style: { paddingTop: '50px', textAlign: 'center', height: '100%' }, children: [SP_JSX.jsx(IconContext.Provider, { value: { className: 'fileError', size: '128px' }, children: SP_JSX.jsx("div", { style: { alignSelf: 'center', alignContent: 'center' }, children: icon }) }), SP_JSX.jsx("p", { style: { height: '32px', paddingTop: '25px', alignSelf: 'flex-start', textAlign: 'center' }, children: text })] }) }));
};

var SortOptions$1;
(function (SortOptions) {
    SortOptions["name_desc"] = "name_desc";
    SortOptions["name_asc"] = "name_asc";
    SortOptions["modified_desc"] = "modified_desc";
    SortOptions["modified_asc"] = "modified_asc";
    SortOptions["created_desc"] = "created_desc";
    SortOptions["created_asc"] = "created_asc";
    SortOptions["size_desc"] = "size_desc";
    SortOptions["size_asc"] = "size_asc";
})(SortOptions$1 || (SortOptions$1 = {}));
const TSortOptions = ({ trans_part }) => {
    return (SP_JSX.jsx(Translation, { children: (t, {}) => {
            switch (trans_part) {
                case SortOptions$1.name_desc:
                    return t('FilePickerIndex.filter.name_desc');
                case SortOptions$1.name_asc:
                    return t('FilePickerIndex.filter.name_asce');
                case SortOptions$1.modified_desc:
                    return t('FilePickerIndex.filter.modified_desc');
                case SortOptions$1.modified_asc:
                    return t('FilePickerIndex.filter.modified_asce');
                case SortOptions$1.created_desc:
                    return t('FilePickerIndex.filter.created_desc');
                case SortOptions$1.created_asc:
                    return t('FilePickerIndex.filter.created_asce');
                case SortOptions$1.size_desc:
                    return t('FilePickerIndex.filter.size_desc');
                case SortOptions$1.size_asc:
                    return t('FilePickerIndex.filter.size_asce');
            }
        } }));
};

const styleDef = [];
// video ////////////////////////////////////
const videoStyle = {
    color: '#f00f0f',
};
const videoExtList = [
    'avi',
    '3g2',
    '3gp',
    'aep',
    'asf',
    'flv',
    'm4v',
    'mkv',
    'mov',
    'mp4',
    'mpeg',
    'mpg',
    'ogv',
    'pr',
    'swfw',
    'webm',
    'wmv',
    'swf',
    'rm',
];
styleDef.push([videoStyle, videoExtList]);
// image ////////////////////////////////////
const imageStyle = {
    color: '#d18f00',
};
const imageExtList = ['png', 'jpg', 'jpeg', 'gif', 'bmp', 'tif', 'tiff', 'apng', 'tga'];
styleDef.push([imageStyle, imageExtList]);
// zip ////////////////////////////////////
const zipStyle = {
    color: '#f7b500',
    labelTextColor: '#000',
    // glyphColor: "#de9400"
};
const zipExtList = ['zip', 'zipx', '7zip', 'tar', 'sitx', 'gz', 'rar'];
styleDef.push([zipStyle, zipExtList]);
// audio ////////////////////////////////////
const audioStyle = {
    color: '#f00f0f',
};
const audioExtList = ['aac', 'aif', 'aiff', 'flac', 'm4a', 'mid', 'mp3', 'ogg', 'wav'];
styleDef.push([audioStyle, audioExtList]);
// text ////////////////////////////////////
const textStyle = {
    color: '#ffffff',
    glyphColor: '#787878',
};
const textExtList = ['cue', 'odt', 'md', 'rtf', 'txt', 'tex', 'wpd', 'wps', 'xlr', 'fodt'];
styleDef.push([textStyle, textExtList]);
// system ////////////////////////////////////
const systemStyle = {
    color: '#111',
};
const systemExtList = ['exe', 'ini', 'dll', 'plist', 'sys'];
styleDef.push([systemStyle, systemExtList]);
// srcCode ////////////////////////////////////
const srcCodeStyle = {
    glyphColor: '#787878',
    color: '#ffffff',
};
const srcCodeExtList = [
    'asp',
    'aspx',
    'c',
    'cpp',
    'cs',
    'css',
    'scss',
    'py',
    'json',
    'htm',
    'html',
    'java',
    'yml',
    'php',
    'js',
    'ts',
    'rb',
    'jsx',
    'tsx',
];
styleDef.push([srcCodeStyle, srcCodeExtList]);
// vector ////////////////////////////////////
const vectorStyle = {
    color: '#ffe600',
};
const vectorExtList = ['dwg', 'dxf', 'ps', 'svg', 'eps'];
styleDef.push([vectorStyle, vectorExtList]);
// font ////////////////////////////////////
const fontStyle = {
    color: '#555',
};
const fontExtList = ['fnt', 'ttf', 'otf', 'fon', 'eot', 'woff'];
styleDef.push([fontStyle, fontExtList]);
// objectModel ////////////////////////////////////
const objectModelStyle = {
    color: '#bf6a02',
    glyphColor: '#bf6a02',
};
const objectModelExtList = ['3dm', '3ds', 'max', 'obj', 'pkg'];
styleDef.push([objectModelStyle, objectModelExtList]);
// sheet ////////////////////////////////////
const sheetStyle = {
    color: '#2a6e00',
};
const sheetExtList = ['csv', 'fods', 'ods', 'xlr'];
styleDef.push([sheetStyle, sheetExtList]);
// const defaultStyle: Record<string, FileIconProps> = {
//   pdf: {
// glyphColor: "white",
// color: "#D93831"
//   }
// };
//////////////////////////////////////////////////
function createStyleObj(extList, styleObj) {
    return Object.fromEntries(extList.map((ext) => {
        return [ext, { ...styleObj, glyphColor: 'white' }];
    }));
}
const styleDefObj = styleDef.reduce((acc, [fileStyle, fileExtList]) => {
    return { ...acc, ...createStyleObj(fileExtList, fileStyle) };
});

const logger$4 = new Logger$1('FilePicker');
var FileSelectionType;
(function (FileSelectionType) {
    FileSelectionType[FileSelectionType["FILE"] = 0] = "FILE";
    FileSelectionType[FileSelectionType["FOLDER"] = 1] = "FOLDER";
})(FileSelectionType || (FileSelectionType = {}));
const sortOptions = [
    {
        data: SortOptions$1.name_desc,
        label: SP_JSX.jsx(TSortOptions, { trans_part: SortOptions$1.name_desc }),
    },
    {
        data: SortOptions$1.name_asc,
        label: SP_JSX.jsx(TSortOptions, { trans_part: SortOptions$1.name_asc }),
    },
    {
        data: SortOptions$1.modified_desc,
        label: SP_JSX.jsx(TSortOptions, { trans_part: SortOptions$1.modified_desc }),
    },
    {
        data: SortOptions$1.modified_asc,
        label: SP_JSX.jsx(TSortOptions, { trans_part: SortOptions$1.modified_asc }),
    },
    {
        data: SortOptions$1.created_desc,
        label: SP_JSX.jsx(TSortOptions, { trans_part: SortOptions$1.created_desc }),
    },
    {
        data: SortOptions$1.created_asc,
        label: SP_JSX.jsx(TSortOptions, { trans_part: SortOptions$1.created_asc }),
    },
    {
        data: SortOptions$1.size_desc,
        label: SP_JSX.jsx(TSortOptions, { trans_part: SortOptions$1.size_desc }),
    },
    {
        data: SortOptions$1.size_asc,
        label: SP_JSX.jsx(TSortOptions, { trans_part: SortOptions$1.size_asc }),
    },
];
const getList = DeckyBackend.callable('utilities/filepicker_ls');
const iconStyles = {
    paddingRight: '10px',
    width: '1em',
};
const FilePicker$1 = ({ startPath, 
// What are we allowing to show in the file picker
includeFiles = true, includeFolders = true, 
// Parameter for specifying a specific filename match
filter = undefined, 
// Filter for specific extensions as an array
validFileExtensions = undefined, 
// Allow to override the fixed extension above
allowAllFiles = true, 
// If we need to show hidden files and folders (both Win and Linux should work)
defaultHidden = false, // false by default makes sense for most users
// How many files per page to show, default 1000
max = 1000, 
// Which picking option to select by default
fileSelType = FileSelectionType.FOLDER, onSubmit, closeModal, }) => {
    const { t } = useTranslation();
    if (startPath !== '/' && startPath.endsWith('/'))
        startPath = startPath.substring(0, startPath.length - 1); // remove trailing path
    const [path, setPath] = SP_REACT.useState(startPath);
    const [listing, setListing] = SP_REACT.useState({ files: [], realpath: path, total: 0 });
    const [files, setFiles] = SP_REACT.useState([]);
    const [error, setError] = SP_REACT.useState(FileErrorTypes.None);
    const [rawError, setRawError] = SP_REACT.useState(null);
    const [page, setPage] = SP_REACT.useState(1);
    const [loading, setLoading] = SP_REACT.useState(true);
    const [showHidden, setShowHidden] = SP_REACT.useState(defaultHidden);
    const [sort, setSort] = SP_REACT.useState(SortOptions$1.name_desc);
    const [selectedExts, setSelectedExts] = SP_REACT.useState(validFileExtensions);
    const validExtsOptions = SP_REACT.useMemo(() => {
        let validExt = [];
        if (validFileExtensions) {
            if (allowAllFiles) {
                validExt.push({ label: t('FilePickerIndex.files.all_files'), value: 'all_files' });
            }
            validExt.push(...validFileExtensions.map((x) => ({ label: x, value: x })));
        }
        return validExt;
    }, [validFileExtensions, allowAllFiles]);
    function isSelectionValid(validExts, selection) {
        if (validExts.some((el) => selection.includes(el)))
            return true;
        return false;
    }
    const handleExtsSelect = SP_REACT.useCallback((val) => {
        // unselect other options if "All Files" is checked
        if (allowAllFiles && val.includes('all_files')) {
            setSelectedExts(['all_files']);
        }
        else if (validFileExtensions && isSelectionValid(validFileExtensions, val)) {
            // If at least one extension is still selected, then assign this selection to the selected values
            setSelectedExts(val);
        }
        else {
            // Else do nothing
            setSelectedExts(selectedExts);
        }
    }, []);
    SP_REACT.useEffect(() => {
        (async () => {
            setLoading(true);
            try {
                const listing = await getList(path, includeFiles, includeFolders, selectedExts, showHidden, sort, filter, page, max);
                setRawError(null);
                setError(FileErrorTypes.None);
                setFiles(listing.files);
                setLoading(false);
                setListing(listing);
                logger$4.log('reloaded', path, listing);
            }
            catch (theError) {
                setListing({ files: [], realpath: path, total: 0 });
                setLoading(false);
                switch (theError) {
                    case theError.match(/\[Errno\s2.*/i)?.input:
                    case theError.match(/\[WinError\s3.*/i)?.input:
                        setError(FileErrorTypes.FileNotFound);
                        break;
                    case theError.match(/\[Errno\s13.*/i)?.input:
                        setError(FileErrorTypes.PermissionDenied);
                        break;
                    default:
                        setRawError(theError);
                        setError(FileErrorTypes.Unknown);
                        break;
                }
                logger$4.debug(theError);
                return;
            }
        })();
    }, [error, path, includeFiles, includeFolders, showHidden, sort, selectedExts, page]);
    return (SP_JSX.jsxs(SP_JSX.Fragment, { children: [SP_JSX.jsxs(DialogBody, { className: "deckyFilePicker", children: [SP_JSX.jsxs(DialogControlsSection, { children: [SP_JSX.jsxs(Focusable, { "flow-children": "right", style: { display: 'flex', marginBottom: '1em' }, children: [SP_JSX.jsx(DialogButton, { style: {
                                            display: 'flex',
                                            alignItems: 'center',
                                            justifyContent: 'center',
                                            minWidth: 'unset',
                                            width: '40px',
                                            borderRadius: 'unset',
                                            margin: '0',
                                            padding: '10px',
                                        }, onClick: () => {
                                            const newPathArr = path.split('/');
                                            const lastPath = newPathArr.pop();
                                            //If I have a single / with spaces, pop the array twice
                                            if (lastPath?.match(/^\/\s*$/) != null)
                                                newPathArr.pop();
                                            let newPath = newPathArr.join('/');
                                            if (newPath == '')
                                                newPath = '/';
                                            setPath(newPath);
                                        }, children: SP_JSX.jsx(FaArrowUp, {}) }), SP_JSX.jsx("div", { style: { width: '100%' }, children: SP_JSX.jsx(TextField, { value: path, onChange: (e) => {
                                                e.target.value && setPath(e.target.value);
                                            }, style: { height: '100%' } }) })] }), SP_JSX.jsxs(ControlsList, { alignItems: "center", spacing: "standard", children: [SP_JSX.jsx(ToggleField, { highlightOnFocus: false, label: t('FilePickerIndex.files.show_hidden'), bottomSeparator: "none", checked: showHidden, onChange: () => setShowHidden((x) => !x) }), SP_JSX.jsx(Dropdown, { rgOptions: sortOptions, selectedOption: sort, onChange: (x) => setSort(x.data) }), validFileExtensions && (SP_JSX.jsx(DropdownMultiselect, { label: t('FilePickerIndex.files.file_type'), items: validExtsOptions, selected: selectedExts ? selectedExts : [], onSelect: handleExtsSelect }))] })] }), SP_JSX.jsx(DialogControlsSection, { style: { marginTop: '1em' }, children: SP_JSX.jsxs(Focusable, { style: { display: 'flex', gap: '.25em', flexDirection: 'column', height: '60vh', overflow: 'scroll' }, children: [loading && error === FileErrorTypes.None && SP_JSX.jsx(SteamSpinner, { style: { height: '100%' } }), !loading &&
                                    error === FileErrorTypes.None &&
                                    files.map((file) => {
                                        const extension = file.realpath.split('.').pop();
                                        return (SP_JSX.jsxs(DialogButton, { style: { borderRadius: 'unset', margin: '0', padding: '10px' }, onClick: () => {
                                                const fullPath = `${path}${path.endsWith('/') ? '' : '/'}${file.name}`;
                                                if (file.isdir)
                                                    setPath(fullPath);
                                                else {
                                                    onSubmit({ path: fullPath, realpath: file.realpath });
                                                    closeModal?.();
                                                }
                                            }, children: [SP_JSX.jsxs("div", { style: { display: 'flex', flexDirection: 'row', alignItems: 'flex-start' }, children: [file.isdir ? (SP_JSX.jsx(FaFolder, { style: iconStyles })) : (SP_JSX.jsx("div", { style: iconStyles, children: file.realpath.includes('.') ? (SP_JSX.jsx(FileIcon, { ...defaultStyles[extension], ...styleDefObj[extension], extension: '' })) : (SP_JSX.jsx(FileIcon, {})) })), SP_JSX.jsx(Marquee, { children: file.name })] }), SP_JSX.jsxs("div", { style: {
                                                        display: 'flex',
                                                        opacity: 0.5,
                                                        fontSize: '.6em',
                                                        textAlign: 'left',
                                                        lineHeight: 1,
                                                        marginTop: '.5em',
                                                    }, children: [file.isdir ? t('FilePickerIndex.folder.label') : filesize(file.size, { standard: 'iec' }), SP_JSX.jsx("span", { style: { marginLeft: 'auto' }, children: new Date(file.modified * 1000).toLocaleString() })] })] }, `${file.realpath}${file.name}`));
                                    }), error !== FileErrorTypes.None && SP_JSX.jsx(FilePickerError, { error: error, rawError: rawError ? rawError : '' })] }) })] }), !loading && error === FileErrorTypes.None && (SP_JSX.jsx(DialogFooter, { children: SP_JSX.jsx(DialogButton, { className: "Primary", style: { marginTop: '10px', alignSelf: 'flex-end' }, onClick: () => {
                        onSubmit({ path, realpath: listing.realpath });
                        closeModal?.();
                    }, children: fileSelType === FileSelectionType.FILE
                        ? t('FilePickerIndex.file.select')
                        : t('FilePickerIndex.folder.select') }) })), page * max < listing.total && (SP_JSX.jsx(DialogFooter, { children: SP_JSX.jsx(DialogButton, { className: "Primary", style: { marginTop: '10px', alignSelf: 'flex-end' }, onClick: () => {
                        setPage(page + 1);
                    }, children: t('FilePickerIndex.folder.show_more') }) }))] }));
};

var index = /*#__PURE__*/Object.freeze({
  __proto__: null,
  get FileSelectionType () { return FileSelectionType; },
  default: FilePicker$1
});

// import library from './library';
// let patches: Function[] = [];
async function initFilepickerPatches() {
    // patches.push(await library());
}

var PluginLoadType;
(function (PluginLoadType) {
    PluginLoadType[PluginLoadType["LEGACY_EVAL_IIFE"] = 0] = "LEGACY_EVAL_IIFE";
    PluginLoadType[PluginLoadType["ESMODULE_V1"] = 1] = "ESMODULE_V1";
})(PluginLoadType || (PluginLoadType = {}));
var InstallType;
(function (InstallType) {
    InstallType[InstallType["INSTALL"] = 0] = "INSTALL";
    InstallType[InstallType["REINSTALL"] = 1] = "REINSTALL";
    InstallType[InstallType["UPDATE"] = 2] = "UPDATE";
    InstallType[InstallType["DOWNGRADE"] = 3] = "DOWNGRADE";
    InstallType[InstallType["OVERWRITE"] = 4] = "OVERWRITE";
})(InstallType || (InstallType = {}));
// values are the JSON keys used in the translation file
// IMPORTANT! keep in sync with `t(...)` comments where this is used
const InstallTypeTranslationMapping = {
    [InstallType.INSTALL]: 'install',
    [InstallType.REINSTALL]: 'reinstall',
    [InstallType.UPDATE]: 'update',
    [InstallType.DOWNGRADE]: 'downgrade',
    [InstallType.OVERWRITE]: 'overwrite',
};
let installPlugin = DeckyBackend.callable('utilities/install_plugin');
let installPlugins = DeckyBackend.callable('utilities/install_plugins');
let uninstallPlugin = DeckyBackend.callable('utilities/uninstall_plugin');
let enablePlugin = DeckyBackend.callable('utilities/enable_plugin');
let disablePlugin = DeckyBackend.callable('utilities/disable_plugin');

const PluginInstallProgress = ({ percentage, operationText }) => {
    return (SP_JSX.jsx("div", { style: { width: '100%', margin: '16px 0 0' }, children: SP_JSX.jsx(Field, { bottomSeparator: "none", childrenLayout: "below", focusable: false, padding: "standard", children: SP_JSX.jsxs("div", { style: { width: '100%' }, children: [SP_JSX.jsx("div", { style: {
                            minHeight: '22px',
                            width: '100%',
                            textAlign: 'left',
                            textTransform: 'uppercase',
                        }, children: operationText }), SP_JSX.jsx(ProgressBar, { focusable: false, nProgress: percentage })] }) }) }));
};

const MultiplePluginsInstallModal = ({ requests, disabledPlugins, onOK, onCancel, closeModal, }) => {
    const [loading, setLoading] = SP_REACT.useState(false);
    const [percentage, setPercentage] = SP_REACT.useState(0);
    const [pluginsCompleted, setPluginsCompleted] = SP_REACT.useState([]);
    const [pluginInProgress, setInProgress] = SP_REACT.useState();
    const [downloadInfo, setDownloadInfo] = SP_REACT.useState(null);
    const { t } = useTranslation();
    function updateDownloadState(percent, trans_text, trans_info) {
        setPercentage(percent);
        if (trans_text === undefined) {
            setDownloadInfo(null);
        }
        else {
            setDownloadInfo(t(trans_text, trans_info));
        }
    }
    function startDownload(name) {
        setInProgress(name);
        setPercentage(0);
    }
    function finishDownload(name) {
        setPluginsCompleted((list) => [...list, name]);
    }
    SP_REACT.useEffect(() => {
        DeckyBackend.addEventListener('loader/plugin_download_info', updateDownloadState);
        DeckyBackend.addEventListener('loader/plugin_download_start', startDownload);
        DeckyBackend.addEventListener('loader/plugin_download_finish', finishDownload);
        return () => {
            DeckyBackend.removeEventListener('loader/plugin_download_info', updateDownloadState);
            DeckyBackend.removeEventListener('loader/plugin_download_start', startDownload);
            DeckyBackend.removeEventListener('loader/plugin_download_finish', finishDownload);
        };
    }, []);
    // used as part of the title translation
    // if we know all operations are of a specific type, we can show so in the title to make decision easier
    const installTypeGrouped = SP_REACT.useMemo(() => {
        if (requests.every(({ install_type }) => install_type === InstallType.INSTALL))
            return 'install';
        if (requests.every(({ install_type }) => install_type === InstallType.REINSTALL))
            return 'reinstall';
        if (requests.every(({ install_type }) => install_type === InstallType.UPDATE))
            return 'update';
        if (requests.every(({ install_type }) => install_type === InstallType.DOWNGRADE))
            return 'downgrade';
        if (requests.every(({ install_type }) => install_type === InstallType.OVERWRITE))
            return 'overwrite';
        return 'mixed';
    }, [requests]);
    return (SP_JSX.jsx(ConfirmModal, { bOKDisabled: loading, closeModal: closeModal, onOK: async () => {
            setLoading(true);
            await onOK();
            setTimeout(() => Navigation.OpenQuickAccessMenu(QuickAccessTab.Decky), 250);
            setTimeout(() => DeckyPluginLoader.checkPluginUpdates(), 1000);
        }, onCancel: async () => {
            await onCancel();
        }, strTitle: SP_JSX.jsx("div", { children: 
            // IMPORTANT! These comments are not cosmetic and are needed for `extracttext` task to work
            // t('MultiplePluginsInstallModal.title.install', { count: n })
            // t('MultiplePluginsInstallModal.title.reinstall', { count: n })
            // t('MultiplePluginsInstallModal.title.update', { count: n })
            // t('MultiplePluginsInstallModal.title.downgrade', { count: n })
            // t('MultiplePluginsInstallModal.title.overwrite', { count: n })
            // t('MultiplePluginsInstallModal.title.mixed', { count: n })
            t(`MultiplePluginsInstallModal.title.${installTypeGrouped}`, { count: requests.length }) }), strOKButtonText: loading ? t('MultiplePluginsInstallModal.ok_button.loading') : t('MultiplePluginsInstallModal.ok_button.idle'), children: SP_JSX.jsxs("div", { children: [t('MultiplePluginsInstallModal.confirm'), SP_JSX.jsx("ul", { style: { listStyle: 'none', display: 'flex', flexDirection: 'column', gap: '4px' }, children: requests.map(({ name, version, install_type, hash }, i) => {
                        const installTypeStr = InstallTypeTranslationMapping[install_type];
                        // IMPORTANT! These comments are not cosmetic and are needed for `extracttext` task to work
                        // t('MultiplePluginsInstallModal.description.install')
                        // t('MultiplePluginsInstallModal.description.reinstall')
                        // t('MultiplePluginsInstallModal.description.update')
                        // t('MultiplePluginsInstallModal.description.downgrade')
                        // t('MultiplePluginsInstallModal.description.overwrite')
                        const description = t(`MultiplePluginsInstallModal.description.${installTypeStr}`, {
                            name,
                            version,
                        });
                        const disabled = disabledPlugins.some((p) => p.name === name);
                        return (SP_JSX.jsxs("li", { style: { display: 'flex', flexDirection: 'column' }, children: [SP_JSX.jsxs("span", { children: [disabled ? `${description} - ${t('PluginInstallModal.disabled')}` : description, ' ', (pluginsCompleted.includes(name) && SP_JSX.jsx(FaCheck, {})) || (name === pluginInProgress && SP_JSX.jsx(FaDownload, {}))] }), hash === 'False' && (SP_JSX.jsx("div", { style: { color: 'red', paddingLeft: '10px' }, children: t('PluginInstallModal.no_hash') }))] }, i));
                    }) }), loading && (SP_JSX.jsx(PluginInstallProgress
                // when the key changes, react considers this a new component so resets the progress without the smoothing animation
                , { percentage: percentage, operationText: downloadInfo }, pluginInProgress))] }) }));
};

const PluginDisableModal = ({ name, title, buttonText, description, closeModal }) => {
    const [disabling, setDisabling] = SP_REACT.useState(false);
    return (SP_JSX.jsx(ConfirmModal, { closeModal: closeModal, onOK: async () => {
            setDisabling(true);
            await disablePlugin(name);
            closeModal?.();
        }, bOKDisabled: disabling, bCancelDisabled: disabling, strTitle: SP_JSX.jsxs("div", { style: { display: 'flex', flexDirection: 'row', alignItems: 'center', width: '100%' }, children: [title, disabling && SP_JSX.jsx(Spinner, { width: "24px", height: "24px", style: { marginLeft: 'auto' } })] }), strOKButtonText: buttonText, children: description }));
};

const PluginInstallModal = ({ artifact, version, hash, installType, disabled, onOK, onCancel, closeModal, }) => {
    const [loading, setLoading] = SP_REACT.useState(false);
    const [percentage, setPercentage] = SP_REACT.useState(0);
    const [downloadInfo, setDownloadInfo] = SP_REACT.useState(null);
    const { t } = useTranslation();
    function updateDownloadState(percent, trans_text, trans_info) {
        setPercentage(percent);
        if (trans_text === undefined) {
            setDownloadInfo(null);
        }
        else {
            setDownloadInfo(t(trans_text, trans_info));
        }
    }
    SP_REACT.useEffect(() => {
        DeckyBackend.addEventListener('loader/plugin_download_info', updateDownloadState);
        return () => {
            DeckyBackend.removeEventListener('loader/plugin_download_info', updateDownloadState);
        };
    }, []);
    const installTypeTranslationKey = InstallTypeTranslationMapping[installType];
    const description = t(`PluginInstallModal.${installTypeTranslationKey}.desc`, {
        artifact: artifact,
        version: version,
    });
    return (SP_JSX.jsxs(ConfirmModal, { bOKDisabled: loading, closeModal: closeModal, onOK: async () => {
            setLoading(true);
            await onOK();
            setTimeout(() => Navigation.OpenQuickAccessMenu(QuickAccessTab.Decky), 250);
            setTimeout(() => DeckyPluginLoader.checkPluginUpdates(), 1000);
        }, onCancel: async () => {
            await onCancel();
        }, strTitle: SP_JSX.jsx("div", { children: 
            // IMPORTANT! These comments are not cosmetic and are needed for `extracttext` task to work
            // t('PluginInstallModal.install.title')
            // t('PluginInstallModal.reinstall.title')
            // t('PluginInstallModal.update.title')
            // t('PluginInstallModal.downgrade.title')
            // t('PluginInstallModal.overwrite.title')
            t(`PluginInstallModal.${installTypeTranslationKey}.title`, { artifact: artifact }) }), strOKButtonText: loading ? (SP_JSX.jsx("div", { children: 
            // IMPORTANT! These comments are not cosmetic and are needed for `extracttext` task to work
            // t('PluginInstallModal.install.button_processing')
            // t('PluginInstallModal.reinstall.button_processing')
            // t('PluginInstallModal.update.button_processing')
            // t('PluginInstallModal.downgrade.button_processing')
            // t('PluginInstallModal.overwrite.button_processing')
            t(`PluginInstallModal.${installTypeTranslationKey}.button_processing`) })) : (SP_JSX.jsx("div", { children: 
            // IMPORTANT! These comments are not cosmetic and are needed for `extracttext` task to work
            // t('PluginInstallModal.install.button_idle')
            // t('PluginInstallModal.reinstall.button_idle')
            // t('PluginInstallModal.update.button_idle')
            // t('PluginInstallModal.downgrade.button_idle')
            // t('PluginInstallModal.overwrite.button_idle')
            t(`PluginInstallModal.${installTypeTranslationKey}.button_idle`) })), children: [SP_JSX.jsx("div", { children: 
                // IMPORTANT! These comments are not cosmetic and are needed for `extracttext` task to work
                // t('PluginInstallModal.install.desc')
                // t('PluginInstallModal.reinstall.desc')
                // t('PluginInstallModal.update.desc')
                // t('PluginInstallModal.downgrade.desc')
                // t('PluginInstallModal.overwrite.desc')
                disabled ? `${description} ${t('PluginInstallModal.disabled')}` : description }), hash == 'False' && SP_JSX.jsx("span", { style: { color: 'red' }, children: t('PluginInstallModal.no_hash') }), loading && SP_JSX.jsx(PluginInstallProgress, { percentage: percentage, operationText: downloadInfo })] }));
};

const PluginUninstallModal = ({ name, title, buttonText, description, deckyState, closeModal, }) => {
    const [uninstalling, setUninstalling] = SP_REACT.useState(false);
    return (SP_JSX.jsx(ConfirmModal, { closeModal: closeModal, onOK: async () => {
            setUninstalling(true);
            await uninstallPlugin(name);
            deckyState.setDisabledPlugins(deckyState.publicState().disabledPlugins.filter((d) => d.name !== name));
            // uninstalling a plugin resets the hidden setting for it server-side
            // we invalidate here so if you re-install it, you won't have an out-of-date hidden filter
            await DeckyPluginLoader.frozenPluginsService.invalidate();
            await DeckyPluginLoader.hiddenPluginsService.invalidate();
            closeModal?.();
        }, bOKDisabled: uninstalling, bCancelDisabled: uninstalling, strTitle: SP_JSX.jsxs("div", { style: { display: 'flex', flexDirection: 'row', alignItems: 'center', width: '100%' }, children: [title, uninstalling && SP_JSX.jsx(Spinner, { width: "24px", height: "24px", style: { marginLeft: 'auto' } })] }), strOKButtonText: buttonText, children: description }));
};

const NotificationBadge = ({ show, style }) => {
    return show ? (SP_JSX.jsx("div", { style: {
            position: 'absolute',
            top: '8px',
            right: '8px',
            height: '10px',
            width: '10px',
            background: 'orange',
            borderRadius: '50%',
            ...style,
        } })) : null;
};

const QuickAccessVisibleState = SP_REACT.createContext(false);
const useQuickAccessVisible = () => SP_REACT.useContext(QuickAccessVisibleState);
const QuickAccessVisibleStateProvider = ({ children, tab }) => {
    const initial = tab.initialVisibility;
    const [visible, setVisible] = SP_REACT.useState(initial);
    // HACK but i can't think of a better way to do this
    tab.qAMVisibilitySetter = (val) => {
        if (val != visible)
            setVisible(val);
    };
    return SP_JSX.jsx(QuickAccessVisibleState.Provider, { value: visible, children: children });
};

// THIS FILE IS AUTO GENERATED
function BsGearFill (props) {
  return GenIcon({"tag":"svg","attr":{"fill":"currentColor","viewBox":"0 0 16 16"},"child":[{"tag":"path","attr":{"d":"M9.405 1.05c-.413-1.4-2.397-1.4-2.81 0l-.1.34a1.464 1.464 0 0 1-2.105.872l-.31-.17c-1.283-.698-2.686.705-1.987 1.987l.169.311c.446.82.023 1.841-.872 2.105l-.34.1c-1.4.413-1.4 2.397 0 2.81l.34.1a1.464 1.464 0 0 1 .872 2.105l-.17.31c-.698 1.283.705 2.686 1.987 1.987l.311-.169a1.464 1.464 0 0 1 2.105.872l.1.34c.413 1.4 2.397 1.4 2.81 0l.1-.34a1.464 1.464 0 0 1 2.105-.872l.31.17c1.283.698 2.686-.705 1.987-1.987l-.169-.311a1.464 1.464 0 0 1 .872-2.105l.34-.1c1.4-.413 1.4-2.397 0-2.81l-.34-.1a1.464 1.464 0 0 1-.872-2.105l.17-.31c.698-1.283-.705-2.686-1.987-1.987l-.311.169a1.464 1.464 0 0 1-2.105-.872zM8 10.93a2.929 2.929 0 1 1 0-5.86 2.929 2.929 0 0 1 0 5.858z"},"child":[]}]})(props);
}

const titleStyles = {
    display: 'flex',
    paddingRight: '16px',
    position: 'sticky',
    top: '0px',
};
const TitleView = () => {
    const { activePlugin, closeActivePlugin } = useDeckyState();
    const { t } = useTranslation();
    const onSettingsClick = () => {
        Navigation.Navigate('/decky/settings');
        Navigation.CloseSideMenus();
    };
    const onStoreClick = () => {
        Navigation.Navigate('/decky/store');
        Navigation.CloseSideMenus();
    };
    if (activePlugin === null) {
        return (SP_JSX.jsxs(Focusable, { style: titleStyles, className: staticClasses.Title, children: [SP_JSX.jsx("div", { style: { marginRight: 'auto', flex: 0.9 }, children: "Decky" }), SP_JSX.jsx(DialogButton, { style: { height: '28px', width: '40px', minWidth: 0, padding: '10px 12px' }, onClick: onStoreClick, onOKActionDescription: t('TitleView.decky_store_desc'), children: SP_JSX.jsx(FaStore, { style: { marginTop: '-4px', display: 'block' } }) }), SP_JSX.jsx(DialogButton, { style: { height: '28px', width: '40px', minWidth: 0, padding: '10px 12px' }, onClick: onSettingsClick, onOKActionDescription: t('TitleView.settings_desc'), children: SP_JSX.jsx(BsGearFill, { style: { marginTop: '-4px', display: 'block' } }) })] }));
    }
    return (SP_JSX.jsxs(Focusable, { className: staticClasses.Title, style: titleStyles, children: [SP_JSX.jsx(DialogButton, { style: { height: '28px', width: '40px', minWidth: 0, padding: '10px 12px' }, onClick: closeActivePlugin, children: SP_JSX.jsx(FaArrowLeft, { style: { marginTop: '-4px', display: 'block' } }) }), activePlugin?.titleView || SP_JSX.jsx("div", { style: { flex: 0.9 }, children: activePlugin.name })] }));
};

const PluginView = () => {
    const { plugins, disabledPlugins, hiddenPlugins, updates, activePlugin, pluginOrder, sortPlugins, setActivePlugin, closeActivePlugin, } = useDeckyState();
    const visible = useQuickAccessVisible();
    const { t } = useTranslation();
    const pluginList = SP_REACT.useMemo(() => {
        console.log('updating PluginView after changes');
        return [...plugins]
            .sort((a, b) => sortPlugins
            ? a.name.localeCompare(b.name, undefined, { sensitivity: 'base' })
            : pluginOrder.indexOf(a.name) - pluginOrder.indexOf(b.name))
            .filter((p) => p.content)
            .filter(({ name }) => !hiddenPlugins.includes(name));
    }, [plugins, pluginOrder, sortPlugins, hiddenPlugins]);
    const numberOfHidden = hiddenPlugins.filter((name) => !!plugins.find((p) => p.name === name)).length;
    if (activePlugin) {
        return (SP_JSX.jsxs(Focusable, { onCancelButton: closeActivePlugin, children: [SP_JSX.jsx(TitleView, {}), SP_JSX.jsx("div", { style: { height: '100%', paddingTop: '16px' }, children: SP_JSX.jsx(ErrorBoundary, { children: (visible || activePlugin.alwaysRender) && activePlugin.content }) })] }));
    }
    return (SP_JSX.jsxs(SP_JSX.Fragment, { children: [SP_JSX.jsx(TitleView, {}), SP_JSX.jsx("div", { style: {
                    paddingTop: '16px',
                }, children: SP_JSX.jsxs(PanelSection, { children: [pluginList.map(({ name, icon }) => (SP_JSX.jsx(PanelSectionRow, { children: SP_JSX.jsx(ButtonItem, { layout: "below", onClick: () => setActivePlugin(name), children: SP_JSX.jsxs("div", { style: { display: 'flex', alignItems: 'center', justifyContent: 'space-between' }, children: [icon, SP_JSX.jsx("div", { children: name }), SP_JSX.jsx(NotificationBadge, { show: updates?.has(name), style: { top: '-5px', right: '-5px' } })] }) }) }, name))), SP_JSX.jsxs("div", { style: {
                                display: 'flex',
                                flexDirection: 'column',
                                position: 'absolute',
                                justifyContent: 'center',
                                padding: '5px 0px',
                            }, children: [numberOfHidden > 0 && (SP_JSX.jsxs("div", { style: { display: 'flex', alignItems: 'center', gap: '10px', fontSize: '0.8rem' }, children: [SP_JSX.jsx(FaEyeSlash, {}), SP_JSX.jsx("div", { children: t('PluginView.hidden', { count: numberOfHidden }) })] })), disabledPlugins.length > 0 && (SP_JSX.jsxs("div", { style: { display: 'flex', alignItems: 'center', gap: '10px', fontSize: '0.8rem' }, children: [SP_JSX.jsx(FaBan, {}), SP_JSX.jsx("div", { children: t('PluginView.disabled', { count: disabledPlugins.length }) })] }))] })] }) })] }));
};

// Nice little wrapper around Suspense so we don't have to duplicate the styles and code for the loading spinner
const WithSuspense = (props) => {
    const propsCopy = { ...props };
    delete propsCopy.children;
    props.children?.props && Object.assign(props.children.props, propsCopy); // There is probably a better way to do this but valve does it this way so ¯\_(ツ)_/¯
    return (SP_JSX.jsx(SP_REACT.Suspense, { fallback: SP_JSX.jsx(Focusable
        // needed to enable focus ring so that the focus properly resets on load
        , { 
            // needed to enable focus ring so that the focus properly resets on load
            onActivate: () => { }, style: {
                overflowY: 'scroll',
                backgroundColor: 'transparent',
                ...(props.route && {
                    marginTop: '40px',
                    height: 'calc( 100% - 40px )',
                }),
            }, children: SP_JSX.jsx(SteamSpinner, { background: "transparent" }) }), children: props.children }));
};

var Branches;
(function (Branches) {
    Branches[Branches["Release"] = 0] = "Release";
    Branches[Branches["Prerelease"] = 1] = "Prerelease";
    // Testing,
})(Branches || (Branches = {}));
const doUpdate = DeckyBackend.callable('updater/do_update');
const doRestart = DeckyBackend.callable('updater/do_restart');
const doShutdown = DeckyBackend.callable('updater/do_shutdown');
const getVersionInfo = DeckyBackend.callable('updater/get_version_info');
const checkForUpdates = DeckyBackend.callable('updater/check_for_updates');

const pluginErrorRegex = /http:\/\/(?:localhost|127\.0\.0\.1):1337\/plugins\/([^\/]*)\//;
const pluginSourceMapErrorRegex = /decky:\/\/decky\/plugin\/([^\/]*)\//;
const legacyPluginErrorRegex = /decky:\/\/decky\/legacy_plugin\/([^\/]*)\/index.js/;
function getLikelyErrorSourceFromValveError(error) {
    return getLikelyErrorSource(JSON.stringify(error?.message));
}
function getLikelyErrorSourceFromValveReactError(error) {
    // get the first 10 lines of the componentStack to avoid matching against the decky router wrapper for any route errors deeper in the tree
    return getLikelyErrorSource(error?.error?.stack + '\n' + error.info.componentStack?.split('\n').slice(0, 8).join('\n'));
}
function getLikelyErrorSource(error) {
    const pluginMatch = error?.match(pluginErrorRegex);
    if (pluginMatch) {
        return [decodeURIComponent(pluginMatch[1]), true, false];
    }
    const pluginMatchViaMap = error?.match(pluginSourceMapErrorRegex);
    if (pluginMatchViaMap) {
        return [decodeURIComponent(pluginMatchViaMap[1]), true, false];
    }
    const legacyPluginMatch = error?.match(legacyPluginErrorRegex);
    if (legacyPluginMatch) {
        return [decodeURIComponent(legacyPluginMatch[1]), true, false];
    }
    if (error?.includes('http://localhost:1337/') || error?.includes('http://127.0.0.1:1337/')) {
        return ['the Decky frontend', false, false];
    }
    return ['Steam', false, true];
}

function useSetting(key, def) {
    const [value, setValue] = SP_REACT.useState(def);
    SP_REACT.useEffect(() => {
        (async () => {
            const res = await getSetting(key, def);
            setValue(res);
        })();
    }, []);
    return [
        value,
        async (val) => {
            setValue(val);
            await setSetting(key, val);
        },
    ];
}

const logger$3 = new Logger$1('BranchSelect');
var UpdateBranch;
(function (UpdateBranch) {
    UpdateBranch[UpdateBranch["Stable"] = 0] = "Stable";
    UpdateBranch[UpdateBranch["Prerelease"] = 1] = "Prerelease";
    UpdateBranch[UpdateBranch["Testing"] = 2] = "Testing";
})(UpdateBranch || (UpdateBranch = {}));
var LessUpdateBranch;
(function (LessUpdateBranch) {
    LessUpdateBranch[LessUpdateBranch["Stable"] = 0] = "Stable";
    LessUpdateBranch[LessUpdateBranch["Prerelease"] = 1] = "Prerelease";
})(LessUpdateBranch || (LessUpdateBranch = {}));
const BranchSelect = () => {
    const { t } = useTranslation();
    const tBranches = [
        t('BranchSelect.update_channel.stable'),
        t('BranchSelect.update_channel.prerelease'),
        t('BranchSelect.update_channel.testing'),
    ];
    const [selectedBranch, setSelectedBranch] = useSetting('branch', UpdateBranch.Stable);
    return (
    // Returns numerical values from 0 to 2 (with current branch setup as of 6/16/23)
    // 0 being stable, 1 being pre-release and 2 being testing (not a branch!)
    SP_JSX.jsx(Field, { label: t('BranchSelect.update_channel.label'), childrenContainerWidth: 'fixed', children: SP_JSX.jsx(Dropdown, { rgOptions: Object.values(selectedBranch == UpdateBranch.Testing ? UpdateBranch : LessUpdateBranch)
                .filter((branch) => typeof branch == 'number')
                .map((branch) => ({
                label: tBranches[branch],
                data: branch,
            })), selectedOption: selectedBranch, onChange: async (newVal) => {
                await setSelectedBranch(newVal.data);
                checkForUpdates();
                logger$3.log('switching branches!');
            } }) }));
};

const classes = {
    root: 'deckyErrorBoundary',
    likelyOccurred: 'likely-occured-msg',
    panel: 'panel-section',
    panelHeader: 'panel-header',
    trace: 'trace',
    rowList: 'row-list',
    rowItem: 'row-item',
    buttonDescRow: 'button-description-row',
    flexRowWGap: 'flex-row',
    marginBottom: 'margin-bottom',
    swipePrompt: 'swipe-prompt',
};
const vars = {
    scrollBarwidth: '18px',
    rootMarginLeft: '15px',
    panelXPadding: '20px',
};
const startSSH = DeckyBackend.callable('utilities/start_ssh');
const starrCEFForwarding = DeckyBackend.callable('utilities/allow_remote_debugging');
function ipToString(ip) {
    return [(ip >>> 24) & 255, (ip >>> 16) & 255, (ip >>> 8) & 255, (ip >>> 0) & 255].join('.');
}
// Intentionally not localized since we can't really trust React here
const DeckyErrorBoundary = ({ error, identifier, reset }) => {
    const [actionLog, addLogLine] = SP_REACT.useReducer((log, line) => (log += '\n' + line), '');
    const [actionsEnabled, setActionsEnabled] = SP_REACT.useState(true);
    const [debugAllowed, setDebugAllowed] = SP_REACT.useState(true);
    // Intentionally doesn't use DeckyState.
    const [versionInfo, setVersionInfo] = SP_REACT.useState();
    const [errorSource, wasCausedByPlugin, shouldReportToValve] = getLikelyErrorSourceFromValveReactError(error);
    SP_REACT.useEffect(() => {
        if (!shouldReportToValve)
            DeckyPluginLoader.errorBoundaryHook.temporarilyDisableReporting();
        DeckyPluginLoader.updateVersion().then(setVersionInfo);
    }, []);
    const [selectedBranch, setSelectedBranch] = useSetting('branch', UpdateBranch.Stable);
    const [isChecking, setIsChecking] = SP_REACT.useState(false);
    const [updateProgress, setUpdateProgress] = SP_REACT.useState(-1);
    const [versionToUpdateTo, setSetVersionToUpdateTo] = SP_REACT.useState('');
    SP_REACT.useEffect(() => {
        const a = DeckyBackend.addEventListener('updater/update_download_percentage', (percentage) => {
            setUpdateProgress(percentage);
        });
        const b = DeckyBackend.addEventListener('updater/finish_download', () => {
            setUpdateProgress(-2);
        });
        return () => {
            DeckyBackend.removeEventListener('updater/update_download_percentage', a);
            DeckyBackend.removeEventListener('updater/finish_download', b);
        };
    }, []);
    return (SP_JSX.jsxs(SP_JSX.Fragment, { children: [SP_JSX.jsx("style", { children: `
          *:has(> .${classes.root}) {
            margin-top: var(--basicui-header-height);
            overflow: scroll !important;
            background: #000;
          }
          *:has(> .${classes.root})::-webkit-scrollbar {
            display: initial !important;
            width: ${vars.scrollBarwidth};
            height: 0px;
          }
          *:has(> .${classes.root})::-webkit-scrollbar-thumb {
            background: #4349535e;
          }
          .${classes.root} {
            color: #93929e;
            font-size: 15px;
            margin: 10px 0px 40px ${vars.rootMarginLeft};
            overflow: visible;
          }
          .${classes.root} button,
          .${classes.root} select {
            border: none;
            padding: 4px 16px !important;
            background: #333;
            color: #ddd;
            font-size: 12px;
            border-radius: 3px;
            outline: none;
            height: 28px;
          }
          .${classes.panel} {
            background: #080808;
            padding: 8px ${vars.panelXPadding};
            border-radius: 3px;
            /* box-shadow: 9px 9px 20px -5px rgb(0 0 0 / 89%); */
          }
          .${classes.panelHeader} {
            font-size: 18px;
            font-weight: bolder;
            text-transform: uppercase;
          }
          .${classes.likelyOccurred} {
            font-size: 22px;
            font-weight: bold;
            color: #588fb4;
          }
          .${classes.rowItem} {
            position: relative;
          }
          .${classes.rowItem}:not(:last-child)::after {
            content: '';
            position: absolute;
            bottom: -4.5px;
            left: 5px;
            right: 15px;
            height: 0.5px;
            background: #3c3c3c47;
          }
          .${classes.flexRowWGap},
          .${classes.buttonDescRow},
          .${classes.rowList},
          .${classes.panel} {
            display: flex;
          }

          .${classes.rowList},
          .${classes.panel} {
            flex-direction: column;
          }
          .${classes.flexRowWGap},
          .${classes.rowList} {
            gap: 8px;
          }
          .${classes.marginBottom} {
            margin-bottom: 10px;
          }
          .${classes.buttonDescRow} {
            justify-content: space-between;
            align-items: center;
          }

          .${classes.swipePrompt} {
            display: flex;
            align-items: center;
            text-align: center;
            position: relative;
            font-style: italic;
            font-size: small;
            margin: 16px 0;
          }
          .${classes.swipePrompt} span {
            padding: 0 8px;
            background-color: #000;
            position: relative;
            z-index: 1;
          }
          .${classes.swipePrompt}::before,
          .${classes.swipePrompt}::after {
            content: "";
            flex-grow: 1;
            border-bottom: 1px solid #474752;
            top: 50%;
          }
          .${classes.swipePrompt}::before {
            right: 50%;
            margin-right: 8px;
          }
          .${classes.swipePrompt}::after {
            left: 50%;
            margin-left: 8px;
          }
        ` }), SP_JSX.jsxs("div", { className: classes.root, children: [SP_JSX.jsx("div", { className: classes.marginBottom, children: "An error occurred while rendering this content." }), SP_JSX.jsx("pre", { className: joinClassNames(classes.marginBottom), style: { marginTop: '0px' }, children: SP_JSX.jsxs("code", { children: [identifier && `Error Reference: ${identifier}`, versionInfo?.current && `\nDecky Version: ${versionInfo.current}${versionInfo.supported ? '' : '[U]'}`] }) }), SP_JSX.jsxs("div", { className: joinClassNames(classes.likelyOccurred, classes.marginBottom), children: ["This error likely occurred in ", errorSource, "."] }), actionLog?.length > 0 && (SP_JSX.jsx("pre", { children: SP_JSX.jsxs("code", { children: ["Running actions...", actionLog] }) })), actionsEnabled && (SP_JSX.jsxs("div", { className: classes.panel, children: [SP_JSX.jsxs("div", { className: classes.flexRowWGap, style: { alignItems: 'center', marginBottom: '8px' }, children: [SP_JSX.jsx("div", { className: classes.panelHeader, children: "Actions" }), SP_JSX.jsx("div", { style: { fontSize: 'small', fontStyle: 'italic' }, children: "Use the touch screen. Solutions are listed in the recommended order. If you are still experiencing issues, please post in the #loader-support channel at decky.xyz/discord." })] }), SP_JSX.jsxs("div", { className: classes.rowList, children: [SP_JSX.jsxs("div", { className: joinClassNames(classes.rowItem, classes.buttonDescRow), children: ["Retry the action or restart", SP_JSX.jsxs("div", { className: classes.flexRowWGap, children: [SP_JSX.jsx("button", { onClick: reset, children: "Retry" }), SP_JSX.jsx("button", { onClick: () => {
                                                            addLogLine('Restarting Steam...');
                                                            SteamClient.User.StartRestart(false);
                                                        }, children: "Restart Steam" }), SP_JSX.jsx("button", { onClick: async () => {
                                                            setActionsEnabled(false);
                                                            addLogLine('Restarting Decky...');
                                                            doRestart();
                                                            await sleep(2000);
                                                            addLogLine('Reloading UI...');
                                                        }, children: "Restart Decky" })] })] }), wasCausedByPlugin && (SP_JSX.jsxs("div", { className: joinClassNames(classes.rowItem, classes.buttonDescRow), children: ["Disable or uninstall the suspected plugin", SP_JSX.jsxs("div", { className: classes.flexRowWGap, children: [SP_JSX.jsxs("button", { onClick: async () => {
                                                            setActionsEnabled(false);
                                                            addLogLine(`Disabling ${errorSource}...`);
                                                            await disablePlugin(errorSource);
                                                            await sleep(1000);
                                                            addLogLine('Restarting Decky...');
                                                            doRestart();
                                                            await sleep(2000);
                                                            addLogLine('Restarting Steam...');
                                                            await sleep(500);
                                                            SteamClient.User.StartRestart(false);
                                                        }, children: ["Disable ", errorSource] }), SP_JSX.jsxs("button", { onClick: async () => {
                                                            setActionsEnabled(false);
                                                            addLogLine(`Uninstalling ${errorSource}...`);
                                                            await uninstallPlugin(errorSource);
                                                            await DeckyPluginLoader.frozenPluginsService.invalidate();
                                                            await DeckyPluginLoader.hiddenPluginsService.invalidate();
                                                            await sleep(1000);
                                                            addLogLine('Restarting Decky...');
                                                            doRestart();
                                                            await sleep(2000);
                                                            addLogLine('Restarting Steam...');
                                                            await sleep(500);
                                                            SteamClient.User.StartRestart(false);
                                                        }, children: ["Uninstall ", errorSource] })] })] })), SP_JSX.jsxs("div", { className: joinClassNames(classes.rowItem, classes.buttonDescRow), children: ["Disable all plugins", SP_JSX.jsx("button", { onClick: async () => {
                                                    setActionsEnabled(false);
                                                    addLogLine(`Disabling plugins...`);
                                                    await DeckyBackend.call('utilities/set_all_plugins_disabled');
                                                    await sleep(1000);
                                                    addLogLine('Restarting Decky...');
                                                    doRestart();
                                                    await sleep(2000);
                                                    addLogLine('Restarting Steam...');
                                                    await sleep(500);
                                                    SteamClient.User.StartRestart(false);
                                                }, children: "Disable All Plugins" })] }), SP_JSX.jsxs("div", { className: joinClassNames(classes.rowItem, classes.buttonDescRow), children: [updateProgress > -1
                                                ? 'Update in progress... ' + updateProgress + '%'
                                                : updateProgress == -2
                                                    ? 'Update complete. Restarting...'
                                                    : 'Check for Decky updates', SP_JSX.jsx("div", { className: classes.flexRowWGap, children: updateProgress == -1 && (SP_JSX.jsxs(SP_JSX.Fragment, { children: [SP_JSX.jsxs("select", { onChange: async (e) => {
                                                                const branch = parseInt(e.target.value);
                                                                setSelectedBranch(branch);
                                                                setSetVersionToUpdateTo('');
                                                            }, children: [SP_JSX.jsx("option", { value: "0", selected: selectedBranch == UpdateBranch.Stable, children: "Stable" }), SP_JSX.jsx("option", { value: "1", selected: selectedBranch == UpdateBranch.Prerelease, children: "Pre-Release" }), SP_JSX.jsx("option", { value: "2", selected: selectedBranch == UpdateBranch.Testing, children: "Testing" })] }), SP_JSX.jsxs("button", { disabled: updateProgress != -1 || isChecking, onClick: async () => {
                                                                if (versionToUpdateTo == '') {
                                                                    setIsChecking(true);
                                                                    const versionInfo = (await DeckyBackend.callable('updater/check_for_updates')());
                                                                    setIsChecking(false);
                                                                    if (versionInfo?.remote && versionInfo?.remote?.tag_name != versionInfo?.current) {
                                                                        setSetVersionToUpdateTo(versionInfo.remote.tag_name);
                                                                    }
                                                                    else {
                                                                        setSetVersionToUpdateTo('');
                                                                    }
                                                                }
                                                                else {
                                                                    DeckyBackend.callable('updater/do_update')();
                                                                    setUpdateProgress(0);
                                                                }
                                                            }, children: [' ', isChecking
                                                                    ? 'Checking for updates...'
                                                                    : versionToUpdateTo != ''
                                                                        ? 'Update to ' + versionToUpdateTo
                                                                        : 'Check for updates'] })] })) })] }), SP_JSX.jsxs("div", { className: joinClassNames(classes.rowItem, classes.buttonDescRow), children: ["Disable Decky until next boot", SP_JSX.jsx("button", { onClick: async () => {
                                                    setActionsEnabled(false);
                                                    addLogLine('Stopping Decky...');
                                                    doShutdown();
                                                    await sleep(5000);
                                                    addLogLine('Restarting Steam...');
                                                    SteamClient.User.StartRestart(false);
                                                }, children: "Disable Decky" })] }), debugAllowed && (SP_JSX.jsxs("div", { className: joinClassNames(classes.rowItem, classes.buttonDescRow), children: ["Enable remote debugging and SSH until next boot (for developers)", SP_JSX.jsx("button", { onClick: async () => {
                                                    setDebugAllowed(false);
                                                    addLogLine('Enabling CEF debugger forwarding...');
                                                    await starrCEFForwarding();
                                                    addLogLine('Enabling SSH...');
                                                    await startSSH();
                                                    addLogLine('Ready for debugging!');
                                                    if (window?.SystemNetworkStore?.wirelessNetworkDevice?.ip4?.addresses?.[0]?.ip) {
                                                        const ip = ipToString(window.SystemNetworkStore.wirelessNetworkDevice.ip4.addresses[0].ip);
                                                        addLogLine(`CEF Debugger: http://${ip}:8081`);
                                                        addLogLine(`SSH: deck@${ip}`);
                                                    }
                                                }, children: "Enable" })] }))] })] })), actionsEnabled && (SP_JSX.jsx("div", { className: classes.swipePrompt, children: SP_JSX.jsx("span", { children: "Swipe to scroll" }) })), SP_JSX.jsxs("div", { className: classes.panel, children: [SP_JSX.jsx("div", { className: classes.panelHeader, children: "Trace" }), SP_JSX.jsx("pre", { style: {
                                    margin: `8px calc(-1 * ${vars.panelXPadding})`,
                                    userSelect: 'auto',
                                    overflowX: 'scroll',
                                    padding: `0px ${vars.panelXPadding}`,
                                    maskImage: `linear-gradient(to right, transparent, black ${vars.panelXPadding}, black calc(100% - ${vars.panelXPadding}), transparent)`,
                                }, children: SP_JSX.jsxs("code", { children: [error.error.stack, '\n\n', "Component Stack:", error.info.componentStack] }) })] })] })] }));
};

class ErrorBoundaryHook extends Logger$1 {
    constructor() {
        super('ErrorBoundaryHook');
        this.doNotReportErrors = false;
        this.disableReportingTimer = 0;
        this.log('Initialized');
        window.__ERRORBOUNDARY_HOOK_INSTANCE?.deinit?.();
        window.__ERRORBOUNDARY_HOOK_INSTANCE = this;
        // valve writes only the sanest of code
        const exp = /^\(\)=>\([\w$]+\|\|(?:[\w$]+\(|\([\w$]+=)new [\w$]+\),[\w$]+\)$/;
        const initErrorReportingStore = findModuleExport((e) => typeof e == 'function' && e?.toString && exp.test(e.toString()));
        if (!initErrorReportingStore) {
            this.error('could not find initErrorReportingStore! error boundary hook disabled!');
            return;
        }
        // will replace the existing one for us seemingly? doesnt matter anyway lol
        const errorReportingStore = initErrorReportingStore();
        // NUH UH.
        // Object.defineProperty(Object.getPrototypeOf(errorReportingStore), 'reporting_enabled', {
        //   get: () => false,
        // });
        // errorReportingStore.m_bEnabled = false;
        // @ts-ignore
        // window.errorStore = errorReportingStore;
        const react15069WorkaroundRegex = /    at .+\.componentDidCatch\..+\.callback /;
        this.errorCheckPatch = replacePatch(Object.getPrototypeOf(errorReportingStore), 'BIsBlacklisted', (args) => {
            const [errorSource, wasPlugin, shouldReport] = getLikelyErrorSourceFromValveError(args[0]);
            this.debug('Caught an error', args, {
                errorSource,
                wasPlugin,
                shouldReport,
                skipAllReporting: this.doNotReportErrors || this.disableReportingTimer,
            });
            if (!shouldReport)
                this.temporarilyDisableReporting();
            // react#15069 workaround. this took 2 hours to figure out.
            if (args[0]?.message?.[3]?.[0] &&
                args[0]?.message?.[1]?.[0] == '    at console.error ' &&
                react15069WorkaroundRegex.test(args[0].message[3][0])) {
                this.debug('ignoring early report caused by react#15069');
                return true;
            }
            if (this.doNotReportErrors || this.disableReportingTimer)
                return true;
            return shouldReport ? callOriginal : true;
        });
        if (!ErrorBoundary) {
            this.error('@decky/ui could not find ErrorBoundary, skipping patch');
            return;
        }
        this.errorBoundaryPatch = replacePatch(ErrorBoundary.prototype, 'render', function () {
            if (this.state._deckyForceRerender) {
                const stateClone = { ...this.state, _deckyForceRerender: null };
                this.setState(stateClone);
                return null;
            }
            // yoinked from valve error boundary
            if (this.state.error && this.props.errorKey == this.state.lastErrorKey) {
                const store = Object.getPrototypeOf(this)?.constructor?.sm_ErrorReportingStore || errorReportingStore;
                return void 0 !== this.props.fallback ? ('function' == typeof this.props.fallback ? (this.props.fallback(this.state.error.error)) : (this.props.fallback)) : (SP_JSX.jsx(DeckyErrorBoundary, { error: this.state.error, errorKey: this.props.errorKey, identifier: `${store.product}_${store.version}_${this.state.identifierHash}`, reset: () => this.Reset() }));
            }
            return callOriginal;
        });
        // Small hack that gives us a lot more flexibility to force rerenders.
        ErrorBoundary.prototype._deckyForceRerender = function () {
            this.setState({ ...this.state, _deckyForceRerender: true });
        };
    }
    temporarilyDisableReporting() {
        this.debug('Reporting disabled for 30s due to a non-steam error.');
        if (this.disableReportingTimer) {
            clearTimeout(this.disableReportingTimer);
        }
        this.disableReportingTimer = setTimeout(() => {
            this.debug('Reporting re-enabled after 30s timeout.');
            this.disableReportingTimer = 0;
        }, 30000);
    }
    deinit() {
        this.errorCheckPatch?.unpatch();
        this.errorBoundaryPatch?.unpatch();
    }
}

/**
 * A Service class for managing the state and actions related to the frozen plugins feature.
 *
 * It's mostly responsible for sending setting updates to the server and keeping the local state in sync.
 */
class FrozenPluginService {
    constructor(deckyState) {
        this.deckyState = deckyState;
    }
    init() {
        getSetting('frozenPlugins', []).then((frozenPlugins) => {
            this.deckyState.setFrozenPlugins(frozenPlugins);
        });
    }
    /**
     * Sends the new frozen plugins list to the server and persists it locally in the decky state
     *
     * @param frozenPlugins The new list of frozen plugins
     */
    async update(frozenPlugins) {
        await setSetting('frozenPlugins', frozenPlugins);
        this.deckyState.setFrozenPlugins(frozenPlugins);
        // Remove pending updates for frozen plugins
        const updates = this.deckyState.publicState().updates;
        if (updates) {
            const filteredUpdates = new Map();
            updates.forEach((v, k) => {
                if (!frozenPlugins.includes(k)) {
                    filteredUpdates.set(k, v);
                }
            });
            this.deckyState.setUpdates(filteredUpdates);
        }
    }
    /**
     * Refreshes the state of frozen plugins in the local state
     */
    async invalidate() {
        this.deckyState.setFrozenPlugins(await getSetting('frozenPlugins', []));
    }
}

/**
 * A Service class for managing the state and actions related to the hidden plugins feature
 *
 * It's mostly responsible for sending setting updates to the server and keeping the local state in sync.
 */
class HiddenPluginsService {
    constructor(deckyState) {
        this.deckyState = deckyState;
    }
    init() {
        getSetting('hiddenPlugins', []).then((hiddenPlugins) => {
            this.deckyState.setHiddenPlugins(hiddenPlugins);
        });
    }
    /**
     * Sends the new hidden plugins list to the server and persists it locally in the decky state
     *
     * @param hiddenPlugins The new list of hidden plugins
     */
    async update(hiddenPlugins) {
        await setSetting('hiddenPlugins', hiddenPlugins);
        this.deckyState.setHiddenPlugins(hiddenPlugins);
    }
    /**
     * Refreshes the state of hidden plugins in the local state
     */
    async invalidate() {
        this.deckyState.setHiddenPlugins(await getSetting('hiddenPlugins', []));
    }
}

class DeckyGlobalComponentsState {
    constructor() {
        // TODO a set would be better
        this._components = new Map();
        this.eventBus = new EventTarget();
    }
    publicState() {
        return { components: this._components };
    }
    addComponent(path, component) {
        this._components.set(path, component);
        this.notifyUpdate();
    }
    removeComponent(path) {
        this._components.delete(path);
        this.notifyUpdate();
    }
    notifyUpdate() {
        this.eventBus.dispatchEvent(new Event('update'));
    }
}
const DeckyGlobalComponentsContext = SP_REACT.createContext(null);
const useDeckyGlobalComponentsState = () => SP_REACT.useContext(DeckyGlobalComponentsContext);
const DeckyGlobalComponentsStateContextProvider = ({ children, deckyGlobalComponentsState: deckyGlobalComponentsState, }) => {
    const [publicDeckyGlobalComponentsState, setPublicDeckyGlobalComponentsState] = SP_REACT.useState({
        ...deckyGlobalComponentsState.publicState(),
    });
    SP_REACT.useEffect(() => {
        function onUpdate() {
            setPublicDeckyGlobalComponentsState({ ...deckyGlobalComponentsState.publicState() });
        }
        deckyGlobalComponentsState.eventBus.addEventListener('update', onUpdate);
        return () => deckyGlobalComponentsState.eventBus.removeEventListener('update', onUpdate);
    }, []);
    const addComponent = deckyGlobalComponentsState.addComponent.bind(deckyGlobalComponentsState);
    const removeComponent = deckyGlobalComponentsState.removeComponent.bind(deckyGlobalComponentsState);
    return (SP_JSX.jsx(DeckyGlobalComponentsContext.Provider, { value: { ...publicDeckyGlobalComponentsState, addComponent, removeComponent }, children: children }));
};

class DeckyRouterState {
    constructor() {
        this._routes = new Map();
        this._routePatches = new Map();
        this.eventBus = new EventTarget();
    }
    publicState() {
        return { routes: this._routes, routePatches: this._routePatches };
    }
    addRoute(path, component, props = {}) {
        this._routes.set(path, { props, component });
        this.notifyUpdate();
    }
    addPatch(path, patch) {
        let patchList = this._routePatches.get(path);
        if (!patchList) {
            patchList = new Set();
            this._routePatches.set(path, patchList);
        }
        patchList.add(patch);
        this.notifyUpdate();
        return patch;
    }
    removePatch(path, patch) {
        const patchList = this._routePatches.get(path);
        patchList?.delete(patch);
        if (patchList?.size == 0) {
            this._routePatches.delete(path);
        }
        this.notifyUpdate();
    }
    removeRoute(path) {
        this._routes.delete(path);
        this.notifyUpdate();
    }
    notifyUpdate() {
        this.eventBus.dispatchEvent(new Event('update'));
    }
}
const DeckyRouterStateContext = SP_REACT.createContext(null);
const useDeckyRouterState = () => SP_REACT.useContext(DeckyRouterStateContext);
const DeckyRouterStateContextProvider = ({ children, deckyRouterState }) => {
    const [publicDeckyRouterState, setPublicDeckyRouterState] = SP_REACT.useState({
        ...deckyRouterState.publicState(),
    });
    SP_REACT.useEffect(() => {
        function onUpdate() {
            setPublicDeckyRouterState({ ...deckyRouterState.publicState() });
        }
        deckyRouterState.eventBus.addEventListener('update', onUpdate);
        return () => deckyRouterState.eventBus.removeEventListener('update', onUpdate);
    }, []);
    const addRoute = deckyRouterState.addRoute.bind(deckyRouterState);
    const addPatch = deckyRouterState.addPatch.bind(deckyRouterState);
    const removePatch = deckyRouterState.removePatch.bind(deckyRouterState);
    const removeRoute = deckyRouterState.removeRoute.bind(deckyRouterState);
    return (SP_JSX.jsx(DeckyRouterStateContext.Provider, { value: { ...publicDeckyRouterState, addRoute, addPatch, removePatch, removeRoute }, children: children }));
};

const isPatched = Symbol('is patched');
class RouterHook extends Logger$1 {
    constructor() {
        super('RouterHook');
        this.routerState = new DeckyRouterState();
        this.globalComponentsState = new DeckyGlobalComponentsState();
        this.renderedComponents = [];
        this.DeckyGamepadRouterWrapper = this.gamepadRouterWrapper.bind(this);
        this.DeckyDesktopRouterWrapper = this.desktopRouterWrapper.bind(this);
        this.DeckyGlobalComponentsWrapper = this.globalComponentsWrapper.bind(this);
        this.toReplace = new Map();
        this.patchedModes = new Set();
        this.log('Initialized');
        window.__ROUTER_HOOK_INSTANCE?.deinit?.();
        window.__ROUTER_HOOK_INSTANCE = this;
        const reactRouterStackModule = findModuleByExport((e) => typeof e == 'string' && e == 'router-backstack', 20);
        if (reactRouterStackModule) {
            this.Route =
                Object.values(reactRouterStackModule).find((e) => typeof e == 'function' && /routePath:[\w$]+\.match\?\.path./.test(e.toString())) ||
                    Object.values(reactRouterStackModule).find((e) => typeof e == 'function' && /routePath:null===\(.=.\.match\)/.test(e.toString()));
            if (!this.Route) {
                this.error('Failed to find Route component');
            }
        }
        else {
            this.error('Failed to find router stack module');
        }
        this.modeChangeRegistration = SteamClient.UI.RegisterForUIModeChanged((mode) => {
            this.debug(`UI mode changed to ${mode}`);
            if (this.patchedModes.has(mode))
                return;
            this.patchedModes.add(mode);
            this.debug(`Patching router for UI mode ${mode}`);
            switch (mode) {
                case EUIMode.GamePad:
                    this.debug('Patching gamepad router');
                    this.patchGamepadRouter();
                    break;
                // Not fully implemented yet
                // case UIMode.Desktop:
                //   this.debug("Patching desktop router");
                //   this.patchDesktopRouter();
                //   break;
                default:
                    this.warn(`Router patch not implemented for UI mode ${mode}`);
                    break;
            }
        });
    }
    async patchGamepadRouter() {
        const root = getReactRoot(document.getElementById('root'));
        const findRouterNode = () => findInReactTree(root, (node) => typeof node?.pendingProps?.loggedIn == 'undefined' && node?.type?.toString().includes('Settings.Root()'));
        await this.waitForUnlock();
        let routerNode = findRouterNode();
        while (!routerNode) {
            this.warn('Failed to find Router node, reattempting in 5 seconds.');
            await sleep(5000);
            await this.waitForUnlock();
            routerNode = findRouterNode();
        }
        if (routerNode) {
            // Patch the component globally
            this.gamepadRouterPatch = afterPatch(routerNode.elementType, 'type', this.handleGamepadRouterRender.bind(this));
            // Swap out the current instance
            routerNode.type = routerNode.elementType.type;
            if (routerNode?.alternate) {
                routerNode.alternate.type = routerNode.type;
            }
            // Force a full rerender via our custom error boundary
            const errorBoundaryNode = findInTree(routerNode, (e) => e?.stateNode?._deckyForceRerender, {
                walkable: ['return'],
            });
            errorBoundaryNode?.stateNode?._deckyForceRerender?.();
        }
    }
    // Currently unused
    // @ts-expect-error 6133
    async patchDesktopRouter() {
        const root = getReactRoot(document.getElementById('root'));
        const findRouterNode = () => findInReactTree(root, (node) => node?.elementType?.type?.toString?.()?.includes('bShowDesktopUIContent:'));
        let routerNode = findRouterNode();
        while (!routerNode) {
            this.warn('Failed to find Router node, reattempting in 5 seconds.');
            await sleep(5000);
            routerNode = findRouterNode();
        }
        if (routerNode) {
            // this.debug("desktop router node", routerNode);
            // Patch the component globally
            this.desktopRouterPatch = afterPatch(routerNode.elementType, 'type', this.handleDesktopRouterRender.bind(this));
            // Swap out the current instance
            routerNode.type = routerNode.elementType.type;
            if (routerNode?.alternate) {
                routerNode.alternate.type = routerNode.type;
            }
            // Force a full rerender via our custom error boundary
            const errorBoundaryNode = findInTree(routerNode, (e) => e?.stateNode?._deckyForceRerender, {
                walkable: ['return'],
            });
            errorBoundaryNode?.stateNode?._deckyForceRerender?.();
            // this.debug("desktop router node", routerNode);
            // // Patch the component globally
            // this.desktopRouterPatch = afterPatch(routerNode.type.prototype, 'render', this.handleDesktopRouterRender.bind(this));
            // const stateNodeClone = { render: routerNode.stateNode.render } as any;
            // // Patch the current instance. render is readonly so we have to do this.
            // Object.assign(stateNodeClone, routerNode.stateNode);
            // Object.setPrototypeOf(stateNodeClone, Object.getPrototypeOf(routerNode.stateNode));
            // this.desktopRouterFirstInstancePatch = afterPatch(stateNodeClone, 'render', this.handleDesktopRouterRender.bind(this));
            // routerNode.stateNode = stateNodeClone;
            // // Swap out the current instance
            // if (routerNode?.alternate) {
            //   routerNode.alternate.type = routerNode.type;
            //   routerNode.alternate.stateNode = routerNode.stateNode;
            // }
            // routerNode.stateNode.forceUpdate();
            // Force a full rerender via our custom error boundary
            // const errorBoundaryNode = findInTree(routerNode, e => e?.stateNode?._deckyForceRerender, { walkable: ["return"] });
            // errorBoundaryNode?.stateNode?._deckyForceRerender?.();
        }
    }
    async waitForUnlock() {
        try {
            while (window?.securitystore?.IsLockScreenActive?.()) {
                await sleep(500);
            }
        }
        catch (e) {
            this.warn('Error while checking if unlocked:', e);
        }
    }
    handleDesktopRouterRender(_, ret) {
        const DeckyDesktopRouterWrapper = this.DeckyDesktopRouterWrapper;
        const DeckyGlobalComponentsWrapper = this.DeckyGlobalComponentsWrapper;
        this.debug('desktop router render', ret);
        if (ret._decky) {
            return ret;
        }
        const returnVal = (SP_JSX.jsxs(SP_JSX.Fragment, { children: [SP_JSX.jsx(DeckyRouterStateContextProvider, { deckyRouterState: this.routerState, children: SP_JSX.jsx(DeckyDesktopRouterWrapper, { children: ret }) }), SP_JSX.jsx(DeckyGlobalComponentsStateContextProvider, { deckyGlobalComponentsState: this.globalComponentsState, children: SP_JSX.jsx(DeckyGlobalComponentsWrapper, {}) })] }));
        returnVal._decky = true;
        return returnVal;
    }
    handleGamepadRouterRender(_, ret) {
        const DeckyGamepadRouterWrapper = this.DeckyGamepadRouterWrapper;
        const DeckyGlobalComponentsWrapper = this.DeckyGlobalComponentsWrapper;
        if (ret._decky) {
            return ret;
        }
        const returnVal = (SP_JSX.jsxs(SP_JSX.Fragment, { children: [SP_JSX.jsx(DeckyRouterStateContextProvider, { deckyRouterState: this.routerState, children: SP_JSX.jsx(DeckyGamepadRouterWrapper, { children: ret }) }), SP_JSX.jsx(DeckyGlobalComponentsStateContextProvider, { deckyGlobalComponentsState: this.globalComponentsState, children: SP_JSX.jsx(DeckyGlobalComponentsWrapper, {}) })] }));
        returnVal._decky = true;
        return returnVal;
    }
    globalComponentsWrapper() {
        const { components } = useDeckyGlobalComponentsState();
        if (this.renderedComponents.length != components.size) {
            this.debug('Rerendering global components');
            this.renderedComponents = Array.from(components.values()).map((GComponent) => SP_JSX.jsx(GComponent, {}));
        }
        return SP_JSX.jsx(SP_JSX.Fragment, { children: this.renderedComponents });
    }
    gamepadRouterWrapper({ children }) {
        // Used to store the new replicated routes we create to allow routes to be unpatched.
        const { routes, routePatches } = useDeckyRouterState();
        // TODO make more redundant
        if (!children?.props?.children?.[0]?.props?.children) {
            this.debug('routerWrapper wrong component?', children);
            return children;
        }
        const mainRouteList = children.props.children[0].props.children;
        const ingameRouteList = children.props.children[1].props.children; // /appoverlay and /apprunning
        this.processList(mainRouteList, routes, routePatches, true);
        this.processList(ingameRouteList, null, routePatches, false);
        this.debug('Rerendered gamepadui routes list');
        return children;
    }
    desktopRouterWrapper({ children }) {
        // Used to store the new replicated routes we create to allow routes to be unpatched.
        this.debug('desktop router wrapper render', children);
        const { routes, routePatches } = useDeckyRouterState();
        const routeList = findInReactTree(children, (node) => node?.length > 2 && node?.find((elem) => elem?.props?.path == '/library/home'));
        if (!routeList) {
            this.debug('routerWrapper wrong component?', children);
            return children;
        }
        const library = children.props.children[1].props.children.props;
        if (!Array.isArray(library.children)) {
            library.children = [library.children];
        }
        this.debug('library', library);
        this.processList(library.children, routes, routePatches, true);
        this.debug('Rerendered desktop routes list');
        return children;
    }
    processList(routeList, routes, routePatches, save) {
        const Route = this.Route;
        this.debug('Route list: ', routeList);
        if (save)
            this.routes = routeList;
        let routerIndex = routeList.length;
        if (routes) {
            if (!routeList[routerIndex - 1]?.length || routeList[routerIndex - 1]?.length !== routes.size) {
                if (routeList[routerIndex - 1]?.length && routeList[routerIndex - 1].length !== routes.size)
                    routerIndex--;
                const newRouterArray = [];
                routes.forEach(({ component, props }, path) => {
                    newRouterArray.push(SP_JSX.jsx(Route, { path: path, ...props, children: SP_JSX.jsx(ErrorBoundary, { children: SP_REACT.createElement(component) }) }));
                });
                routeList[routerIndex] = newRouterArray;
            }
        }
        routeList.forEach((route, index) => {
            const replaced = this.toReplace.get(route?.props?.path);
            if (replaced) {
                routeList[index].props.children = replaced;
                this.toReplace.delete(route?.props?.path);
            }
            if (route?.props?.path && routePatches.has(route.props.path)) {
                this.toReplace.set(route?.props?.path, 
                // @ts-ignore
                routeList[index].props.children);
                routePatches.get(route.props.path)?.forEach((patch) => {
                    const oType = routeList[index].props.children.type;
                    routeList[index].props.children = patch({
                        ...routeList[index].props,
                        children: {
                            ...SP_REACT.cloneElement(routeList[index].props.children),
                            type: routeList[index].props.children[isPatched] ? oType : (props) => SP_REACT.createElement(oType, props),
                        },
                    }).children;
                    routeList[index].props.children[isPatched] = true;
                });
            }
        });
    }
    addRoute(path, component, props = {}) {
        this.routerState.addRoute(path, component, props);
    }
    addPatch(path, patch) {
        return this.routerState.addPatch(path, patch);
    }
    addGlobalComponent(name, component) {
        this.globalComponentsState.addComponent(name, component);
    }
    removeGlobalComponent(name) {
        this.globalComponentsState.removeComponent(name);
    }
    removePatch(path, patch) {
        this.routerState.removePatch(path, patch);
    }
    removeRoute(path) {
        this.routerState.removeRoute(path);
    }
    deinit() {
        this.modeChangeRegistration?.unregister();
        this.gamepadRouterPatch?.unpatch();
        this.desktopRouterPatch?.unpatch();
    }
}

const logger$2 = new Logger$1('CEFSocketFix');
const closeCEFSocket = DeckyBackend.callable('utilities/close_cef_socket');
function cefSocketFix() {
    const reg = window.SteamClient?.User?.RegisterForShutdownStart(async () => {
        logger$2.log('Closing CEF socket before shutdown');
        await closeCEFSocket();
    });
    if (reg)
        logger$2.debug('CEF shutdown handler ready');
    return () => reg?.unregister();
}

// import restartFix from './restart';
let fixes = [];
function deinitSteamFixes() {
    fixes.forEach((deinit) => deinit());
}
async function initSteamFixes() {
    fixes.push(cefSocketFix());
    // fixes.push(await restartFix());
}

const semver = /^[v^~<>=]*?(\d+)(?:\.([x*]|\d+)(?:\.([x*]|\d+)(?:\.([x*]|\d+))?(?:-([\da-z\-]+(?:\.[\da-z\-]+)*))?(?:\+[\da-z\-]+(?:\.[\da-z\-]+)*)?)?)?$/i;
const validateAndParse = (version) => {
    if (typeof version !== 'string') {
        throw new TypeError('Invalid argument expected string');
    }
    const match = version.match(semver);
    if (!match) {
        throw new Error(`Invalid argument not valid semver ('${version}' received)`);
    }
    match.shift();
    return match;
};
const isWildcard = (s) => s === '*' || s === 'x' || s === 'X';
const tryParse = (v) => {
    const n = parseInt(v, 10);
    return isNaN(n) ? v : n;
};
const forceType = (a, b) => typeof a !== typeof b ? [String(a), String(b)] : [a, b];
const compareStrings = (a, b) => {
    if (isWildcard(a) || isWildcard(b))
        return 0;
    const [ap, bp] = forceType(tryParse(a), tryParse(b));
    if (ap > bp)
        return 1;
    if (ap < bp)
        return -1;
    return 0;
};
const compareSegments = (a, b) => {
    for (let i = 0; i < Math.max(a.length, b.length); i++) {
        const r = compareStrings(a[i] || '0', b[i] || '0');
        if (r !== 0)
            return r;
    }
    return 0;
};

/**
 * Compare [semver](https://semver.org/) version strings to find greater, equal or lesser.
 * This library supports the full semver specification, including comparing versions with different number of digits like `1.0.0`, `1.0`, `1`, and pre-release versions like `1.0.0-alpha`.
 * @param v1 - First version to compare
 * @param v2 - Second version to compare
 * @returns Numeric value compatible with the [Array.sort(fn) interface](https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Array/sort#Parameters).
 */
const compareVersions = (v1, v2) => {
    // validate input and split into segments
    const n1 = validateAndParse(v1);
    const n2 = validateAndParse(v2);
    // pop off the patch
    const p1 = n1.pop();
    const p2 = n2.pop();
    // validate numbers
    const r = compareSegments(n1, n2);
    if (r !== 0)
        return r;
    // validate pre-release
    if (p1 && p2) {
        return compareSegments(p1.split('.'), p2.split('.'));
    }
    else if (p1 || p2) {
        return p1 ? -1 : 1;
    }
    return 0;
};

/**
 * Compare [semver](https://semver.org/) version strings using the specified operator.
 *
 * @param v1 First version to compare
 * @param v2 Second version to compare
 * @param operator Allowed arithmetic operator to use
 * @returns `true` if the comparison between the firstVersion and the secondVersion satisfies the operator, `false` otherwise.
 *
 * @example
 * ```
 * compare('10.1.8', '10.0.4', '>'); // return true
 * compare('10.0.1', '10.0.1', '='); // return true
 * compare('10.1.1', '10.2.2', '<'); // return true
 * compare('10.1.1', '10.2.2', '<='); // return true
 * compare('10.1.1', '10.2.2', '>='); // return false
 * ```
 */
const compare = (v1, v2, operator) => {
    // validate input operator
    assertValidOperator(operator);
    // since result of compareVersions can only be -1 or 0 or 1
    // a simple map can be used to replace switch
    const res = compareVersions(v1, v2);
    return operatorResMap[operator].includes(res);
};
const operatorResMap = {
    '>': [1],
    '>=': [0, 1],
    '=': [0],
    '<=': [-1, 0],
    '<': [-1],
    '!=': [-1, 1],
};
const allowedOperators = Object.keys(operatorResMap);
const assertValidOperator = (op) => {
    if (allowedOperators.indexOf(op) === -1) {
        throw new Error(`Invalid operator, expected one of ${allowedOperators.join('|')}`);
    }
};

/**
 * Validate [semver](https://semver.org/) version strings.
 *
 * @param version Version number to validate
 * @returns `true` if the version number is a valid semver version number, `false` otherwise.
 *
 * @example
 * ```
 * validate('1.0.0-rc.1'); // return true
 * validate('1.0-rc.1'); // return false
 * validate('foo'); // return false
 * ```
 */
const validate = (version) => typeof version === 'string' && /^[v\d]/.test(version) && semver.test(version);

var Store;
(function (Store) {
    Store[Store["Default"] = 0] = "Default";
    Store[Store["Testing"] = 1] = "Testing";
    Store[Store["Custom"] = 2] = "Custom";
})(Store || (Store = {}));
var SortOptions;
(function (SortOptions) {
    SortOptions["name"] = "name";
    SortOptions["date"] = "date";
    SortOptions["downloads"] = "downloads";
})(SortOptions || (SortOptions = {}));
var SortDirections;
(function (SortDirections) {
    SortDirections["ascending"] = "asc";
    SortDirections["descending"] = "desc";
})(SortDirections || (SortDirections = {}));
class StoreRequestError extends Error {
    constructor(status) {
        super(`Plugin store request failed (HTTP ${status})`);
        this.status = status;
        this.name = 'StoreRequestError';
    }
}
async function getStore() {
    return await getSetting('store', Store.Default);
}
async function getStoreBaseURL() {
    let store = await getSetting('store', null);
    let customURL = await getSetting('store-url', 'https://plugins.deckbrew.xyz/plugins');
    let storeURL;
    if (store === null) {
        console.log('Could not get store, using Default.');
        await setSetting('store', Store.Default);
        store = Store.Default;
    }
    switch (+store) {
        case Store.Default:
            storeURL = 'https://plugins.deckbrew.xyz/plugins';
            break;
        case Store.Testing:
            storeURL = 'https://testing.deckbrew.xyz/plugins';
            break;
        case Store.Custom:
            storeURL = customURL;
            break;
        default:
            console.error('Somehow you ended up without a standard URL, using the default URL.');
            storeURL = 'https://plugins.deckbrew.xyz/plugins';
            break;
    }
    return storeURL;
}
async function getPluginList(sort_by = null, sort_direction = null, signal) {
    let query = new URLSearchParams();
    sort_by && query.set('sort_by', sort_by);
    sort_direction && query.set('sort_direction', sort_direction);
    query = '?' + String(query);
    const data = await getStoreData(query, signal);
    if (!Array.isArray(data))
        throw new Error('Plugin store returned an invalid plugin list');
    return data;
}
async function getVersionList() {
    const data = await getStoreData('/versions');
    if (!data || typeof data !== 'object' || Array.isArray(data)) {
        throw new Error('Plugin store returned an invalid version list');
    }
    return data;
}
async function getStoreData(path, signal) {
    const version = await window.DeckyPluginLoader.updateVersion();
    const storeURL = await getStoreBaseURL();
    const response = await fetch(storeURL + path, {
        method: 'GET',
        signal,
        headers: {
            'X-Decky-Version': version.current,
        },
    });
    if (!response.ok)
        throw new StoreRequestError(response.status);
    return response.json();
}
async function installFromURL(url) {
    const splitURL = url.split('/');
    await installPlugin(url, splitURL[splitURL.length - 1].replace('.zip', ''));
}
async function requestPluginInstall(plugin, selectedVer, installType) {
    const artifactUrl = selectedVer.artifact ?? pluginUrl(selectedVer.hash);
    await installPlugin(artifactUrl, plugin, selectedVer.name, selectedVer.hash, installType);
}
async function requestMultiplePluginInstalls(requests) {
    await installPlugins(requests.map(({ plugin, installType, selectedVer }) => ({
        name: plugin,
        artifact: selectedVer.artifact ?? pluginUrl(selectedVer.hash),
        version: selectedVer.name,
        hash: selectedVer.hash,
        install_type: installType,
    })));
}
async function checkForPluginUpdates(plugins) {
    const serverData = await getVersionList();
    const updateMap = new Map();
    for (let plugin of plugins) {
        const remotePlugin = serverData?.[plugin.name];
        //FIXME: Ugly hack since plugin.version might be null during evaluation,
        //so this will set the older version possible
        const curVer = plugin.version ? plugin.version : '0.0.0';
        if (remotePlugin &&
            plugin.version != remotePlugin[0] &&
            validate(remotePlugin[0]) &&
            validate(curVer) &&
            compare(remotePlugin[0], curVer, '>')) {
            updateMap.set(plugin.name, {
                name: remotePlugin[0],
                hash: remotePlugin[1],
                artifact: remotePlugin[2],
            });
        }
    }
    return updateMap;
}
function pluginUrl(hash) {
    return `https://cdn.tzatzikiweeb.moe/file/steam-deck-homebrew/versions/${hash}.zip`;
}

class TabsHook extends Logger$1 {
    constructor() {
        super('TabsHook');
        // private keys = 7;
        this.tabs = [];
        this.log('Initialized');
        window.__TABS_HOOK_INSTANCE?.deinit?.();
        window.__TABS_HOOK_INSTANCE = this;
    }
    init() {
        const qamModule = findModuleByExport((e) => e?.type?.toString?.()?.includes('QuickAccessMenuBrowserView'));
        const qamBrowserViewRenderer = Object.values(qamModule).find((e) => e?.type?.toString?.()?.includes('QuickAccessMenuBrowserView'));
        const qamEmbeddedRenderer = Object.values(qamModule).find((e) => e?.type?.toString?.()?.includes('QuickAccessMenuEmbedded'));
        const patchHandler = createReactTreePatcher([(tree) => findInReactTree(tree, (node) => node?.props?.onFocusNavDeactivated)], (args, ret) => {
            const tabs = findInReactTree(ret, (x) => x?.props?.tabs);
            this.render(tabs.props.tabs, args[0].visible);
            return ret;
        }, 'TabsHook');
        this.qamBrowserViewPatch = afterPatch(qamBrowserViewRenderer, 'type', patchHandler);
        if (qamEmbeddedRenderer)
            this.qamEmbeddedPatch = afterPatch(qamEmbeddedRenderer, 'type', patchHandler);
        // Patch already rendered qam
        const root = getReactRoot(document.getElementById('root'));
        const qamNode = root &&
            findInReactTree(root, (n) => n.elementType == qamBrowserViewRenderer ||
                (qamEmbeddedRenderer != null && n.elementType == qamEmbeddedRenderer)); // need elementType, because type is actually mobx wrapper
        if (qamNode) {
            // Only affects this fiber node so we don't need to unpatch here
            qamNode.type = qamNode.elementType.type;
            if (qamNode?.alternate) {
                qamNode.alternate.type = qamNode.type;
            }
        }
    }
    deinit() {
        this.qamBrowserViewPatch?.unpatch();
        this.qamEmbeddedPatch?.unpatch();
    }
    add(tab) {
        this.debug('Adding tab', tab.id, 'to render array');
        this.tabs.push(tab);
    }
    removeById(id) {
        this.debug('Removing tab', id);
        this.tabs = this.tabs.filter((tab) => tab.id !== id);
    }
    render(existingTabs, visible) {
        let deckyTabAmount = existingTabs.reduce((prev, cur) => (cur.decky ? prev + 1 : prev), 0);
        if (deckyTabAmount == this.tabs.length) {
            for (let tab of existingTabs) {
                if (tab?.decky) {
                    if (tab?.qAMVisibilitySetter) {
                        tab?.qAMVisibilitySetter(visible);
                    }
                    else {
                        tab.initialVisibility = visible;
                    }
                }
            }
            return;
        }
        for (const { title, icon, content, id } of this.tabs) {
            const tab = {
                key: id,
                title,
                tab: icon,
                decky: true,
                initialVisibility: visible,
            };
            tab.panel = (SP_JSX.jsx(ErrorBoundary, { children: SP_JSX.jsx(QuickAccessVisibleStateProvider, { tab: tab, children: content }) }));
            existingTabs.push(tab);
        }
    }
}

const logger$1 = new Logger$1('ToastRenderer');
// TODO there are more of these
var ToastLocation;
(function (ToastLocation) {
    /** Big Picture popup toasts */
    ToastLocation[ToastLocation["GAMEPADUI_POPUP"] = 1] = "GAMEPADUI_POPUP";
    /** QAM Notifications tab */
    ToastLocation[ToastLocation["GAMEPADUI_QAM"] = 3] = "GAMEPADUI_QAM";
})(ToastLocation || (ToastLocation = {}));
const templateClasses = findClassModule((m) => m.ShortTemplate) || {};
// These are memoized as they like to randomly rerender
const GamepadUIPopupToast = SP_REACT.memo(({ toast }) => {
    return (SP_JSX.jsxs("div", { style: { '--toast-duration': `${toast.duration}ms` }, onClick: toast.onClick, className: joinClassNames(templateClasses.ShortTemplate, toast.className || '', 'DeckyGamepadUIPopupToast'), children: [toast.logo && SP_JSX.jsx("div", { className: templateClasses.StandardLogoDimensions, children: toast.logo }), SP_JSX.jsxs("div", { className: joinClassNames(templateClasses.Content, toast.contentClassName || ''), children: [SP_JSX.jsxs("div", { className: templateClasses.Header, children: [toast.icon && SP_JSX.jsx("div", { className: templateClasses.Icon, children: toast.icon }), SP_JSX.jsx("div", { className: templateClasses.Title, children: toast.title })] }), SP_JSX.jsx("div", { className: templateClasses.Body, children: toast.body })] })] }));
});
const GamepadUIQAMToast = SP_REACT.memo(({ toast, newIndicator }) => {
    // The fields aren't mismatched, the logic for these is just a bit weird.
    return (SP_JSX.jsx(Focusable, { onActivate: () => {
            toast.onClick?.();
            Navigation.CloseSideMenus();
        }, className: joinClassNames(templateClasses.StandardTemplateContainer, toast.className || '', 'DeckyGamepadUIQAMToast'), children: SP_JSX.jsxs("div", { className: templateClasses.StandardTemplate, children: [toast.logo && SP_JSX.jsx("div", { className: templateClasses.StandardLogoDimensions, children: toast.logo }), SP_JSX.jsxs("div", { className: joinClassNames(templateClasses.Content, toast.contentClassName || ''), children: [SP_JSX.jsxs("div", { className: templateClasses.Header, children: [toast.icon && SP_JSX.jsx("div", { className: templateClasses.Icon, children: toast.icon }), toast.title && SP_JSX.jsx("div", { className: templateClasses.Title, children: toast.title }), toast.timestamp && (SP_JSX.jsx("div", { className: templateClasses.Timestamp, children: toast.timestamp.toLocaleTimeString(undefined, { timeStyle: 'short' }) }))] }), toast.body && SP_JSX.jsx("div", { className: templateClasses.StandardNotificationDescription, children: toast.body }), toast.subtext && SP_JSX.jsx("div", { className: templateClasses.StandardNotificationSubText, children: toast.subtext })] }), newIndicator && (SP_JSX.jsx("div", { className: templateClasses.NewIndicator, children: SP_JSX.jsx("svg", { xmlns: "http://www.w3.org/2000/svg", width: "50", height: "50", viewBox: "0 0 50 50", fill: "none", children: SP_JSX.jsx("circle", { fill: "currentColor", cx: "25", cy: "25", r: "25" }) }) }))] }) }));
});
const ToastRenderer = SP_REACT.memo(({ toast, location, newIndicator }) => {
    switch (location) {
        default:
            logger$1.warn(`Toast UI not implemented for location ${location}! Falling back to GamepadUIQAMToast.`);
            return SP_JSX.jsx(GamepadUIQAMToast, { toast: toast, newIndicator: false });
        case ToastLocation.GAMEPADUI_POPUP:
            return SP_JSX.jsx(GamepadUIPopupToast, { toast: toast });
        case ToastLocation.GAMEPADUI_QAM:
            return SP_JSX.jsx(GamepadUIQAMToast, { toast: toast, newIndicator: newIndicator });
    }
});

class Toaster extends Logger$1 {
    constructor() {
        super('Toaster');
        window.__TOASTER_INSTANCE?.deinit?.();
        window.__TOASTER_INSTANCE = this;
        const ValveToastRenderer = findModuleExport((e) => e?.toString?.()?.includes(`controller:"notification",method:`));
        // TODO find a way to undo this if possible?
        const patchedRenderer = injectFCTrampoline(ValveToastRenderer);
        this.toastPatch = replacePatch(patchedRenderer, 'component', (args) => {
            if (args?.[0]?.group?.decky || args?.[0]?.group?.notifications?.[0]?.decky) {
                return args[0].group.notifications.map((notification) => (SP_JSX.jsx(ErrorBoundary, { children: SP_JSX.jsx(ToastRenderer, { toast: notification.data, newIndicator: notification.bNewIndicator, location: args?.[0]?.location }) })));
            }
            return callOriginal;
        });
        this.log('Initialized');
    }
    toast(toast) {
        if (toast.sound === undefined)
            toast.sound = 6;
        if (toast.playSound === undefined)
            toast.playSound = true;
        if (toast.showToast === undefined)
            toast.showToast = true;
        if (toast.timestamp === undefined)
            toast.timestamp = new Date();
        if (toast.showNewIndicator === undefined)
            toast.showNewIndicator = true;
        /* eType 13
          13: {
            proto: m.mu,
            fnTray: null,
            showToast: !0,
            sound: f.PN.ToastMisc,
            eFeature: l.uX
          }
        */
        let toastData = {
            nNotificationID: window.NotificationStore.m_nNextTestNotificationID++,
            bNewIndicator: toast.showNewIndicator,
            rtCreated: Date.now(),
            eType: toast.eType || 31,
            eSource: 1, // Client
            nToastDurationMS: toast.duration || (toast.duration = 5e3),
            data: toast,
            decky: true,
        };
        let group;
        function fnTray(toast, tray) {
            group = {
                eType: toast.eType,
                notifications: [toast],
            };
            tray.unshift(group);
        }
        const info = {
            showToast: toast.showToast,
            sound: toast.sound,
            playSound: toast.playSound,
            eFeature: 0,
            toastDurationMS: toastData.nToastDurationMS,
            bCritical: toast.critical,
            fnTray,
        };
        const self = this;
        let expirationTimeout;
        const toastResult = {
            data: toast,
            dismiss() {
                // it checks against the id of notifications[0]
                try {
                    expirationTimeout && clearTimeout(expirationTimeout);
                    group && window.NotificationStore.RemoveGroupFromTray(group);
                }
                catch (e) {
                    self.error('Error while dismissing toast:', e);
                }
            },
        };
        if (toast.expiration) {
            expirationTimeout = setTimeout(() => {
                try {
                    group && window.NotificationStore.RemoveGroupFromTray(group);
                }
                catch (e) {
                    this.error('Error while dismissing expired toast:', e);
                }
            }, toast.expiration);
        }
        try {
            window.NotificationStore.ProcessNotification(info, toastData, ESteamNotificationAction.New);
        }
        catch (e) {
            this.error('Error while sending toast:', e);
        }
        return toastResult;
    }
    deinit() {
        this.toastPatch?.unpatch();
    }
}

/**
 * Returns a formatted display name for a plugin with version if available
 * @param name - The plugin name
 * @param version - The optional plugin version
 *
 * @returns Formatted string like "PluginName (v1.2.3)" or just "PluginName" if version is undefined
 */
function getPluginDisplayName(name, version) {
    if (version) {
        return `${name} (v${version})`;
    }
    return name;
}

var WarnThirdPartyType;
(function (WarnThirdPartyType) {
    WarnThirdPartyType[WarnThirdPartyType["REPO"] = 0] = "REPO";
    WarnThirdPartyType[WarnThirdPartyType["ZIP"] = 1] = "ZIP";
})(WarnThirdPartyType || (WarnThirdPartyType = {}));

var TranslationClass;
(function (TranslationClass) {
    TranslationClass["PLUGIN_LOADER"] = "PluginLoader";
    TranslationClass["DEVELOPER"] = "Developer";
    TranslationClass["WARN_THIRD_PARTY"] = "WarnThirdParty";
})(TranslationClass || (TranslationClass = {}));
const logger = new Logger$1('TranslationHelper');
const TranslationHelper = ({ transClass, transText, i18nArgs = null, warnType = WarnThirdPartyType.REPO, }) => {
    return (SP_JSX.jsx(Translation, { children: (t, {}) => {
            switch (transClass) {
                case TranslationClass.PLUGIN_LOADER:
                    return i18nArgs
                        ? t(TranslationClass.PLUGIN_LOADER + '.' + transText, i18nArgs)
                        : t(TranslationClass.PLUGIN_LOADER + '.' + transText);
                case TranslationClass.DEVELOPER:
                    return i18nArgs
                        ? t(TranslationClass.DEVELOPER + '.' + transText, i18nArgs)
                        : t(TranslationClass.DEVELOPER + '.' + transText);
                //Handle different messages in different class cases
                case TranslationClass.WARN_THIRD_PARTY:
                    //Needed only for title and description
                    if (!transText.startsWith('button')) {
                        switch (warnType) {
                            case WarnThirdPartyType.REPO:
                                return i18nArgs
                                    ? t(TranslationClass.WARN_THIRD_PARTY + '.' + transText + '_repo', i18nArgs)
                                    : t(TranslationClass.WARN_THIRD_PARTY + '.' + transText + '_repo');
                            case WarnThirdPartyType.ZIP:
                                return i18nArgs
                                    ? t(TranslationClass.WARN_THIRD_PARTY + '.' + transText + '_zip', i18nArgs)
                                    : t(TranslationClass.WARN_THIRD_PARTY + '.' + transText + '_zip');
                        }
                    }
                    else {
                        return i18nArgs
                            ? t(TranslationClass.WARN_THIRD_PARTY + '.' + transText, i18nArgs)
                            : t(TranslationClass.WARN_THIRD_PARTY + '.' + transText);
                    }
                default:
                    logger.error('We should never fall in the default case!');
                    return '';
            }
        } }));
};

const StorePage = SP_REACT.lazy(() => import('./chunk-yTmtKpjI.js'));
const SettingsPage = SP_REACT.lazy(() => import('./chunk-CrvrCQZp.js').then(function (n) { return n.i; }));
const FilePicker = SP_REACT.lazy(() => Promise.resolve().then(function () { return index; }));
const callPluginMethod = DeckyBackend.callable('loader/call_plugin_method');
class PluginLoader extends Logger$1 {
    constructor() {
        super(PluginLoader.name);
        this.plugins = [];
        this.errorBoundaryHook = new ErrorBoundaryHook();
        this.tabsHook = new TabsHook();
        this.routerHook = new RouterHook();
        this.toaster = new Toaster();
        this.deckyState = new DeckyState();
        // stores a map of plugin names to all their event listeners
        this.pluginEventListeners = new Map();
        this.frozenPluginsService = new FrozenPluginService(this.deckyState);
        this.hiddenPluginsService = new HiddenPluginsService(this.deckyState);
        this.notificationService = new NotificationService(this.deckyState);
        this.reloadLock = false;
        // stores a list of plugin names which requested to be reloaded
        this.pluginReloadQueue = [];
        this.getPluginsFromBackend = DeckyBackend.callable('loader/get_plugins');
        this.restartWebhelper = DeckyBackend.callable('utilities/restart_webhelper');
        this.pluginEventListener = (data) => {
            const { plugin, event, args } = data;
            this.debug(`Recieved plugin event ${event} for ${plugin} with args`, args);
            if (!this.pluginEventListeners.has(plugin)) {
                this.warn(`plugin ${plugin} does not have event listeners`);
                return;
            }
            const eventListeners = this.pluginEventListeners.get(plugin);
            if (eventListeners.has(event)) {
                for (const listener of eventListeners.get(event)) {
                    (async () => {
                        try {
                            await listener(...args);
                        }
                        catch (e) {
                            this.error(`error in event ${event}`, e, listener);
                        }
                    })();
                }
            }
            else {
                this.warn(`event ${event} has no listeners`);
            }
        };
        DeckyBackend.addEventListener('loader/notify_updates', this.notifyUpdates.bind(this));
        DeckyBackend.addEventListener('loader/import_plugin', this.importPlugin.bind(this));
        DeckyBackend.addEventListener('loader/unload_plugin', this.unloadPlugin.bind(this));
        DeckyBackend.addEventListener('loader/disable_plugin', this.doDisablePlugin.bind(this));
        DeckyBackend.addEventListener('loader/add_plugin_install_prompt', this.addPluginInstallPrompt.bind(this));
        DeckyBackend.addEventListener('loader/add_multiple_plugins_install_prompt', this.addMultiplePluginsInstallPrompt.bind(this));
        DeckyBackend.addEventListener('updater/update_download_percentage', () => {
            this.deckyState.setIsLoaderUpdating(true);
        });
        DeckyBackend.addEventListener(`loader/plugin_event`, this.pluginEventListener);
        this.tabsHook.init();
        const TabBadge = () => {
            const { updates, hasLoaderUpdate } = useDeckyState();
            return SP_JSX.jsx(NotificationBadge, { show: (updates && updates.size > 0) || hasLoaderUpdate });
        };
        this.tabsHook.add({
            id: QuickAccessTab.Decky,
            title: null,
            content: (SP_JSX.jsx(DeckyStateContextProvider, { deckyState: this.deckyState, children: SP_JSX.jsx(PluginView, {}) })),
            icon: (SP_JSX.jsxs(DeckyStateContextProvider, { deckyState: this.deckyState, children: [SP_JSX.jsx(FaPlug, {}), SP_JSX.jsx(TabBadge, {})] })),
        });
        this.routerHook.addRoute('/decky/store', () => (SP_JSX.jsx(DeckyStateContextProvider, { deckyState: this.deckyState, children: SP_JSX.jsx(WithSuspense, { route: true, children: SP_JSX.jsx(StorePage, {}) }) })));
        this.routerHook.addRoute('/decky/settings', () => {
            return (SP_JSX.jsx(DeckyStateContextProvider, { deckyState: this.deckyState, children: SP_JSX.jsx(WithSuspense, { route: true, children: SP_JSX.jsx(SettingsPage, {}) }) }));
        });
        initSteamFixes();
        initFilepickerPatches();
        this.initPluginBackendAPI();
        Promise.all([this.getUserInfo(), this.updateVersion()])
            .then(() => this.loadPlugins())
            .then(() => this.log('Initialized'))
            .then(() => {
            this.notifySupportStatus();
        }) // TODO safeguard this
            .then(() => sleep(30000)) // Internet might not immediately be up
            .then(() => this.checkPluginUpdates());
    }
    checkForSP() {
        try {
            return !!findSP();
        }
        catch (e) {
            this.warn('Error checking for SP tab', e);
            return false;
        }
    }
    async runCrashChecker() {
        const spExists = this.checkForSP();
        await sleep(5000);
        if (spExists && !this.checkForSP()) {
            // SP died after plugin loaded. Give up and let the loader's crash loop detection handle it.
            this.error('SP died during startup. Restarting webhelper.');
            await this.restartWebhelper();
        }
    }
    async loadPlugins() {
        let registration;
        const uiMode = await new Promise((r) => (registration = SteamClient.UI.RegisterForUIModeChanged((mode) => {
            r(mode);
            registration.unregister();
        })));
        if (uiMode == EUIMode.GamePad) {
            // wait for SP window to exist before loading plugins
            while (!findSP()) {
                await sleep(100);
            }
        }
        this.runCrashChecker();
        const plugins = await this.getPluginsFromBackend();
        const pluginLoadPromises = [];
        const disabledPlugins = [];
        const loadStart = performance.now();
        for (const plugin of plugins) {
            if (plugin.disabled) {
                disabledPlugins.push({ name: plugin.name, version: plugin.version });
                this.deckyState.setDisabledPlugins(disabledPlugins);
            }
            else {
                if (!this.hasPlugin(plugin.name))
                    pluginLoadPromises.push(this.importPlugin(plugin.name, plugin.version, plugin.load_type, false));
            }
        }
        await Promise.all(pluginLoadPromises);
        const loadEnd = performance.now();
        this.log(`Loaded ${plugins.length} plugins in ${loadEnd - loadStart}ms`);
        this.checkPluginUpdates();
    }
    async notifySupportStatus() {
        await this.routerHook.waitForUnlock();
        if (!this.deckyState.publicState().versionInfo?.supported) {
            this.toaster.toast({
                title: SP_JSX.jsx(TranslationHelper, { transClass: TranslationClass.PLUGIN_LOADER, transText: "decky_unsupported" }),
                body: SP_JSX.jsx(TranslationHelper, { transClass: TranslationClass.PLUGIN_LOADER, transText: "decky_unsupported_body" }),
                logo: SP_JSX.jsx(DeckyIcon, {}),
                icon: SP_JSX.jsx(FaExclamationTriangle, {}),
                onClick: () => Navigation.Navigate('/decky/settings'),
            });
        }
    }
    async getUserInfo() {
        const userInfo = await DeckyBackend.call('utilities/get_user_info');
        setSetting('user_info.user_name', userInfo.username);
        setSetting('user_info.user_home', userInfo.path);
    }
    async updateVersion() {
        const versionInfo = await getVersionInfo();
        this.deckyState.setVersionInfo(versionInfo);
        return versionInfo;
    }
    async notifyUpdates() {
        const versionInfo = await this.updateVersion();
        if (versionInfo?.remote && versionInfo?.remote?.tag_name != versionInfo?.current) {
            this.deckyState.setHasLoaderUpdate(true);
            if (this.notificationService.shouldNotify('deckyUpdates')) {
                this.loaderUpdateToast && this.loaderUpdateToast.dismiss();
                await this.routerHook.waitForUnlock();
                this.loaderUpdateToast = this.toaster.toast({
                    title: SP_JSX.jsx(TranslationHelper, { transClass: TranslationClass.PLUGIN_LOADER, transText: "decky_title" }),
                    body: (SP_JSX.jsx(TranslationHelper, { transClass: TranslationClass.PLUGIN_LOADER, transText: "decky_update_available", i18nArgs: { tag_name: versionInfo?.remote?.tag_name } })),
                    logo: SP_JSX.jsx(DeckyIcon, {}),
                    icon: SP_JSX.jsx(FaDownload, {}),
                    onClick: () => Navigation.Navigate('/decky/settings'),
                });
            }
        }
        await sleep(7000);
        await this.notifyPluginUpdates();
    }
    async checkPluginUpdates() {
        try {
            const frozenPlugins = this.deckyState.publicState().frozenPlugins;
            const updates = await checkForPluginUpdates(this.deckyState.publicState().installedPlugins.filter((p) => !frozenPlugins.includes(p.name)));
            this.deckyState.setUpdates(updates);
            return updates;
        }
        catch (error) {
            this.error('Failed to check for plugin updates', error);
            return null;
        }
    }
    async notifyPluginUpdates() {
        const updates = await this.checkPluginUpdates();
        if (updates && updates.size > 0 && this.notificationService.shouldNotify('pluginUpdates')) {
            this.pluginUpdateToast && this.pluginUpdateToast.dismiss();
            this.pluginUpdateToast = this.toaster.toast({
                title: SP_JSX.jsx(TranslationHelper, { transClass: TranslationClass.PLUGIN_LOADER, transText: "decky_title" }),
                body: (SP_JSX.jsx(TranslationHelper, { transClass: TranslationClass.PLUGIN_LOADER, transText: "plugin_update", i18nArgs: { count: updates.size } })),
                logo: SP_JSX.jsx(DeckyIcon, {}),
                icon: SP_JSX.jsx(FaDownload, {}),
                onClick: () => Navigation.Navigate('/decky/settings/plugins'),
            });
        }
    }
    addPluginInstallPrompt(artifact, version, request_id, hash, install_type) {
        showModal(SP_JSX.jsx(PluginInstallModal, { artifact: artifact, version: version, hash: hash, installType: install_type, disabled: this.deckyState.publicState().disabledPlugins.some((p) => p.name === artifact), onOK: () => DeckyBackend.call('utilities/confirm_plugin_install', request_id), onCancel: () => DeckyBackend.call('utilities/cancel_plugin_install', request_id) }));
    }
    addMultiplePluginsInstallPrompt(request_id, requests) {
        showModal(SP_JSX.jsx(MultiplePluginsInstallModal, { requests: requests, disabledPlugins: this.deckyState.publicState().disabledPlugins, onOK: () => DeckyBackend.call('utilities/confirm_plugin_install', request_id), onCancel: () => DeckyBackend.call('utilities/cancel_plugin_install', request_id) }));
    }
    uninstallPlugin(name, title, buttonText, description) {
        showModal(SP_JSX.jsx(PluginUninstallModal, { name: name, title: title, buttonText: buttonText, description: description, deckyState: this.deckyState }));
    }
    disablePlugin(name, title, buttonText, description) {
        showModal(SP_JSX.jsx(PluginDisableModal, { name: name, title: title, buttonText: buttonText, description: description }));
    }
    hasPlugin(name) {
        return Boolean(this.plugins.find((plugin) => plugin.name == name));
    }
    dismountAll() {
        for (const plugin of this.plugins) {
            this.log(`Dismounting ${getPluginDisplayName(plugin.name, plugin.version)}`);
            plugin.onDismount?.();
        }
    }
    init() {
        getSetting('developer.enabled', false).then((val) => {
            if (val)
                import('./chunk-BVKRgher.js').then((developer) => developer.startup());
        });
        // Grab and set plugin order
        getSetting('pluginOrder', []).then((pluginOrder) => {
            this.debug('pluginOrder: ', pluginOrder);
            this.deckyState.setPluginOrder(pluginOrder);
        });
        // Grab and set sort plugins setting
        getSetting('sortPlugins', false).then((sortPlugins) => {
            this.debug('sortPlugins: ', sortPlugins);
            this.deckyState.setSortPlugins(sortPlugins);
        });
        this.frozenPluginsService.init();
        this.hiddenPluginsService.init();
        this.notificationService.init();
    }
    deinit() {
        this.routerHook.removeRoute('/decky/store');
        this.routerHook.removeRoute('/decky/settings');
        deinitSteamFixes();
        this.routerHook.deinit();
        this.tabsHook.deinit();
        this.toaster.deinit();
        this.errorBoundaryHook.deinit();
    }
    doDisablePlugin(name) {
        const plugin = this.plugins.find((plugin) => plugin.name === name);
        if (plugin == undefined)
            return;
        plugin?.onDismount?.();
        this.plugins = this.plugins.filter((p) => p !== plugin);
        this.deckyState.setDisabledPlugins([
            ...this.deckyState.publicState().disabledPlugins,
            { name: plugin.name, version: plugin.version },
        ]);
        this.deckyState.setPlugins(this.plugins);
    }
    unloadPlugin(name, skipStateUpdate = false) {
        const plugin = this.plugins.find((plugin) => plugin.name === name);
        plugin?.onDismount?.();
        this.plugins = this.plugins.filter((p) => p !== plugin);
        if (!skipStateUpdate)
            this.deckyState.setPlugins(this.plugins);
    }
    async importPlugin(name, version, loadType = PluginLoadType.ESMODULE_V1, useQueue = true, timeoutMS) {
        if (useQueue && this.reloadLock) {
            this.log(`Reload currently in progress, adding ${getPluginDisplayName(name, version)} to queue`);
            this.pluginReloadQueue.push({ name, version: version, loadType });
            return;
        }
        try {
            if (useQueue)
                this.reloadLock = true;
            this.log(`Trying to load ${getPluginDisplayName(name, version)}`);
            this.unloadPlugin(name, true);
            const startTime = performance.now();
            await this.importReactPlugin(name, version, loadType, timeoutMS);
            const endTime = performance.now();
            this.deckyState.setDisabledPlugins(this.deckyState.publicState().disabledPlugins.filter((d) => d.name !== name));
            this.deckyState.setPlugins(this.plugins);
            this.log(`Loaded ${getPluginDisplayName(name, version)} in ${endTime - startTime}ms`);
        }
        catch (e) {
            throw e;
        }
        finally {
            if (useQueue) {
                this.reloadLock = false;
                const nextPlugin = this.pluginReloadQueue.shift();
                if (nextPlugin) {
                    this.importPlugin(nextPlugin.name, nextPlugin.version, nextPlugin.loadType, true, timeoutMS);
                }
            }
        }
    }
    async importReactPlugin(name, version, loadType = PluginLoadType.ESMODULE_V1, timeoutMS) {
        let spExists = this.checkForSP();
        const timeoutException = new Error(`${name} failed to load within ${timeoutMS ? `${timeoutMS / 1000} second` : ''} time limit`);
        let timeout;
        try {
            switch (loadType) {
                case PluginLoadType.ESMODULE_V1:
                    const importJS = () => import(`http://127.0.0.1:1337/plugins/${name}/dist/index.js?t=${Date.now()}`);
                    const promise = timeoutMS === undefined
                        ? importJS()
                        : Promise.race([
                            importJS(),
                            new Promise((_, reject) => (timeout = setTimeout(() => reject(timeoutException), timeoutMS))),
                        ]);
                    const plugin_exports = await promise;
                    let plugin = plugin_exports.default();
                    this.plugins.push({
                        ...plugin,
                        name: name,
                        version: version,
                        loadType,
                    });
                    break;
                case PluginLoadType.LEGACY_EVAL_IIFE:
                    const fetchJS = async () => {
                        const controller = new AbortController();
                        const { signal } = controller;
                        if (timeoutMS !== undefined)
                            timeout = setTimeout(() => controller.abort(), timeoutMS);
                        try {
                            return await fetch(`http://127.0.0.1:1337/plugins/${name}/frontend_bundle`, {
                                credentials: 'include',
                                headers: {
                                    'X-Decky-Auth': deckyAuthToken,
                                },
                                signal,
                            });
                        }
                        catch (e) {
                            throw 'name' in e && e.name === 'AbortError' ? timeoutException : e;
                        }
                    };
                    let res = await fetchJS();
                    if (res.ok) {
                        let plugin_export = await eval((await res.text()) + `\n//# sourceURL=decky://decky/legacy_plugin/${encodeURIComponent(name)}/index.js`);
                        let plugin = plugin_export(this.createLegacyPluginAPI(name));
                        this.plugins.push({
                            ...plugin,
                            name: name,
                            version: version,
                            loadType,
                        });
                    }
                    else
                        throw new Error(`${getPluginDisplayName(name, version)} frontend_bundle not OK`);
                    break;
                default:
                    throw new Error(`${getPluginDisplayName(name, version)} has no defined loadType.`);
            }
        }
        catch (e) {
            if (e === timeoutException)
                throw timeoutException;
            this.error(`Error loading plugin ${getPluginDisplayName(name, version)}`, e);
            const TheError = () => (SP_JSX.jsxs(PanelSection, { children: [SP_JSX.jsx(PanelSectionRow, { children: SP_JSX.jsx("div", { className: quickAccessMenuClasses.FriendsTitle, style: { display: 'flex', justifyContent: 'center' }, children: SP_JSX.jsx(TranslationHelper, { transClass: TranslationClass.PLUGIN_LOADER, transText: "error" }) }) }), SP_JSX.jsx(PanelSectionRow, { children: SP_JSX.jsx("pre", { style: { overflowX: 'scroll' }, children: SP_JSX.jsx("code", { children: e instanceof Error ? '' + e.stack : JSON.stringify(e) }) }) }), SP_JSX.jsx(PanelSectionRow, { children: SP_JSX.jsx("div", { className: quickAccessMenuClasses.Text, children: SP_JSX.jsx(TranslationHelper, { transClass: TranslationClass.PLUGIN_LOADER, transText: "plugin_error_uninstall", i18nArgs: { name: name } }) }) })] }));
            this.plugins.push({
                name: name,
                version: version,
                content: SP_JSX.jsx(TheError, {}),
                icon: SP_JSX.jsx(FaExclamationCircle, {}),
                loadType,
            });
            this.toaster.toast({
                title: (SP_JSX.jsx(TranslationHelper, { transClass: TranslationClass.PLUGIN_LOADER, transText: "plugin_load_error.toast", i18nArgs: { name: name } })),
                body: '' + e,
                icon: SP_JSX.jsx(FaExclamationCircle, {}),
            });
        }
        finally {
            if (timeout !== undefined)
                clearTimeout(timeout);
        }
        if (spExists && !this.checkForSP()) {
            // SP died after plugin loaded. Give up and let the loader's crash loop detection handle it.
            this.error('SP died after loading plugin. Restarting webhelper.');
            await this.restartWebhelper();
        }
    }
    async callServerMethod(methodName, args = {}) {
        this.warn(`Calling ${methodName} via callServerMethod, which is deprecated and will be removed in a future release. Please switch to the backend API.`);
        return await DeckyBackend.call('utilities/_call_legacy_utility', methodName, args);
    }
    openFilePickerLegacy(startPath, selectFiles, regex) {
        this.warn('openFilePicker is deprecated and will be removed. Please migrate to openFilePickerV2');
        if (selectFiles) {
            return this.openFilePicker(FileSelectionType.FILE, startPath, true, true, regex);
        }
        else {
            return this.openFilePicker(FileSelectionType.FOLDER, startPath, false, true, regex);
        }
    }
    openFilePicker(select, startPath, includeFiles, includeFolders, filter, extensions, showHiddenFiles, allowAllFiles, max) {
        return new Promise((resolve, reject) => {
            const Content = ({ closeModal }) => (
            // Purposely outside of the FilePicker component as lazy-loaded ModalRoots don't focus correctly
            SP_JSX.jsx(ModalRoot, { onCancel: () => {
                    reject('User canceled');
                    closeModal?.();
                }, children: SP_JSX.jsx(WithSuspense, { children: SP_JSX.jsx(FilePicker, { startPath: startPath, includeFiles: includeFiles, includeFolders: includeFolders, filter: filter, validFileExtensions: extensions, allowAllFiles: allowAllFiles, defaultHidden: showHiddenFiles, onSubmit: resolve, closeModal: closeModal, fileSelType: select, max: max }) }) }));
            showModal(SP_JSX.jsx(Content, {}));
        });
    }
    // Useful for audio/video streams
    getExternalResourceURL(url) {
        return `http://127.0.0.1:1337/fetch?auth=${deckyAuthToken}&fetch_url=${encodeURIComponent(url)}`;
    }
    // Same syntax as fetch but only supports the url-based syntax and an object for headers since it's the most common usage pattern
    fetchNoCors(input, init) {
        const { headers: initHeaders = {}, ...restOfInit } = init || {};
        const getPrefixedHeaders = () => {
            let prefixedInitHeaders = {};
            for (const [key, value] of Object.entries(initHeaders)) {
                prefixedInitHeaders[`X-Decky-Header-${key}`] = value;
            }
            return prefixedInitHeaders;
        };
        const headers = getPrefixedHeaders();
        if (init?.excludedHeaders) {
            headers['X-Decky-Fetch-Excluded-Headers'] = init.excludedHeaders.join(', ');
        }
        return fetch(this.getExternalResourceURL(input), {
            ...restOfInit,
            credentials: 'include',
            headers,
        });
    }
    async legacyFetchNoCors(url, request = {}) {
        let method;
        const req = { headers: {}, ...request, data: request.body };
        req?.body && delete req.body;
        if (!request.method) {
            method = 'POST';
        }
        else {
            method = request.method;
            delete req.method;
        }
        try {
            const ret = await DeckyBackend.call('utilities/http_request', method, url, req);
            return { success: true, result: ret };
        }
        catch (e) {
            return { success: false, result: e?.toString() };
        }
    }
    initPluginBackendAPI() {
        // Things will break *very* badly if plugin code touches this outside of @decky/api, so lets make that clear.
        window.__DECKY_SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED_deckyLoaderAPIInit = {
            connect: (version, pluginName) => {
                if (version < 1 || version > 2) {
                    console.warn(`Plugin ${pluginName} requested unsupported api version ${version}.`);
                }
                const eventListeners = new Map();
                this.pluginEventListeners.set(pluginName, eventListeners);
                const backendAPI = {
                    call: (methodName, ...args) => {
                        return callPluginMethod(pluginName, methodName, ...args);
                    },
                    callable: (methodName) => {
                        return (...args) => callPluginMethod(pluginName, methodName, ...args);
                    },
                    addEventListener: (event, listener) => {
                        if (!eventListeners.has(event)) {
                            eventListeners.set(event, new Set([listener]));
                        }
                        else {
                            eventListeners.get(event)?.add(listener);
                        }
                        return listener;
                    },
                    removeEventListener: (event, listener) => {
                        if (eventListeners.has(event)) {
                            const set = eventListeners.get(event);
                            set?.delete(listener);
                        }
                    },
                    openFilePicker: this.openFilePicker.bind(this),
                    executeInTab: DeckyBackend.callable('utilities/execute_in_tab'),
                    fetchNoCors: this.fetchNoCors.bind(this),
                    getExternalResourceURL: this.getExternalResourceURL.bind(this),
                    injectCssIntoTab: DeckyBackend.callable('utilities/inject_css_into_tab'),
                    removeCssFromTab: DeckyBackend.callable('utilities/remove_css_from_tab'),
                    routerHook: this.routerHook,
                    toaster: this.toaster,
                    _version: 1,
                };
                if (version >= 2) {
                    backendAPI._version = 2;
                    backendAPI.useQuickAccessVisible = useQuickAccessVisible;
                }
                // Note: version info not available at connection time
                this.debug(`Plugin ${pluginName} connected to loader API.`);
                return backendAPI;
            },
        };
    }
    createLegacyPluginAPI(pluginName) {
        const pluginAPI = {
            routerHook: this.routerHook,
            toaster: this.toaster,
            // Legacy
            callServerMethod: this.callServerMethod.bind(this),
            openFilePicker: this.openFilePickerLegacy.bind(this),
            openFilePickerV2: this.openFilePicker.bind(this),
            // Legacy
            async callPluginMethod(methodName, args = {}) {
                return DeckyBackend.call('loader/call_legacy_plugin_method', pluginName, methodName, args);
            },
            fetchNoCors: this.legacyFetchNoCors.bind(this),
            executeInTab: DeckyBackend.callable('utilities/execute_in_tab'),
            injectCssIntoTab: DeckyBackend.callable('utilities/inject_css_into_tab'),
            removeCssFromTab: DeckyBackend.callable('utilities/remove_css_from_tab'),
        };
        return pluginAPI;
    }
}

(async () => {
    instance
        .use(Backend)
        .use(initReactI18next)
        .init({
        load: 'currentOnly',
        detection: {
            order: ['querystring', 'navigator'],
            lookupQuerystring: 'lng',
        },
        //debug: true,
        lng: navigator.language,
        fallbackLng: 'en-US',
        interpolation: {
            escapeValue: true,
        },
        returnEmptyString: false,
        backend: {
            loadPath: 'http://127.0.0.1:1337/locales/{{lng}}.json',
            customHeaders: {
                'X-Decky-Auth': deckyAuthToken,
            },
            requestOptions: {
                credentials: 'include',
            },
        },
    });
    window?.DeckyPluginLoader?.dismountAll();
    window?.DeckyPluginLoader?.deinit();
    window.DeckyPluginLoader = new PluginLoader();
    DeckyPluginLoader.init();
})();

var start = /*#__PURE__*/Object.freeze({
  __proto__: null
});

export { enablePlugin as A, BranchSelect as B, FaPlug as C, DeckyIcon as D, FaCode as E, FaArrowUp as F, FaFlask as G, FaChrome as H, InstallType as I, FaFileArchive as J, FaLink as K, installFromURL as L, FaTerminal as M, FaSteamSymbol as N, FaReact as O, getSetting as P, FileSelectionType as Q, setSetting as R, SortOptions as S, TranslationHelper as T, FaInfo as U, UpdateBranch as V, WarnThirdPartyType as W, commonjsGlobal as X, getDefaultExportFromCjs as Y, start as Z, FaRecycle as a, FaArrowDown as b, FaDownload as c, FaCheck as d, SortDirections as e, getStore as f, getPluginList as g, Store as h, useDeckyState as i, StoreRequestError as j, FaExclamationTriangle as k, TranslationClass as l, useSetting as m, FaShapes as n, FaExclamation as o, checkForUpdates as p, doUpdate as q, requestPluginInstall as r, WithSuspense as s, FaLock as t, useTranslation as u, FaEyeSlash as v, FaBan as w, requestMultiplePluginInstalls as x, FaEllipsisH as y, getPluginDisplayName as z };
//# sourceMappingURL=chunk-BRlI6dAn.js.map
