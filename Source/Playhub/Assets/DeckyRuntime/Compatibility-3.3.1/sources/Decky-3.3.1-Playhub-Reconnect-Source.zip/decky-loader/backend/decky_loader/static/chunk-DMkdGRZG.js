import { f as findModuleExport, C as CommonUIModule, a as findModuleByExport, R as ReactRouter } from './chunk-CFxgpTYP.js';
export { I as IconsModule, g as createModuleMapping, e as findAllModules, b as findModule, d as findModuleChild, c as findModuleDetailsByExport, m as modules } from './chunk-CFxgpTYP.js';
import { g as getGamepadNavigationTrees } from './chunk-DxhJXJ98.js';
export { f as findSP, a as getFocusNavController, j as joinClassNames, s as sleep } from './chunk-DxhJXJ98.js';
import { D as DialogButton, C as ConfirmModal, g as gamepadSliderClasses } from './chunk-sIGTtP5a.js';
export { B as ButtonItem, a as ControlsList, h as DialogBody, f as DialogBodyText, k as DialogButtonPrimary, l as DialogButtonSecondary, m as DialogCheckbox, i as DialogControlsSection, j as DialogControlsSectionHeader, d as DialogFooter, b as DialogHeader, e as DialogLabel, c as DialogSubHeader, n as Dropdown, p as DropdownItem, o as DropdownItemInternal, W as EBroadcastPermission, L as EBrowserType, O as EPopupCreationFlags, Y as ESteamNotificationAction, X as ESteamNotificationSource, Q as ESteamRealm, U as ESteamUISound, V as EUIMode, E as ErrorBoundary, F as Field, q as Focusable, av as INTERNAL_HOOKS, M as Marquee, r as Menu, t as MenuGroup, u as MenuItem, v as MenuSeparator, y as ModalPosition, x as ModalRoot, N as Navigation, P as PanelSection, z as PanelSectionRow, A as ProgressBar, H as ProgressBarItem, G as ProgressBarWithInfo, Z as QuickAccessTab, R as Router, _ as SideMenu, S as SimpleModal, I as Spinner, J as SteamSpinner, T as TextField, K as ToggleField, at as achievementClasses, ae as achievementListClasses, af as achievementPageClasses, a1 as afterPatch, ak as appActionButtonClasses, aa as appDetailsClasses, a9 as appDetailsHeaderClasses, aw as applyHookStubs, ah as basicAppDetailsSectionStylerClasses, a0 as beforePatch, $ as callOriginal, aN as classMap, aM as classModuleMap, au as createPropListRegex, aL as createReactTreePatcher, ay as fakeRenderComponent, aO as findClass, aP as findClassByName, aQ as findClassModule, aE as findInReactTree, aD as findInTree, an as focusRingClasses, aj as footerClasses, ad as gamepadContextMenuClasses, a5 as gamepadDialogClasses, am as gamepadLibraryClasses, ac as gamepadTabbedPageClasses, ab as gamepadUIClasses, aF as getParentWindow, aC as getReactInstance, aB as getReactRoot, aI as injectFCTrampoline, al as libraryAssetImageClasses, ap as mainBrowserClasses, ag as mainMenuAppRunningClasses, a8 as playSectionClasses, a6 as quickAccessControlsClasses, a3 as quickAccessMenuClasses, ax as removeHookStubs, a2 as replacePatch, as as scrollClasses, a4 as scrollPanelClasses, ao as searchBarClasses, aH as setFCTrampolineLoggingEnabled, aJ as setReactPatcherLoggingEnabled, aK as setReactPatcherPerformanceLoggingEnabled, s as showContextMenu, w as showModal, ar as staticClasses, ai as steamSpinnerClasses, aR as unminifyClass, a7 as updaterFieldClasses, aG as useWindowRef, aq as vrDashboardClasses, aA as wrapReactClass, az as wrapReactType } from './chunk-sIGTtP5a.js';
export { S as SuspensefulImage, T as Tabs } from './chunk-CGQRiEsV.js';
export { C as Carousel, R as ReorderableList, S as SidebarNavigation, T as Toggle } from './chunk-DDBhefN9.js';
export { E as EFocusSource, G as GamepadButton, N as NavEntryPositionPreferences } from './chunk-C7f0gL0I.js';

const Button = DialogButton?.render({}).type;

const FocusRing = findModuleExport((e) => e?.toString?.()?.includes('.GetShowDebugFocusRing())'));

const SliderField = Object.values(CommonUIModule).find((mod) => mod?.toString?.()?.includes('SliderField,fallback') || mod?.toString?.()?.includes("SliderField\","));

const ScrollingModule = findModuleByExport((e) => e?.render?.toString?.().includes('{case"x":'));
const ScrollingModuleProps = ScrollingModule ? Object.values(ScrollingModule) : [];
const ScrollPanel = ScrollingModuleProps.find((prop) => prop?.render?.toString?.().includes('{case"x":'));
const ScrollPanelGroup = findModuleExport((e) => e?.render?.toString().includes('.FocusVisibleChild(),[])') || e?.render?.toString().includes('.FocusVisibleChild()),[])'));

const ColorPickerModal = ({ closeModal, onConfirm = () => { }, title = 'Color Picker', defaultH = 0, defaultS = 100, defaultL = 50, defaultA = 1, }) => {
    const [H, setH] = SP_REACT.useState(defaultH);
    const [S, setS] = SP_REACT.useState(defaultS);
    const [L, setL] = SP_REACT.useState(defaultL);
    const [A, setA] = SP_REACT.useState(defaultA);
    const colorPickerCSSVars = {
        '--decky-color-picker-hvalue': `${H}`,
        '--decky-color-picker-svalue': `${S}%`,
        '--decky-color-picker-lvalue': `${L}%`,
        '--decky-color-picker-avalue': `${A}`,
    };
    return (SP_JSX.jsxs(ConfirmModal, { bAllowFullSize: true, onCancel: closeModal, onOK: () => {
            onConfirm(`hsla(${H}, ${S}%, ${L}%, ${A})`);
            closeModal();
        }, children: [SP_JSX.jsx("style", { children: `
        /* This removes the cyan track color that is behind the slider head */
        .ColorPicker_Container .${gamepadSliderClasses.SliderTrack} {
          --left-track-color: #0000;
          /* This is for compatibility with the "Colored Toggles" CSSLoader Theme*/
          --colored-toggles-main-color: #0000;
        }

        .ColorPicker_HSlider .${gamepadSliderClasses.SliderTrack} {
          background: linear-gradient(
            270deg,
            hsla(360, var(--decky-color-picker-svalue), var(--decky-color-picker-lvalue), var(--decky-color-picker-avalue)),
            hsla(270, var(--decky-color-picker-svalue), var(--decky-color-picker-lvalue), var(--decky-color-picker-avalue)),
            hsla(180, var(--decky-color-picker-svalue), var(--decky-color-picker-lvalue), var(--decky-color-picker-avalue)),
            hsla(90, var(--decky-color-picker-svalue), var(--decky-color-picker-lvalue), var(--decky-color-picker-avalue)),
            hsla(0, var(--decky-color-picker-svalue), var(--decky-color-picker-lvalue), var(--decky-color-picker-avalue))
          );
        }

        .ColorPicker_SSlider .${gamepadSliderClasses.SliderTrack} {
          background: linear-gradient(
            90deg,
            hsla(var(--decky-color-picker-hvalue), 0%, var(--decky-color-picker-lvalue), var(--decky-color-picker-avalue)),
            hsla(var(--decky-color-picker-hvalue), 100%, var(--decky-color-picker-lvalue), var(--decky-color-picker-avalue))
          );
        }

        .ColorPicker_LSlider .${gamepadSliderClasses.SliderTrack} {
          background: linear-gradient(
            90deg,
            hsla(var(--decky-color-picker-hvalue), var(--decky-color-picker-svalue), 0%, var(--decky-color-picker-avalue)),
            hsla(var(--decky-color-picker-hvalue), var(--decky-color-picker-svalue), 50%, var(--decky-color-picker-avalue)),
            hsla(var(--decky-color-picker-hvalue), var(--decky-color-picker-svalue), 100%, var(--decky-color-picker-avalue))
          );
        }

        .ColorPicker_ASlider .${gamepadSliderClasses.SliderTrack} {
          background: linear-gradient(
            90deg,
            hsla(var(--decky-color-picker-hvalue), var(--decky-color-picker-svalue), var(--decky-color-picker-lvalue), 0),
            hsla(var(--decky-color-picker-hvalue), var(--decky-color-picker-svalue), var(--decky-color-picker-lvalue), 1)
          );
        }
        ` }), SP_JSX.jsxs("div", { className: "ColorPicker_ColorDisplayContainer", style: {
                    display: 'flex',
                    justifyContent: 'space-between',
                    alignItems: 'center',
                    marginBottom: '1em',
                    marginTop: '-2.5em',
                }, children: [SP_JSX.jsx("div", { children: SP_JSX.jsx("span", { style: { fontSize: '1.5em' }, children: SP_JSX.jsx("b", { children: title }) }) }), SP_JSX.jsx("div", { style: {
                            backgroundColor: `hsla(${H}, ${S}%, ${L}%, ${A})`,
                            width: '40px',
                            height: '40px',
                        } })] }), SP_JSX.jsxs("div", { className: "ColorPicker_Container", style: colorPickerCSSVars, children: [SP_JSX.jsx("div", { className: "ColorPicker_HSlider", children: SP_JSX.jsx(SliderField, { showValue: true, editableValue: true, label: "Hue", value: H, min: 0, max: 360, onChange: setH }) }), SP_JSX.jsx("div", { className: "ColorPicker_SSlider", children: SP_JSX.jsx(SliderField, { showValue: true, editableValue: true, label: "Saturation", value: S, min: 0, max: 100, onChange: setS }) }), SP_JSX.jsx("div", { className: "ColorPicker_LSlider", children: SP_JSX.jsx(SliderField, { showValue: true, editableValue: true, label: "Lightness", value: L, min: 0, max: 100, onChange: setL }) }), SP_JSX.jsx("div", { className: "ColorPicker_ASlider", children: SP_JSX.jsx(SliderField, { showValue: true, editableValue: true, label: "Alpha", value: A, step: 0.1, min: 0, max: 1, onChange: setA }) })] })] }));
};

function getQuickAccessWindow() {
    const navTrees = getGamepadNavigationTrees();
    return (navTrees.find((tree) => tree?.id === 'QuickAccess-NA')?.m_Root?.m_element?.ownerDocument.defaultView ?? null);
}
function useQuickAccessVisible() {
    const [isHidden, setIsHidden] = SP_REACT.useState(getQuickAccessWindow()?.document.hidden ?? false);
    SP_REACT.useEffect(() => {
        const quickAccessWindow = getQuickAccessWindow();
        if (quickAccessWindow === null) {
            console.error('Could not get window of QuickAccess menu!');
            return;
        }
        const onVisibilityChange = () => setIsHidden(quickAccessWindow.document.hidden);
        quickAccessWindow.addEventListener('visibilitychange', onVisibilityChange);
        return () => {
            quickAccessWindow.removeEventListener('visibilitychange', onVisibilityChange);
        };
    }, []);
    return !isHidden;
}

const useParams = Object.values(ReactRouter).find((val) => /return (\w*)\?\1\.params:{}/.test(`${val}`));

var ENavigationSourceType;
(function (ENavigationSourceType) {
    ENavigationSourceType[ENavigationSourceType["UNKNOWN"] = 0] = "UNKNOWN";
    ENavigationSourceType[ENavigationSourceType["GAMEPAD"] = 1] = "GAMEPAD";
    ENavigationSourceType[ENavigationSourceType["KEYBOARD_SIMULATOR"] = 2] = "KEYBOARD_SIMULATOR";
    ENavigationSourceType[ENavigationSourceType["MOUSE"] = 3] = "MOUSE";
    ENavigationSourceType[ENavigationSourceType["TOUCH"] = 4] = "TOUCH";
    ENavigationSourceType[ENavigationSourceType["LPAD"] = 5] = "LPAD";
    ENavigationSourceType[ENavigationSourceType["RPAD"] = 6] = "RPAD";
})(ENavigationSourceType || (ENavigationSourceType = {}));

var EAccountType;
(function (EAccountType) {
    EAccountType[EAccountType["Invalid"] = 0] = "Invalid";
    EAccountType[EAccountType["Individual"] = 1] = "Individual";
    EAccountType[EAccountType["Multiseat"] = 2] = "Multiseat";
    EAccountType[EAccountType["GameServer"] = 3] = "GameServer";
    EAccountType[EAccountType["AnonGameServer"] = 4] = "AnonGameServer";
    EAccountType[EAccountType["Pending"] = 5] = "Pending";
    EAccountType[EAccountType["ContentServer"] = 6] = "ContentServer";
    EAccountType[EAccountType["Clan"] = 7] = "Clan";
    EAccountType[EAccountType["Chat"] = 8] = "Chat";
    EAccountType[EAccountType["ConsoleUser"] = 9] = "ConsoleUser";
    EAccountType[EAccountType["AnonUser"] = 10] = "AnonUser";
    EAccountType[EAccountType["Max"] = 11] = "Max";
})(EAccountType || (EAccountType = {}));

var EFilterAppFeature;
(function (EFilterAppFeature) {
    EFilterAppFeature[EFilterAppFeature["FullControllerSupport"] = 1] = "FullControllerSupport";
    EFilterAppFeature[EFilterAppFeature["PartialControllerSupport"] = 2] = "PartialControllerSupport";
    EFilterAppFeature[EFilterAppFeature["VR"] = 3] = "VR";
    EFilterAppFeature[EFilterAppFeature["TradingCards"] = 4] = "TradingCards";
    EFilterAppFeature[EFilterAppFeature["Workshop"] = 5] = "Workshop";
    EFilterAppFeature[EFilterAppFeature["Achievements"] = 6] = "Achievements";
    EFilterAppFeature[EFilterAppFeature["SinglePlayer"] = 7] = "SinglePlayer";
    EFilterAppFeature[EFilterAppFeature["MultiPlayer"] = 8] = "MultiPlayer";
    EFilterAppFeature[EFilterAppFeature["CoOp"] = 9] = "CoOp";
    EFilterAppFeature[EFilterAppFeature["SteamCloud"] = 10] = "SteamCloud";
    EFilterAppFeature[EFilterAppFeature["RemotePlayTogether"] = 11] = "RemotePlayTogether";
    EFilterAppFeature[EFilterAppFeature["SteamDeckVerified"] = 12] = "SteamDeckVerified";
    EFilterAppFeature[EFilterAppFeature["SteamDeckPlayable"] = 13] = "SteamDeckPlayable";
    EFilterAppFeature[EFilterAppFeature["SteamDeckUnknown"] = 14] = "SteamDeckUnknown";
    EFilterAppFeature[EFilterAppFeature["SteamDeckUnsupported"] = 15] = "SteamDeckUnsupported";
    EFilterAppFeature[EFilterAppFeature["PS4ControllerSupport"] = 16] = "PS4ControllerSupport";
    EFilterAppFeature[EFilterAppFeature["PS4ControllerBTSupport"] = 17] = "PS4ControllerBTSupport";
    EFilterAppFeature[EFilterAppFeature["PS5ControllerSupport"] = 18] = "PS5ControllerSupport";
    EFilterAppFeature[EFilterAppFeature["PS5ControllerBTSupport"] = 19] = "PS5ControllerBTSupport";
    EFilterAppFeature[EFilterAppFeature["SteamInputAPI"] = 20] = "SteamInputAPI";
    EFilterAppFeature[EFilterAppFeature["GamepadPreferred"] = 21] = "GamepadPreferred";
    EFilterAppFeature[EFilterAppFeature["HDR"] = 22] = "HDR";
    EFilterAppFeature[EFilterAppFeature["FamilySharing"] = 23] = "FamilySharing";
    EFilterAppFeature[EFilterAppFeature["SteamOSCompatible"] = 24] = "SteamOSCompatible";
    EFilterAppFeature[EFilterAppFeature["SteamOSUnknown"] = 25] = "SteamOSUnknown";
})(EFilterAppFeature || (EFilterAppFeature = {}));
var EFilterGroup;
(function (EFilterGroup) {
    EFilterGroup[EFilterGroup["AppType"] = 0] = "AppType";
    EFilterGroup[EFilterGroup["PlayState"] = 1] = "PlayState";
    EFilterGroup[EFilterGroup["AppFeature"] = 2] = "AppFeature";
    EFilterGroup[EFilterGroup["Genre"] = 3] = "Genre";
    EFilterGroup[EFilterGroup["StoreCategory"] = 4] = "StoreCategory";
    EFilterGroup[EFilterGroup["Partner"] = 5] = "Partner";
    EFilterGroup[EFilterGroup["Friends"] = 6] = "Friends";
})(EFilterGroup || (EFilterGroup = {}));
var EGamePlayState;
(function (EGamePlayState) {
    EGamePlayState[EGamePlayState["Installed"] = 1] = "Installed";
    EGamePlayState[EGamePlayState["ReadyToPlay"] = 2] = "ReadyToPlay";
    EGamePlayState[EGamePlayState["PlayedPreviously"] = 3] = "PlayedPreviously";
    EGamePlayState[EGamePlayState["Unplayed"] = 4] = "Unplayed";
    EGamePlayState[EGamePlayState["ValidPlatform"] = 5] = "ValidPlatform";
})(EGamePlayState || (EGamePlayState = {}));
var EGenre;
(function (EGenre) {
    EGenre[EGenre["action"] = 19] = "action";
    EGenre[EGenre["adventure"] = 21] = "adventure";
    EGenre[EGenre["anime"] = 4085] = "anime";
    EGenre[EGenre["casual"] = 597] = "casual";
    EGenre[EGenre["open_world"] = 1695] = "open_world";
    EGenre[EGenre["fighting"] = 4328] = "fighting";
    EGenre[EGenre["fighting_2"] = 4736] = "fighting_2";
    EGenre[EGenre["fighting_3"] = 6506] = "fighting_3";
    EGenre[EGenre["horror"] = 1667] = "horror";
    EGenre[EGenre["coop"] = 1685] = "coop";
    EGenre[EGenre["puzzle"] = 1664] = "puzzle";
    EGenre[EGenre["puzzle_2"] = 5537] = "puzzle_2";
    EGenre[EGenre["puzzle_3"] = 1665] = "puzzle_3";
    EGenre[EGenre["racing"] = 699] = "racing";
    EGenre[EGenre["racing_2"] = 4102] = "racing_2";
    EGenre[EGenre["roguelike"] = 42804] = "roguelike";
    EGenre[EGenre["rpg"] = 112] = "rpg";
    EGenre[EGenre["rpg_2"] = 4434] = "rpg_2";
    EGenre[EGenre["rpg_3"] = 4231] = "rpg_3";
    EGenre[EGenre["scifi"] = 3942] = "scifi";
    EGenre[EGenre["simulation"] = 599] = "simulation";
    EGenre[EGenre["simulation_2"] = 12472] = "simulation_2";
    EGenre[EGenre["sports"] = 701] = "sports";
    EGenre[EGenre["story_rich"] = 1742] = "story_rich";
    EGenre[EGenre["strategy"] = 9] = "strategy";
    EGenre[EGenre["strategy_2"] = 1670] = "strategy_2";
    EGenre[EGenre["strategy_3"] = 1676] = "strategy_3";
    EGenre[EGenre["cities_settlements"] = 9] = "cities_settlements";
    EGenre[EGenre["cities_settlements_2"] = 4328] = "cities_settlements_2";
    EGenre[EGenre["cities_settlements_3"] = 220585] = "cities_settlements_3";
    EGenre[EGenre["survival"] = 1662] = "survival";
    EGenre[EGenre["visual_novel"] = 3799] = "visual_novel";
    EGenre[EGenre["f2p"] = 113] = "f2p";
    EGenre[EGenre["vr"] = 402] = "vr";
    EGenre[EGenre["vr_2"] = 401] = "vr_2";
})(EGenre || (EGenre = {}));
var EStoreCategory;
(function (EStoreCategory) {
    EStoreCategory[EStoreCategory["MultiPlayer"] = 1] = "MultiPlayer";
    EStoreCategory[EStoreCategory["SinglePlayer"] = 2] = "SinglePlayer";
    EStoreCategory[EStoreCategory["CoOp"] = 9] = "CoOp";
    EStoreCategory[EStoreCategory["PartialController"] = 18] = "PartialController";
    EStoreCategory[EStoreCategory["MMO"] = 20] = "MMO";
    EStoreCategory[EStoreCategory["Achievements"] = 22] = "Achievements";
    EStoreCategory[EStoreCategory["SteamCloud"] = 23] = "SteamCloud";
    EStoreCategory[EStoreCategory["SplitScreen"] = 24] = "SplitScreen";
    EStoreCategory[EStoreCategory["CrossPlatformMultiPlayer"] = 27] = "CrossPlatformMultiPlayer";
    EStoreCategory[EStoreCategory["FullController"] = 28] = "FullController";
    EStoreCategory[EStoreCategory["TradingCards"] = 29] = "TradingCards";
    EStoreCategory[EStoreCategory["Workshop"] = 30] = "Workshop";
    EStoreCategory[EStoreCategory["VRSupport"] = 31] = "VRSupport";
    EStoreCategory[EStoreCategory["OnlineMultiPlayer"] = 36] = "OnlineMultiPlayer";
    EStoreCategory[EStoreCategory["LocalMultiPlayer"] = 37] = "LocalMultiPlayer";
    EStoreCategory[EStoreCategory["OnlineCoOp"] = 38] = "OnlineCoOp";
    EStoreCategory[EStoreCategory["LocalCoOp"] = 39] = "LocalCoOp";
    EStoreCategory[EStoreCategory["RemotePlayTogether"] = 44] = "RemotePlayTogether";
    EStoreCategory[EStoreCategory["HighQualitySoundtrackAudio"] = 50] = "HighQualitySoundtrackAudio";
    EStoreCategory[EStoreCategory["FamilySharing"] = 62] = "FamilySharing";
})(EStoreCategory || (EStoreCategory = {}));
var EPartnerCollection;
(function (EPartnerCollection) {
    EPartnerCollection["EASubscription"] = "EAAccess";
})(EPartnerCollection || (EPartnerCollection = {}));
var ESystemCollection;
(function (ESystemCollection) {
    ESystemCollection["Favorites"] = "favorite";
    ESystemCollection["Uncategorized"] = "uncategorized";
    ESystemCollection["Hidden"] = "hidden";
    ESystemCollection["AllAppsAlpha"] = "all-apps-alpha";
    ESystemCollection["AllAppsRecent"] = "all-apps-recent";
    ESystemCollection["MyGames"] = "my-games";
    ESystemCollection["SiteLicense"] = "site-license";
    ESystemCollection["Recent"] = "recent";
    ESystemCollection["Shared"] = "shared-";
    ESystemCollection["FamilyGroup"] = "shared-familygroup";
    ESystemCollection["DeckGames"] = "deck-games";
    ESystemCollection["DTst1Games"] = "dtst1-games";
    ESystemCollection["LocalGames"] = "local-install";
    ESystemCollection["AllGames"] = "all-games";
    ESystemCollection["LocalPlayed"] = "local-played";
    ESystemCollection["RecentPurchased"] = "recent-purchased";
    ESystemCollection["DeckDesktopApps"] = "deck-desktop-apps";
    ESystemCollection["RemotePlay"] = "remote-play";
    ESystemCollection["RemotePlayActive"] = "remote-play-active";
    ESystemCollection["VR"] = "vr";
    ESystemCollection["Xbox"] = "xbox";
    ESystemCollection["PS4"] = "ps4";
    ESystemCollection["PS5"] = "ps5";
    ESystemCollection["AppType"] = "type-";
    ESystemCollection["AppType_Games"] = "type-games";
    ESystemCollection["AppType_Soundtracks"] = "type-music";
    ESystemCollection["AppType_Software"] = "type-software";
    ESystemCollection["AppType_Videos"] = "type-videos";
    ESystemCollection["AppType_Tools"] = "type-tools";
})(ESystemCollection || (ESystemCollection = {}));

var EGameListView;
(function (EGameListView) {
    EGameListView[EGameListView["kNormal"] = 1] = "kNormal";
    EGameListView[EGameListView["kSingleCollection"] = 10] = "kSingleCollection";
    EGameListView[EGameListView["kSearchResults"] = 11] = "kSearchResults";
})(EGameListView || (EGameListView = {}));
var EAppPropertiesSection;
(function (EAppPropertiesSection) {
    EAppPropertiesSection["General"] = "general";
    EAppPropertiesSection["Compatibility"] = "compatibility";
    EAppPropertiesSection["Updates"] = "updates";
    EAppPropertiesSection["LocalFiles"] = "localfiles";
    EAppPropertiesSection["Language"] = "language";
    EAppPropertiesSection["Betas"] = "betas";
    EAppPropertiesSection["Controller"] = "controller";
    EAppPropertiesSection["Shortcut"] = "shortcut";
    EAppPropertiesSection["Dlc"] = "dlc";
    EAppPropertiesSection["Workshop"] = "workshop";
    EAppPropertiesSection["Feedback"] = "feedback";
})(EAppPropertiesSection || (EAppPropertiesSection = {}));
var EControllerConfiguratorSection;
(function (EControllerConfiguratorSection) {
    EControllerConfiguratorSection["Main"] = "Main";
    EControllerConfiguratorSection["Summary"] = "Summary";
    EControllerConfiguratorSection["Preview"] = "Preview";
    EControllerConfiguratorSection["ActionSets"] = "ActionSets";
    EControllerConfiguratorSection["Buttons"] = "Buttons";
    EControllerConfiguratorSection["Triggers"] = "Triggers";
    EControllerConfiguratorSection["Sticks"] = "Sticks";
    EControllerConfiguratorSection["Touchpads"] = "Touchpads";
    EControllerConfiguratorSection["Gyroscopes"] = "Gyroscopes";
    EControllerConfiguratorSection["VirtualMenus"] = "VirtualMenus";
    EControllerConfiguratorSection["ChooseBinding"] = "ChooseBinding";
})(EControllerConfiguratorSection || (EControllerConfiguratorSection = {}));
var ESettingsZooSection;
(function (ESettingsZooSection) {
    ESettingsZooSection["Dropdowns"] = "Dropdowns";
    ESettingsZooSection["Modals"] = "Modals";
    ESettingsZooSection["Buttons"] = "Buttons";
    ESettingsZooSection["Sliders"] = "Sliders";
    ESettingsZooSection["Toggles"] = "Toggles";
    ESettingsZooSection["OtherControls"] = "Misc";
    ESettingsZooSection["Glyphs"] = "Glyphs";
    ESettingsZooSection["SVG"] = "SVG";
    ESettingsZooSection["Input"] = "Input";
    ESettingsZooSection["Type"] = "Type";
})(ESettingsZooSection || (ESettingsZooSection = {}));
var ESettingsZooDevSection;
(function (ESettingsZooDevSection) {
    ESettingsZooDevSection["DeveloperOptions"] = "DeveloperOptions";
    ESettingsZooDevSection["VRDeveloperOptions"] = "VRDeveloperOptions";
    ESettingsZooDevSection["AppSpotlight"] = "AppSpotlight";
    ESettingsZooDevSection["PlayNext"] = "PlayNext";
    ESettingsZooDevSection["Notifications"] = "Notifications";
    ESettingsZooDevSection["Share"] = "Share";
})(ESettingsZooDevSection || (ESettingsZooDevSection = {}));

var ETextFilterSetting;
(function (ETextFilterSetting) {
    ETextFilterSetting[ETextFilterSetting["SteamLabOptedOut"] = 0] = "SteamLabOptedOut";
    ETextFilterSetting[ETextFilterSetting["Enabled"] = 1] = "Enabled";
    ETextFilterSetting[ETextFilterSetting["EnabledAllowProfanity"] = 2] = "EnabledAllowProfanity";
    ETextFilterSetting[ETextFilterSetting["Disabled"] = 3] = "Disabled";
})(ETextFilterSetting || (ETextFilterSetting = {}));
var EUserReviewScorePreference;
(function (EUserReviewScorePreference) {
    EUserReviewScorePreference[EUserReviewScorePreference["Unset"] = 0] = "Unset";
    EUserReviewScorePreference[EUserReviewScorePreference["IncludeAll"] = 1] = "IncludeAll";
    EUserReviewScorePreference[EUserReviewScorePreference["ExcludeBombs"] = 2] = "ExcludeBombs";
})(EUserReviewScorePreference || (EUserReviewScorePreference = {}));
var EProvideDeckFeedbackPreference;
(function (EProvideDeckFeedbackPreference) {
    EProvideDeckFeedbackPreference[EProvideDeckFeedbackPreference["Unset"] = 0] = "Unset";
    EProvideDeckFeedbackPreference[EProvideDeckFeedbackPreference["Yes"] = 1] = "Yes";
    EProvideDeckFeedbackPreference[EProvideDeckFeedbackPreference["No"] = 2] = "No";
})(EProvideDeckFeedbackPreference || (EProvideDeckFeedbackPreference = {}));

var EOpenSideMenu;
(function (EOpenSideMenu) {
    EOpenSideMenu[EOpenSideMenu["None"] = 0] = "None";
    EOpenSideMenu[EOpenSideMenu["Main"] = 1] = "Main";
    EOpenSideMenu[EOpenSideMenu["QuickAccess"] = 2] = "QuickAccess";
})(EOpenSideMenu || (EOpenSideMenu = {}));

const definePlugin = (fn) => {
    return (...args) => {
        return fn(...args);
    };
};

export { Button, ColorPickerModal, CommonUIModule, ConfirmModal, DialogButton, EAccountType, EAppPropertiesSection, EControllerConfiguratorSection, EFilterAppFeature, EGamePlayState, EGenre, ENavigationSourceType, EOpenSideMenu, EPartnerCollection, EProvideDeckFeedbackPreference, ESettingsZooDevSection, ESettingsZooSection, EStoreCategory, ESystemCollection, ETextFilterSetting, EUserReviewScorePreference, FocusRing, ReactRouter, ScrollPanel, ScrollPanelGroup, SliderField, definePlugin, findModuleByExport, findModuleExport, gamepadSliderClasses, getGamepadNavigationTrees, useParams, useQuickAccessVisible };
//# sourceMappingURL=chunk-DMkdGRZG.js.map
