import { m as useSetting, u as useTranslation, H as FaChrome, J as FaFileArchive, W as WarnThirdPartyType, K as FaLink, L as installFromURL, M as FaTerminal, N as FaSteamSymbol, O as FaReact, P as getSetting, Q as FileSelectionType } from './chunk-BRlI6dAn.js';
import { setShowValveInternal, setShouldConnectToReactDevTools } from './chunk-BVKRgher.js';
import { L as Logger } from './chunk-St9casVY.js';
import { W as WarnThirdParty } from './chunk-CrvrCQZp.js';
import { F as Field, h as DialogBody, i as DialogControlsSection, j as DialogControlsSectionHeader, D as DialogButton, w as showModal, T as TextField, N as Navigation } from './chunk-sIGTtP5a.js';
import { T as Toggle } from './chunk-DDBhefN9.js';
import './chunk-CFxgpTYP.js';
import './chunk-DxhJXJ98.js';
import './chunk-C7f0gL0I.js';

function RemoteDebuggingSettings() {
    const [allowRemoteDebugging, setAllowRemoteDebugging] = useSetting('cef_forward', false);
    const { t } = useTranslation();
    return (SP_JSX.jsx(Field, { label: t('RemoteDebugging.remote_cef.label'), description: SP_JSX.jsx("span", { style: { whiteSpace: 'pre-line' }, children: t('RemoteDebugging.remote_cef.desc') }), icon: SP_JSX.jsx(FaChrome, { style: { display: 'block' } }), children: SP_JSX.jsx(Toggle, { value: allowRemoteDebugging || false, onChange: (toggleValue) => {
                setAllowRemoteDebugging(toggleValue);
                if (toggleValue)
                    DeckyBackend.call('utilities/allow_remote_debugging');
                else
                    DeckyBackend.call('utilities/disallow_remote_debugging');
            } }) }));
}

const logger = new Logger('DeveloperIndex');
const installFromZip = async () => {
    const path = await getSetting('user_info.user_home', '');
    if (path === '') {
        logger.error('The default path has not been found!');
        return;
    }
    DeckyPluginLoader.openFilePicker(FileSelectionType.FILE, path, true, true, undefined, ['zip'], false, false).then((val) => {
        const url = `file://${val.path}`;
        console.log(`Installing plugin locally from ${url}`);
        installFromURL(url);
    });
};
const getTabID = DeckyBackend.callable('utilities/get_tab_id');
function DeveloperSettings() {
    const [enableValveInternal, setEnableValveInternal] = useSetting('developer.valve_internal', false);
    const [reactDevtoolsEnabled, setReactDevtoolsEnabled] = useSetting('developer.rdt.enabled', false);
    const [reactDevtoolsIP, setReactDevtoolsIP] = useSetting('developer.rdt.ip', '');
    const [acceptedWarning, setAcceptedWarning] = useSetting('developer.warn.third_party', false);
    const waitTime = acceptedWarning ? 0 : 5;
    const [pluginURL, setPluginURL] = SP_REACT.useState('');
    const textRef = SP_REACT.useRef(null);
    const { t } = useTranslation();
    return (SP_JSX.jsxs(DialogBody, { children: [SP_JSX.jsxs(DialogControlsSection, { children: [SP_JSX.jsx(DialogControlsSectionHeader, { children: t('SettingsDeveloperIndex.third_party_plugins.header') }), SP_JSX.jsx(Field, { label: t('SettingsDeveloperIndex.third_party_plugins.label_zip'), icon: SP_JSX.jsx(FaFileArchive, { style: { display: 'block' } }), children: SP_JSX.jsx(DialogButton, { onClick: () => {
                                showModal(SP_JSX.jsx(WarnThirdParty, { type: WarnThirdPartyType.ZIP, onOK: () => {
                                        setAcceptedWarning(true);
                                        installFromZip();
                                    }, onCancel: () => { }, seconds: waitTime }));
                            }, children: t('SettingsDeveloperIndex.third_party_plugins.button_zip') }) }), SP_JSX.jsx(Field, { label: t('SettingsDeveloperIndex.third_party_plugins.label_url'), description: SP_JSX.jsx(TextField, { label: t('SettingsDeveloperIndex.third_party_plugins.label_desc'), value: pluginURL, onChange: (e) => setPluginURL(e?.target.value) }), icon: SP_JSX.jsx(FaLink, { style: { display: 'block' } }), children: SP_JSX.jsx(DialogButton, { disabled: pluginURL.length == 0, onClick: () => showModal(SP_JSX.jsx(WarnThirdParty, { type: WarnThirdPartyType.ZIP, onOK: () => {
                                    setAcceptedWarning(true);
                                    if (/^https?:\/\//.test(pluginURL)) {
                                        installFromURL(pluginURL);
                                    }
                                    else {
                                        installFromURL('https://' + pluginURL);
                                    }
                                }, onCancel: () => { }, seconds: waitTime })), children: t('SettingsDeveloperIndex.third_party_plugins.button_install') }) })] }), SP_JSX.jsxs(DialogControlsSection, { children: [SP_JSX.jsx(DialogControlsSectionHeader, { children: t('SettingsDeveloperIndex.header') }), SP_JSX.jsx(Field, { label: t('SettingsDeveloperIndex.cef_console.label'), description: SP_JSX.jsx("span", { style: { whiteSpace: 'pre-line' }, children: t('SettingsDeveloperIndex.cef_console.desc') }), icon: SP_JSX.jsx(FaTerminal, { style: { display: 'block' } }), children: SP_JSX.jsx(DialogButton, { onClick: async () => {
                                try {
                                    let tabId = await getTabID('SharedJSContext');
                                    Navigation.NavigateToExternalWeb('localhost:8080/devtools/inspector.html?ws=localhost:8080/devtools/page/' + tabId);
                                }
                                catch (e) {
                                    console.error('Unable to find ID for SharedJSContext tab ', e);
                                    Navigation.NavigateToExternalWeb('localhost:8080');
                                }
                            }, children: t('SettingsDeveloperIndex.cef_console.button') }) }), SP_JSX.jsx(RemoteDebuggingSettings, {}), SP_JSX.jsx(Field, { label: t('SettingsDeveloperIndex.valve_internal.label'), description: SP_JSX.jsxs("span", { style: { whiteSpace: 'pre-line' }, children: [t('SettingsDeveloperIndex.valve_internal.desc1'), ' ', SP_JSX.jsx("span", { style: { color: 'red' }, children: t('SettingsDeveloperIndex.valve_internal.desc2') })] }), icon: SP_JSX.jsx(FaSteamSymbol, { style: { display: 'block' } }), children: SP_JSX.jsx(Toggle, { value: enableValveInternal, onChange: (toggleValue) => {
                                setEnableValveInternal(toggleValue);
                                setShowValveInternal(toggleValue);
                            } }) }), SP_JSX.jsx(Field, { label: t('SettingsDeveloperIndex.react_devtools.label'), description: SP_JSX.jsxs(SP_JSX.Fragment, { children: [SP_JSX.jsx("span", { style: { whiteSpace: 'pre-line' }, children: t('SettingsDeveloperIndex.react_devtools.desc') }), SP_JSX.jsx("br", {}), SP_JSX.jsx("br", {}), SP_JSX.jsx("div", { ref: textRef, children: SP_JSX.jsx(TextField, { label: t('SettingsDeveloperIndex.react_devtools.ip_label'), value: reactDevtoolsIP, onChange: (e) => setReactDevtoolsIP(e?.target.value) }) })] }), icon: SP_JSX.jsx(FaReact, { style: { display: 'block' } }), children: SP_JSX.jsx(Toggle, { value: reactDevtoolsEnabled, 
                            // disabled={reactDevtoolsIP == ''}
                            onChange: (toggleValue) => {
                                setReactDevtoolsEnabled(toggleValue);
                                setShouldConnectToReactDevTools(toggleValue);
                            } }) })] })] }));
}

export { DeveloperSettings as default };
//# sourceMappingURL=chunk-C--ZC6oZ.js.map
