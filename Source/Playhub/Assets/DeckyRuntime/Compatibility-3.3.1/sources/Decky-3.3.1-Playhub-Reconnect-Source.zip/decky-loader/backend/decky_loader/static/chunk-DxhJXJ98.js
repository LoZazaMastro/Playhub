function joinClassNames(...classes) {
    return classes.join(' ');
}
function sleep(ms) {
    return new Promise((res) => setTimeout(res, ms));
}
function findSP() {
    if (document.title == 'SP')
        return window;
    const navTrees = getGamepadNavigationTrees();
    return navTrees?.find((x) => x.m_ID == 'GamepadUI_Full_Root' || x.m_ID == 'root_1_' || x.m_ID == 'GamepadUI_VR_Full_Root')?.Root?.Element?.ownerDocument?.defaultView;
}
function getFocusNavController() {
    return window.GamepadNavTree?.m_context?.m_controller || window.FocusNavController;
}
function getGamepadNavigationTrees() {
    const focusNav = getFocusNavController();
    const context = focusNav?.m_ActiveContext || focusNav?.m_LastActiveContext;
    return context?.m_rgGamepadNavigationTrees;
}

export { getFocusNavController as a, findSP as f, getGamepadNavigationTrees as g, joinClassNames as j, sleep as s };
//# sourceMappingURL=chunk-DxhJXJ98.js.map
