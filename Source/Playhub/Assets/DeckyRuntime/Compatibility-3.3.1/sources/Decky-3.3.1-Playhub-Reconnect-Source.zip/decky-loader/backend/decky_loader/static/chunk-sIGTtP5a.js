import { C as CommonUIModule, g as createModuleMapping, L as Logger, f as findModuleExport, c as findModuleDetailsByExport, a as findModuleByExport, b as findModule, I as IconsModule } from './chunk-CFxgpTYP.js';
import { f as findSP } from './chunk-DxhJXJ98.js';

const CommonDialogDivs = Object.values(CommonUIModule).filter((m) => typeof m === 'object' &&
    (m?.render?.toString().includes('jsx)("div",{...') ||
        m?.render?.toString().includes('jsx)("div",Object.assign({},')) ||
    (m?.render?.toString().includes('createElement("div",{...') ||
        m?.render?.toString().includes('createElement("div",Object.assign({},')));
const MappedDialogDivs = new Map(Object.values(CommonDialogDivs).map((m) => {
    try {
        const renderedDiv = m.render({});
        return [renderedDiv?.props?.className?.split(' ')[0], m];
    }
    catch (e) {
        console.error("[DFL:Dialog]: failed to render common dialog component", e);
        return [null, null];
    }
}));
const DialogHeader = (MappedDialogDivs.get('DialogHeader') || Object.values(CommonUIModule).find((component) => {
    const str = component?.render?.toString?.();
    return str?.includes("role:\"heading\"") && str.includes(")(\"DialogHeader\",");
}));
const DialogSubHeader = MappedDialogDivs.get('DialogSubHeader');
const DialogFooter = MappedDialogDivs.get('DialogFooter');
const DialogLabel = MappedDialogDivs.get('DialogLabel');
const DialogBodyText = MappedDialogDivs.get('DialogBodyText');
const DialogBody = MappedDialogDivs.get('DialogBody');
const DialogControlsSection = MappedDialogDivs.get('DialogControlsSection');
const DialogControlsSectionHeader = MappedDialogDivs.get('DialogControlsSectionHeader');
const DialogButtonPrimary = Object.values(CommonUIModule).find((mod) => mod?.render?.toString?.()?.includes('"DialogButton","_DialogLayout","Primary"'));
const DialogButtonSecondary = Object.values(CommonUIModule).find((mod) => mod?.render?.toString?.()?.includes('"DialogButton","_DialogLayout","Secondary"'));
const DialogButton = DialogButtonSecondary;

let callOriginal = Symbol('DECKY_CALL_ORIGINAL');
function beforePatch(object, property, handler, options = {}) {
    const orig = object[property];
    object[property] = function (...args) {
        handler.call(this, args);
        const ret = patch.original.call(this, ...args);
        if (options.singleShot) {
            patch.unpatch();
        }
        return ret;
    };
    const patch = processPatch(object, property, handler, object[property], orig);
    return patch;
}
function afterPatch(object, property, handler, options = {}) {
    const orig = object[property];
    object[property] = function (...args) {
        let ret = patch.original.call(this, ...args);
        ret = handler.call(this, args, ret);
        if (options.singleShot) {
            patch.unpatch();
        }
        return ret;
    };
    const patch = processPatch(object, property, handler, object[property], orig);
    return patch;
}
function replacePatch(object, property, handler, options = {}) {
    const orig = object[property];
    object[property] = function (...args) {
        const ret = handler.call(this, args);
        if (ret == callOriginal)
            return patch.original.call(this, ...args);
        if (options.singleShot) {
            patch.unpatch();
        }
        return ret;
    };
    const patch = processPatch(object, property, handler, object[property], orig);
    return patch;
}
function processPatch(object, property, handler, patchedFunction, original) {
    Object.assign(object[property], original);
    object[property].toString = () => original.toString();
    Object.defineProperty(object[property], '__deckyOrig', {
        get: () => patch.original,
        set: (val) => (patch.original = val),
    });
    const patch = {
        object,
        property,
        handler,
        patchedFunction,
        original,
        hasUnpatched: false,
        unpatch: () => unpatch(patch),
    };
    object[property].__deckyPatch = patch;
    return patch;
}
function unpatch(patch) {
    const { object, property, handler, patchedFunction, original } = patch;
    if (patch.hasUnpatched)
        throw new Error('Function is already unpatched.');
    let realProp = property;
    let realObject = object;
    console.debug('[Patcher] unpatching', {
        realObject,
        realProp,
        object,
        property,
        handler,
        patchedFunction,
        original,
        isEqual: realObject[realProp] === patchedFunction,
    });
    while (realObject[realProp] && realObject[realProp] !== patchedFunction) {
        realObject = realObject[realProp].__deckyPatch;
        realProp = 'original';
        console.debug('[Patcher] moved to next', {
            realObject,
            realProp,
            object,
            property,
            handler,
            patchedFunction,
            original,
            isEqual: realObject[realProp] === patchedFunction,
        });
    }
    realObject[realProp] = realObject[realProp].__deckyPatch.original;
    patch.hasUnpatched = true;
    console.debug('[Patcher] unpatched', {
        realObject,
        realProp,
        object,
        property,
        handler,
        patchedFunction,
        original,
        isEqual: realObject[realProp] === patchedFunction,
    });
}

const classModuleMap = createModuleMapping((m) => {
    if (typeof m == 'object' && !m.__esModule) {
        const keys = Object.keys(m);
        if (keys.length == 1 && m.version)
            return false;
        if (keys.length > 1000 && m.AboutSettings)
            return false;
        return keys.length > 0 && keys.every((k) => !Object.getOwnPropertyDescriptor(m, k)?.get && typeof m[k] == 'string');
    }
    return false;
});
const classMap = [...classModuleMap.values()];
function findClass(id, name) {
    return classModuleMap.get(id)?.[name];
}
function findClassByName(name) {
    return classMap.find((m) => m[name])?.[name];
}
function findClassModule(filter) {
    return classMap.find((m) => filter(m));
}
function unminifyClass(minifiedClass) {
    for (let m of classModuleMap.values()) {
        for (let className of Object.keys(m)) {
            if (m[className] == minifiedClass)
                return className;
        }
    }
}

const quickAccessMenuClasses = findClassModule((m) => m.Title && m.QuickAccessMenu);
const scrollPanelClasses = findClassModule((m) => m.ScrollPanel);
const gamepadDialogClasses = findClassModule((m) => m.GamepadDialogContent && !m.BindingButtons);
const quickAccessControlsClasses = findClassModule((m) => m.BatteryPercentageLabel && m.PanelSection && !m['vr-dashboard-bar-height'] && !m.QuickAccessMenu && !m.QuickAccess && !m.PerfProfileInfo);
const updaterFieldClasses = findClassModule((m) => m.OOBEUpdateStatusContainer);
const playSectionClasses = findClassModule((m) => m.PlayBarDetailLabel);
const gamepadSliderClasses = findClassModule((m) => m.SliderControlPanelGroup);
const appDetailsHeaderClasses = findClassModule((m) => m.TopCapsule);
const appDetailsClasses = findClassModule((m) => m.HeaderLoaded);
const gamepadUIClasses = findClassModule((m) => m.BasicUiRoot);
const gamepadTabbedPageClasses = findClassModule((m) => m.GamepadTabbedPage);
const gamepadContextMenuClasses = findClassModule((m) => m.BasicContextMenuModal);
const achievementListClasses = findClassModule((m) => m.AchievementListItemBase && !m.Page);
const achievementPageClasses = findClassModule((m) => m.AchievementListItemBase && m.Page);
const mainMenuAppRunningClasses = findClassModule((m) => m.AppRunningControls && m.OverlayAchievements);
const basicAppDetailsSectionStylerClasses = findClassModule((m) => m.AppDetailsRoot);
const steamSpinnerClasses = findClassModule(m => m.SpinnerLoaderContainer);
const footerClasses = findClassModule(m => m.QuickAccessFooter);
const appActionButtonClasses = findClassModule(m => m.PlayButtonContainer);
const libraryAssetImageClasses = findClassModule(m => m.LongTitles && m.GreyBackground);
const gamepadLibraryClasses = findClassModule(m => m.GamepadLibrary);
const focusRingClasses = findClassModule(m => m.FocusRingRoot);
const searchBarClasses = findClassModule(m => m.SearchAndTitleContainer);
const mainBrowserClasses = findClassModule(m => m.MainBrowserContainer);
const vrDashboardClasses = findClassModule(m => m.DashboardBarPopupContents && m.DashboardBar);
const staticClasses = quickAccessMenuClasses;
const scrollClasses = scrollPanelClasses;
const achievementClasses = achievementListClasses;

var __setFunctionName = (undefined && undefined.__setFunctionName) || function (f, name, prefix) {
    if (typeof name === "symbol") name = name.description ? "[".concat(name.description, "]") : "";
    return Object.defineProperty(f, "name", { configurable: true, value: prefix ? "".concat(prefix, " ", name) : name });
};

function createPropListRegex(propList, fromStart = true) {
    let regexString = fromStart ? "const\{" : "";
    propList.forEach((prop, propIdx) => {
        regexString += `"?${prop}"?:[a-zA-Z_$]{1,2}`;
        if (propIdx < propList.length - 1) {
            regexString += ",";
        }
    });
    return new RegExp(regexString);
}
let oldHooks = {};
let INTERNAL_HOOKS = window.SP_REACT?.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED?.ReactCurrentDispatcher
    .current || Object.values(window.SP_REACT?.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE).find((p) => p?.useEffect);
function applyHookStubs(customHooks = {}) {
    const hooks = INTERNAL_HOOKS;
    oldHooks = {
        useContext: hooks.useContext,
        useCallback: hooks.useCallback,
        useLayoutEffect: hooks.useLayoutEffect,
        useEffect: hooks.useEffect,
        useMemo: hooks.useMemo,
        useRef: hooks.useRef,
        useState: hooks.useState,
    };
    hooks.useCallback = (cb) => cb;
    hooks.useContext = (cb) => cb?._currentValue;
    hooks.useLayoutEffect = (_) => { };
    hooks.useMemo = (_, __) => ({});
    hooks.useEffect = (_) => { };
    hooks.useRef = (val) => ({ current: val || void 0 });
    hooks.useState = (v) => {
        let val = v;
        return [val, (n) => (val = n)];
    };
    Object.assign(hooks, customHooks);
    return hooks;
}
function removeHookStubs() {
    const hooks = INTERNAL_HOOKS;
    Object.assign(hooks, oldHooks);
    oldHooks = {};
}
function fakeRenderComponent(fun, customHooks) {
    const hooks = applyHookStubs(customHooks);
    const res = fun(hooks);
    removeHookStubs();
    return res;
}
function wrapReactType(node, prop = 'type') {
    if (node[prop]?.__DECKY_WRAPPED) {
        return node[prop];
    }
    else {
        return (node[prop] = { ...node[prop], __DECKY_WRAPPED: true });
    }
}
function wrapReactClass(node, prop = 'type') {
    var _a;
    if (node[prop]?.__DECKY_WRAPPED) {
        return node[prop];
    }
    else {
        const cls = node[prop];
        const wrappedCls = (_a = class extends cls {
            },
            __setFunctionName(_a, "wrappedCls"),
            _a.__DECKY_WRAPPED = true,
            _a);
        return (node[prop] = wrappedCls);
    }
}
function getReactRoot(o) {
    return (o[Object.keys(o).find((k) => k.startsWith('__reactContainer$'))] ||
        o['_reactRootContainer']?._internalRoot?.current);
}
function getReactInstance(o) {
    return (o[Object.keys(o).find((k) => k.startsWith('__reactFiber'))] ||
        o[Object.keys(o).find((k) => k.startsWith('__reactInternalInstance'))]);
}
const findInTree = (parent, filter, opts) => {
    const { walkable = null, ignore = [] } = opts ?? {};
    if (!parent || typeof parent !== 'object') {
        return null;
    }
    if (filter(parent))
        return parent;
    if (Array.isArray(parent)) {
        return parent.map((x) => findInTree(x, filter, opts)).find((x) => x);
    }
    return (walkable || Object.keys(parent))
        .map((x) => !ignore.includes(x) && findInTree(parent[x], filter, opts))
        .find((x) => x);
};
const findInReactTree = (node, filter) => findInTree(node, filter, {
    walkable: ['props', 'children', 'child', 'sibling'],
});
function getParentWindow(elem) {
    return elem?.ownerDocument?.defaultView;
}
function useWindowRef() {
    const [win, setWin] = SP_REACT.useState(null);
    return [(elem) => setWin(getParentWindow(elem)), win];
}

let loggingEnabled$1 = false;
function setFCTrampolineLoggingEnabled(value = true) { loggingEnabled$1 = value; }
let logger$1 = new Logger('FCTrampoline');
function injectFCTrampoline(component, customHooks) {
    const newComponent = function (...args) {
        loggingEnabled$1 && logger$1.debug("new component rendering with props", args);
        return component.apply(this, args);
    };
    const userComponent = { component: newComponent };
    component.prototype.render = function (...args) {
        loggingEnabled$1 && logger$1.debug("rendering trampoline", args, this);
        const ret = SP_REACT.createElement(userComponent.component, this.props, this.props.children);
        loggingEnabled$1 && logger$1.debug("trampoline", ret);
        return ret;
    };
    component.prototype.isReactComponent = true;
    let stubsApplied = false;
    const patchJsx = window.SP_REACTDOM.version.startsWith("19.");
    let oldJsx = window.SP_JSX?.jsx;
    let oldJsxs = window.SP_JSX?.jsxs;
    let oldCreateElement = window.SP_REACT.createElement;
    const applyStubsIfNeeded = () => {
        if (!stubsApplied) {
            loggingEnabled$1 && logger$1.debug("applied stubs");
            stubsApplied = true;
            applyHookStubs(customHooks);
            window.SP_REACT.createElement = () => {
                loggingEnabled$1 && logger$1.debug("createElement hook called");
                loggingEnabled$1 && console.trace("createElement trace");
                return Object.create(component.prototype);
            };
            if (patchJsx) {
                window.SP_JSX.jsx = () => {
                    loggingEnabled$1 && logger$1.debug("jsx hook called");
                    loggingEnabled$1 && console.trace("jsx trace");
                    return Object.create(component.prototype);
                };
                window.SP_JSX.jsxs = () => {
                    loggingEnabled$1 && logger$1.debug("jsxs hook called");
                    loggingEnabled$1 && console.trace("jsxs trace");
                    return Object.create(component.prototype);
                };
            }
        }
    };
    const removeStubsIfNeeded = () => {
        if (stubsApplied) {
            loggingEnabled$1 && logger$1.debug("removed stubs");
            stubsApplied = false;
            removeHookStubs();
            window.SP_REACT.createElement = oldCreateElement;
            if (patchJsx) {
                window.SP_JSX.jsx = oldJsx;
                window.SP_JSX.jsxs = oldJsxs;
            }
        }
    };
    let renderHookStep = 0;
    if (window.SP_REACTDOM.version.startsWith("19.")) {
        Object.defineProperty(component, "contextType", {
            configurable: true,
            get: function () {
                loggingEnabled$1 && logger$1.debug("get contexttype", this, this._contextType, stubsApplied, renderHookStep);
                loggingEnabled$1 && console.trace("contextType trace");
                if (renderHookStep == 0) {
                    renderHookStep = 1;
                }
                if (this._contextType == null) {
                    this._contextType = {};
                }
                if (!this._contextType.appliedCurrentValueHook) {
                    logger$1.debug("applied currentvalue hook");
                    this._contextType.appliedCurrentValueHook = true;
                    Object.defineProperty(this._contextType, "_currentValue", {
                        configurable: true,
                        get: function () {
                            loggingEnabled$1 && logger$1.debug("get currentValue", this, stubsApplied, renderHookStep);
                            loggingEnabled$1 && console.trace("currentValue trace");
                            if (renderHookStep == 1) {
                                renderHookStep = 2;
                                applyStubsIfNeeded();
                            }
                            return this.__currentValue;
                        },
                        set: function (value) {
                            return this.__currentValue = value;
                        }
                    });
                }
                return this._contextType;
            },
            set: function (value) {
                this._contextType = value;
            }
        });
        Object.defineProperty(component.prototype, "updater", {
            configurable: true,
            get: function () {
                return this._updater;
            },
            set: function (value) {
                loggingEnabled$1 && logger$1.debug("set updater", this, value, stubsApplied, renderHookStep);
                loggingEnabled$1 && console.trace("updater trace");
                if (renderHookStep == 1 || renderHookStep == 2) {
                    renderHookStep = 0;
                    removeStubsIfNeeded();
                }
                return this._updater = value;
            }
        });
        Object.defineProperty(component, "getDerivedStateFromProps", {
            configurable: true,
            get: function () {
                loggingEnabled$1 && logger$1.debug("get getDerivedStateFromProps", this, stubsApplied, renderHookStep);
                loggingEnabled$1 && console.trace("getDerivedStateFromProps trace");
                if (renderHookStep == 1 || renderHookStep == 2) {
                    renderHookStep = 0;
                    removeStubsIfNeeded();
                }
                return this._getDerivedStateFromProps;
            },
            set: function (value) {
                this._getDerivedStateFromProps = value;
            }
        });
    }
    else if (window.SP_REACTDOM.version.startsWith("18.")) {
        Object.defineProperty(component, "contextType", {
            configurable: true,
            get: function () {
                loggingEnabled$1 && logger$1.debug("get contexttype", this, stubsApplied, renderHookStep);
                loggingEnabled$1 && console.trace("contextType trace");
                if (renderHookStep == 0)
                    renderHookStep = 1;
                else if (renderHookStep == 3)
                    renderHookStep = 4;
                return this._contextType;
            },
            set: function (value) {
                this._contextType = value;
            }
        });
        Object.defineProperty(component, "contextTypes", {
            configurable: true,
            get: function () {
                loggingEnabled$1 && logger$1.debug("get contexttypes", this, stubsApplied, renderHookStep);
                loggingEnabled$1 && console.trace("contextTypes trace");
                if (renderHookStep == 1) {
                    renderHookStep = 2;
                    applyStubsIfNeeded();
                }
                return this._contextTypes;
            },
            set: function (value) {
                this._contextTypes = value;
            }
        });
        Object.defineProperty(component.prototype, "updater", {
            configurable: true,
            get: function () {
                return this._updater;
            },
            set: function (value) {
                loggingEnabled$1 && logger$1.debug("set updater", this, value, stubsApplied, renderHookStep);
                loggingEnabled$1 && console.trace("updater trace");
                if (renderHookStep == 2) {
                    renderHookStep = 0;
                    removeStubsIfNeeded();
                }
                return this._updater = value;
            }
        });
        Object.defineProperty(component, "getDerivedStateFromProps", {
            configurable: true,
            get: function () {
                loggingEnabled$1 && logger$1.debug("get getDerivedStateFromProps", this, stubsApplied, renderHookStep);
                loggingEnabled$1 && console.trace("getDerivedStateFromProps trace");
                if (renderHookStep == 2) {
                    renderHookStep = 0;
                    removeStubsIfNeeded();
                }
                return this._getDerivedStateFromProps;
            },
            set: function (value) {
                this._getDerivedStateFromProps = value;
            }
        });
    }
    return userComponent;
}

let loggingEnabled = true;
let perfLoggingEnabled = false;
function setReactPatcherLoggingEnabled(value = true) { loggingEnabled = value; }
function setReactPatcherPerformanceLoggingEnabled(value = true) { perfLoggingEnabled = value; }
function patchComponent(node, handler, steps, step, caches, logger, prop = 'type') {
    loggingEnabled && logger.group('Patching node:', node);
    switch (typeof node?.[prop]) {
        case 'function':
            if (node[prop]?.prototype?.render) {
                wrapReactClass(node);
                const patch = afterPatch(node[prop].prototype, 'render', steps[step + 1] ? createStepHandler(handler, steps, step + 1, caches, logger) : handler);
                loggingEnabled && logger.debug('Patched class component', patch);
            }
            else {
                const patch = afterPatch(node, prop, steps[step + 1] ? createStepHandler(handler, steps, step + 1, caches, logger) : handler);
                loggingEnabled && logger.debug('Patched a function component', patch);
            }
            break;
        case 'object':
            loggingEnabled && logger.debug('Patching forwardref/memo');
            wrapReactType(node, prop);
            patchComponent(node[prop], handler, steps, step, caches, logger, node[prop]?.render ? 'render' : 'type');
            break;
        default:
            logger.error('Unhandled component type', node);
            break;
    }
    loggingEnabled && logger.groupEnd();
}
function handleStep(tree, handler, steps, step, caches, logger) {
    const startTime = (loggingEnabled || perfLoggingEnabled) ? performance.now() : 0;
    const stepHandler = steps[step];
    const cache = caches[step] || (caches[step] = new Map());
    loggingEnabled && logger.debug(`Patch step ${step} running`, { tree, stepHandler, step, caches });
    const node = stepHandler(tree);
    if (node && node.type) {
        loggingEnabled && logger.debug('Found node', node);
    }
    else if (node) {
        loggingEnabled && logger.error('Found node without type. Something is probably wrong.', node);
        return tree;
    }
    else {
        loggingEnabled && logger.warn('Found no node. Depending on your usecase, this might be fine.', node);
        return tree;
    }
    let cachedType;
    if (cachedType = cache.get(node.type)) {
        loggingEnabled && logger.debug('Found cached patched component', node);
        node.type = cachedType;
        (loggingEnabled || perfLoggingEnabled) && logger.debug(`Patch step ${step} took ${performance.now() - startTime}ms with cache`);
        return tree;
    }
    const originalType = node.type;
    patchComponent(node, handler, steps, step, caches, logger);
    cache.set(originalType, node.type);
    (loggingEnabled || perfLoggingEnabled) && logger.debug(`Patch step ${step} took ${performance.now() - startTime}ms`);
    return tree;
}
function createStepHandler(handler, steps, step, caches, logger) {
    loggingEnabled && logger.debug(`Creating handler for step ${step}`);
    return (_, tree) => handleStep(tree, handler, steps, step, caches, logger);
}
function createReactTreePatcher(steps, handler, debugName = 'ReactPatch') {
    const caches = [];
    const logger = new Logger(`ReactTreePatcher -> ${debugName}`);
    loggingEnabled && logger.debug('Init with options:', steps, debugName);
    return createStepHandler(handler, steps, 0, caches, logger);
}

const buttonItemRegex = createPropListRegex(["highlightOnFocus", "childrenContainerWidth"], false);
const ButtonItem = Object.values(CommonUIModule).find((mod) => (mod?.render?.toString && buttonItemRegex.test(mod.render.toString())) ||
    mod?.render?.toString?.().includes('childrenContainerWidth:"min"'));

const ControlsList = findModuleExport((e) => e?.toString && e.toString?.().includes('().ControlsListChild') && e.toString?.().includes('().ControlsListOuterPanel'));

const DialogCheckbox = findModuleExport(e => e?.prototype &&
    typeof e?.prototype == "object" &&
    "GetPanelElementProps" in e?.prototype &&
    "SetChecked" in e?.prototype &&
    "Toggle" in e?.prototype &&
    (e?.prototype?.render?.toString?.().includes('="DialogCheckbox"') || (e.contextType &&
        e.prototype?.render?.toString?.().includes('fallback:'))));

const Dropdown = Object.values(CommonUIModule).find((mod) => mod?.prototype?.SetSelectedOption && mod?.prototype?.BuildMenu);
const dropdownItemRegex = createPropListRegex(["dropDownControlRef", "description"], false);
const DropdownItemInternal = Object.values(CommonUIModule).find((mod) => mod?.toString && dropdownItemRegex.test(mod.toString()));
const DropdownItem = ((args) => SP_JSX.jsx(DropdownItemInternal, { childrenContainerWidth: "min", ...args }));

const ErrorBoundary = findModuleExport((e) => e?.prototype?.Reset && e?.prototype?.componentDidCatch && e.prototype?.render?.toString().includes("lastErrorKey"));

const Field = findModuleExport((e) => (e?.toString?.()?.includes('().Field') && e?.toString?.()?.includes('"shift-children-below"')) || e?.render?.toString()?.includes('"shift-children-below"'));

const focusableRegex = createPropListRegex(["flow-children", "onActivate", "onCancel", "focusClassName", "focusWithinClassName"]);
const Focusable = findModuleExport((e) => (typeof e == 'function' && e?.toString && focusableRegex.test(e.toString?.())) || (e?.render?.toString && focusableRegex.test(e.render.toString())));

const Marquee = findModuleExport((e) => e?.toString && e.toString?.().includes('.Marquee') && e.toString?.().includes('--fade-length'));

const showContextMenu = findModuleExport((e) => typeof e === 'function' &&
    e.toString?.().includes('GetContextMenuManagerFromWindow(') &&
    e.toString?.().includes('.CreateContextMenuInstance('));
const MenuModule = findModuleDetailsByExport((e) => e?.render?.toString()?.includes('bPlayAudio:') || (e?.prototype?.OnOKButton && e?.prototype?.OnMouseEnter));
const Menu = findModuleExport((e) => e?.prototype?.HideIfSubmenu && e?.prototype?.HideMenu) ||
    Object.values(MenuModule?.[0] ?? {}).find((e) => e?.toString?.()?.includes?.(`useId`) && e?.toString?.()?.includes?.(`labelId`));
const MenuGroupModule = findModuleByExport(e => e?.prototype?.Focus && e?.prototype?.OnOKButton && (e?.prototype?.render?.toString().includes?.(`this.props.tone=="emphasis"`) || e?.prototype?.render?.toString().includes?.(`"emphasis"==this.props.tone`)));
const MenuGroup = MenuGroupModule && Object.values(MenuGroupModule).find((e) => typeof e == "function" && e?.toString?.()?.includes("bInGamepadUI:"));
const MenuItem = MenuModule?.[1];
const MenuSeparator = findModuleExport((e) => typeof e === 'function' && /className:.+?\.ContextMenuSeparator/.test(e.toString?.()));

const showModalRaw = findModuleExport((e) => typeof e === 'function' && e.toString?.().includes('props.bDisableBackgroundDismiss') && !e?.prototype?.Cancel);
const showModal = (modal, parent, props = {
    strTitle: 'Decky Dialog',
    bHideMainWindowForPopouts: false,
}) => {
    return showModalRaw(modal, parent || findSP() || window, props.strTitle, props, undefined, {
        bHideActions: props.bHideActionIcons,
    });
};
const ConfirmModal = findModuleExport((e) => e?.toString?.()?.includes('bUpdateDisabled') && e?.toString?.()?.includes('closeModal') && e?.toString?.()?.includes('onGamepadCancel'));
const ModalRoot = findModuleExport((e) => typeof e === 'function' && e.toString?.().includes('Either closeModal or onCancel should be passed to GenericDialog. Classes: ')) ||
    Object.values(findModule((m) => {
        if (typeof m !== 'object')
            return false;
        for (let prop in m) {
            if (m[prop]?.m_mapModalManager && Object.values(m)?.find((x) => x?.type)) {
                return true;
            }
        }
        return false;
    }) || {})?.find((x) => x?.type?.toString?.()?.includes('((function(){'));
const [ModalModule, _ModalPosition] = findModuleDetailsByExport((e) => e?.toString?.().includes('.ModalPosition'), 5);
const ModalModuleProps = ModalModule ? Object.values(ModalModule) : [];
const SimpleModal = ModalModuleProps.find((prop) => {
    const string = prop?.toString();
    return string?.includes('.ShowPortalModal()') && string?.includes('.OnElementReadyCallbacks.Register(');
});
const ModalPosition = _ModalPosition;

const [mod, panelSection] = findModuleDetailsByExport((e) => e.toString?.()?.includes('.PanelSection'));
const PanelSection = panelSection;
const PanelSectionRow = Object.values(mod).filter((exp) => !exp?.toString?.()?.includes('.PanelSection'))[0];

const ProgressBar = findModuleExport((e) => e?.toString && /\.ProgressBar,(?:\w*==)?"standard"(?:==)?/.test(e.toString?.()));
const ProgressBarWithInfo = findModuleExport((e) => e?.toString?.()?.includes('.ProgressBarFieldStatus,children') || e?.toString?.()?.includes('.ProgressBarFieldStatus},'));
const progressBarItemRegex = createPropListRegex(["indeterminate", "nTransitionSec", "nProgress"]);
const ProgressBarItem = findModuleExport((e) => e?.toString && progressBarItemRegex.test(e.toString?.()));

const Spinner = IconsModule && Object.values(IconsModule)?.find((mod) => mod?.toString && /Spinner\),children:\[\(0,\w+\.jsx\)\("path",\{d:"M18 /.test(mod.toString()) || /Spinner\)}\)?,.\.createElement\(\"path\",{d:\"M18 /.test(mod.toString()));

const SteamSpinner = findModuleExport((e) => e?.toString?.()?.includes('Steam Spinner') && e?.toString?.()?.includes('src'));

const TextField = Object.values(CommonUIModule).find((mod) => mod?.validateUrl && mod?.validateEmail);

const ToggleField = Object.values(CommonUIModule).find((mod) => mod?.render?.toString?.()?.includes('ToggleField,fallback') || mod?.render?.toString?.()?.includes("ToggleField\","));

const Router = findModuleExport((e) => e.Navigate && e.NavigationManager);
let Navigation = {};
const logger = new Logger("Navigation");
try {
    function createNavigationFunction(fncName, handler) {
        return (...args) => {
            let win;
            try {
                win = window.SteamUIStore.GetFocusedWindowInstance();
            }
            catch (e) {
                logger.warn("Navigation interface failed to call GetFocusedWindowInstance", e);
            }
            if (!win) {
                logger.warn("Navigation interface could not find any focused window. Falling back to Main Window Instance");
                win = Router.WindowStore?.GamepadUIMainWindowInstance || Router?.WindowStore?.SteamUIWindows?.[0];
            }
            if (win) {
                try {
                    const thisObj = handler && handler(win);
                    (thisObj || win)[fncName](...args);
                }
                catch (e) {
                    logger.error("Navigation handler failed", e);
                }
            }
            else {
                logger.error("Navigation interface could not find a window to navigate");
            }
        };
    }
    const newNavigation = {
        Navigate: createNavigationFunction("Navigate"),
        NavigateBack: createNavigationFunction("NavigateBack"),
        NavigateToAppProperties: createNavigationFunction("AppProperties", win => win.Navigator),
        NavigateToExternalWeb: createNavigationFunction("ExternalWeb", win => win.Navigator),
        NavigateToInvites: createNavigationFunction("Invites", win => win.Navigator),
        NavigateToChat: createNavigationFunction("Chat", win => win.Navigator),
        NavigateToLibraryTab: createNavigationFunction("LibraryTab", win => win.Navigator),
        NavigateToLayoutPreview: Router.NavigateToLayoutPreview?.bind(Router),
        NavigateToSteamWeb: createNavigationFunction("NavigateToSteamWeb"),
        OpenSideMenu: createNavigationFunction("OpenSideMenu", win => win.MenuStore),
        OpenQuickAccessMenu: createNavigationFunction("OpenQuickAccessMenu", win => win.MenuStore),
        OpenMainMenu: createNavigationFunction("OpenMainMenu", win => win.MenuStore),
        CloseSideMenus: createNavigationFunction("CloseSideMenus", win => win.MenuStore),
        OpenPowerMenu: Router.OpenPowerMenu?.bind(Router),
    };
    Object.assign(Navigation, newNavigation);
}
catch (e) {
    logger.error('Error initializing Navigation interface', e);
}

var EBrowserType;
(function (EBrowserType) {
    EBrowserType[EBrowserType["OffScreen"] = 0] = "OffScreen";
    EBrowserType[EBrowserType["OpenVROverlay"] = 1] = "OpenVROverlay";
    EBrowserType[EBrowserType["OpenVROverlay_Dashboard"] = 2] = "OpenVROverlay_Dashboard";
    EBrowserType[EBrowserType["DirectHWND"] = 3] = "DirectHWND";
    EBrowserType[EBrowserType["DirectHWND_Borderless"] = 4] = "DirectHWND_Borderless";
    EBrowserType[EBrowserType["DirectHWND_Hidden"] = 5] = "DirectHWND_Hidden";
    EBrowserType[EBrowserType["ChildHWNDNative"] = 6] = "ChildHWNDNative";
    EBrowserType[EBrowserType["Offscreen_SteamUI"] = 12] = "Offscreen_SteamUI";
    EBrowserType[EBrowserType["OpenVROverlay_Subview"] = 13] = "OpenVROverlay_Subview";
})(EBrowserType || (EBrowserType = {}));
var EPopupCreationFlags;
(function (EPopupCreationFlags) {
    EPopupCreationFlags[EPopupCreationFlags["None"] = 0] = "None";
    EPopupCreationFlags[EPopupCreationFlags["Minimized"] = 1] = "Minimized";
    EPopupCreationFlags[EPopupCreationFlags["Hidden"] = 2] = "Hidden";
    EPopupCreationFlags[EPopupCreationFlags["TooltipHint"] = 4] = "TooltipHint";
    EPopupCreationFlags[EPopupCreationFlags["NoTaskbarIcon"] = 8] = "NoTaskbarIcon";
    EPopupCreationFlags[EPopupCreationFlags["Resizable"] = 16] = "Resizable";
    EPopupCreationFlags[EPopupCreationFlags["ScalePosition"] = 32] = "ScalePosition";
    EPopupCreationFlags[EPopupCreationFlags["ScaleSize"] = 64] = "ScaleSize";
    EPopupCreationFlags[EPopupCreationFlags["Maximized"] = 128] = "Maximized";
    EPopupCreationFlags[EPopupCreationFlags["Composited"] = 256] = "Composited";
    EPopupCreationFlags[EPopupCreationFlags["NotFocusable"] = 512] = "NotFocusable";
    EPopupCreationFlags[EPopupCreationFlags["FullScreen"] = 1024] = "FullScreen";
    EPopupCreationFlags[EPopupCreationFlags["Fullscreen_Exclusive"] = 2048] = "Fullscreen_Exclusive";
    EPopupCreationFlags[EPopupCreationFlags["ApplyBrowserScaleToDimensions"] = 4096] = "ApplyBrowserScaleToDimensions";
    EPopupCreationFlags[EPopupCreationFlags["AlwaysOnTop"] = 8192] = "AlwaysOnTop";
    EPopupCreationFlags[EPopupCreationFlags["NoWindowShadow"] = 16384] = "NoWindowShadow";
    EPopupCreationFlags[EPopupCreationFlags["NoMinimize"] = 32768] = "NoMinimize";
    EPopupCreationFlags[EPopupCreationFlags["PopUpMenuHint"] = 65536] = "PopUpMenuHint";
    EPopupCreationFlags[EPopupCreationFlags["IgnoreSavedSize"] = 131072] = "IgnoreSavedSize";
    EPopupCreationFlags[EPopupCreationFlags["NoRoundedCorners"] = 262144] = "NoRoundedCorners";
    EPopupCreationFlags[EPopupCreationFlags["ForceRoundedCorners"] = 524288] = "ForceRoundedCorners";
    EPopupCreationFlags[EPopupCreationFlags["OverrideRedirect"] = 1048576] = "OverrideRedirect";
    EPopupCreationFlags[EPopupCreationFlags["IgnoreSteamDisplayScale"] = 2097152] = "IgnoreSteamDisplayScale";
    EPopupCreationFlags[EPopupCreationFlags["TransparentParentWindow"] = 4194304] = "TransparentParentWindow";
    EPopupCreationFlags[EPopupCreationFlags["DisableDPIScale"] = 8388608] = "DisableDPIScale";
    EPopupCreationFlags[EPopupCreationFlags["ForceBrowserVisible"] = 16777216] = "ForceBrowserVisible";
})(EPopupCreationFlags || (EPopupCreationFlags = {}));
var ESteamRealm;
(function (ESteamRealm) {
    ESteamRealm[ESteamRealm["Unknown"] = 0] = "Unknown";
    ESteamRealm[ESteamRealm["Global"] = 1] = "Global";
    ESteamRealm[ESteamRealm["China"] = 2] = "China";
})(ESteamRealm || (ESteamRealm = {}));
var ESteamUISound;
(function (ESteamUISound) {
    ESteamUISound[ESteamUISound["LaunchGame"] = 0] = "LaunchGame";
    ESteamUISound[ESteamUISound["FriendMessage"] = 1] = "FriendMessage";
    ESteamUISound[ESteamUISound["ChatMention"] = 2] = "ChatMention";
    ESteamUISound[ESteamUISound["ChatMessage"] = 3] = "ChatMessage";
    ESteamUISound[ESteamUISound["ToastMessage"] = 4] = "ToastMessage";
    ESteamUISound[ESteamUISound["ToastAchievement"] = 5] = "ToastAchievement";
    ESteamUISound[ESteamUISound["ToastMisc"] = 6] = "ToastMisc";
    ESteamUISound[ESteamUISound["ToastMiscShort"] = 7] = "ToastMiscShort";
    ESteamUISound[ESteamUISound["FriendOnline"] = 8] = "FriendOnline";
    ESteamUISound[ESteamUISound["FriendInGame"] = 9] = "FriendInGame";
    ESteamUISound[ESteamUISound["VolSound"] = 10] = "VolSound";
    ESteamUISound[ESteamUISound["ShowModal"] = 11] = "ShowModal";
    ESteamUISound[ESteamUISound["HideModal"] = 12] = "HideModal";
    ESteamUISound[ESteamUISound["IntoGameDetail"] = 13] = "IntoGameDetail";
    ESteamUISound[ESteamUISound["OutOfGameDetail"] = 14] = "OutOfGameDetail";
    ESteamUISound[ESteamUISound["PagedNavigation"] = 15] = "PagedNavigation";
    ESteamUISound[ESteamUISound["ToggleOn"] = 16] = "ToggleOn";
    ESteamUISound[ESteamUISound["ToggleOff"] = 17] = "ToggleOff";
    ESteamUISound[ESteamUISound["SliderUp"] = 18] = "SliderUp";
    ESteamUISound[ESteamUISound["SliderDown"] = 19] = "SliderDown";
    ESteamUISound[ESteamUISound["ChangeTabs"] = 20] = "ChangeTabs";
    ESteamUISound[ESteamUISound["DefaultOk"] = 21] = "DefaultOk";
    ESteamUISound[ESteamUISound["OpenSideMenu"] = 22] = "OpenSideMenu";
    ESteamUISound[ESteamUISound["CloseSideMenu"] = 23] = "CloseSideMenu";
    ESteamUISound[ESteamUISound["BasicNav"] = 24] = "BasicNav";
    ESteamUISound[ESteamUISound["FailedNav"] = 25] = "FailedNav";
    ESteamUISound[ESteamUISound["Typing"] = 26] = "Typing";
    ESteamUISound[ESteamUISound["TimerExpired"] = 27] = "TimerExpired";
    ESteamUISound[ESteamUISound["Screenshot"] = 28] = "Screenshot";
})(ESteamUISound || (ESteamUISound = {}));
var EUIMode;
(function (EUIMode) {
    EUIMode[EUIMode["Unknown"] = -1] = "Unknown";
    EUIMode[EUIMode["GamePad"] = 4] = "GamePad";
    EUIMode[EUIMode["Desktop"] = 7] = "Desktop";
})(EUIMode || (EUIMode = {}));

var EBroadcastPermission;
(function (EBroadcastPermission) {
    EBroadcastPermission[EBroadcastPermission["k_EBroadcastPermissionDisabled"] = 0] = "k_EBroadcastPermissionDisabled";
    EBroadcastPermission[EBroadcastPermission["k_EBroadcastPermissionFriendsApprove"] = 1] = "k_EBroadcastPermissionFriendsApprove";
    EBroadcastPermission[EBroadcastPermission["k_EBroadcastPermissionFriendsAllowed"] = 2] = "k_EBroadcastPermissionFriendsAllowed";
    EBroadcastPermission[EBroadcastPermission["k_EBroadcastPermissionPublic"] = 3] = "k_EBroadcastPermissionPublic";
    EBroadcastPermission[EBroadcastPermission["k_EBroadcastPermissionSubscribers"] = 4] = "k_EBroadcastPermissionSubscribers";
})(EBroadcastPermission || (EBroadcastPermission = {}));
var ESteamNotificationSource;
(function (ESteamNotificationSource) {
    ESteamNotificationSource[ESteamNotificationSource["Client"] = 0] = "Client";
    ESteamNotificationSource[ESteamNotificationSource["Server"] = 1] = "Server";
})(ESteamNotificationSource || (ESteamNotificationSource = {}));
var ESteamNotificationAction;
(function (ESteamNotificationAction) {
    ESteamNotificationAction[ESteamNotificationAction["New"] = 0] = "New";
    ESteamNotificationAction[ESteamNotificationAction["Update"] = 1] = "Update";
    ESteamNotificationAction[ESteamNotificationAction["Remove"] = 2] = "Remove";
})(ESteamNotificationAction || (ESteamNotificationAction = {}));

var QuickAccessTab;
(function (QuickAccessTab) {
    QuickAccessTab[QuickAccessTab["Notifications"] = 0] = "Notifications";
    QuickAccessTab[QuickAccessTab["RemotePlayTogetherControls"] = 1] = "RemotePlayTogetherControls";
    QuickAccessTab[QuickAccessTab["VoiceChat"] = 2] = "VoiceChat";
    QuickAccessTab[QuickAccessTab["Friends"] = 3] = "Friends";
    QuickAccessTab[QuickAccessTab["Settings"] = 4] = "Settings";
    QuickAccessTab[QuickAccessTab["Perf"] = 5] = "Perf";
    QuickAccessTab[QuickAccessTab["Help"] = 6] = "Help";
    QuickAccessTab[QuickAccessTab["Soundtrack"] = 7] = "Soundtrack";
    QuickAccessTab[QuickAccessTab["VRBatteries"] = 8] = "VRBatteries";
    QuickAccessTab[QuickAccessTab["Decky"] = 999] = "Decky";
})(QuickAccessTab || (QuickAccessTab = {}));
var SideMenu;
(function (SideMenu) {
    SideMenu[SideMenu["None"] = 0] = "None";
    SideMenu[SideMenu["Main"] = 1] = "Main";
    SideMenu[SideMenu["QuickAccess"] = 2] = "QuickAccess";
})(SideMenu || (SideMenu = {}));

export { callOriginal as $, ProgressBar as A, ButtonItem as B, ConfirmModal as C, DialogButton as D, ErrorBoundary as E, Field as F, ProgressBarWithInfo as G, ProgressBarItem as H, Spinner as I, SteamSpinner as J, ToggleField as K, EBrowserType as L, Marquee as M, Navigation as N, EPopupCreationFlags as O, PanelSection as P, ESteamRealm as Q, Router as R, SimpleModal as S, TextField as T, ESteamUISound as U, EUIMode as V, EBroadcastPermission as W, ESteamNotificationSource as X, ESteamNotificationAction as Y, QuickAccessTab as Z, SideMenu as _, ControlsList as a, beforePatch as a0, afterPatch as a1, replacePatch as a2, quickAccessMenuClasses as a3, scrollPanelClasses as a4, gamepadDialogClasses as a5, quickAccessControlsClasses as a6, updaterFieldClasses as a7, playSectionClasses as a8, appDetailsHeaderClasses as a9, wrapReactClass as aA, getReactRoot as aB, getReactInstance as aC, findInTree as aD, findInReactTree as aE, getParentWindow as aF, useWindowRef as aG, setFCTrampolineLoggingEnabled as aH, injectFCTrampoline as aI, setReactPatcherLoggingEnabled as aJ, setReactPatcherPerformanceLoggingEnabled as aK, createReactTreePatcher as aL, classModuleMap as aM, classMap as aN, findClass as aO, findClassByName as aP, findClassModule as aQ, unminifyClass as aR, appDetailsClasses as aa, gamepadUIClasses as ab, gamepadTabbedPageClasses as ac, gamepadContextMenuClasses as ad, achievementListClasses as ae, achievementPageClasses as af, mainMenuAppRunningClasses as ag, basicAppDetailsSectionStylerClasses as ah, steamSpinnerClasses as ai, footerClasses as aj, appActionButtonClasses as ak, libraryAssetImageClasses as al, gamepadLibraryClasses as am, focusRingClasses as an, searchBarClasses as ao, mainBrowserClasses as ap, vrDashboardClasses as aq, staticClasses as ar, scrollClasses as as, achievementClasses as at, createPropListRegex as au, INTERNAL_HOOKS as av, applyHookStubs as aw, removeHookStubs as ax, fakeRenderComponent as ay, wrapReactType as az, DialogHeader as b, DialogSubHeader as c, DialogFooter as d, DialogLabel as e, DialogBodyText as f, gamepadSliderClasses as g, DialogBody as h, DialogControlsSection as i, DialogControlsSectionHeader as j, DialogButtonPrimary as k, DialogButtonSecondary as l, DialogCheckbox as m, Dropdown as n, DropdownItemInternal as o, DropdownItem as p, Focusable as q, Menu as r, showContextMenu as s, MenuGroup as t, MenuItem as u, MenuSeparator as v, showModal as w, ModalRoot as x, ModalPosition as y, PanelSectionRow as z };
//# sourceMappingURL=chunk-sIGTtP5a.js.map
