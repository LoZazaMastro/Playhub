import { a as findModuleByExport } from './chunk-CFxgpTYP.js';
import { I as Spinner } from './chunk-sIGTtP5a.js';

const tabsModule = findModuleByExport(e => e?.toString?.()?.includes(".TabRowTabs") && e?.toString?.()?.includes("activeTab:"));
const Tabs = tabsModule && Object.values(tabsModule).find((e) => e?.type?.toString?.()?.includes("(function()"));

const SuspensefulImage = (props) => {
    const [loading, setLoading] = SP_REACT.useState(true);
    const [error, setError] = SP_REACT.useState(false);
    SP_REACT.useEffect(() => {
        setLoading(true);
        setError(false);
        const img = new Image();
        img.src = props.src || '';
        img.addEventListener('load', () => {
            setLoading(false);
        });
        img.addEventListener('error', () => {
            setError(true);
        });
    }, [props.src]);
    return loading ? (SP_JSX.jsx("div", { style: {
            width: props.suspenseWidth || props.style?.width,
            height: props.suspenseHeight || props.style?.height,
            background: 'rgba(255, 255, 255, 0.2)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
        }, children: error ? 'Missing image' : SP_JSX.jsx(Spinner, { style: { height: '48px' } }) })) : (SP_JSX.jsx("img", { ...props }));
};

export { SuspensefulImage as S, Tabs as T };
//# sourceMappingURL=chunk-CGQRiEsV.js.map
