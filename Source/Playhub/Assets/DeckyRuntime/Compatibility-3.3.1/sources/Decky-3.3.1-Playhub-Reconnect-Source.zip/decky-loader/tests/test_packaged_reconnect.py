import asyncio, json, logging, marshal, os, pathlib, sys, types, unittest
from unittest.mock import AsyncMock
import pefile
from aiohttp import web, client_exceptions
from PyInstaller.archive.readers import CArchiveReader

ROOT=pathlib.Path(os.environ.get('DECKY_TEST_BUILD_ROOT',pathlib.Path(__file__).resolve().parent))

def recursive(code,name):
    if code.co_name==name:return code
    for child in code.co_consts:
        if isinstance(child,types.CodeType):
            found=recursive(child,name)
            if found:return found
    return None

def modules(exe,subsystem):
    pe=pefile.PE(str(exe));assert pe.OPTIONAL_HEADER.Subsystem==subsystem
    archive=CArchiveReader(str(exe));pyz=archive.open_embedded_archive('PYZ.pyz')
    assert 'python314.dll' in archive.toc
    namespace={'__name__':'decky_reconnect_fixture_injector'}
    exec(pyz.extract('decky_loader.injector'),namespace)
    method=recursive(pyz.extract('decky_loader.main'),'loader_reinjector')
    assert method and 'get_gamepadui_tab' in method.co_names
    return namespace,method

async def loopback(exe,subsystem,close_before_ack=False):
    injector,code=modules(exe,subsystem)
    owner=types.SimpleNamespace(reinject=True,js_ctx_tab=None,handle_crash=AsyncMock())
    counts={'json':0,'stale':0,'live':0,'injection':0};delays=[]
    async def discovery(request):
        counts['json']+=1
        endpoint='stale' if counts['json']==1 else 'live'
        return web.json_response([{'title':'SharedJSContext','id':endpoint,'url':'https://steamloopback.host/index.html',
            'webSocketDebuggerUrl':f'ws://127.0.0.1:{port}/ws/{endpoint}'}])
    async def socket(request):
        which=request.match_info['which'];counts[which]+=1
        if which=='stale':return web.Response(status=404)
        ws=web.WebSocketResponse();await ws.prepare(request)
        async for message in ws:
            command=json.loads(message.data)
            if close_before_ack and counts['live']==1 and command['method']=='Page.enable':
                await ws.close();break
            if command['method']=='Runtime.evaluate':
                await ws.close();break
            await ws.send_json({'id':command['id'],'result':{}})
        return ws
    app=web.Application();app.router.add_get('/json',discovery);app.router.add_get('/ws/{which}',socket)
    runner=web.AppRunner(app);await runner.setup();site=web.TCPSite(runner,'127.0.0.1',0);await site.start()
    port=site._server.sockets[0].getsockname()[1]
    injector['BASE_ADDRESS']=f'http://127.0.0.1:{port}'
    async def injected(tab,first=False):
        counts['injection']+=1
        await tab.evaluate_js('void 0',False,False,False)
        owner.reinject=False
    owner.inject_javascript=injected
    async def backoff(seconds):delays.append(seconds);await asyncio.sleep(0)
    namespace={'get_gamepadui_tab':injector['get_gamepadui_tab'],'client_exceptions':client_exceptions,
        'logger':logging.getLogger('fixture'),'format_exc':lambda:'expected fixture target replaced',
        'sleep':backoff,'wait_for':asyncio.wait_for,'CancelledError':asyncio.CancelledError}
    try:
        await asyncio.wait_for(types.FunctionType(code,namespace)(owner),3)
        assert counts=={'json':3 if close_before_ack else 2,'stale':1,'live':2 if close_before_ack else 1,'injection':1},counts
        assert owner.js_ctx_tab is None and owner.handle_crash.await_count==1
        assert delays==([.25,.5] if close_before_ack else [.25]),delays
    finally:await runner.cleanup()
    print('PASS frozen loopback discovery -> 404 handshake -> replacement websocket -> inject -> exact cleanup',exe.parent.name,counts)


async def ack_cases(exe,subsystem):
    injector,_=modules(exe,subsystem)
    for case in ('close','error','events','cancel','timeout','flood'):
        started=asyncio.Event()
        async def socket(request):
            ws=web.WebSocketResponse();await ws.prepare(request)
            async for message in ws:
                cmd=json.loads(message.data)
                if cmd['method']!='Page.enable':continue
                started.set()
                if case=='close':await ws.close();break
                elif case=='error':await ws.send_json({'id':cmd['id'],'error':{'code':-32000,'message':'fixture'}})
                elif case=='events':
                    await ws.send_json({'method':'Page.domContentEventFired','params':{'timestamp':1}})
                    await ws.send_json({'method':'Runtime.executionContextCreated','params':{'context':{'id':9}}})
                    await ws.send_json({'id':cmd['id'],'result':{}})
                elif case=='flood':
                    for i in range(257):await ws.send_json({'method':'Page.fixture','params':{'i':i}})
            return ws
        app=web.Application();app.router.add_get('/ws',socket)
        runner=web.AppRunner(app);await runner.setup();site=web.TCPSite(runner,'127.0.0.1',0);await site.start()
        port=site._server.sockets[0].getsockname()[1]
        tab=injector['Tab']({'title':'SharedJSContext','id':'fixture','url':'https://steamloopback.host/index.html',
            'webSocketDebuggerUrl':f'ws://127.0.0.1:{port}/ws'})
        try:
            await tab.open_websocket(); task=asyncio.create_task(tab.enable())
            if case=='cancel':
                await started.wait();task.cancel()
                try:await task;raise AssertionError('cancellation swallowed')
                except asyncio.CancelledError:pass
            elif case=='events':
                await asyncio.wait_for(task,1)
                events=tab.listen_for_message()
                assert (await anext(events))['method']=='Page.domContentEventFired'
                assert (await anext(events))['method']=='Runtime.executionContextCreated'
                await events.aclose();assert tab._pending_messages==[]
            else:
                before=asyncio.get_running_loop().time()
                try:await asyncio.wait_for(task,3.6);raise AssertionError('invalid acknowledgement accepted')
                except (ConnectionError,asyncio.TimeoutError):pass
                if case=='timeout':assert 2.8<=asyncio.get_running_loop().time()-before<3.5
                if case=='flood':assert len(tab._pending_messages)==256
        finally:
            await tab.close_websocket();assert tab.client.closed
            await runner.cleanup()
        print('PASS frozen Page.enable',case,exe.parent.name)

source=(ROOT/'source/decky-loader/tests/test_reinjector_recovery.py').read_text(encoding='utf-8')
needle='exec(compile(ast.Module(body=[method()], type_ignores=[]), "main.py", "exec"), namespace)'
assert needle in source
source=source.replace(needle,'namespace["loader_reinjector"] = types.FunctionType(FROZEN_METHOD, namespace)')
for mode,subsystem in [('console',3),('noconsole',2)]:
    exe=ROOT/'out'/mode/'PluginLoader.exe';_,method=modules(exe,subsystem)
    namespace={'__name__':'frozen_recovery_fixture','__file__':str(ROOT/'source/decky-loader/tests/test_reinjector_recovery.py'),'FROZEN_METHOD':method}
    exec(compile(source,'frozen_recovery_fixture','exec'),namespace)
    result=unittest.TextTestRunner(verbosity=1).run(unittest.defaultTestLoader.loadTestsFromTestCase(namespace['ReinjectorTests']))
    assert result.wasSuccessful(),mode
    asyncio.run(loopback(exe,subsystem))
    asyncio.run(loopback(exe,subsystem,True))
    asyncio.run(ack_cases(exe,subsystem))
print('30/30 frozen-bytecode fault/loopback checks passed; GUI/CUI and Python314 payload verified. No loader process launched.')
