import { u as useTranslation, G as FaFlask, R as setSetting, c as FaDownload, U as FaInfo, V as UpdateBranch } from './chunk-BRlI6dAn.js';
import { J as SteamSpinner, h as DialogBody, A as ProgressBar, i as DialogControlsSection, F as Field, q as Focusable, D as DialogButton, N as Navigation } from './chunk-sIGTtP5a.js';
import { N as NavEntryPositionPreferences } from './chunk-C7f0gL0I.js';
import './chunk-St9casVY.js';
import './chunk-CFxgpTYP.js';
import './chunk-DxhJXJ98.js';

const getTestingVersions = DeckyBackend.callable('updater/get_testing_versions');
const downloadTestingVersion = DeckyBackend.callable('updater/download_testing_version');
function TestingVersionList() {
    const { t } = useTranslation();
    const [testingVersions, setTestingVersions] = SP_REACT.useState([]);
    const [loading, setLoading] = SP_REACT.useState(true);
    const [updateProgress, setUpdateProgress] = SP_REACT.useState(null);
    const [reloading, setReloading] = SP_REACT.useState(false);
    SP_REACT.useEffect(() => {
        (async () => {
            setTestingVersions(await getTestingVersions());
            setLoading(false);
        })();
    }, []);
    SP_REACT.useEffect(() => {
        const a = DeckyBackend.addEventListener('updater/update_download_percentage', (percentage) => {
            setUpdateProgress(percentage);
        });
        const b = DeckyBackend.addEventListener('updater/finish_download', () => {
            setReloading(true);
        });
        return () => {
            DeckyBackend.removeEventListener('updater/update_download_percentage', a);
            DeckyBackend.removeEventListener('updater/finish_download', b);
        };
    }, []);
    if (loading) {
        return (SP_JSX.jsx(SP_JSX.Fragment, { children: SP_JSX.jsx(SteamSpinner, { background: "transparent", children: t('Testing.loading') }) }));
    }
    if (testingVersions.length === 0) {
        return (SP_JSX.jsx(DialogBody, { children: SP_JSX.jsx("p", { children: "No open PRs found" }) }));
    }
    return (SP_JSX.jsxs(DialogBody, { children: [updateProgress !== null && SP_JSX.jsx(ProgressBar, { nProgress: updateProgress, indeterminate: reloading }), SP_JSX.jsxs(DialogControlsSection, { children: [SP_JSX.jsx("h4", { children: t('Testing.header') }), SP_JSX.jsx("ul", { style: { listStyleType: 'none', padding: '0' }, children: testingVersions.map((version) => {
                            return (SP_JSX.jsx("li", { children: SP_JSX.jsx(Field, { label: SP_JSX.jsxs(SP_JSX.Fragment, { children: [version.name, ' ', SP_JSX.jsx("span", { style: { opacity: '50%', whiteSpace: 'nowrap', marginLeft: 'auto', alignSelf: 'center' }, children: '#' + version.id })] }), children: SP_JSX.jsxs(Focusable, { style: { height: '40px', marginLeft: 'auto', display: 'flex' }, navEntryPreferPosition: NavEntryPositionPreferences.MAINTAIN_X, children: [SP_JSX.jsx(DialogButton, { style: { height: '40px', minWidth: '60px', marginRight: '10px' }, onClick: async () => {
                                                    const downloadToast = DeckyPluginLoader.toaster.toast({
                                                        title: t('Testing.start_download_toast', { id: version.id }),
                                                        body: null,
                                                        icon: SP_JSX.jsx(FaFlask, {}),
                                                    });
                                                    try {
                                                        await downloadTestingVersion(version.id, version.head_sha);
                                                        downloadToast.dismiss();
                                                    }
                                                    catch (e) {
                                                        if (e instanceof Error) {
                                                            DeckyPluginLoader.toaster.toast({
                                                                title: t('Testing.error'),
                                                                body: `${e.name}: ${e.message}`,
                                                                icon: SP_JSX.jsx(FaFlask, {}),
                                                            });
                                                        }
                                                    }
                                                    setSetting('branch', UpdateBranch.Testing);
                                                }, children: SP_JSX.jsxs("div", { style: {
                                                        display: 'flex',
                                                        minWidth: '150px',
                                                        justifyContent: 'space-between',
                                                        alignItems: 'center',
                                                    }, children: [t('Testing.download'), SP_JSX.jsx(FaDownload, { style: { paddingLeft: '1rem' } })] }) }), SP_JSX.jsx(DialogButton, { style: {
                                                    height: '40px',
                                                    width: '40px',
                                                    padding: '10px 12px',
                                                    minWidth: '40px',
                                                    display: 'flex',
                                                    flexDirection: 'column',
                                                    justifyContent: 'center',
                                                }, onClick: () => Navigation.NavigateToExternalWeb(version.link), children: SP_JSX.jsx(FaInfo, {}) })] }) }) }, `${version.id}_${version.name}`));
                        }) })] })] }));
}

export { TestingVersionList as default };
//# sourceMappingURL=chunk-DkB-DI94.js.map
