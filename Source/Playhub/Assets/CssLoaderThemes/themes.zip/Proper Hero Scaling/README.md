# Proper Hero Scaling v2.1 — Playhub alignment

Modifica basata su Proper Hero Scaling di **SoyGonDo**.

Con le impostazioni correnti di Art Hero (`Wide Hero`, `Cover`, `Top`, altezza hero `0 + 0`) la hero Home è alta esattamente `50vh`.
Questa versione imposta sia Home sia pagina dettagli gioco alla stessa geometria:

- altezza: `50vh`;
- larghezza: `100vw`;
- ritaglio: `cover`;
- ancoraggio: `top center`;
- nessun margine o limite interno differente.

In questo modo la stessa immagine passa da Home a dettagli senza cambiare altezza o punto di ritaglio.
