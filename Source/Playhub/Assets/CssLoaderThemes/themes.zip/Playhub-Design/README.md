# Playhub Design v1.4.0

This streamlined build removes every custom animation, navigation transition, position slider and size slider.

The only setting is **Home Hero Gradient Opacity**, available as a dropdown from 0% to 100% in 10% increments.
