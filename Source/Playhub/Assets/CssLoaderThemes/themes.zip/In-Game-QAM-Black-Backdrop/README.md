# In-Game QAM Black Backdrop v1.0.1

Tema CSSLoader di LoZazaMastro.

- Applica una base nera dietro il Quick Access Menu solo durante una partita.
- Usa il vero stato `HeaderAndFooterVisible` del QAM in-game.
- Non modifica il menu Steam dell'overlay.
- Non modifica il QAM fuori dal gioco.
- Mantiene sopra il nero colori e trasparenze impostati da Obsidian o altri temi.
