"""CSS readiness adapter for CSS Loader's existing Runtime.evaluate transaction.

No filesystem writes, network, timers, theme settings or Steam process access.
The native consumer is responsible for verifying the current main Steam browser.
"""
import json
from pathlib import Path

_SCRIPT = Path(__file__).with_name('theme-readiness.mjs').read_text(encoding='utf-8').replace('export function ', 'function ')


def transaction_script(generation, adds, removes, expected, complete, remove_all=False):
    if len(generation) != 34 or not generation.startswith('g-') or any(c not in '0123456789abcdef' for c in generation[2:]):
        raise ValueError('Invalid readiness generation')
    if len(expected) > 2048 or len(adds) > 2048 or len(removes) > 2048:
        raise ValueError('Theme target inventory is too large')
    payload = {'generation': generation,
               'add': [{'id': key, 'css': value} for key, value in adds.items()],
               'remove': list(removes),
               'expected': [{'id': key, 'css': value} for key, value in expected.items()],
               'complete': bool(complete), 'removeAll': bool(remove_all)}
    return '(()=>{' + _SCRIPT + '\nreturn applyCssTransaction(window,document,' + json.dumps(payload, ensure_ascii=True) + ');})()'


def invalidate_script(generation):
    return '(()=>{' + _SCRIPT + '\nconst gate=createThemeReadiness(window,document);return {success:!gate||!!gate.begin(' + json.dumps(generation) + ')};})()'


def clear_script(generation):
    return ('(()=>{' + _SCRIPT + '\nconst gate=createThemeReadiness(window,document);'
            + 'const begun=gate?.begin(' + json.dumps(generation) + ');'
            + "document.querySelectorAll('style.css-loader-style').forEach(x=>x.remove());"
            + 'return {success:!gate||!!begun};})()')
