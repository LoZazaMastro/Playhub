# Playhub CSS Loader compatibility

Based on DeckThemes/SDH-CssLoader under its original GPL license.

## 2.1.5

- Confirm the complete theme stylesheet batch in the current Steam document before the managed startup curtain clears.
- Invalidate old document receipts during theme reloads and recover after a successful reload.
- Preserve immediate first connection and bounded reconnect backoff from 2.1.4.

A resolved-style receipt confirms the CSSOM state. It does not claim that an occluded Steam window has already presented a frame. The native curtain checks the exact current main Steam document and native foreground window, and closes on cancellation or deadline.

## Build and checks

The preferred source archive includes the complete frontend source, package lock and Python backend. Rebuild the frontend using the repository package manager and original scripts. This change adds backend/document readiness; the existing frontend bundle is unchanged.

Python tests: `python -B -X utf8 -m unittest discover -s tests -p "test_*.py"` (aiohttp required by the existing connection fixtures).
Document tests: `node tests/document/run-document-fixture.mjs` with Chrome installed on Windows. The fixture starts its own headless browser and loopback HTTP server, never an installed Steam debugging endpoint.
