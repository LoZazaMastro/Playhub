// Install in the Steam document through CSS Loader.
// Native caller must bind the receipt to the verified current main browser/document.
export function isSteamUiDocument(view, doc) {
  try {
    if (view.document !== doc || view.top !== view || !doc.documentElement || !doc.head) return false;
    const url = new URL(doc.URL);
    const loopback = ['http:', 'https:'].includes(url.protocol) && url.hostname === 'steamloopback.host'
      && !url.username && !url.password;
    const internalPopup = url.protocol === 'about:' && url.pathname === 'blank'
      && url.searchParams.has('createflags') && !url.searchParams.has('browserviewpopup');
    const id = view.SteamClient?.Browser?.GetBrowserID?.();
    return (loopback || internalPopup) && Number.isSafeInteger(id) && id > 0;
  } catch { return false; }
}

export function createThemeReadiness(view, doc) {
  const key = '__playhubThemeReadinessV1';
  if (!isSteamUiDocument(view, doc)) return null;
  if (view[key]?.ownerDocument === doc && view[key].ownerRoot === doc.documentElement
    && view[key].ownerHead === doc.head) return view[key];
  const root = doc.documentElement, head = doc.head;
  const documentId = Array.from(view.crypto.getRandomValues(new Uint8Array(16)), x => x.toString(16).padStart(2,'0')).join('');
  let serial = 0, generation = '', expected = [], sentinel = null, frameCount = 0;
  let resolvedAt = null, failed = false;
  const connected = () => view.document === doc && doc.documentElement === root && doc.head === head
    && root.isConnected && head.isConnected && isSteamUiDocument(view, doc);
  const validStyles = () => expected.every(item => item.node.isConnected && item.node.ownerDocument === doc
    && item.node.tagName === 'STYLE' && item.node.classList.contains('css-loader-style')
    && item.node.id === item.id && item.node.textContent === item.css && item.node.sheet
    && item.node.sheet.ownerNode === item.node && item.node.sheet.disabled === false);
  const applied = () => !failed && resolvedAt !== null && connected() && validStyles()
    && sentinel?.isConnected && sentinel.ownerDocument === doc && sentinel.sheet?.ownerNode === sentinel
    && view.getComputedStyle(root).getPropertyValue('--playhub-css-generation').trim() === generation;
  const read = () => ({ protocol: 1, documentId, generation, serial,
    browserId: view.SteamClient?.Browser?.GetBrowserID?.() ?? 0,
    href: doc.URL, styles: expected.length,
    state: applied() ? 'applied' : failed ? 'failed' : 'loading',
    proof: applied() ? frameCount === 2 ? 'frame-confirmed' : 'style-resolved' : null,
    appliedAt: resolvedAt, frames: frameCount });
  const begin = nextGeneration => {
    if (!connected() || !/^g-[a-f0-9]{32}$/.test(nextGeneration)) return false;
    serial++; generation = nextGeneration; expected = []; frameCount = 0; resolvedAt = null; failed = false;
    sentinel?.remove(); sentinel = null;
    return serial;
  };
  const complete = (expectedSerial, styles, batchSucceeded) => {
    if (expectedSerial !== serial || !connected()) return false;
    if (!batchSucceeded || !Array.isArray(styles) || styles.length > 2048
      || new Set(styles.map(item => item.id)).size !== styles.length) { failed = true; return false; }
    expected = styles.map(item => ({ id: item.id, css: item.css, node: doc.getElementById(item.id) }));
    if (expected.some(item => typeof item.id !== 'string' || typeof item.css !== 'string' || !item.node)
      || !validStyles()) { failed = true; return false; }
    sentinel = doc.createElement('style');
    sentinel.id = 'playhub-css-readiness-sentinel';
    sentinel.textContent = ':root { --playhub-css-generation: ' + generation + ' !important; }';
    head.append(sentinel);
    // getComputedStyle forces the browser to resolve the complete style batch.
    // Native splash may fully occlude Steam: never wait indefinitely for RAF.
    if (view.getComputedStyle(root).getPropertyValue('--playhub-css-generation').trim() !== generation) {
      failed = true; return false;
    }
    resolvedAt = view.performance.now();
    const receiptSerial = serial;
    view.requestAnimationFrame(() => {
      if (receiptSerial !== serial || !applied()) return;
      frameCount = 1;
      view.requestAnimationFrame(() => { if (receiptSerial === serial && applied()) frameCount = 2; });
    });
    return applied();
  };
  const gate = { ownerDocument: doc, ownerRoot: root, ownerHead: head, begin, complete, read };
  Object.defineProperty(view, key, { value: gate, configurable: true });
  return gate;
}

// CSS Loader calls this once with the complete expected current target inventory.
// Existing style IDs outside CSS Loader's ownership are not overwritten or removed.
export function applyCssTransaction(view, doc, data) {
  if (!data || !Array.isArray(data.add) || !Array.isArray(data.remove) || !Array.isArray(data.expected))
    return {success:false};
  const gate = createThemeReadiness(view, doc);
  const serial = gate?.begin(data.generation);
  const owned = node => node?.ownerDocument === doc && node.tagName === 'STYLE'
    && node.classList.contains('css-loader-style');
  const fail = () => { if (serial) gate.complete(serial,[],false); return {success:false}; };
  if (data.add.length > 2048 || data.expected.length > 2048 || data.remove.length > 2048) return fail();
  for (const item of data.add) {
    if (typeof item.id !== 'string' || typeof item.css !== 'string') return fail();
    const prior = doc.getElementById(item.id); if (prior && !owned(prior)) return fail();
  }
  for (const id of data.remove) {
    const prior=doc.getElementById(id); if (prior && !owned(prior)) return fail();
  }
  if (data.removeAll) doc.querySelectorAll('style.css-loader-style').forEach(node => node.remove());
  for (const item of data.add) {
    let node=doc.getElementById(item.id);
    if (!node) { node=doc.createElement('style');node.id=item.id;node.classList.add('css-loader-style');doc.head.append(node); }
    node.textContent=item.css;
  }
  for (const id of data.remove) doc.getElementById(id)?.remove();
  const applied = serial ? gate.complete(serial,data.expected,data.complete === true) : null;
  // Popup targets still receive CSS; only the exact main document is consumed by native cover.
  return {success:true, applied, readiness:gate?.read() ?? null};
}
