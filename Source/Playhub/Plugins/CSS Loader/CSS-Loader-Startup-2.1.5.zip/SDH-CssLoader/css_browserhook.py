import os, re, uuid, asyncio, json, aiohttp, time
from typing import List
from css_utils import get_theme_path, Log, Result, PLATFORM_WIN
import css_inject
from css_readiness import transaction_script, invalidate_script, clear_script

MAX_QUEUE_SIZE = 500
SUPPORTED_POPUP_TITLE = re.compile(r"^(MainMenu|QuickAccess|notificationtoasts)(?:_uid\d+)?$")

class BrowserTabHook:
    def __init__(self, browserHook, sessionId : str, targetInfo : dict):
        self.id = targetInfo["targetId"]
        self.type = targetInfo["type"]
        self.title = targetInfo["title"]
        self.url = targetInfo["url"]
        self.sessionId = sessionId
        self.hook = browserHook
        self.applied_css = {}
        self._commit_gate = asyncio.Lock()
        self.pending_add = {}
        self.pending_remove = []
        self.init_done = False
        self.html_classes = []
        asyncio.create_task(self._init())

    async def _init(self):
        res = await self.evaluate_js("(function(){ return {\"title\": document.title, \"classes\": Array.from(document.documentElement.classList).concat(Array.from(document.body.classList)).concat(Array.from(document.head.classList))} })()")

        if res != None:
            self.title = res["title"]
            self.html_classes = res["classes"]
        else:
            Log(f"Failed to connect to tab with id {self.id}")
            self.hook.mark_target_failed(self.id, self.title, self.url)
            if self in self.hook.connected_tabs:
                self.hook.connected_tabs.remove(self)
            return

        self.hook.mark_target_ready(self.id)
        self.init_done = True
        Log(f"Connected to tab: {self.title}")
        await self.health_check()

    async def evaluate_js(self, js, run_async=False, get_result=True):
        try:
            res = await self.hook.send_command("Runtime.evaluate", {
                "expression": js,
                "userGesture": True,
                "awaitPromise": run_async,
                "returnByValue": True,
                }, self.sessionId, get_result)

            if "result" in res and "result" in res["result"]:
                if "value" in res["result"]["result"]:
                    res = res["result"]["result"]["value"]
                elif "type" in res["result"]["result"] and res["result"]["result"]["type"] == "undefined":
                    res = "Undefined"
                else:
                    res = None
            else:
                res = None

        except:
            res = None
            pass

        return res

    async def has_element(self, element_name):
        res = await self.evaluate_js(f"document.getElementById('{element_name}') != null")

        return res if res != None else False

    def compare(self, tab_name : str) -> bool:
        if tab_name.startswith("~") and tab_name.endswith("~") and len(tab_name) > 2:
            if tab_name[1:-1] in self.url:
                return True
        elif tab_name.startswith("!"):
            if tab_name[1:] in self.html_classes:
                return True
        elif re.match(f"^({tab_name})$", self.title):
            return True

        return False

    async def force_reinject(self) -> Result:
        for inject in css_inject.ALL_INJECTS:
            if inject.enabled:
                for x in inject.tabs:
                    if self.compare(x):
                        await inject.inject_with_tab(self)
                        break

        await self.commit_css_transaction(remove_all_first=True)

    async def health_check(self) -> Result:
        if not self.init_done:
            return Result(True)

        try:
            if not await self.has_element("test_css_loaded"):
                await self.evaluate_js(
                    f"""
                    (function() {{
                        const elem = document.createElement('div');
                        elem.id = "test_css_loaded";
                        document.head.append(elem);
                    }})()
                    """)

                if not await self.has_element("test_css_loaded"):
                    raise Exception("a variable was injected but cannot be found when retrieved")

                await self.force_reinject()

        except Exception as e:
            return Result(False, str(e))

        return Result(True)

    async def inject_css(self, css : str, id : str = None) -> Result:
        if id == None:
            id = str(uuid.uuid4())

        self.pending_add[id] = css
        return Result(True, id)

    async def remove_css(self, css_id : str) -> Result:
        if css_id in self.pending_add:
            del self.pending_add[css_id]
        else:
            self.pending_remove.append(css_id)

        return Result(True)

    async def commit_css_transaction(self, retry : int = 3, remove_all_first : bool = False) -> Result:
        async with self._commit_gate:
            pending_add, pending_remove = self.pending_add, self.pending_remove
            self.pending_add, self.pending_remove = {}, []
            expected = {} if remove_all_first else dict(self.applied_css)
            expected.update(pending_add)
            for identity in pending_remove:
                expected.pop(identity, None)
            generation = "g-" + uuid.uuid4().hex
            script = transaction_script(generation, pending_add, pending_remove, expected,
                                        self.hook.startup_batch_ok, remove_all_first)
            for attempt in range(retry):
                response = await self.evaluate_js(script)
                if isinstance(response, dict) and response.get("success") is True:
                    self.applied_css = expected
                    return Result(True)
                if attempt + 1 < retry:
                    await asyncio.sleep(0.2)
            # Preserve pending intent so a later complete reinjection can recover.
            self.pending_add = {**pending_add, **self.pending_add}
            self.pending_remove = pending_remove + self.pending_remove
            return Result(False, "Css Commit Retry Count Exceeded")

    async def invalidate_readiness(self):
        async with self._commit_gate:
            return await self.evaluate_js(invalidate_script('g-' + uuid.uuid4().hex))

    async def remove_all_css(self, retry : int = 3) -> Result:
        async with self._commit_gate:
            self.pending_add = {}
            self.pending_remove = []
            generation = 'g-' + uuid.uuid4().hex
            # Invalidate before removing even the last active theme.
            script = clear_script(generation)
            for attempt in range(retry):
                response = await self.evaluate_js(script)
                if isinstance(response, dict) and response.get('success') is True:
                    self.applied_css = {}
                    return Result(True)
                if attempt + 1 < retry:
                    await asyncio.sleep(0.2)
            return Result(False, 'CSS removal did not complete')

class BrowserHook:
    def __init__(self, startup_batch_ok=True):
        self.startup_batch_ok = startup_batch_ok
        Log("Initializing hook")
        self.client = None
        self.websocket = None
        self.current_id = 0
        self.ws_url = None
        self.ws_response : List[asyncio.Queue] = []
        self.connected_tabs : List[BrowserTabHook] = []
        self.pending_targets = {}
        self.failed_targets = {}

        asyncio.create_task(self.on_new_tab())
        asyncio.create_task(self.on_tab_update())
        asyncio.create_task(self.on_tab_attach())
        asyncio.create_task(self.on_tab_detach())
        asyncio.create_task(self.health_check())
        asyncio.create_task(self.css_health_check())
        asyncio.create_task(self.sanity_check_tabs())

    def get_id(self) -> int:
        self.current_id += 1
        return self.current_id

    def is_supported_target(self, target_info : dict) -> bool:
        if target_info.get("type") != "page":
            return False

        title = target_info.get("title", "")
        url = target_info.get("url", "")
        if url.startswith("https://steamloopback.host/") or url.startswith("http://steamloopback.host/"):
            return True
        if url.startswith("about:blank?createflags="):
            return True

        return url.startswith("about:blank?browserviewpopup=1") and SUPPORTED_POPUP_TITLE.match(title) != None

    def can_attach_target(self, target_id : str) -> bool:
        now = time.monotonic()
        pending_until = self.pending_targets.get(target_id)
        if pending_until != None:
            if pending_until > now:
                return False
            del self.pending_targets[target_id]

        return target_id not in self.failed_targets

    def mark_target_failed(self, target_id : str, title : str, url : str):
        self.pending_targets.pop(target_id, None)
        self.failed_targets[target_id] = (title, url)
        Log(f"Target {target_id} quarantined after initialization failure")

    def mark_target_ready(self, target_id : str):
        self.pending_targets.pop(target_id, None)
        self.failed_targets.pop(target_id, None)

    async def attach_target(self, target_info : dict):
        target_id = target_info.get("targetId", "")
        if not target_id or not self.is_supported_target(target_info) or not self.can_attach_target(target_id):
            return

        self.pending_targets[target_id] = time.monotonic() + 10
        try:
            await self.send_command("Target.attachToTarget", {"targetId": target_id, "flatten": True}, None, False)
        except:
            self.pending_targets.pop(target_id, None)
            raise

    async def open_websocket(self):
        self.client = aiohttp.ClientSession()
        self.websocket = await self.client.ws_connect(self.ws_url)

    async def close_websocket(self):
        self.connected_tabs.clear()
        self.pending_targets.clear()
        websocket, client = self.websocket, self.client
        self.websocket = None
        self.client = None
        try:
            if websocket is not None:
                await websocket.close()
        finally:
            if client is not None:
                await client.close()

    def is_connected(self) -> bool:
        return self.websocket != None and not self.websocket.closed

    async def send_command(self, method : str, params : dict, sessionId : str|None, await_response : bool = True):
        if not self.is_connected():
            raise RuntimeError("Websocket not opened")
        request_id = self.get_id()
        data = {"id": request_id, "method": method, "params": params}
        if sessionId is not None:
            data["sessionId"] = sessionId
        queue = asyncio.Queue(maxsize=MAX_QUEUE_SIZE) if await_response else None
        if queue is not None:
            self.ws_response.append(queue)
        try:
            await self.websocket.send_json(data)
            if queue is None:
                return None
            deadline = time.monotonic() + 5
            while True:
                remaining = deadline - time.monotonic()
                if remaining <= 0:
                    raise asyncio.TimeoutError()
                result = await asyncio.wait_for(queue.get(), remaining)
                if result.get("id") == request_id:
                    return result
        except asyncio.TimeoutError:
            Result(False, f"Request for {method} timed out")
            return None
        finally:
            if queue is not None and queue in self.ws_response:
                self.ws_response.remove(queue)

    async def _tab_exists(self, tab_id : str):
        result = await self.send_command("Target.getTargets", {}, None)
        if result == None:
            return False
        return tab_id in [x["targetId"] for x in result["result"]["targetInfos"] if self.is_supported_target(x)]

    async def on_new_tab(self):
        queue = asyncio.Queue(maxsize=MAX_QUEUE_SIZE)
        self.ws_response.append(queue)

        while True:
            message = await queue.get()

            if "method" in message and message["method"] == "Target.targetCreated":
                target_info = message["params"]["targetInfo"]
                if not self.is_supported_target(target_info):
                    continue

                if not await self._tab_exists(target_info["targetId"]):
                    continue

                await self.attach_target(target_info)

    async def on_tab_update(self):
        queue = asyncio.Queue(maxsize=MAX_QUEUE_SIZE)
        self.ws_response.append(queue)

        while True:
            message = await queue.get()

            if "method" in message and message["method"] == "Target.targetInfoChanged":
                target_info = message["params"]["targetInfo"]
                target_id = target_info["targetId"]

                if not self.is_supported_target(target_info) or not await self._tab_exists(target_id):
                    continue

                failed_info = self.failed_targets.get(target_id)
                if failed_info != None and failed_info != (target_info.get("title", ""), target_info.get("url", "")):
                    self.failed_targets.pop(target_id, None)
                    await self.attach_target(target_info)

                for connected_tab in self.connected_tabs:
                    if target_info["targetId"] == connected_tab.id:
                        reinject = False

                        if (target_info["title"] != connected_tab.title):
                            connected_tab.title = target_info["title"]
                            reinject = True

                        if (target_info["url"] != connected_tab.url):
                            connected_tab.url = target_info["url"]
                            reinject = True

                        if reinject:
                            asyncio.create_task(connected_tab.force_reinject())

                        found = True
                        break

    async def on_tab_attach(self):
        queue = asyncio.Queue(maxsize=MAX_QUEUE_SIZE)
        self.ws_response.append(queue)

        while True:
            message = await queue.get()

            if "method" in message and message["method"] == "Target.attachedToTarget":
                target_info = message["params"]["targetInfo"]
                target_id = target_info["targetId"]
                self.pending_targets.pop(target_id, None)
                if not self.is_supported_target(target_info):
                    await self.send_command("Target.detachFromTarget", {"sessionId": message["params"]["sessionId"]}, None, False)
                    continue
                if target_id in [x.id for x in self.connected_tabs]:
                    continue
                self.connected_tabs.append(BrowserTabHook(self, message["params"]["sessionId"], target_info))

    async def on_tab_detach(self):
        queue = asyncio.Queue(maxsize=MAX_QUEUE_SIZE)
        self.ws_response.append(queue)

        while True:
            message = await queue.get()

            if "method" in message and message["method"] == "Target.detachedFromTarget":
                targetId = message["params"]["targetId"]

                tab = None

                for x in self.connected_tabs:
                    if x.id == targetId:
                        tab = x
                        break

                if tab != None:
                    Log(f"Disconnected from tab: {tab.title}")
                    self.connected_tabs.remove(tab)

    async def sanity_check_tabs(self):
        while True:
            try:
                result = await self.send_command("Target.getTargets", {}, None, True)
                if result == None:
                    await asyncio.sleep(5)
                    continue
                target_infos = result["result"]["targetInfos"]
                all_target_ids = [x["targetId"] for x in target_infos]
                for target_id in list(self.failed_targets):
                    if target_id not in all_target_ids:
                        del self.failed_targets[target_id]

                supported_targets = [x for x in target_infos if self.is_supported_target(x)]
                target_ids = [x["targetId"] for x in supported_targets]
                for x in list(self.connected_tabs): # Remove tabs that are no longer connected
                    if x.id not in target_ids:
                        Log(f"Disconnected from tab: {x.title}")
                        self.connected_tabs.remove(x)

                connected_ids = [x.id for x in self.connected_tabs]
                for x in supported_targets:
                    if x["targetId"] not in connected_ids: # Attach tabs that are not connected
                        await self.attach_target(x)
                    else:
                        for connected_tab in self.connected_tabs: # Update info on tabs that are connected
                            if connected_tab.id == x["targetId"]:
                                reinject = False
                                if (x["title"] != connected_tab.title):
                                    connected_tab.title = x["title"]
                                    reinject = True

                                if (x["url"] != connected_tab.url):
                                    connected_tab.url = x["url"]
                                    reinject = True

                                if reinject:
                                    asyncio.create_task(connected_tab.force_reinject())

                                break
            except:
                pass

            await asyncio.sleep(5)

    async def css_health_check(self):
        while True:
            for tab in self.connected_tabs:
                try:
                    await tab.health_check()
                except Exception as e:
                    Result(False, f"[Health Check on {tab.title}] {str(e)}")

            await asyncio.sleep(3)

    async def health_check(self):
        delay = 0.0
        while True:
            if delay:
                await asyncio.sleep(delay)
            try:
                # Steam's debugger is local: bypass environment proxies and
                # do not let a redirect replace its browser endpoint.
                async with aiohttp.ClientSession(trust_env=False) as web:
                    async with web.get("http://127.0.0.1:8080/json/version", timeout=3,
                                       allow_redirects=False) as response:
                        if response.status != 200:
                            raise RuntimeError(f"/json/version returned {response.status}")
                        data = await response.json()
                self.ws_url = data["webSocketDebuggerUrl"]
                await asyncio.wait_for(self.open_websocket(), 3)
                delay = 0.25
                Log("Connected to Steam Browser")
                await self.send_command("Target.setDiscoverTargets", {"discover": True}, None, False)
                async for message in self.websocket:
                    data = message.json()
                    for queue in list(self.ws_response):
                        if not queue.full():
                            queue.put_nowait(data)
            except asyncio.CancelledError:
                raise
            except Exception as error:
                Result(False, f"[Health Check] {error}")
                delay = min(3.0, delay * 2 if delay else 0.25)
            finally:
                try:
                    await self.close_websocket()
                except Exception:
                    pass


HOOK : BrowserHook = None

async def initialize(startup_batch_ok=True):
    global HOOK
    HOOK = BrowserHook(startup_batch_ok)

def get_tabs(tab_name : str) -> List[BrowserTabHook]:
    tabs = []

    for tab in HOOK.connected_tabs:
        if tab.compare(tab_name):
            tabs.append(tab)

    #if tabs == []:
    #    Log(f"[Warn] get_tabs({tab_name}) returned []. All tabs: {str([x.title for x in HOOK.connected_tabs])}")

    return tabs

async def inject(tab_name : str, css : str) -> Result:
    id = str(uuid.uuid4())
    for tab in get_tabs(tab_name):
        await tab.inject_css(css, id)

    return Result(True, id)

async def remove(tab_name : str, css_id : str) -> Result:
    for tab in get_tabs(tab_name):
        await tab.remove_css(css_id)

    return Result(True)

async def commit_all(remove_all_first : bool = False):
    await asyncio.gather(*[x.commit_css_transaction(remove_all_first=remove_all_first) for x in HOOK.connected_tabs])

async def remove_all():
    await asyncio.gather(*[x.remove_all_css() for x in HOOK.connected_tabs])

async def begin_theme_load():
    if HOOK is None:
        return
    HOOK.startup_batch_ok = False
    await asyncio.gather(*[tab.invalidate_readiness() for tab in HOOK.connected_tabs])


def finish_theme_load(success):
    if HOOK is not None:
        HOOK.startup_batch_ok = bool(success)
