using System;
using System.IO;
using System.Runtime.InteropServices;
using System.Threading;
using System.Windows.Threading;

public sealed class PlayhubVolumeEvents : IDisposable
{
    private readonly Dispatcher _dispatcher;
    private readonly FileSystemWatcher _settings;
    private readonly DispatcherTimer _settingsDelay;
    private IMMDeviceEnumerator _enumerator;
    private IMMDevice _endpoint;
    private IAudioEndpointVolume _volume;
    private VolumeCallback _volumeCallback;
    private readonly DeviceCallback _deviceCallback;
    private string _endpointId;
    private int _generation;
    private int _refreshPending;
    private int _settingsPending;
    private volatile bool _disposed;

    public event EventHandler VolumeChanged;
    public event EventHandler SettingsChanged;
    public bool Ready { get; private set; }
    public int Level { get; private set; }
    public bool Muted { get; private set; }

    public PlayhubVolumeEvents(Dispatcher dispatcher, string settingsPath)
    {
        _dispatcher = dispatcher;
        _deviceCallback = new DeviceCallback(this);
        _settingsDelay = new DispatcherTimer(DispatcherPriority.Background, dispatcher);
        _settingsDelay.Interval = TimeSpan.FromMilliseconds(120);
        _settingsDelay.Tick += delegate {
            _settingsDelay.Stop();
            if (!_disposed && SettingsChanged != null) SettingsChanged(this, EventArgs.Empty);
        };
        _settings = new FileSystemWatcher(Path.GetDirectoryName(Path.GetFullPath(settingsPath)), Path.GetFileName(settingsPath));
        _settings.NotifyFilter = NotifyFilters.FileName | NotifyFilters.LastWrite | NotifyFilters.Size;
        _settings.Changed += SettingsFileChanged;
        _settings.Created += SettingsFileChanged;
        _settings.Deleted += SettingsFileChanged;
        _settings.Renamed += SettingsFileChanged;
        _settings.Error += delegate { QueueSettings(); };
        _settings.EnableRaisingEvents = true;
        try {
            _enumerator = (IMMDeviceEnumerator)Activator.CreateInstance(Type.GetTypeFromCLSID(new Guid("BCDE0395-E52F-467C-8E3D-C4579291692E"), true));
            Marshal.ThrowExceptionForHR(_enumerator.RegisterEndpointNotificationCallback(_deviceCallback));
            RefreshEndpoint();
        } catch { Ready = false; }
    }

    private void SettingsFileChanged(object sender, FileSystemEventArgs args) { QueueSettings(); }

    private void QueueSettings()
    {
        if (_disposed || Interlocked.Exchange(ref _settingsPending, 1) != 0) return;
        _dispatcher.BeginInvoke(DispatcherPriority.Background, new Action(delegate {
            Interlocked.Exchange(ref _settingsPending, 0);
            if (_disposed) return;
            _settingsDelay.Stop();
            _settingsDelay.Start();
        }));
    }

    private void QueueRefresh()
    {
        if (_disposed || Interlocked.Exchange(ref _refreshPending, 1) != 0) return;
        _dispatcher.BeginInvoke(DispatcherPriority.Background, new Action(delegate {
            Interlocked.Exchange(ref _refreshPending, 0);
            if (_disposed) return;
            RefreshEndpoint();
            if (VolumeChanged != null) VolumeChanged(this, EventArgs.Empty);
        }));
    }

    private void RefreshEndpoint()
    {
        ReleaseEndpoint();
        Ready = false;
        if (_enumerator == null) return;
        try {
            Marshal.ThrowExceptionForHR(_enumerator.GetDefaultAudioEndpoint(0, 1, out _endpoint));
            Marshal.ThrowExceptionForHR(_endpoint.GetId(out _endpointId));
            object activated;
            Guid iid = typeof(IAudioEndpointVolume).GUID;
            Marshal.ThrowExceptionForHR(_endpoint.Activate(ref iid, 0x17, IntPtr.Zero, out activated));
            _volume = (IAudioEndpointVolume)activated;
            _volumeCallback = new VolumeCallback(this, _generation);
            Marshal.ThrowExceptionForHR(_volume.RegisterControlChangeNotify(_volumeCallback));
            float level;
            bool muted;
            Marshal.ThrowExceptionForHR(_volume.GetMasterVolumeLevelScalar(out level));
            Marshal.ThrowExceptionForHR(_volume.GetMute(out muted));
            Level = Percent(level);
            Muted = muted;
            Ready = true;
        } catch { ReleaseEndpoint(); }
    }

    private static int Percent(float scalar) { return (int)Math.Round(Math.Max(0f, Math.Min(1f, scalar)) * 100); }

    private void QueueVolume(int generation, float level, bool muted)
    {
        if (_disposed) return;
        _dispatcher.BeginInvoke(DispatcherPriority.Background, new Action(delegate {
            if (_disposed || generation != _generation) return;
            Level = Percent(level);
            Muted = muted;
            Ready = true;
            if (VolumeChanged != null) VolumeChanged(this, EventArgs.Empty);
        }));
    }

    private void ReleaseEndpoint()
    {
        _generation++;
        if (_volume != null && _volumeCallback != null) {
            try { _volume.UnregisterControlChangeNotify(_volumeCallback); } catch { }
        }
        _volumeCallback = null;
        if (_volume != null && Marshal.IsComObject(_volume)) Marshal.FinalReleaseComObject(_volume);
        if (_endpoint != null && Marshal.IsComObject(_endpoint)) Marshal.FinalReleaseComObject(_endpoint);
        _volume = null;
        _endpoint = null;
        _endpointId = null;
    }

    public void Dispose()
    {
        if (_disposed) return;
        _disposed = true;
        _settings.EnableRaisingEvents = false;
        _settings.Dispose();
        _settingsDelay.Stop();
        if (_enumerator != null) {
            try { _enumerator.UnregisterEndpointNotificationCallback(_deviceCallback); } catch { }
        }
        ReleaseEndpoint();
        if (_enumerator != null && Marshal.IsComObject(_enumerator)) Marshal.FinalReleaseComObject(_enumerator);
        _enumerator = null;
    }

    [ComVisible(true), ClassInterface(ClassInterfaceType.None)]
    public sealed class VolumeCallback : IAudioEndpointVolumeCallback
    {
        private readonly PlayhubVolumeEvents _owner;
        private readonly int _generation;
        public VolumeCallback(PlayhubVolumeEvents owner, int generation) { _owner = owner; _generation = generation; }
        public int OnNotify(IntPtr pointer) {
            try {
                var notification = (AudioVolumeNotification)Marshal.PtrToStructure(pointer, typeof(AudioVolumeNotification));
                _owner.QueueVolume(_generation, notification.Level, notification.Muted);
            } catch { }
            return 0;
        }
    }

    [ComVisible(true), ClassInterface(ClassInterfaceType.None)]
    public sealed class DeviceCallback : IMMNotificationClient
    {
        private readonly PlayhubVolumeEvents _owner;
        public DeviceCallback(PlayhubVolumeEvents owner) { _owner = owner; }
        public int OnDeviceStateChanged(string id, uint state) { if (!_owner.Ready || id == _owner._endpointId) _owner.QueueRefresh(); return 0; }
        public int OnDeviceAdded(string id) { if (!_owner.Ready) _owner.QueueRefresh(); return 0; }
        public int OnDeviceRemoved(string id) { if (id == _owner._endpointId) _owner.QueueRefresh(); return 0; }
        public int OnDefaultDeviceChanged(int flow, int role, string id) { if (flow == 0 && role == 1) _owner.QueueRefresh(); return 0; }
        public int OnPropertyValueChanged(string id, PropertyKey key) { return 0; }
    }

    [StructLayout(LayoutKind.Sequential)]
    private struct AudioVolumeNotification {
        public Guid Context;
        [MarshalAs(UnmanagedType.Bool)] public bool Muted;
        public float Level;
        public uint Channels;
    }
    [StructLayout(LayoutKind.Sequential)]
    public struct PropertyKey { public Guid Format; public uint Id; }

    [ComVisible(true), Guid("657804FA-D6AD-4496-8A60-352752AF4F89"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    public interface IAudioEndpointVolumeCallback { [PreserveSig] int OnNotify(IntPtr notification); }

    [ComVisible(true), Guid("7991EEC9-7E89-4D85-8390-6C703CEC60C0"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    public interface IMMNotificationClient {
        [PreserveSig] int OnDeviceStateChanged([MarshalAs(UnmanagedType.LPWStr)] string id, uint state);
        [PreserveSig] int OnDeviceAdded([MarshalAs(UnmanagedType.LPWStr)] string id);
        [PreserveSig] int OnDeviceRemoved([MarshalAs(UnmanagedType.LPWStr)] string id);
        [PreserveSig] int OnDefaultDeviceChanged(int flow, int role, [MarshalAs(UnmanagedType.LPWStr)] string id);
        [PreserveSig] int OnPropertyValueChanged([MarshalAs(UnmanagedType.LPWStr)] string id, PropertyKey key);
    }
    [ComImport, Guid("A95664D2-9614-4F35-A746-DE8DB63617E6"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    private interface IMMDeviceEnumerator {
        [PreserveSig] int EnumAudioEndpoints(int flow, uint state, out object devices);
        [PreserveSig] int GetDefaultAudioEndpoint(int flow, int role, out IMMDevice endpoint);
        [PreserveSig] int GetDevice([MarshalAs(UnmanagedType.LPWStr)] string id, out IMMDevice device);
        [PreserveSig] int RegisterEndpointNotificationCallback(IMMNotificationClient client);
        [PreserveSig] int UnregisterEndpointNotificationCallback(IMMNotificationClient client);
    }
    [ComImport, Guid("D666063F-1587-4E43-81F1-B948E807363F"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    private interface IMMDevice {
        [PreserveSig] int Activate(ref Guid iid, uint context, IntPtr activation, [MarshalAs(UnmanagedType.IUnknown)] out object instance);
        [PreserveSig] int OpenPropertyStore(int access, out object properties);
        [PreserveSig] int GetId([MarshalAs(UnmanagedType.LPWStr)] out string id);
        [PreserveSig] int GetState(out uint state);
    }
    [ComImport, Guid("5CDF2C82-841E-4546-9722-0CF74078229A"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    private interface IAudioEndpointVolume {
        [PreserveSig] int RegisterControlChangeNotify(IAudioEndpointVolumeCallback notify);
        [PreserveSig] int UnregisterControlChangeNotify(IAudioEndpointVolumeCallback notify);
        [PreserveSig] int GetChannelCount(out uint count);
        [PreserveSig] int SetMasterVolumeLevel(float level, ref Guid context);
        [PreserveSig] int SetMasterVolumeLevelScalar(float level, ref Guid context);
        [PreserveSig] int GetMasterVolumeLevel(out float level);
        [PreserveSig] int GetMasterVolumeLevelScalar(out float level);
        [PreserveSig] int SetChannelVolumeLevel(uint channel, float level, ref Guid context);
        [PreserveSig] int SetChannelVolumeLevelScalar(uint channel, float level, ref Guid context);
        [PreserveSig] int GetChannelVolumeLevel(uint channel, out float level);
        [PreserveSig] int GetChannelVolumeLevelScalar(uint channel, out float level);
        [PreserveSig] int SetMute([MarshalAs(UnmanagedType.Bool)] bool mute, ref Guid context);
        [PreserveSig] int GetMute([MarshalAs(UnmanagedType.Bool)] out bool mute);
        [PreserveSig] int GetVolumeStepInfo(out uint step, out uint count);
        [PreserveSig] int VolumeStepUp(ref Guid context);
        [PreserveSig] int VolumeStepDown(ref Guid context);
        [PreserveSig] int QueryHardwareSupport(out uint mask);
        [PreserveSig] int GetVolumeRange(out float min, out float max, out float increment);
    }
}
