from __future__ import annotations

import asyncio
import json
import os
import subprocess
import sys
import tempfile
import time
import hashlib
import mimetypes
import urllib.parse
import urllib.request
import re
import shutil
import base64
from typing import Any, Dict, Optional

import decky

VERSION = "1.3.1"
INTERNAL_BUILD = "volume-events-20261003"
SETTINGS_FILENAME = "playhub-notifications.json"
MAX_QUEUE = 32

DEFAULT_DURATION_MS = 5000

DEFAULT_SETTINGS: Dict[str, Any] = {
    "settings_version": 2,
    "enabled": True,
    "volume_overlay_enabled": True,
    "theme": "xbox",
    "position": "bottom-right",
    # Legacy fallback kept only for migration from 1.0.0 settings.
    "duration_ms": DEFAULT_DURATION_MS,
    "duration_by_kind": {
        "achievement": DEFAULT_DURATION_MS,
        "message": DEFAULT_DURATION_MS,
        "invite": DEFAULT_DURATION_MS,
        "friend": DEFAULT_DURATION_MS,
        "download": DEFAULT_DURATION_MS,
        "screenshot": DEFAULT_DURATION_MS,
        "controller": DEFAULT_DURATION_MS,
        "warning": DEFAULT_DURATION_MS,
        "system": DEFAULT_DURATION_MS,
        "community": DEFAULT_DURATION_MS,
    },
    "sound_volume": 72,
    "visible_kinds": {
        "achievement": True,
        "message": True,
        "invite": True,
        "friend": True,
        "download": True,
        "screenshot": True,
        "controller": True,
        "warning": True,
        "system": True,
        "community": True,
    },
}

THEMES = {"xbox", "playstation", "gog", "epic", "nintendo", "android16", "glass"}
POSITIONS = {"top-left", "top-center", "top-right", "bottom-left", "bottom-center", "bottom-right"}
KINDS = {"achievement", "message", "invite", "friend", "download", "screenshot", "controller", "warning", "system", "community"}

SAMPLES: Dict[str, Dict[str, str]] = {
    "achievement": {"title": "No Stone Unturned", "body": "Achievement unlocked", "subtitle": "Playhub Test Game"},
    "message": {"title": "Alex", "body": "Ready to play?", "subtitle": "Steam message"},
    "invite": {"title": "Game invitation", "body": "Alex invited you to join a game.", "subtitle": "Playhub Test Game"},
    "friend": {"title": "Alex is now playing", "body": "Playhub Test Game", "subtitle": "Friend status"},
    "download": {"title": "Download complete", "body": "Playhub Test Game", "subtitle": ""},
    "screenshot": {"title": "Screenshot saved", "body": "Saved to your Steam screenshots.", "subtitle": "Playhub Test Game"},
    "controller": {"title": "Xbox Wireless Controller connected", "body": "Steam Input", "subtitle": "Controller"},
    "warning": {"title": "Cloud sync conflict", "body": "Choose which save you want to keep.", "subtitle": "Steam"},
    "system": {"title": "System notification", "body": "A Steam system event was received.", "subtitle": "Steam"},
    "community": {"title": "Steam Community", "body": "You have a new community notification.", "subtitle": "Community"},
}


def _is_windows() -> bool:
    return sys.platform.startswith("win")


def _homebrew_root() -> str:
    plugin_dir = os.path.dirname(__file__)
    plugins_dir = os.path.dirname(plugin_dir)
    if os.path.basename(plugins_dir).lower() == "plugins":
        return os.path.dirname(plugins_dir)
    return plugin_dir


def _data_dir() -> str:
    path = os.path.join(_homebrew_root(), "data", "playhub-notifications")
    os.makedirs(path, exist_ok=True)
    return path


def _settings_path() -> str:
    return os.path.join(_data_dir(), SETTINGS_FILENAME)


def _log_path() -> str:
    return os.path.join(_data_dir(), "playhub-notifications.log")


def _image_cache_dir() -> str:
    path = os.path.join(_data_dir(), "image-cache")
    os.makedirs(path, exist_ok=True)
    return path


def _convert_image_for_wpf(path: str, preferred_ext: str = ".png") -> str:
    candidate = str(path or "").strip()
    if not candidate or not os.path.isfile(candidate):
        return candidate
    lower = candidate.lower()
    needs_conversion = lower.endswith(".webp") or lower.endswith(".avif") or lower.endswith(".img")
    if not needs_conversion:
        return candidate
    try:
        from PIL import Image
        target = os.path.splitext(candidate)[0] + preferred_ext
        if os.path.isfile(target) and os.path.getsize(target) > 0:
            return target
        with Image.open(candidate) as image:
            converted = image.convert("RGBA")
            converted.save(target, format="PNG")
        if os.path.isfile(target) and os.path.getsize(target) > 0:
            return target
    except Exception as error:
        _log("WARNING", f"Image conversion failed for {candidate[:180]}: {error}")
    return candidate


def _cache_data_url(value: str) -> str:
    raw = str(value or "").strip()
    if not raw.startswith("data:image/") or ";base64," not in raw:
        return ""
    try:
        header, encoded = raw.split(",", 1)
        mime = header[5:].split(";", 1)[0].lower()
        ext = mimetypes.guess_extension(mime) or ".png"
        payload = base64.b64decode(encoded, validate=False)
        if not payload or len(payload) > 2_500_000:
            return ""
        digest = hashlib.sha1(payload).hexdigest()
        target = os.path.join(_image_cache_dir(), digest + ext)
        if not os.path.exists(target):
            with open(target, "wb") as handle:
                handle.write(payload)
        return _convert_image_for_wpf(target)
    except Exception as error:
        _log("WARNING", f"Embedded image cache failed: {error}")
        return ""


def _download_url_to_file(url: str, target: str) -> bool:
    request = urllib.request.Request(url, headers={
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) PlayhubNotifications/1.0",
        "Accept": "image/avif,image/webp,image/apng,image/svg+xml,image/*,*/*;q=0.8",
    })
    try:
        with urllib.request.urlopen(request, timeout=10) as response:
            body = response.read()
            if not body:
                return False
            with open(target, "wb") as handle:
                handle.write(body)
            return os.path.isfile(target) and os.path.getsize(target) > 0
    except Exception as error:
        _log("WARNING", f"urllib image fetch failed for {url[:180]}: {error}")

    # Windows 10/11 ships curl.exe. It is a useful second network stack when
    # the embedded Python runtime has certificate/proxy issues.
    curl = shutil.which("curl.exe") or shutil.which("curl")
    if curl:
        try:
            result = subprocess.run([
                curl, "-L", "--fail", "--silent", "--show-error",
                "--connect-timeout", "5", "--max-time", "12",
                "-A", "Mozilla/5.0 PlayhubNotifications/1.0",
                "-o", target, url,
            ], capture_output=True, text=True, timeout=15, creationflags=(subprocess.CREATE_NO_WINDOW if _is_windows() else 0))
            if result.returncode == 0 and os.path.isfile(target) and os.path.getsize(target) > 0:
                return True
            _log("WARNING", f"curl image fetch failed rc={result.returncode}: {(result.stderr or '')[:220]}")
        except Exception as error:
            _log("WARNING", f"curl image fetch failed for {url[:180]}: {error}")
    return False


def _current_steam64_id() -> str:
    steam = _steam_install_path()
    if not steam:
        return ""
    path = os.path.join(steam, "config", "loginusers.vdf")
    try:
        content = open(path, "r", encoding="utf-8", errors="ignore").read()
    except Exception:
        return ""

    matches = list(re.finditer(r'(?m)^\s*"(\d{17})"\s*$', content))
    if not matches:
        return ""
    fallback = matches[0].group(1)
    for index, match in enumerate(matches):
        end = matches[index + 1].start() if index + 1 < len(matches) else len(content)
        block = content[match.end():end]
        if re.search(r'"MostRecent"\s+"1"', block, flags=re.I):
            return match.group(1)
    return fallback


def _xml_text_unescape(value: str) -> str:
    # Keep this intentionally tiny: Decky's sandboxed Python runtime does not ship
    # xml.etree, so the Steam Community fallback must not depend on XML modules.
    return (str(value or "")
            .replace("&amp;", "&")
            .replace("&quot;", '"')
            .replace("&apos;", "'")
            .replace("&lt;", "<")
            .replace("&gt;", ">"))


def _steam_community_achievement_icon(appid: int, achievement_id: str) -> str:
    achid = str(achievement_id or "").strip()
    if appid <= 0 or not achid:
        return ""
    steam64 = _current_steam64_id()
    if not steam64:
        _log("WARNING", f"Achievement XML fallback: SteamID64 unavailable for app {appid}")
        return ""
    url = f"https://steamcommunity.com/profiles/{steam64}/stats/{appid}/?xml=1"
    try:
        request = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0 PlayhubNotifications/1.0"})
        with urllib.request.urlopen(request, timeout=10) as response:
            body = response.read().decode("utf-8", errors="ignore")

        # Steam's stats XML is simple and regular. Parse only the <achievement>
        # blocks and three fields we need rather than importing an XML parser that
        # is missing from Decky's sandboxed Python distribution.
        wanted = achid.casefold()
        for block_match in re.finditer(r"<achievement\b[^>]*>(.*?)</achievement>", body, flags=re.I | re.S):
            block = block_match.group(1)
            api_match = re.search(r"<apiname>(?:<!\[CDATA\[)?(.*?)(?:\]\]>)?</apiname>", block, flags=re.I | re.S)
            if not api_match:
                continue
            apiname = _xml_text_unescape(api_match.group(1).strip())
            if apiname.casefold() != wanted:
                continue

            icon_match = re.search(r"<iconClosed>(?:<!\[CDATA\[)?(.*?)(?:\]\]>)?</iconClosed>", block, flags=re.I | re.S)
            if not icon_match:
                icon_match = re.search(r"<iconOpen>(?:<!\[CDATA\[)?(.*?)(?:\]\]>)?</iconOpen>", block, flags=re.I | re.S)
            if not icon_match:
                return ""
            icon_url = _xml_text_unescape(icon_match.group(1).strip())
            if not icon_url:
                return ""
            resolved = _normalize_image_source(icon_url)
            _log("INFO", f"Achievement XML fallback resolved appid={appid} id={achid} -> {resolved[:220]}")
            return resolved
    except Exception as error:
        _log("WARNING", f"Achievement XML fallback failed appid={appid} id={achid}: {error}")
    return ""


def _normalize_image_source(value: str) -> str:
    raw = str(value or "").strip()
    if not raw:
        return ""
    if raw.startswith("//"):
        raw = "https:" + raw
    parsed = urllib.parse.urlparse(raw)
    if parsed.scheme in {"http", "https"}:
        try:
            digest = hashlib.sha1(raw.encode("utf-8", errors="ignore")).hexdigest()
            ext = os.path.splitext(parsed.path)[1].lower()
            if ext not in {".png", ".jpg", ".jpeg", ".webp", ".bmp"}:
                ext = ".img"
            target = os.path.join(_image_cache_dir(), digest + ext)
            if not os.path.exists(target) or os.path.getsize(target) <= 0:
                _download_url_to_file(raw, target)
            if os.path.exists(target) and os.path.getsize(target) > 0:
                return _convert_image_for_wpf(target)
        except Exception as error:
            _log("WARNING", f"Image cache failed for {raw[:180]}: {error}")
        return raw
    if raw.startswith("file://"):
        return _convert_image_for_wpf(urllib.parse.unquote(raw[7:]))
    return raw


def _log(level: str, message: str) -> None:
    text = f"[{time.strftime('%Y-%m-%d %H:%M:%S')}] [{level}] {message}"
    try:
        logger = getattr(decky, "logger", None)
        if logger:
            fn = getattr(logger, level.lower(), None) or getattr(logger, "info", None)
            if fn:
                fn(message)
    except Exception:
        pass
    try:
        with open(_log_path(), "a", encoding="utf-8") as handle:
            handle.write(text + "\n")
    except Exception:
        pass


def _helper_path() -> str:
    return os.path.join(os.path.dirname(__file__), "helpers", "PlayhubNotificationsHelper.exe")

def _renderer_path() -> str:
    return os.path.join(os.path.dirname(__file__), "helpers", "PlayhubNotificationsWpf.ps1")

def _volume_renderer_path() -> str:
    return os.path.join(os.path.dirname(__file__), "helpers", "PlayhubNotificationsVolume.ps1")

def _sound_path(theme: str, kind: str) -> str:
    safe_theme = theme if theme in THEMES else "xbox"
    safe_kind = kind if kind in KINDS else "system"

    # PlayStation uses specific Deck UI sounds requested by the user:
    # - message -> deck_ui_message_toast.wav
    # - achievement -> deck_ui_achievement_toast.wav
    # - everything else -> deck_ui_toast.wav
    if safe_theme == "playstation":
        mapped_kind = "system"
        if safe_kind == "message":
            mapped_kind = "message"
        elif safe_kind == "achievement":
            mapped_kind = "achievement"
        direct = os.path.join(os.path.dirname(__file__), "assets", "sounds", safe_theme, f"{mapped_kind}.wav")
        if os.path.isfile(direct):
            return direct
        fallback = os.path.join(os.path.dirname(__file__), "assets", "sounds", safe_theme, "system.wav")
        return fallback if os.path.isfile(fallback) else ""

    direct = os.path.join(os.path.dirname(__file__), "assets", "sounds", safe_theme, f"{safe_kind}.wav")
    if os.path.isfile(direct):
        return direct
    fallback = os.path.join(os.path.dirname(__file__), "assets", "sounds", safe_theme, "system.wav")
    return fallback if os.path.isfile(fallback) else ""


_BOOST_SOUND_MANIFEST: Optional[Dict[str, Any]] = None


def _boosted_sound_info(theme: str, kind: str) -> tuple[str, float]:
    original = _sound_path(theme, kind)
    if not original:
        return "", 0.0
    sounds_root = os.path.join(os.path.dirname(__file__), "assets", "sounds")
    try:
        relative = os.path.relpath(original, sounds_root)
    except Exception:
        return "", 0.0
    target_root = os.path.join(os.path.dirname(__file__), "assets", "sounds_boosted")
    target = os.path.join(target_root, relative)
    if not os.path.isfile(target):
        return "", 0.0

    global _BOOST_SOUND_MANIFEST
    if _BOOST_SOUND_MANIFEST is None:
        try:
            with open(os.path.join(target_root, "manifest.json"), "r", encoding="utf-8") as handle:
                loaded = json.load(handle)
            _BOOST_SOUND_MANIFEST = loaded if isinstance(loaded, dict) else {}
        except Exception:
            _BOOST_SOUND_MANIFEST = {}
    key = relative.replace("\\", "/")
    try:
        gain_db = float((_BOOST_SOUND_MANIFEST.get(key, {}) or {}).get("clean_gain_db", 6.0206))
    except (TypeError, ValueError):
        gain_db = 6.0206
    return target, max(0.0, min(6.0206, gain_db))


def _normalize_settings(data: Any) -> Dict[str, Any]:
    source = data if isinstance(data, dict) else {}
    out = dict(DEFAULT_SETTINGS)
    out.update({key: source[key] for key in DEFAULT_SETTINGS if key in source})
    out["settings_version"] = 2
    out["enabled"] = bool(out.get("enabled", True))
    out["volume_overlay_enabled"] = bool(out.get("volume_overlay_enabled", True))
    out["theme"] = str(out.get("theme", "xbox")) if str(out.get("theme", "xbox")) in THEMES else "xbox"
    out["position"] = str(out.get("position", "bottom-right")) if str(out.get("position", "bottom-right")) in POSITIONS else "bottom-right"
    try:
        legacy_duration = max(2000, min(12000, int(source.get("duration_ms", DEFAULT_DURATION_MS))))
    except (TypeError, ValueError):
        legacy_duration = DEFAULT_DURATION_MS
    out["duration_ms"] = legacy_duration
    raw_durations = source.get("duration_by_kind", {}) if isinstance(source.get("duration_by_kind", {}), dict) else {}
    duration_by_kind: Dict[str, int] = {}
    for notification_kind in KINDS:
        try:
            duration_by_kind[notification_kind] = max(2000, min(12000, int(raw_durations.get(notification_kind, legacy_duration))))
        except (TypeError, ValueError):
            duration_by_kind[notification_kind] = legacy_duration
    out["duration_by_kind"] = duration_by_kind
    try:
        out["sound_volume"] = max(0, min(200, int(out.get("sound_volume", 72))))
    except (TypeError, ValueError):
        out["sound_volume"] = 72
    raw_visible = out.get("visible_kinds", {}) if isinstance(out.get("visible_kinds", {}), dict) else {}
    out["visible_kinds"] = {kind: bool(raw_visible.get(kind, True)) for kind in KINDS}
    return out


def _steam_install_path() -> str:
    if not _is_windows():
        return ""
    try:
        import winreg
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, r"Software\Valve\Steam") as key:
            value, _ = winreg.QueryValueEx(key, "SteamPath")
            return str(value or "")
    except Exception:
        return ""


def _resolve_steam_app_icon(appid: int, icon_hash: str = "") -> str:
    if appid <= 0:
        return ""
    steam = _steam_install_path()
    if not steam:
        return ""
    libcache = os.path.join(steam, "appcache", "librarycache")
    candidates = []
    # Artwork/SGDB custom icon path used by the user's Artwork plugin.
    for ext in (".jpg", ".png", ".jpeg", ".webp"):
        candidates.append(os.path.join(libcache, f"{appid}_icon{ext}"))
    # Steam's legacy/current icon caches.
    for ext in (".jpg", ".png", ".jpeg", ".webp"):
        candidates.append(os.path.join(libcache, str(appid), f"icon{ext}"))
    clean_hash = str(icon_hash or "").strip()
    if clean_hash:
        for ext in (".jpg", ".png", ".jpeg", ".webp"):
            candidates.append(os.path.join(libcache, str(appid), clean_hash + ext))
    # Custom shortcut icons created by Artwork live in userdata/<user>/config/grid/<appid>_icon.*
    userdata = os.path.join(steam, "userdata")
    try:
        if os.path.isdir(userdata):
            for user in os.listdir(userdata):
                grid = os.path.join(userdata, user, "config", "grid")
                if not os.path.isdir(grid):
                    continue
                for ext in (".png", ".jpg", ".jpeg", ".webp"):
                    candidates.append(os.path.join(grid, f"{appid}_icon{ext}"))
    except Exception:
        pass
    for candidate in candidates:
        try:
            if os.path.isfile(candidate) and os.path.getsize(candidate) > 0:
                return candidate
        except OSError:
            continue
    return ""


def _normalize_notification(data: Any, settings: Dict[str, Any]) -> Dict[str, Any]:
    source = data if isinstance(data, dict) else {}
    kind = str(source.get("kind", "system")).strip().lower()
    if kind not in KINDS:
        kind = "system"
    def clean(key: str, limit: int) -> str:
        return str(source.get(key, "") or "").replace("\x00", "").strip()[:limit]
    embedded_image = str(source.get("image_data", "") or "")
    try:
        appid = int(source.get("appid", 0) or 0)
    except (TypeError, ValueError):
        appid = 0
    icon_hash = str(source.get("icon_hash", "") or "")
    # Download toasts intentionally do not render a game icon anymore. The Steam-side
    # icon sources proved too inconsistent for this notification class and the user
    # explicitly asked to remove them.
    local_app_icon = ""
    raw_image_value = clean("image", 2048)
    image_value = "" if kind == "download" else (_cache_data_url(embedded_image) or _normalize_image_source(raw_image_value))
    if kind == "achievement" and not image_value:
        image_value = _steam_community_achievement_icon(appid, str(source.get("achievement_id", "") or ""))
    if kind == "achievement":
        _log("INFO", f"Achievement image resolve raw={'embedded-data' if embedded_image else raw_image_value[:220]} -> {image_value[:220]}")
    sound_volume = int(settings["sound_volume"])
    sound_boost_path, sound_boost_gain_db = _boosted_sound_info(settings["theme"], kind) if sound_volume > 100 else ("", 0.0)
    image_remote = raw_image_value if isinstance(raw_image_value, str) and raw_image_value.strip().lower().startswith(("http://", "https://", "file://", "//")) else ""
    payload: Dict[str, Any] = {
        "kind": kind,
        "title": clean("title", 140) or "Steam notification",
        "body": clean("body", 320),
        "subtitle": clean("subtitle", 160),
        "image": image_value,
        "image_remote": image_remote,
        "appid": appid,
        "theme": settings["theme"],
        "position": settings["position"],
        "duration_ms": int(settings.get("duration_by_kind", {}).get(kind, settings.get("duration_ms", DEFAULT_DURATION_MS))),
        "sound_enabled": sound_volume > 0,
        "sound_volume": sound_volume,
        "sound_path": _sound_path(settings["theme"], kind) if sound_volume > 0 else "",
        "sound_boost_path": sound_boost_path,
        "sound_boost_gain_db": sound_boost_gain_db,
    }
    for key in ("steam_type", "steam_source", "steam_test_name", "steam_notification_id"):
        if key in source:
            payload[key] = source.get(key)
    return payload


class Plugin:
    def __init__(self) -> None:
        self.settings: Dict[str, Any] = dict(DEFAULT_SETTINGS)
        self.queue: asyncio.Queue[Dict[str, Any]] = asyncio.Queue(maxsize=MAX_QUEUE)
        self.worker_task: Optional[asyncio.Task[Any]] = None
        self.volume_watch_task: Optional[asyncio.Task[Any]] = None
        self.active_process: Optional[subprocess.Popen[Any]] = None
        self.volume_process: Optional[subprocess.Popen[Any]] = None
        self.last_error = ""
        self._unloading = False
        self.recent_notification_ids: Dict[str, float] = {}

    async def _main(self) -> None:
        self.settings = self._load_settings()
        self._unloading = False
        self.worker_task = asyncio.create_task(self._notification_worker())
        self._start_volume_monitor()
        self.volume_watch_task = asyncio.create_task(self._volume_monitor_watchdog())
        status = self._status_sync()
        _log("INFO", f"Playhub Notifications {VERSION} [{INTERNAL_BUILD}] loaded; windows={status['windows']} overlay_ready={status['overlay_ready']} helper={status['helper']}")

    async def _unload(self) -> None:
        self._unloading = True
        self._drain_overlay_queue()
        if self.worker_task:
            self.worker_task.cancel()
            try:
                await self.worker_task
            except (asyncio.CancelledError, Exception):
                pass
            self.worker_task = None
        if self.volume_watch_task:
            self.volume_watch_task.cancel()
            try:
                await self.volume_watch_task
            except (asyncio.CancelledError, Exception):
                pass
            self.volume_watch_task = None
        self._terminate_active_overlay()
        self._stop_volume_monitor()
        _log("INFO", "Playhub Notifications unloaded")

    async def _uninstall(self) -> None:
        self._unloading = True
        if self.volume_watch_task:
            self.volume_watch_task.cancel()
            try:
                await self.volume_watch_task
            except (asyncio.CancelledError, Exception):
                pass
            self.volume_watch_task = None
        self._terminate_active_overlay()
        self._stop_volume_monitor()

    def _load_settings(self) -> Dict[str, Any]:
        try:
            with open(_settings_path(), "r", encoding="utf-8") as handle:
                return _normalize_settings(json.load(handle))
        except FileNotFoundError:
            return dict(DEFAULT_SETTINGS)
        except Exception as error:
            self.last_error = f"Settings load failed: {error}"
            _log("WARNING", self.last_error)
            return dict(DEFAULT_SETTINGS)

    def _save_settings(self) -> None:
        os.makedirs(_data_dir(), exist_ok=True)
        temp_path = _settings_path() + ".tmp"
        with open(temp_path, "w", encoding="utf-8") as handle:
            json.dump(self.settings, handle, indent=2)
        os.replace(temp_path, _settings_path())

    def _status_sync(self) -> Dict[str, Any]:
        helper = _helper_path()
        renderer = _renderer_path()
        volume_renderer = _volume_renderer_path()
        ready = _is_windows() and os.path.isfile(helper) and os.path.isfile(renderer)
        return {
            "ok": True,
            "windows": _is_windows(),
            "overlay_ready": ready,
            "helper": helper,
            "renderer": renderer,
            "volume_overlay_ready": _is_windows() and os.path.isfile(volume_renderer) and self.volume_process is not None and self.volume_process.poll() is None,
            "queue_size": self.queue.qsize(),
            "last_error": self.last_error,
        }

    async def get_settings(self) -> Dict[str, Any]:
        return dict(self.settings)

    def _start_volume_monitor(self) -> None:
        if not _is_windows():
            return
        if self.volume_process is not None:
            exit_code = self.volume_process.poll()
            if exit_code is None:
                return
            _log("WARNING", f"Volume overlay monitor exited with code {exit_code}; restarting")
            self.volume_process = None
        renderer = _volume_renderer_path()
        if not os.path.isfile(renderer):
            _log("WARNING", f"Volume renderer missing: {renderer}")
            return
        powershell = os.path.join(os.environ.get("SystemRoot", r"C:\Windows"), "System32", "WindowsPowerShell", "v1.0", "powershell.exe")
        if not os.path.isfile(powershell):
            powershell = "powershell.exe"
        args = [
            powershell, "-NoLogo", "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass",
            "-WindowStyle", "Hidden", "-STA", "-File", renderer,
            "-SettingsPath", _settings_path(), "-LogPath", _log_path(),
        ]
        try:
            self.volume_process = subprocess.Popen(
                args,
                cwd=os.path.dirname(renderer),
                creationflags=subprocess.CREATE_NO_WINDOW,
            )
            _log("INFO", f"Volume overlay monitor started pid={self.volume_process.pid}")
        except Exception as error:
            self.volume_process = None
            self.last_error = f"Volume overlay failed to start: {error}"
            _log("ERROR", self.last_error)

    async def _volume_monitor_watchdog(self) -> None:
        while not self._unloading:
            await asyncio.sleep(5)
            self._start_volume_monitor()

    def _stop_volume_monitor(self) -> None:
        proc = self.volume_process
        self.volume_process = None
        if not proc or proc.poll() is not None:
            return
        try:
            proc.terminate()
            proc.wait(timeout=1.0)
        except Exception:
            try:
                proc.kill()
            except Exception:
                pass

    async def save_settings(self, settings: Any) -> Dict[str, Any]:
        self.settings = _normalize_settings(settings)
        try:
            self._save_settings()
            _log("INFO", f"Settings saved enabled={self.settings['enabled']} theme={self.settings['theme']} position={self.settings['position']} durations={self.settings.get('duration_by_kind', {})} volume={self.settings['sound_volume']}")
        except Exception as error:
            self.last_error = f"Settings save failed: {error}"
            _log("ERROR", self.last_error)
            raise
        return dict(self.settings)

    async def get_status(self) -> Dict[str, Any]:
        return self._status_sync()

    async def debug_log(self, message: str = "") -> Dict[str, Any]:
        _log("INFO", f"FRONTEND {str(message)[:1000]}")
        return {"ok": True}

    async def emit_notification(self, payload: Any) -> Dict[str, Any]:
        if not self.settings.get("enabled", True):
            return {"ok": False, "queued": False, "message": "Playhub Notifications is disabled."}
        status = self._status_sync()
        if not status["overlay_ready"]:
            return {"ok": False, "queued": False, "message": "Native overlay is not ready."}
        item = _normalize_notification(payload, self.settings)
        kind = str(item.get("kind", "system"))
        if not bool(self.settings.get("visible_kinds", {}).get(kind, True)):
            return {"ok": True, "queued": False, "hidden": True}
        notification_id = str(item.get("steam_notification_id", "") or "").strip()
        if notification_id:
            now = time.monotonic()
            previous = self.recent_notification_ids.get(notification_id, 0.0)
            self.recent_notification_ids = {key: ts for key, ts in self.recent_notification_ids.items() if now - ts < 8.0}
            if previous and now - previous < 1.5:
                return {"ok": True, "queued": False, "deduplicated": True}
            self.recent_notification_ids[notification_id] = now
        self._enqueue(item)
        return {"ok": True, "queued": True}

    async def test_notification(self, kind: str = "system") -> Dict[str, Any]:
        normalized_kind = str(kind or "system").lower()
        if normalized_kind not in KINDS:
            normalized_kind = "system"
        status = self._status_sync()
        if not status["overlay_ready"]:
            return {"ok": False, "queued": False, "message": "Native Windows overlay is not ready."}
        sample = dict(SAMPLES[normalized_kind])
        sample["kind"] = normalized_kind
        if normalized_kind in {"achievement", "download"}:
            sample["image"] = os.path.join(os.path.dirname(__file__), "assets", "sample-achievement.png")
        item = _normalize_notification(sample, self.settings)
        self._enqueue(item)
        return {"ok": True, "queued": True}

    def _drain_overlay_queue(self) -> None:
        # Internal runtime cleanup only. This queue is not Steam's notification
        # history and is never exposed as a user-facing "clear notifications" action.
        try:
            while True:
                self.queue.get_nowait()
                self.queue.task_done()
        except asyncio.QueueEmpty:
            pass

    def _enqueue(self, item: Dict[str, Any]) -> None:
        if self.queue.full():
            try:
                self.queue.get_nowait()
                self.queue.task_done()
                _log("WARNING", "Notification queue full; dropped oldest pending toast")
            except asyncio.QueueEmpty:
                pass
        try:
            self.queue.put_nowait(item)
        except asyncio.QueueFull:
            _log("WARNING", "Notification queue full; could not queue toast")

    async def _notification_worker(self) -> None:
        while not self._unloading:
            try:
                payload = await self.queue.get()
            except asyncio.CancelledError:
                break
            try:
                await asyncio.to_thread(self._run_overlay_sync, payload)
            except asyncio.CancelledError:
                break
            except Exception as error:
                self.last_error = f"Overlay worker error: {error}"
                _log("ERROR", self.last_error)
            finally:
                self.queue.task_done()

    def _run_overlay_sync(self, payload: Dict[str, Any]) -> None:
        if not _is_windows():
            return
        helper = _helper_path()
        if not os.path.isfile(helper):
            self.last_error = f"Notification helper missing: {helper}"
            _log("ERROR", self.last_error)
            return

        fd, payload_path = tempfile.mkstemp(prefix="toast-", suffix=".json", dir=_data_dir())
        os.close(fd)
        with open(payload_path, "w", encoding="utf-8") as handle:
            json.dump(payload, handle, ensure_ascii=False)

        args = [helper, "--payload", payload_path, "--log", _log_path()]
        try:
            # The bundled native launcher starts the bundled WPF renderer in an STA
            # PowerShell host. Both files live inside the Decky plugin directory;
            # nothing is installed separately. WPF owns retained-mode animation and
            # the window is topmost, non-activating and click-through.
            self.active_process = subprocess.Popen(args, cwd=os.path.dirname(helper))
            timeout = max(8.0, float(payload.get("duration_ms", 5000)) / 1000.0 + 5.0)
            return_code = self.active_process.wait(timeout=timeout)
            if return_code != 0:
                self.last_error = f"Notification helper exited with code {return_code}. See playhub-notifications.log."
                _log("ERROR", self.last_error)
            else:
                self.last_error = ""
        except subprocess.TimeoutExpired:
            self.last_error = "Notification helper exceeded its safety timeout and was terminated."
            _log("WARNING", self.last_error)
            self._terminate_active_overlay()
        except Exception as error:
            self.last_error = f"Notification helper failed: {error}"
            _log("ERROR", self.last_error)
        finally:
            self.active_process = None
            try:
                os.remove(payload_path)
            except OSError:
                pass

    def _terminate_active_overlay(self) -> None:
        proc = self.active_process
        if not proc or proc.poll() is not None:
            self.active_process = None
            return
        try:
            proc.terminate()
            proc.wait(timeout=0.8)
        except Exception:
            try:
                proc.kill()
            except Exception:
                pass
        self.active_process = None
