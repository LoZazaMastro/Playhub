param(
    [Parameter(Mandatory=$true)][string]$SettingsPath,
    [string]$LogPath = ""
)

$ErrorActionPreference = "Stop"

$monitorPidPath = Join-Path ([IO.Path]::GetDirectoryName($SettingsPath)) "volume-overlay.pid"
try {
    if (Test-Path -LiteralPath $monitorPidPath) {
        $previousPid = 0
        if ([int]::TryParse((Get-Content -LiteralPath $monitorPidPath -Raw).Trim(), [ref]$previousPid) -and $previousPid -gt 0 -and $previousPid -ne $PID) {
            $previous = Get-CimInstance Win32_Process -Filter "ProcessId = $previousPid" -ErrorAction SilentlyContinue
            if ($previous -and ([string]$previous.CommandLine).IndexOf("PlayhubNotificationsVolume.ps1", [StringComparison]::OrdinalIgnoreCase) -ge 0) {
                Stop-Process -Id $previousPid -Force -ErrorAction SilentlyContinue
            }
        }
    }
    New-Item -ItemType Directory -Path ([IO.Path]::GetDirectoryName($monitorPidPath)) -Force | Out-Null
    Set-Content -LiteralPath $monitorPidPath -Value $PID -Encoding ASCII
} catch {}

function Write-VolumeLog([string]$Message) {
    try {
        if ([string]::IsNullOrWhiteSpace($LogPath)) { return }
        $stamp = [DateTime]::Now.ToString("yyyy-MM-dd HH:mm:ss.fff")
        Add-Content -LiteralPath $LogPath -Value "$stamp [VOLUME] $Message" -Encoding UTF8
    } catch {}
}

function Get-ExplorerState {
    $processes = @()
    try {
        $sessionId = [System.Diagnostics.Process]::GetCurrentProcess().SessionId
        $processes = [System.Diagnostics.Process]::GetProcessesByName("explorer")
        foreach ($process in $processes) {
            try {
                if (-not $process.HasExited -and $process.SessionId -eq $sessionId) {
                    return @{ Ok=$true; Running=$true; Error="" }
                }
            } catch {}
        }
        return @{ Ok=$true; Running=$false; Error="" }
    } catch {
        # Fail closed: a missed Windows shell must never produce a duplicate OSD.
        return @{ Ok=$false; Running=$true; Error=$_.Exception.Message }
    } finally {
        foreach ($process in $processes) {
            try { $process.Dispose() } catch {}
        }
    }
}

try {
    Add-Type -AssemblyName PresentationFramework, PresentationCore, WindowsBase
    Add-Type -Path (Join-Path $PSScriptRoot "PlayhubVolumeEvents.cs") -ReferencedAssemblies ([System.Windows.Threading.Dispatcher].Assembly.Location)
    Add-Type -TypeDefinition @"
using System;
using System.Runtime.InteropServices;

public static class PlayhubVolumeWindow {
    public const int GwlExStyle = -20;
    public const int Transparent = 0x20;
    public const int ToolWindow = 0x80;
    public const int NoActivate = 0x08000000;
    public const uint NoSize = 0x0001;
    public const uint NoMove = 0x0002;
    public const uint NoActivateFlag = 0x0010;
    public const uint ShowWindow = 0x0040;
    public static readonly IntPtr Topmost = new IntPtr(-1);
    [DllImport("user32.dll", EntryPoint="GetWindowLongPtr")] public static extern IntPtr GetWindowLongPtr(IntPtr hwnd, int index);
    [DllImport("user32.dll", EntryPoint="SetWindowLongPtr")] public static extern IntPtr SetWindowLongPtr(IntPtr hwnd, int index, IntPtr value);
    [DllImport("user32.dll", SetLastError=true)] public static extern bool SetWindowPos(IntPtr hwnd, IntPtr insertAfter, int x, int y, int cx, int cy, uint flags);
}
"@
} catch {
    Write-VolumeLog "startup failed: $($_.Exception.Message)"
    exit 30
}

function Color([string]$Value) {
    return [System.Windows.Media.ColorConverter]::ConvertFromString($Value)
}

function Solid([string]$Value, [double]$Opacity = 1) {
    $color = Color $Value
    $color.A = [byte][Math]::Round($color.A * [Math]::Max(0, [Math]::Min(1, $Opacity)))
    return [System.Windows.Media.SolidColorBrush]::new($color)
}

function Gradient([string]$Start, [string]$End) {
    $brush = [System.Windows.Media.LinearGradientBrush]::new()
    $brush.StartPoint = [System.Windows.Point]::new(0, .5)
    $brush.EndPoint = [System.Windows.Point]::new(1, .5)
    $brush.GradientStops.Add([System.Windows.Media.GradientStop]::new((Color $Start), 0))
    $brush.GradientStops.Add([System.Windows.Media.GradientStop]::new((Color $End), 1))
    return $brush
}

function Shadow([string]$Value, [double]$Blur, [double]$Depth, [double]$Opacity) {
    $effect = [System.Windows.Media.Effects.DropShadowEffect]::new()
    $effect.Color = Color $Value
    $effect.BlurRadius = $Blur
    $effect.ShadowDepth = $Depth
    $effect.Opacity = $Opacity
    return $effect
}

function Read-Settings {
    try {
        $value = Get-Content -LiteralPath $SettingsPath -Raw -Encoding UTF8 | ConvertFrom-Json
        return @{ Enabled=($value.volume_overlay_enabled -ne $false); Theme=[string]$value.theme }
    } catch {
        return @{ Enabled=$true; Theme="xbox" }
    }
}

$window = [System.Windows.Window]::new()
$window.Width = 450
$window.Height = 96
$window.WindowStyle = "None"
$window.ResizeMode = "NoResize"
$window.AllowsTransparency = $true
$window.Background = [System.Windows.Media.Brushes]::Transparent
$window.ShowInTaskbar = $false
$window.ShowActivated = $false
$window.Topmost = $true
$window.Focusable = $false
$window.IsHitTestVisible = $false
$window.Opacity = 0
$window.Left = ([System.Windows.SystemParameters]::PrimaryScreenWidth - $window.Width) / 2
$window.Top = [System.Windows.SystemParameters]::PrimaryScreenHeight - $window.Height - 54

$root = [System.Windows.Controls.Grid]::new()
$window.Content = $root

$shell = [System.Windows.Controls.Border]::new()
$shell.Width = 420
$shell.Height = 72
$shell.HorizontalAlignment = "Center"
$shell.VerticalAlignment = "Center"
$root.Children.Add($shell) | Out-Null

$grid = [System.Windows.Controls.Grid]::new()
$grid.ColumnDefinitions.Add([System.Windows.Controls.ColumnDefinition]::new())
$grid.ColumnDefinitions[0].Width = [System.Windows.GridLength]::new(72)
$grid.ColumnDefinitions.Add([System.Windows.Controls.ColumnDefinition]::new())
$grid.ColumnDefinitions[1].Width = [System.Windows.GridLength]::new(1, [System.Windows.GridUnitType]::Star)
$grid.ColumnDefinitions.Add([System.Windows.Controls.ColumnDefinition]::new())
$grid.ColumnDefinitions[2].Width = [System.Windows.GridLength]::new(72)
$shell.Child = $grid

$rail = [System.Windows.Controls.Border]::new()
$rail.Width = 8
$rail.HorizontalAlignment = "Left"
$rail.Visibility = "Collapsed"
$grid.Children.Add($rail) | Out-Null

$iconTile = [System.Windows.Controls.Border]::new()
$iconTile.Width = 52
$iconTile.Height = 52
$iconTile.HorizontalAlignment = "Center"
$iconTile.VerticalAlignment = "Center"
[System.Windows.Controls.Grid]::SetColumn($iconTile, 0)
$grid.Children.Add($iconTile) | Out-Null

$icon = [System.Windows.Controls.TextBlock]::new()
$icon.FontFamily = [System.Windows.Media.FontFamily]::new("Segoe MDL2 Assets")
$icon.FontSize = 25
$icon.HorizontalAlignment = "Center"
$icon.VerticalAlignment = "Center"
$icon.TextAlignment = "Center"
$icon.Text = [char]0xE767
$iconRing = [System.Windows.Controls.Border]::new()
$iconRing.HorizontalAlignment = "Center"
$iconRing.VerticalAlignment = "Center"
$iconRing.Child = $icon
$iconTile.Child = $iconRing

$track = [System.Windows.Controls.Border]::new()
$track.Height = 8
$track.CornerRadius = [System.Windows.CornerRadius]::new(4)
$track.VerticalAlignment = "Center"
$track.Margin = [System.Windows.Thickness]::new(2, 0, 10, 0)
$bar = [System.Windows.Controls.Border]::new()
$bar.Height = 8
$bar.Width = 0
$bar.CornerRadius = [System.Windows.CornerRadius]::new(4)
$bar.HorizontalAlignment = "Left"
$track.Child = $bar
[System.Windows.Controls.Grid]::SetColumn($track, 1)
$grid.Children.Add($track) | Out-Null

$percent = [System.Windows.Controls.TextBlock]::new()
$percent.FontFamily = [System.Windows.Media.FontFamily]::new("Segoe UI Variable Text, Segoe UI")
$percent.FontSize = 18
$percent.FontWeight = [System.Windows.FontWeights]::SemiBold
$percent.TextAlignment = "Right"
$percent.VerticalAlignment = "Center"
$percent.Margin = [System.Windows.Thickness]::new(0, 0, 18, 0)
[System.Windows.Controls.Grid]::SetColumn($percent, 2)
$grid.Children.Add($percent) | Out-Null

function Apply-Theme([string]$Theme) {
    $shell.Width = 420
    $shell.Height = 72
    $shell.BorderThickness = [System.Windows.Thickness]::new(0)
    $shell.Effect = $null
    $grid.ColumnDefinitions[0].Width = [System.Windows.GridLength]::new(72)
    $grid.ColumnDefinitions[2].Width = [System.Windows.GridLength]::new(72)
    $rail.Visibility = "Collapsed"
    $rail.Background = [System.Windows.Media.Brushes]::Transparent
    $rail.CornerRadius = [System.Windows.CornerRadius]::new(0)
    $iconTile.Width = 52
    $iconTile.Height = 52
    $iconTile.BorderThickness = [System.Windows.Thickness]::new(0)
    $iconTile.Effect = $null
    $iconRing.Width = [Double]::NaN
    $iconRing.Height = [Double]::NaN
    $iconRing.BorderThickness = [System.Windows.Thickness]::new(0)
    $iconRing.CornerRadius = [System.Windows.CornerRadius]::new(0)
    $icon.FontSize = 25
    $track.Height = 8
    $track.CornerRadius = [System.Windows.CornerRadius]::new(4)
    $bar.Height = 8
    $bar.CornerRadius = [System.Windows.CornerRadius]::new(4)
    $percent.FontFamily = [System.Windows.Media.FontFamily]::new("Segoe UI Variable Text, Segoe UI")
    $percent.FontSize = 18
    $percent.FontWeight = [System.Windows.FontWeights]::SemiBold

    switch ($Theme) {
        "playstation" {
            $shell.Background = Gradient "#F823252B" "#F82A2C33"
            $shell.BorderBrush = Solid "#FFFFFFFF" .08
            $shell.BorderThickness = [System.Windows.Thickness]::new(1)
            $shell.CornerRadius = [System.Windows.CornerRadius]::new(18)
            $iconTile.Background = Solid "#FF1C1E24"
            $iconTile.CornerRadius = [System.Windows.CornerRadius]::new(9)
            $iconRing.Width = 42
            $iconRing.Height = 42
            $iconRing.BorderBrush = Solid "#FFFFFFFF" .80
            $iconRing.BorderThickness = [System.Windows.Thickness]::new(1.5)
            $iconRing.CornerRadius = [System.Windows.CornerRadius]::new(21)
            $icon.Foreground = Solid "#FFFFFFFF" .96
            $percent.Foreground = Solid "#FFFFFFFF" .96
            $track.Background = Solid "#FFFFFFFF" .16
            $bar.Background = Solid "#FF5C9DFF"
        }
        "gog" {
            $shell.Background = Gradient "#FA251C30" "#FA30243C"
            $shell.BorderBrush = Solid "#FFB65CFF" .18
            $shell.BorderThickness = [System.Windows.Thickness]::new(1)
            $shell.CornerRadius = [System.Windows.CornerRadius]::new(18)
            $rail.Visibility = "Visible"
            $rail.Background = Gradient "#FFB65CFF" "#FFD28AFF"
            $rail.CornerRadius = [System.Windows.CornerRadius]::new(18, 0, 0, 18)
            $iconTile.Background = Solid "#FF442D52"
            $iconTile.CornerRadius = [System.Windows.CornerRadius]::new(15)
            $icon.Foreground = Solid "#FFFFFFFF" .98
            $percent.Foreground = Solid "#FFFFFFFF" .98
            $track.Background = Solid "#FFFFFFFF" .15
            $bar.Background = Solid "#FFB65CFF"
        }
        "epic" {
            $shell.Background = Solid "#C0191919"
            $shell.CornerRadius = [System.Windows.CornerRadius]::new(10)
            $iconTile.Width = 60
            $iconTile.Height = 60
            $iconTile.Background = Gradient "#FA191A1E" "#FA212227"
            $iconTile.CornerRadius = [System.Windows.CornerRadius]::new(10)
            $icon.Foreground = Solid "#FFFFFFFF" .98
            $percent.Foreground = Solid "#FFF4F4F4"
            $track.Background = Solid "#FFFFFFFF" .17
            $bar.Background = Solid "#FFFFFFFF"
        }
        "nintendo" {
            $shell.Height = 68
            $shell.Background = Solid "#FFFAF9F7"
            $shell.CornerRadius = [System.Windows.CornerRadius]::new(22)
            $shell.Effect = Shadow "#FF000000" 18 5 .24
            $iconTile.Width = 62
            $iconTile.Height = 62
            $iconTile.Background = Solid "#FFE60012"
            $iconTile.CornerRadius = [System.Windows.CornerRadius]::new(22)
            $icon.Foreground = Solid "#FFFFFFFF"
            $percent.Foreground = Solid "#FF1F1F21"
            $track.Background = Solid "#FF1F1F21" .14
            $bar.Background = Solid "#FFE60012"
        }
        "android16" {
            $shell.Height = 74
            $shell.Background = Gradient "#FF20242C" "#FF293342"
            $shell.BorderBrush = Solid "#FFF7F9FC" .10
            $shell.BorderThickness = [System.Windows.Thickness]::new(1)
            $shell.CornerRadius = [System.Windows.CornerRadius]::new(30)
            $iconTile.Width = 54
            $iconTile.Height = 54
            $iconTile.Background = Solid "#FFA8C7FA" .22
            $iconTile.CornerRadius = [System.Windows.CornerRadius]::new(19)
            $icon.Foreground = Solid "#FFA8C7FA"
            $percent.Foreground = Solid "#FFF7F9FC"
            $track.Background = Solid "#FFF7F9FC" .14
            $bar.Background = Solid "#FFA8C7FA"
        }
        "glass" {
            $shell.Height = 76
            $shell.Background = Gradient "#A5506071" "#46FFFFFF"
            $shell.BorderBrush = Solid "#FFFFFFFF" .30
            $shell.BorderThickness = [System.Windows.Thickness]::new(1)
            $shell.CornerRadius = [System.Windows.CornerRadius]::new(30)
            $shell.Effect = Shadow "#FF000000" 18 6 .22
            $iconTile.Width = 58
            $iconTile.Height = 58
            $iconTile.Background = Gradient "#AAFFFFFF" "#68A9DDFF"
            $iconTile.BorderBrush = Solid "#FFFFFFFF" .34
            $iconTile.BorderThickness = [System.Windows.Thickness]::new(1)
            $iconTile.CornerRadius = [System.Windows.CornerRadius]::new(27)
            $icon.Foreground = Solid "#FFFFFFFF" .94
            $percent.Foreground = Solid "#FFFFFFFF"
            $track.Background = Solid "#FFFFFFFF" .20
            $bar.Background = Solid "#FFA9DDFF"
        }
        default {
            $shell.Height = 70
            $shell.Background = Solid "#FF107C10"
            $shell.CornerRadius = [System.Windows.CornerRadius]::new(35)
            $iconTile.Width = 54
            $iconTile.Height = 54
            $iconTile.Background = Solid "#FFFFFFFF" .14
            $iconTile.BorderBrush = Solid "#FFFFFFFF" .20
            $iconTile.BorderThickness = [System.Windows.Thickness]::new(1)
            $iconTile.CornerRadius = [System.Windows.CornerRadius]::new(27)
            $icon.Foreground = Solid "#FFFFFFFF"
            $percent.Foreground = Solid "#FFFFFFFF"
            $track.Background = Solid "#FFFFFFFF" .24
            $bar.Background = Solid "#FFFFFFFF"
        }
    }
}

function Show-Volume([int]$Level) {
    if ($state.Handle -ne [IntPtr]::Zero) {
        [void][PlayhubVolumeWindow]::SetWindowPos(
            $state.Handle,
            [PlayhubVolumeWindow]::Topmost,
            0, 0, 0, 0,
            [PlayhubVolumeWindow]::NoSize -bor [PlayhubVolumeWindow]::NoMove -bor [PlayhubVolumeWindow]::NoActivateFlag -bor [PlayhubVolumeWindow]::ShowWindow
        )
    }
    $usable = [Math]::Max(0, $track.ActualWidth)
    $ease = [System.Windows.Media.Animation.QuinticEase]::new()
    $ease.EasingMode = [System.Windows.Media.Animation.EasingMode]::EaseOut
    $width = [System.Windows.Media.Animation.DoubleAnimation]::new()
    $width.From = [Math]::Max(0, $bar.ActualWidth)
    $width.To = $usable * $Level / 100
    $width.Duration = [System.Windows.Duration]::new([TimeSpan]::FromMilliseconds(220))
    $width.EasingFunction = $ease
    $bar.BeginAnimation([System.Windows.FrameworkElement]::WidthProperty, $width)

    $fade = [System.Windows.Media.Animation.DoubleAnimation]::new()
    $fade.From = $window.Opacity
    $fade.To = 1
    $fade.Duration = [System.Windows.Duration]::new([TimeSpan]::FromMilliseconds(90))
    $window.BeginAnimation([System.Windows.UIElement]::OpacityProperty, $fade)
}

function Hide-Volume {
    $ease = [System.Windows.Media.Animation.CubicEase]::new()
    $ease.EasingMode = [System.Windows.Media.Animation.EasingMode]::EaseIn
    $fade = [System.Windows.Media.Animation.DoubleAnimation]::new()
    $fade.From = $window.Opacity
    $fade.To = 0
    $fade.Duration = [System.Windows.Duration]::new([TimeSpan]::FromMilliseconds(200))
    $fade.EasingFunction = $ease
    $window.BeginAnimation([System.Windows.UIElement]::OpacityProperty, $fade)
}

$state = [pscustomobject]@{
    Handle = [IntPtr]::Zero
    Settings = Read-Settings
    CurrentTheme = ""
    LastLevel = -1
    LastMuted = $false
    HideAt = [DateTime]::MinValue
    LastSnapshotErrorAt = [DateTime]::MinValue
    ExplorerRunning = $true
    ExplorerStateKnown = $false
    ExplorerCheckedAt = [DateTime]::MinValue
    LastExplorerProbeErrorAt = [DateTime]::MinValue
}

function Hide-VolumeImmediately {
    $window.BeginAnimation([System.Windows.UIElement]::OpacityProperty, $null)
    $window.Opacity = 0
    $state.HideAt = [DateTime]::MinValue
}

function Update-ExplorerOverlayPolicy([DateTime]$Now, [bool]$Force = $false) {
    if (-not $Force -and ($Now - $state.ExplorerCheckedAt).TotalMilliseconds -lt 1000) { return }

    $state.ExplorerCheckedAt = $Now
    $probe = Get-ExplorerState
    if (-not $probe.Ok -and ($Now - $state.LastExplorerProbeErrorAt).TotalSeconds -ge 30) {
        $state.LastExplorerProbeErrorAt = $Now
        Write-VolumeLog "explorer.exe probe failed; overlay suppressed: $($probe.Error)"
    }

    $explorerRunning = [bool]$probe.Running
    if (-not $state.ExplorerStateKnown -or $explorerRunning -ne $state.ExplorerRunning) {
        $state.ExplorerStateKnown = $true
        $state.ExplorerRunning = $explorerRunning
        if ($explorerRunning) {
            Hide-VolumeImmediately
            Write-VolumeLog "explorer.exe active in current session; Decky volume overlay suppressed"
        } else {
            Write-VolumeLog "explorer.exe not running in current session; Decky volume overlay enabled"
        }
    }
}

$window.Add_SourceInitialized({
    $helper = [System.Windows.Interop.WindowInteropHelper]::new($window)
    $state.Handle = $helper.Handle
    $style = [PlayhubVolumeWindow]::GetWindowLongPtr($state.Handle, [PlayhubVolumeWindow]::GwlExStyle).ToInt64()
    $style = $style -bor [PlayhubVolumeWindow]::Transparent -bor [PlayhubVolumeWindow]::ToolWindow -bor [PlayhubVolumeWindow]::NoActivate
    [void][PlayhubVolumeWindow]::SetWindowLongPtr($state.Handle, [PlayhubVolumeWindow]::GwlExStyle, [IntPtr]::new($style))
})

$state.CurrentTheme = $state.Settings.Theme
Apply-Theme $state.CurrentTheme

$volumeMonitor = [PlayhubVolumeEvents]::new([System.Windows.Threading.Dispatcher]::CurrentDispatcher, $SettingsPath)
if ($volumeMonitor.Ready) {
    $state.LastLevel = $volumeMonitor.Level
    $state.LastMuted = $volumeMonitor.Muted
}

$volumeMonitor.Add_SettingsChanged({
    $state.Settings = Read-Settings
    if ($state.Settings.Theme -ne $state.CurrentTheme) {
        $state.CurrentTheme = $state.Settings.Theme
        Apply-Theme $state.CurrentTheme
    }
    if (-not $state.Settings.Enabled) {
        Hide-VolumeImmediately
        $timer.Stop()
    }
})

$timer = [System.Windows.Threading.DispatcherTimer]::new()
$timer.Interval = [TimeSpan]::FromMilliseconds(125)
$timer.Add_Tick({
    $now = [DateTime]::Now
    Update-ExplorerOverlayPolicy $now
    if ($state.HideAt -eq [DateTime]::MinValue) { $timer.Stop(); return }
    if ($now -ge $state.HideAt) {
        $state.HideAt = [DateTime]::MinValue
        Hide-Volume
        $timer.Stop()
    }
})

$volumeMonitor.Add_VolumeChanged({
    $now = [DateTime]::Now
    if (-not $volumeMonitor.Ready) {
        if (($now - $state.LastSnapshotErrorAt).TotalSeconds -ge 30) {
            $state.LastSnapshotErrorAt = $now
            Write-VolumeLog "default playback device unavailable"
        }
        return
    }
    $level = [int]$volumeMonitor.Level
    $muted = $volumeMonitor.Muted

    if ($state.LastLevel -lt 0) {
        $state.LastLevel = $level
        $state.LastMuted = $muted
        return
    }

    if ($level -ne $state.LastLevel -or $muted -ne $state.LastMuted) {
        $state.LastLevel = $level
        $state.LastMuted = $muted
        # Recheck at the exact moment an OSD would be shown. This closes the short
        # interval between Explorer starting and the periodic process probe.
        Update-ExplorerOverlayPolicy $now $true
        if ($state.Settings.Enabled -and -not $state.ExplorerRunning) {
            $icon.Text = if ($muted -or $level -eq 0) { [char]0xE74F } else { [char]0xE767 }
            $percent.Text = if ($muted) { "MUTE" } else { "$level%" }
            if (-not $window.IsVisible) { $window.Show() }
            Show-Volume $level
            $state.HideAt = $now.AddMilliseconds(1450)
            $timer.Start()
        } elseif ($state.ExplorerRunning) {
            Hide-VolumeImmediately
        }
    }

})

$window.Add_Closed({
    $timer.Stop()
    $volumeMonitor.Dispose()
    try {
        if ((Get-Content -LiteralPath $monitorPidPath -Raw -ErrorAction SilentlyContinue).Trim() -eq [string]$PID) {
            Remove-Item -LiteralPath $monitorPidPath -Force -ErrorAction SilentlyContinue
        }
    } catch {}
    [System.Windows.Threading.Dispatcher]::CurrentDispatcher.InvokeShutdown()
})
$window.Show()
$window.Opacity = 0
Write-VolumeLog "monitor started"
try { [System.Windows.Threading.Dispatcher]::Run() }
finally { $timer.Stop(); $volumeMonitor.Dispose() }
