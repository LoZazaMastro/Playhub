Playhub Notifications 1.3.1

Reduced idle CPU use by updating the volume indicator only when the audio device or settings change.

Fixed volume monitoring when the default audio output changes. Preserved the existing themes, animations and desktop overlay suppression.
