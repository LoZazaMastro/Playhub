<div align="center">

# Playhub Notifications

### Steam notifications, with the style you chose.

Popups, sounds, and a volume indicator coordinated with your Gaming Mode, without altering Steam's notification history.

[![Release](https://img.shields.io/github/v/release/LoZazaMastro/Playhub-Notifications?style=for-the-badge&label=Release&labelColor=111111&color=ffffff)](https://github.com/LoZazaMastro/Playhub-Notifications/releases/latest)
[![Licenza MIT](https://img.shields.io/badge/Licenza-MIT-ffffff?style=for-the-badge&labelColor=111111)](LICENSE)

</div>

## A notification that feels part of the system

Playhub Notifications replaces the visible popups and their respective sounds in Steam Big Picture with overlays designed for TVs and couch gaming. It changes what appears on screen, not what Steam records: your original notification history remains intact.

The seven available themes are not just simple color variations. **Xbox Console, PlayStation, GOG Galaxy, Epic Games Launcher, Nintendo, Android, and Playhub** each feature their own unique shapes, animations, colors, and sounds.

## What you can customize

- achievements, messages, and invites;
- friend activity, complete with avatars and detected games;
- completed downloads and screenshots;
- controller status, warnings, and system events;
- community notifications;
- separate position and duration for each category;
- sound volume from 0% to 200%;
- categories managed by the plugin or left to the original Steam interface.

Achievements utilize the artwork provided by Steam when available. Friend avatars are stored in a local cache, ensuring subsequent notifications appear with no visible loading times.

## Volume overlay

Starting with version 1.3.0, the plugin also manages the volume indicator used by Gaming Mode when Explorer is inactive. The overlay follows your selected theme, maintains dimensions and animations suitable for a system indicator, never takes focus, and does not intercept controller, mouse, or keyboard inputs.

Playhub Notifications only monitors the system volume. Media keys remain managed by Playhub Gaming Mode, preventing duplicate hooks. The indicator can be disabled without turning off other notifications.

## Requirements

- Windows;
- Steam in Big Picture mode;
- [Decky Loader](https://decky.xyz) 3.x.

## Installation

You can install and update the plugin from the [Playhub](https://github.com/LoZazaMastro/Playhub) Plugin Store, or manually:

1. download the ZIP from the [latest release](https://github.com/LoZazaMastro/Playhub-Notifications/releases/latest);
2. enable Decky's developer mode;
3. choose **Decky → Settings → Developer → Install plugin from ZIP**;
4. open Playhub Notifications in the QAM, pick a theme, and use the previews to test it.

## Development

```bash
npm install
npm run test
npm run build
```

On Windows, the installable ZIP is created using:

```powershell
.\package-win.ps1
```

## License and credits

Playhub Notifications is distributed under the [MIT](LICENSE) license. Third-party components and assets are listed in [NOTICE](NOTICE) and in [third_party/Achievements-MIT-LICENSE.txt](third_party/Achievements-MIT-LICENSE.txt).

Steam and other mentioned platform names belong to their respective owners and are used solely to identify the themes.

<div align="center">

Created and maintained by **[LoZazaMastro](https://github.com/LoZazaMastro)**.

</div>
