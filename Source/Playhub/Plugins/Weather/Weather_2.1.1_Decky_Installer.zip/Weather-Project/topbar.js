function updateWeatherTopbar(config) {
  const key = "__deckyWeatherTopbarRuntime";
  const previous = window[key];
  if (previous?.version === 2) {
    previous.update(config);
    return "Weather top bar updated";
  }
  previous?.dispose?.();
  window.__deckyWeatherTopbarObserver?.disconnect();
  if (window.__deckyWeatherTopbarInterval) window.clearInterval(window.__deckyWeatherTopbarInterval);

  const badgeId = "decky-weather-topbar-badge";
  const styleId = "decky-weather-topbar-style";
  let state = {}, clock = null, badge = document.getElementById(badgeId);
  let icon = badge?.querySelector(".decky-weather-topbar-icon");
  let temperature = badge?.querySelector(".decky-weather-topbar-temp");
  let observer = null, watching = false, disposed = false;
  const css = `
    [data-decky-weather-clock="1"] {
      display:inline-flex !important; align-items:baseline !important;
      justify-content:center !important; gap:0 !important; white-space:nowrap !important;
      overflow:visible !important; text-overflow:clip !important;
      min-width:max-content !important; max-width:none !important;
    }
    #${badgeId} {
      display:inline-flex !important; align-items:baseline !important; justify-content:center !important;
      gap:.16em !important; margin-left:.34em !important; padding:0 !important;
      width:auto !important; min-width:max-content !important; max-width:none !important;
      height:auto !important; line-height:inherit !important; font:inherit !important;
      font-size:1em !important; font-weight:inherit !important; letter-spacing:inherit !important;
      color:inherit !important; opacity:.98 !important; white-space:nowrap !important;
      overflow:visible !important; transform:none !important; pointer-events:none !important;
      vertical-align:baseline !important;
    }
    #${badgeId} .decky-weather-topbar-icon {
      display:inline-flex !important; align-items:center !important; justify-content:center !important;
      flex:0 0 auto !important; width:1em !important; height:1em !important;
      font-size:calc(.82em + 5px) !important; line-height:1 !important;
      transform:translateY(.04em) !important; margin:0 !important;
    }
    #${badgeId} .decky-weather-topbar-temp {
      display:inline-block !important; font:inherit !important; font-size:1em !important;
      font-weight:inherit !important; line-height:inherit !important; letter-spacing:inherit !important;
      color:inherit !important; transform:none !important; margin:0 !important; padding:0 !important;
    }
    html[data-decky-weather-left="1"] #header [data-decky-weather-clock="1"] { order:-2 !important; }
  `;
  function attribute(node, name, value) {
    if (node.getAttribute(name) !== value) node.setAttribute(name, value);
  }
  function text(node, value) {
    if (node.textContent !== value) node.textContent = value;
  }
  function ownText(node) {
    return Array.from(node.childNodes).filter(child => child.nodeType === Node.TEXT_NODE)
      .map(child => child.textContent || "").join(" ").trim();
  }
  function findClock() {
    for (const selector of state.selectors || []) {
      const found = document.querySelector(selector);
      if (found) return found;
    }
    const header = document.querySelector("#header") || document.querySelector(".BasicUIHeader_Header_1E_SL");
    return header && Array.from(header.querySelectorAll("div, span, button"))
      .find(node => /^\d{1,2}:\d{2}(?:\s|$)/.test(ownText(node))) || null;
  }
  function installStyle() {
    let style = document.getElementById(styleId);
    if (!style) {
      style = document.createElement("style");
      style.id = styleId;
      style.textContent = css;
      document.head.appendChild(style);
    } else text(style, css);
  }
  function detach() {
    badge?.remove();
    clock?.removeAttribute("data-decky-weather-clock");
    clock = null;
    document.documentElement.removeAttribute("data-decky-weather-topbar");
    document.documentElement.removeAttribute("data-decky-weather-left");
  }
  function repair() {
    if (disposed || !state.enabled || !state.label) return;
    installStyle();
    if (!clock?.isConnected) {
      const next = findClock();
      if (!next) return;
      if (clock && clock !== next) clock.removeAttribute("data-decky-weather-clock");
      clock = next;
    }
    attribute(clock, "data-decky-weather-clock", "1");
    if (!badge) {
      badge = document.createElement("span");
      badge.id = badgeId;
      badge.setAttribute("aria-hidden", "true");
    }
    if (!icon) {
      icon = document.createElement("span");
      icon.className = "decky-weather-topbar-icon";
      badge.appendChild(icon);
    }
    if (!temperature) {
      temperature = document.createElement("span");
      temperature.className = "decky-weather-topbar-temp";
      badge.appendChild(temperature);
    }
    text(icon, state.iconText || "");
    text(temperature, state.tempText || state.label);
    attribute(badge, "title", state.label);
    if (badge.parentNode !== clock) clock.appendChild(badge);
    attribute(document.documentElement, "data-decky-weather-topbar", "1");
    if (state.moveLeft) attribute(document.documentElement, "data-decky-weather-left", "1");
    else document.documentElement.removeAttribute("data-decky-weather-left");
  }
  function mutations() {
    // CEF delivers mutations before paint. Reuse the detached badge in this
    // microtask instead of waiting a frame or timeout with the weather missing.
    if (!clock?.isConnected || badge?.parentNode !== clock || !document.getElementById(styleId)) repair();
  }
  function wake() {
    if (document.visibilityState !== "hidden") repair();
  }
  function watch() {
    if (watching) return;
    observer = new MutationObserver(mutations);
    observer.observe(document.documentElement, { childList: true, subtree: true });
    document.addEventListener("visibilitychange", wake, true);
    window.addEventListener("focus", wake, true);
    watching = true;
  }
  function unwatch() {
    observer?.disconnect();
    observer = null;
    document.removeEventListener("visibilitychange", wake, true);
    window.removeEventListener("focus", wake, true);
    watching = false;
  }
  const runtime = {
    version: 2,
    update(next) {
      if (disposed) return;
      // A failed refresh keeps the last valid reading for the same query.
      if (next.enabled && !next.label && next.context === state.context && state.label)
        next = { ...next, label: state.label, iconText: state.iconText, tempText: state.tempText };
      state = { ...next };
      window.__deckyWeatherTopbarState = state;
      if (!state.enabled || !state.label) {
        unwatch();
        detach();
        document.getElementById(styleId)?.remove();
        return;
      }
      repair();
      watch();
    },
    dispose() {
      unwatch();
      detach();
      document.getElementById(styleId)?.remove();
      disposed = true;
      if (window[key] === runtime) delete window[key];
    },
  };
  window[key] = runtime;
  runtime.update(config);
  return "Weather top bar ready";
}
