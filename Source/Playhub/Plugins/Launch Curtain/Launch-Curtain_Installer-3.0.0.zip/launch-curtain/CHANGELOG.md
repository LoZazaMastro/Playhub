3.0.0

Added support for Playhub 3.0.0.

2.5.6

Fixed Soundbite download validation and interrupted saves. Fixed unused Soundbite and background cleanup while preserving shared, local and active files.

2.5.5

Fixed Xbox game detection and foreground handoff during loading.

2.5.4

Fixed the loading screen staying visible when a controller press does not start a game. Unconfirmed attempts close within three seconds. Confirmed launches keep their normal loading screen, including games that start slowly.

2.5.3

Fixed unnecessary process and window scans between launches and after the game receives focus. Game exit detection and the return to Steam remain active. Modern mode no longer starts the unused black cover helper.
