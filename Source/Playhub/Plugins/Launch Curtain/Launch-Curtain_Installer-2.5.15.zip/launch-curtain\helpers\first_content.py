# SPDX-License-Identifier: MIT
"""LC's private rendered-Main receipt and owned Agent cover publisher.

Only observe(), wired to the retained original Main render callback, can mint.
No public RPC accepts a HWND, publisher PID, game identity or a ready boolean.
"""
from __future__ import annotations
import asyncio
import time
import uuid
from urllib.error import HTTPError


def _hex(value):
    return isinstance(value, str) and len(value) == 32 and all(c in '0123456789abcdef' for c in value)


class FirstContent:
    def __init__(self, native, publish, clock=time.monotonic, report=lambda text: None, tick=None):
        self.native, self.publish, self.clock = native, publish, clock
        self.report = report
        self.tick = tick if tick is not None else lambda: int(clock() * 1000)
        self.revision = 0
        self.launch = None
        self.receipt = None
        self.retired = set()
        self.task = None
        self.result = None
        self.finish_requested = False
        self.trace_seen = set()
        self.visual = None
        self.release_completion = None

    def trace(self, stage):
        # Constant diagnostic labels only; no payload, token, nonce or path.
        if stage not in self.trace_seen and len(self.trace_seen) < 24:
            self.trace_seen.add(stage)
            try:
                self.report('First-content source stage=' + stage)
            except Exception:
                pass

    def begin(self, app_id, epoch, owner, trigger):
        self.retire()
        self.release_completion = None
        self.revision += 1
        self.launch = {'appId': app_id, 'requestEpoch': str(epoch), 'requestId': uuid.uuid4().hex,
                       'challenge': uuid.uuid4().hex, 'revision': str(self.revision), 'owner': owner, 'triggerAt': trigger}
        self.result = None
        self.finish_requested = False
        self.trace_seen = set()
        self.trace('begin')

    def status(self):
        if self.launch is not None and self.result is None:
            self.trace('status-offered')
        return dict(self.launch) if self.launch is not None and self.result is None else None

    def observe(self, payload):
        self.trace('observe-entered')
        if not isinstance(payload, dict) or set(payload) != {'action', 'requestId', 'challenge', 'revision', 'receipt'}:
            return {'ok': False}
        if payload['action'] == 'released':
            value = self.release_completion
            if (not isinstance(value, dict) or self.revision != value['revision']
                    or self.launch not in (None, value['launch'])
                    or any(payload[key] != value['launch'][key] for key in ('requestId', 'challenge', 'revision'))
                    or payload['receipt'] != value['nonce']):
                return {'ok': False}
            value['frontend_hidden'] = True
            self._try_release(value)
            return {'ok': True}
        launch = self.launch
        if (launch is None or self.result is not None or payload['action'] not in ('rendered', 'renew', 'revoke')
                or any(payload[key] != launch[key] for key in ('requestId', 'challenge', 'revision'))
                or not _hex(payload['receipt'])):
            return {'ok': False}
        nonce = payload['receipt']
        if payload['action'] == 'revoke':
            self.retired.add(nonce)
            if self.receipt is not None and self.receipt['nonce'] == nonce:
                self.receipt = None
                self.result = 'revoked'
            return {'ok': True}
        if nonce in self.retired:
            return {'ok': False}
        if self.receipt is None:
            if payload['action'] != 'rendered':
                return {'ok': False}
            started = self.clock()
            native = self.native(None, True)
            self.trace('native-mint-refused' if native is None else 'native-mint-current')
            if native is None or self.launch is not launch or self.clock() < started or self.clock() - started > .25:
                self.retired.add(nonce)
                return {'ok': False}
            self.receipt = {'nonce': nonce, 'native': native, 'expires': self.clock() + .7, 'observedTick': self.tick(), 'launch': launch}
            self.trace('publisher-task-created')
            self.task = asyncio.create_task(self._run(self.receipt))
        else:
            held = self.receipt
            if (held['nonce'] != nonce or held['launch'] is not launch or held['expires'] <= self.clock()
                    or self.native(held['native'], False) is not held['native'] or self.launch is not launch
                    or self.receipt is not held or held['expires'] <= self.clock()):
                self.retired.add(held['nonce'])
                self.receipt = None
                self.result = 'revoked'
                return {'ok': False}
            held['expires'] = self.clock() + .7
            held['observedTick'] = self.tick()
        return {'ok': True}

    def current(self, held):
        # Diagnostic latch only: exact original predicate order/call counts.
        held['_currentFailure'] = None
        def check(ok, reason):
            if not ok:
                held['_currentFailure'] = reason
            return ok
        return (check(self.receipt is held, 'receipt-not-current')
                and check(self.launch is held['launch'], 'launch-replaced')
                and check(self.result is None, 'result-terminal')
                and check(held['nonce'] not in self.retired, 'nonce-retired')
                and check(held['expires'] > self.clock(), 'render-expired')
                and check(self.native(held['native'], False) is held['native'], 'native-source')
                and check(self.receipt is held, 'receipt-changed-after-source')
                and check(self.launch is held['launch'], 'launch-changed-after-source')
                and check(held['expires'] > self.clock(), 'render-expired-after-source'))

    def visual_status(self):
        # Read-only evidence for retaining this same artwork, never a Ready,
        # focus, input or game-candidate grant. No caller may supply this tuple.
        value = self.visual
        if not isinstance(value, dict):
            return None
        held = value['held']
        now = self.clock()
        if (now < value['received'] or now > value['validUntil']
                or not self.current(held)):
            return None
        now = self.clock()
        if (self.visual is not value or now < value['received'] or now > value['validUntil']
                or self.receipt is not held or self.launch is not held['launch']):
            return None
        return {**value['identity'], '_record': value}

    def visual_current(self, status):
        # Final cheap barrier after the caller's last native app-ID read.
        value = self.visual
        if not isinstance(status, dict) or not isinstance(value, dict) or status.get('_record') is not value:
            return False
        held, now = value['held'], self.clock()
        return (self.receipt is held and self.launch is held['launch'] and self.result is None
                and held['nonce'] not in self.retired and held['expires'] > now
                and value['received'] <= now <= value['validUntil'])

    def handoff_status(self):
        # The original DOM cover may yield only to this same, currently Presented
        # native cover after actual opaque content; this grants no game readiness.
        status = self.visual_status()
        return {**status, 'gameWindow': status['_record']['gameWindow']} if status is not None and status['_record'].get('contentObserved') is True else None

    def handoff_current(self, status):
        return (isinstance(status, dict) and isinstance(status.get('_record'), dict)
                and status['_record'].get('contentObserved') is True
                and status.get('gameWindow') == status['_record'].get('gameWindow') and self.visual_current(status))

    def capture_unavailable_cleaned(self):
        value = self.release_completion
        return bool(isinstance(value, dict) and value.get('capture_unavailable') is True
                    and value.get('closed') is True and self.result == 'retired'
                    and value['launch'] is self.launch and value['revision'] == self.revision)

    def retired_capture_cleaned(self, pid, birth):
        value = self.release_completion
        return bool(isinstance(value, dict) and value.get('geometry_retired') is True
                    and value.get('gamePid') == pid and value.get('gameBirth') == birth
                    and value.get('closed') is True and self.result == 'retired'
                    and value['launch'] is self.launch and value['revision'] == self.revision)

    async def _run(self, held):
        lease = None
        launch = held['launch']
        last_state = None
        observed = False
        finish_sent = False
        reoffers = 0
        reoffer_after_tick = None
        withdrawn_lease = None
        exit_reason = 'local-current'
        last_diagnostic = ' last_reply_state=none last_native_phase=-1 last_native_stage=-1 last_render_remaining_ms=-1'
        try:
            while self.current(held):
                if reoffer_after_tick is not None:
                    # Only a real original-Main render callback can advance
                    # this tick. No time resampling, nonce or deadline renewal.
                    if held['observedTick'] <= reoffer_after_tick:
                        await asyncio.sleep(.025)
                        continue
                    withdrawn_lease = lease
                    lease = None
                    observed = finish_sent = False
                    reoffer_after_tick = None
                    reoffers += 1
                    self.visual = None
                    self.trace('geometry-reoffer')
                if lease is None:
                    body = {'protocol': 1, 'action': 'begin', 'appId': launch['appId'],
                            'requestId': launch['requestId'], 'requestEpoch': launch['requestEpoch'],
                            'sourceReceipt': held['nonce'], 'surfaceRevision': launch['revision'],
                            'sourceObservedAt': str(held['observedTick']), **held['native']['wire']}
                else:
                    body = {'protocol': 1, 'action': 'finish' if observed and self.finish_requested and not finish_sent else 'renew', 'requestId': launch['requestId'],
                            'requestEpoch': launch['requestEpoch'], 'lease': lease, 'sourceObservedAt': str(held['observedTick'])}
                self.trace('publish-' + body['action'])
                try:
                    reply = await self.publish(body)
                except HTTPError as error:
                    # The server's bounded association lookup can time out while
                    # a genuine launch is still starting. Retry only an exact
                    # unacknowledged begin; the original Main receipt, native
                    # identity, epoch and 700 ms freshness still govern it.
                    if error.code != 408 or body['action'] != 'begin' or lease is not None or reoffers:
                        raise
                    self.trace('begin-408-retry')
                    if not self.current(held):
                        break
                    await asyncio.sleep(.1)
                    continue
                self.trace('reply-unavailable' if isinstance(reply, dict) and reply.get('available') is False else 'reply-ok' if isinstance(reply, dict) and reply.get('ok') is True else 'reply-not-admitted')
                if isinstance(reply, dict) and reply.get('ok') is not True:
                    reasons = {'publisher-channel-unverified', 'rendered-source-stale', 'launch-request-stale',
                               'publisher-channel-mismatch', 'receipt-not-current', 'rendered-source-regressed',
                               'stopping', 'rendered-source-retired', 'rendered-source-replaced',
                               'native-pins-unavailable', 'owned-cleanup-pending', 'retained-source-unavailable',
                               'request-replaced', 'component-or-source-unavailable'}
                    reason = reply.get('reason')
                    self.trace('reply-reason-' + (reason if isinstance(reason, str) and reason in reasons else 'unknown'))
                # A late reply never re-creates a revoked local render receipt.
                if not self.current(held):
                    if isinstance(reply, dict) and _hex(reply.get('lease')):
                        lease = reply['lease']
                    break
                if isinstance(reply, dict) and reply.get('available') is False:
                    exit_reason = 'agent-unavailable'
                    self.result = 'unavailable'
                    break
                if isinstance(reply, dict) and reply.get('reason') in ('rendered-source-retired', 'rendered-source-replaced', 'receipt-not-current', 'request-replaced'):
                    exit_reason = 'agent-request-revoked'
                    self.result = 'revoked'
                    break
                if reoffers and body['action'] == 'begin' and (not isinstance(reply, dict) or reply.get('ok') is not True or not _hex(reply.get('lease'))):
                    exit_reason = 'geometry-reoffer-refused'
                    break
                if isinstance(reply, dict) and reply.get('ok') is True and _hex(reply.get('lease')):
                    if (reply.get('requestId') != launch['requestId'] or reply.get('requestEpoch') != launch['requestEpoch']
                            or reply.get('appId') != launch['appId'] or reply.get('gameReadyClaimed') is not False
                            or reply.get('inputAuthorityClaimed') is not False):
                        exit_reason = 'reply-lineage'
                        break
                    if ((body['action'] != 'begin' and reply['lease'] != lease)
                            or (reoffers and body['action'] == 'begin' and reply['lease'] == withdrawn_lease)):
                        exit_reason = 'reply-lease'
                        break
                    if withdrawn_lease is not None:
                        self.release_completion = None
                    lease = reply['lease']
                    withdrawn_lease = None
                    if body['action'] == 'finish' and reply.get('finishRequested') is True:
                        finish_sent = True
                    self.visual = None
                    game_pid, game_birth, age = reply.get('gamePid'), reply.get('gameBirth'), reply.get('sourceProofAgeMs')
                    game_window = reply.get('gameWindow')
                    handoff_window = (int(game_window) if isinstance(game_window, str) and game_window.isascii()
                        and game_window.isdecimal() and 0 < len(game_window) <= 19
                        and 0 < int(game_window) <= 0x7fffffffffffffff else 0)
                    if (reply.get('state') in ('presented', 'first-content-observed') and reply.get('nativePhase') == 2
                            and type(age) is int and 0 <= age <= 250
                            and type(game_pid) is int and 0 < game_pid <= 0x7fffffff
                            and isinstance(game_birth, str) and game_birth.isascii() and game_birth.isdecimal()
                            and 0 < len(game_birth) <= 19 and 0 < int(game_birth) <= 0x7fffffffffffffff):
                        received = self.clock()
                        self.visual = {'held': held, 'received': received, 'validUntil': received + (250 - age) / 1000,
                                       'identity': {'appId': launch['appId'], 'gamePid': game_pid, 'gameBirth': int(game_birth)},
                                       'gameWindow': handoff_window,
                                       'contentObserved': (handoff_window > 0 and reply.get('nativePresented') is True
                                           and type(reply.get('nativePhase')) is int and reply['nativePhase'] == 2
                                           and reply.get('state') == 'first-content-observed'
                                           and reply.get('currentFailure') is None and reply.get('retirementCheck') == 'fresh'
                                           and type(reply.get('captureSamples')) is int and reply['captureSamples'] > 0
                                           and type(reply.get('captureOpaqueSamples')) is int
                                           and 0 < reply['captureOpaqueSamples'] <= reply['captureSamples'])}
                    if (reply.get('cleanupComplete') is True and reply.get('nativePhase') == 0
                            and reply.get('state') in ('first-content-observed', 'retired')):
                        self.release_completion = {'launch': launch, 'revision': self.revision, 'nonce': held['nonce'],
                                                   'lease': lease, 'backend_hidden': False, 'frontend_hidden': False,
                                                   'closed': False, 'sent': False,
                                                   'capture_unavailable': (reply.get('retireReason') == 'CaptureUnavailable'
                                                       and reply.get('captureState') == 'Unavailable' and reply.get('currentFailure') is None),
                                                   'geometry_retired': (reply.get('currentFailure') == 'game-window'
                                                       and reply.get('retireReason') in ('Canceled', 'SourceLost')
                                                       and reply.get('finishRequested') is False and type(game_pid) is int and game_pid > 0
                                                       and isinstance(game_birth, str) and game_birth.isascii() and game_birth.isdecimal()
                                                       and 0 < len(game_birth) <= 19 and 0 < int(game_birth) <= 0x7fffffffffffffff),
                                                   'gamePid': game_pid, 'gameBirth': int(game_birth) if isinstance(game_birth,str) and game_birth.isascii() and game_birth.isdecimal() and len(game_birth)<=19 else 0}
                    state = (reply.get('state'), reply.get('nativePhase'), reply.get('cleanupComplete'), reply.get('retireReason'), reply.get('currentFailure'), reply.get('captureState'), reply.get('captureObserverState'), reply.get('captureObserverStage'), reply.get('captureRejectReason'), type(reply.get('captureOpaqueSamples')) is int and reply['captureOpaqueSamples'] > 0, reply.get('retirementCheck'))
                    if state != last_state:
                        last_state = state
                        safe = state[0] if state[0] in ('preparing', 'presented', 'first-content-observed', 'retired') else 'unknown'
                        phase = state[1] if type(state[1]) is int and 0 <= state[1] <= 3 else -1
                        retire = reply.get('retireReason')
                        retire = retire if retire in ('FirstObservedContent', 'SourceLost', 'CaptureUnavailable', 'Canceled') else 'none'
                        failure = reply.get('currentFailure')
                        failure = failure if failure in ('controller-disposed', 'session-replaced', 'session-retired', 'lease-expired', 'render-receipt-expired', 'session-canceled',
                            'controller-disposed-after-source', 'session-replaced-after-source', 'session-retired-after-source', 'lease-expired-after-source', 'render-receipt-expired-after-source', 'session-canceled-after-source',
                            'retained-source', 'heartbeat-or-native-publish', 'association-refresh', 'retained-disposed', 'game-source', 'publisher-process', 'steam-process', 'game-process', 'frame-process',
                            'native-finish-rejected', 'native-finish-incomplete', 'dpi-context', 'game-foreground-proof', 'game-window', 'steam-window', 'game-source-after-windows', 'publisher-process-after-windows', 'steam-process-after-windows',
                            'frame-process-after-windows', 'game-process-after-windows', 'foreground-window') else 'none'
                        capture = reply.get('captureState')
                        capture = capture if capture in ('Pending', 'Facts', 'SourceLost', 'Unavailable', 'IdentityChanged', 'Invalid') else 'none'
                        def numeric(key):
                            value = reply.get(key)
                            return value if type(value) is int and -0x80000000 <= value <= 0xffffffff else -1
                        def label(key, allowed):
                            value = reply.get(key)
                            return value if isinstance(value, str) and value in allowed else 'none'
                        observer = label('captureObserverState', ('frame-facts', 'no-fresh-frame', 'identity-changed', 'unsupported', 'unavailable', 'access-denied', 'canceled', 'unknown'))
                        observer_stage = label('captureObserverStage', ('bind', 'qpc', 'native-guard-open', 'native-guard-current', 'geometry', 'capture-item-factory', 'create-for-window',
                            'item-size', 'frame-pool', 'create-session', 'cursor-disable', 'cursor-readback', 'native-guard-before-start', 'start-capture', 'frame', 'different-target', 'geometry-changed',
                            'client-crop', 'surface', 'format-or-size', 'readback', 'final-currentness'))
                        retirement = label('retirementCheck', ('fresh', 'future-frame', 'expired-frame', 'source-not-current', 'observer-retired'))
                        rejection = label('captureRejectReason', ('source-not-current', 'hello-unavailable', 'hello-contract', 'response-unavailable', 'envelope', 'state-contract', 'native-state',
                            'transport-timeout', 'json', 'transport-io', 'target-invalid', 'source-before-frame', 'authority-flags', 'frame-state', 'source-current-flag', 'foreground-flag',
                            'format', 'target-identity', 'frame-time-fields', 'geometry-or-statistics', 'source-after-frame', 'receiver-frame-time', 'none'))
                        last_diagnostic = (f' last_reply_state={safe} last_native_phase={phase} last_native_stage={numeric("nativeStage")}'
                            f' last_retire_reason={retire} last_current_failure={failure} last_capture_state={capture}'
                            f' last_render_remaining_ms={numeric("renderReceiptRemainingMs")} last_lease_remaining_ms={numeric("leaseRemainingMs")}'
                            f' last_finish_requested={reply.get("finishRequested") is True}'
                            f' last_samples={numeric("captureSamples")} last_opaque={numeric("captureOpaqueSamples")}'
                            f' last_retirement_check={retirement} last_retirement_age_ms={numeric("retirementFrameAgeMs")} last_post_read_elapsed_ms={numeric("retirementPostReadElapsedMs")}')
                        self.report(f'First-content cover state={safe} native_phase={phase} retire_reason={retire} current_failure={failure} capture_state={capture}'
                            f' native_stage={numeric("nativeStage")} native_error={numeric("nativeError")} native_result={numeric("nativeResult")} native_flags={numeric("nativeFlags")}'
                            f' observer_state={observer} observer_stage={observer_stage} capture_reject={rejection}'
                            f' capture_hresult={numeric("captureHresult")} capture_error={numeric("captureWinError")} receiver_frame_age_ms={numeric("captureReceiverFrameAgeMs")}'
                            f' lease_remaining_ms={numeric("leaseRemainingMs")} render_remaining_ms={numeric("renderReceiptRemainingMs")}'
                            f' samples={numeric("captureSamples")} opaque={numeric("captureOpaqueSamples")} retirement_check={retirement}'
                            f' retirement_age_ms={numeric("retirementFrameAgeMs")} post_read_elapsed_ms={numeric("retirementPostReadElapsedMs")}'
                            f' finish_requested={reply.get("finishRequested") is True}; no game-ready/input claim')
                    # The report callback is external. A reentrant new launch
                    # may not receive the old reply's result or retry state.
                    if self.receipt is not held or self.launch is not launch or self.result is not None:
                        exit_reason = 'reply-owner-replaced'
                        break
                    terminal_cleanup = (reply.get('cleanupComplete') is True
                        and type(reply.get('nativePhase')) is int and reply['nativePhase'] == 0
                        and reply.get('state') in ('first-content-observed', 'retired'))
                    # Cleanup is not a completed launch. It may precede any
                    # content, or withdraw an old geometry before audio ends.
                    completed = (terminal_cleanup and self.finish_requested and finish_sent
                        and reply.get('finishRequested') is True and reply.get('nativeFinishComplete') is True
                        and reply.get('retireReason') == 'Canceled'
                        and reply.get('currentFailure') is None and reply.get('retirementCheck') == 'fresh'
                        and type(reply.get('captureSamples')) is int
                        and type(reply.get('captureOpaqueSamples')) is int
                        and 0 < reply['captureOpaqueSamples'] <= reply['captureSamples'])
                    if completed:
                        exit_reason = 'finish-complete'
                        self.result = 'first-content-observed'
                        break
                    geometry_withdrawn = (reply.get('currentFailure') == 'game-window'
                        and reply.get('state') in ('first-content-observed', 'retired'))
                    if geometry_withdrawn:
                        observed = False
                    if terminal_cleanup:
                        remaining, render = reply.get('leaseRemainingMs'), reply.get('renderReceiptRemainingMs')
                        if (geometry_withdrawn and not finish_sent and reply.get('finishRequested') is False
                                and reply.get('retireReason') in ('Canceled', 'SourceLost') and reoffers < 2
                                and type(remaining) is int and remaining > 0 and type(render) is int and render > 0):
                            self.visual = None
                            reoffer_after_tick = int(body['sourceObservedAt'])
                            self.trace('geometry-reoffer-wait-render')
                            continue
                        exit_reason = 'agent-retired-without-completed-finish'
                        self.result = 'retired'
                        break
                    if reply.get('state') == 'first-content-observed' and not geometry_withdrawn:
                        observed = True
                    elif reply.get('state') == 'retired':
                        exit_reason = 'agent-retired'
                        self.result = 'retired'
                        break
                # Admission can spend most of the original render receipt on
                # retained-source I/O. If Main actually renewed that SAME
                # receipt while begin was in flight, forward its recorded tick
                # immediately. Never resample time or extend a receipt here.
                if (body['action'] == 'begin' and lease is not None
                        and held['observedTick'] > int(body['sourceObservedAt'])):
                    self.trace('bootstrap-fresh-render-renew')
                    continue
                # No native admission before the existing server association and game FG exist.
                await asyncio.sleep(.1)
        except asyncio.CancelledError:
            exit_reason = 'publisher-canceled'
            raise
        except (OSError, ValueError, asyncio.TimeoutError) as error:
            exit_reason = 'publisher-exception'
            self.trace('publisher-exception')
            kind = type(error).__name__
            self.trace('publisher-error-' + (kind if kind in {'HTTPError', 'URLError', 'TimeoutError', 'ValueError', 'OSError'} else 'other'))
            code = getattr(error, 'code', None)
            if type(code) is int and code in {400, 401, 403, 408, 409, 429, 500, 502, 503, 504}:
                self.trace('publisher-http-' + str(code))
        finally:
            # Exactly one uncapped terminal line per publisher task. Only
            # constant labels, booleans and already-cached safe scalar facts.
            failure = held.get('_currentFailure')
            allowed = {'receipt-not-current', 'launch-replaced', 'result-terminal', 'nonce-retired',
                       'render-expired', 'native-source', 'receipt-changed-after-source',
                       'launch-changed-after-source', 'render-expired-after-source'}
            failure = failure if failure in allowed else 'none'
            try:
                self.report(f'First-content publisher terminal reason={exit_reason} local_failure={failure}'
                    f' finish_requested={self.launch is launch and self.finish_requested is True} lease_held={lease is not None}' + last_diagnostic)
            except Exception:
                pass
            if isinstance(self.visual, dict) and self.visual.get('held') is held:
                self.visual = None
            self.retired.add(held['nonce'])
            if self.launch is launch and self.result is None:
                self.result = 'retired'
            if self.receipt is held:
                self.receipt = None
            cleanup_lease = lease if lease is not None else withdrawn_lease
            if cleanup_lease is not None:
                try:
                    reply = await self.publish({'protocol': 1, 'action': 'close', 'requestId': launch['requestId'],
                                                'requestEpoch': launch['requestEpoch'], 'lease': cleanup_lease})
                    value = self.release_completion
                    if (isinstance(value, dict) and value['launch'] is launch and value['lease'] == cleanup_lease
                            and isinstance(reply, dict) and reply.get('ok') is True and reply.get('state') == 'closed'):
                        value['closed'] = True
                        self._try_release(value)
                except (OSError, ValueError, asyncio.TimeoutError):
                    pass  # The Agent's independent 1 s intent and 250 ms source pulse expire.

    def hidden(self, launch):
        # Called only after hide_curtain has completed all native/audio cleanup.
        # DOM removal is a separate original-Main acknowledgement below.
        value = self.release_completion
        if (not isinstance(value, dict) or launch is not value['launch']
                or self.revision != value['revision'] or self.launch is not None):
            return
        value['backend_hidden'] = True
        self._try_release(value)

    def _try_release(self, value):
        if (self.release_completion is value and self.revision == value['revision']
                and self.launch in (None, value['launch']) and value['closed']
                and value['backend_hidden'] and value['frontend_hidden'] and not value['sent']):
            value['sent'] = True
            asyncio.create_task(self._release(value))

    async def _release(self, value):
        if (self.release_completion is not value or self.revision != value['revision']
                or self.launch is not None):
            return
        launch = value['launch']
        try:
            await self.publish({'protocol': 1, 'action': 'released', 'requestId': launch['requestId'],
                                'requestEpoch': launch['requestEpoch'], 'lease': value['lease']})
        except (OSError, ValueError, asyncio.TimeoutError):
            pass  # Missing acknowledgement keeps the scoped shell; never assume closed.

    async def finish(self):
        # Backend-only call after exact game focus, configured minimum and audio
        # completion. This cannot mint a lease or claim first-frame readiness.
        held, launch = self.receipt, self.launch
        if self.result is not None:
            return 'completed' if self.result == 'first-content-observed' else 'terminated'
        if held is None or launch is None or self.task is None or self.task.done():
            return 'unavailable'
        self.finish_requested = True
        for _ in range(50):
            if self.receipt is not held or self.launch is not launch or self.result is not None:
                break
            await asyncio.sleep(.025)
        if self.launch is not launch:
            return 'replaced'
        if self.result == 'first-content-observed':
            return 'completed'
        if self.result is not None or self.receipt is not held or self.task.done():
            return 'terminated'
        # A bounded wait is not a completed handoff. The same publisher keeps
        # only its existing current lease; the monitor must retain this launch.
        return 'pending'

    def retire(self):
        self.visual = None
        if self.receipt is not None:
            self.retired.add(self.receipt['nonce'])
        self.receipt = None
        self.launch = None
        self.result = None
        # Do not cancel a shared Decky caller or leave a late begin reply unclosed.
        # The owned task sees revocation after its bounded request and closes its lease.

