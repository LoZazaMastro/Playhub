import json
import logging
import os
import urllib.parse
from concurrent.futures import ThreadPoolExecutor
from multiprocessing import cpu_count
from time import sleep
import nile.utils.download as dl_utils
from nile.models import manifest, hash_pairs, patch_manifest
from nile.downloading.progress import ProgressBar
from nile.downloading.worker import DownloadWorker
from nile.utils.config import ConfigType
from nile import constants

class DownloadManager:
    def __init__(self, config_manager, library_manager, session_manager, game):
        self.config = config_manager
        self.library_manager = library_manager
        self.session = session_manager
        self.game = game
        self.progress_bar = None
        self.logger = logging.getLogger("DOWNLOAD")
        self.logger.debug("Initialized Download Manager")

        self.manifest = None
        self.old_manifest = None
        self.threads = []

    def get_manifest(self):
        game_manifest = self.library_manager.get_game_manifest(self.game["id"])
        self.logger.debug("Got download manifest")
        self.version = game_manifest["versionId"]
        self.downloadUrl = game_manifest["downloadUrl"]

        url = urllib.parse.urlparse(self.downloadUrl)
        url = url._replace(path=url.path + '/manifest.proto')

        url = urllib.parse.urlunparse(url)
        self.logger.debug("Getting protobuff manifest")
        response = self.session.session.get(url)
        r_manifest = manifest.Manifest()
        self.logger.debug("Parsing manifest data")
        r_manifest.parse(response.content)
        self.protobuff_manifest = response.content
        return r_manifest

    def get_patchmanifest(self, comparison: manifest.ManifestComparison):
        self.logger.info("Generating patches, this might take a second...")
        hash_pair_builder = hash_pairs.PatchBuilder(comparison)
        hash_pair_builder.build_hashpairs()
        patches = []
        for hash_pair in hash_pair_builder.get_next_hashes():
            patches.extend(
                self.library_manager.get_patches(
                    self.game["id"], self.version, hash_pair
                )
            )

        return patch_manifest.PatchManifest.build_patch_manifest(comparison, patches)

    def get_installed_version(self):
        installed_games = self.config.get("installed")
        if installed_games:
            for game in installed_games:
                if self.game["product"]["id"] == game["id"]:
                    return game["version"]
        return None

    def load_installed_manifest(self):
        old_manifest_pb = self.config.get(f"manifests/{self.game['product']['id']}", cfg_type=ConfigType.RAW)
        old_manifest = None
        if old_manifest_pb:
            old_manifest = manifest.Manifest()
            old_manifest.parse(old_manifest_pb)
        return old_manifest

    def download(self, force_verifying=False, base_install_path="", install_path=""):
        game_location = base_install_path
        directory_name = self.game['product'].get("title") or self.game['product']['id']
        directory_name = dl_utils.save_directory_name(directory_name)
        if not base_install_path:
            game_location = install_path
        else:
            game_location = os.path.join(
                base_install_path,
                directory_name,
            )
        if not base_install_path and not install_path:
            game_location = os.path.join(
                constants.DEFAULT_INSTALL_PATH,
                directory_name,
            )
        saved_location = self.library_manager.get_installed_game_info(
            self.game["id"]
        ).get("path")
        if saved_location:
            game_location = saved_location

        self.install_path = game_location
        if not force_verifying:
            self.manifest = self.get_manifest()
            self.old_manifest = self.load_installed_manifest()
        else:
            self.logger.debug("Loading manifest from the disk")
            self.version = self.get_installed_version()
            self.manifest = self.load_installed_manifest()

        if not self.manifest:
            self.logger.error("Unable to load manifest")
            return
        self.logger.debug(f"Number of packages: {len(self.manifest.packages)}")

        comparison = manifest.ManifestComparison.compare(
            self.manifest, self.old_manifest
        )

        if len(comparison.new) == 0:
            self.logger.info("Game is up to date")
            self.finish(False)
            return
        total_size = sum(f.size for f in comparison.new)
        self.info()

        if not dl_utils.check_available_space(total_size, game_location):
            self.logger.error("Not enough space available")
            return

        readable_size = dl_utils.get_readable_size(total_size)

        self.progress_bar = ProgressBar(total_size, f"{round(readable_size[0],2)}{readable_size[1]}")
        self.progress_bar.start()

        self.thpool = ThreadPoolExecutor(max_workers=6)
        for f in comparison.new:
            file_path = os.path.join(
                game_location, f.path.replace("\\", "/")
            )
            dir, _ = os.path.split(file_path)
            if not os.path.exists(dir):
                os.makedirs(dir)
            url = urllib.parse.urlparse(self.downloadUrl)
            url = url._replace(path=url.path + '/files/' + f.hash.value)
            url = urllib.parse.urlunparse(url)
            worker = DownloadWorker(url, f, game_location, self.session, self.progress_bar)
            # worker.execute()
            self.threads.append(self.thpool.submit(worker.execute))

        while True:
            is_done = False
            for thread in self.threads:
                is_done = thread.done()
                if is_done == False:
                    break
            if is_done:
                break
            # self.progressbar.print()
            sleep(0.5)

        for f in comparison.removed:
            file_path = os.path.join(game_location, f.path.replace("\\", "/"))
            if os.path.exists(file_path):
                os.remove(file_path)

        self.progress_bar.completed = True
        self.finish(force_verifying)

    def info(self, json_format=False):
        self.manifest = self.get_manifest()

        if not self.manifest:
            self.logger.error("Unable to load manifest")
            return
        self.logger.debug(f"Number of packages: {len(self.manifest.packages)}")

        total_size = sum(f.size for f in self.manifest.packages[0].files)
        if json_format:
            output = {
                'download_size': total_size
            }
            print(json.dumps(output))
        else:
            readable_size = dl_utils.get_readable_size(total_size)
            self.logger.info(
                f"Download size: {round(readable_size[0],2)}{readable_size[1]}"
            )

    def finish(self, verifying):
        # Save manifest to the file

        self.config.write(
            f"manifests/{self.game['product']['id']}", self.protobuff_manifest, cfg_type=ConfigType.RAW
        )

        # Save data to installed.json file
        installed_array = self.config.get("installed")

        if not installed_array:
            installed_array = list()

        total_size = sum(f.size for f in self.manifest.packages[0].files)

        # If we verify we don't want to overwrite version or path
        if verifying:
            for game in installed_array:
                if game["id"] == self.game["product"]["id"]:
                    game.update({"size": total_size})
                    break

            self.config.write("installed", installed_array)
            return
        installed_game_data = dict(
            id=self.game["product"]["id"], version=self.version, path=self.install_path, size=total_size
        )
        updated = False
        # Swap existing entry in case of updating etc..
        for i, game in enumerate(installed_array):
            if game["id"] == self.game["product"]["id"]:
                installed_array[i] = installed_game_data
                updated = True
                break

        if not updated:
            installed_array.append(installed_game_data)

        self.config.write("installed", installed_array)
