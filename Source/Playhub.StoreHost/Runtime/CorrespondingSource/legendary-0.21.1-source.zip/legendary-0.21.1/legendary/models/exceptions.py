
class InvalidCredentialsError(Exception):
    pass
