from __future__ import annotations

from dataclasses import dataclass
from enum import Flag, auto
from pathlib import PurePath


class BaseDiff:
    def __init__(self):
        self.deleted = []
        self.new = []
        self.changed = []
        self.redist = []
        self.removed_redist = []

        self.links = [] # Unix only

    def __str__(self):
        return f"Deleted: {len(self.deleted)} New: {len(self.new)} Changed: {len(self.changed)}"

class TaskFlag(Flag):
    NONE = 0
    SUPPORT = auto()
    OPEN_FILE = auto()
    CLOSE_FILE = auto()
    CREATE_FILE = auto()
    CREATE_SYMLINK = auto()
    RENAME_FILE = auto()
    COPY_FILE = auto()
    DELETE_FILE = auto()
    OFFLOAD_TO_CACHE = auto()
    MAKE_EXE = auto()
    PATCH = auto()
    RELEASE_MEM = auto()
    ZIP_DEC = auto()

@dataclass
class MemorySegment:
    offset: int
    end: int

    @property
    def size(self):
        return self.end - self.offset

@dataclass
class ChunkTask:
    product: str
    index: int

    compressed_md5: str
    md5: str
    size: int
    download_size: int
    
    cleanup: bool = False
    offload_to_cache: bool = False
    old_offset: int | None = None
    old_flags: TaskFlag = TaskFlag.NONE 
    old_file: str | None = None

@dataclass
class V1Task:
    product: str
    index: int
    offset: int
    size: int
    md5: str
    cleanup: bool | None = True

    old_offset: int | None = None
    offload_to_cache: bool | None = False
    old_flags: TaskFlag = TaskFlag.NONE 
    old_file: str | None = None

    # This isn't actual sum, but unique id of chunk we use to decide 
    # if we should push it to writer
    @property
    def compressed_md5(self):
        return self.md5 + "_" + str(self.index)

@dataclass
class FileTask:
    path: str
    flags: TaskFlag

    old_flags: TaskFlag = TaskFlag.NONE 
    old_file: str | None = None

    patch_file: str | None = None


@dataclass
class TerminateWorker:
    pass

class FileExclusion:
    def matches(file, excludelist):
        return any(PurePath(file).full_match(pattern) for pattern in excludelist)