import datetime
import gzip
import hashlib
import logging
import os
import sys
import urllib.parse
from enum import Enum

import requests

from gogdl import constants
from gogdl.dl import dl_utils

LOCAL_TIMEZONE = datetime.datetime.utcnow().astimezone().tzinfo


class SyncAction(Enum):
    DOWNLOAD = 0
    UPLOAD = 1
    CONFLICT = 2
    NONE = 3


class SyncFile:
    def __init__(self, path, abs_path, md5=None, update_time=None):
        self.relative_path = path.replace('\\', '/')  # cloud file identifier
        self.absolute_path = abs_path
        self.md5 = md5
        self.update_time = update_time
        self.update_ts = (
            datetime.datetime.fromisoformat(update_time).astimezone().timestamp()
            if update_time
            else None
        )

    def get_file_metadata(self):
        ts = os.stat(self.absolute_path).st_mtime
        date_time_obj = datetime.datetime.fromtimestamp(
            ts, tz=LOCAL_TIMEZONE
        ).astimezone(datetime.timezone.utc)
        with open(self.absolute_path, "rb") as file:
            self.md5 = hashlib.md5(
                gzip.compress(file.read(), 6, mtime=0)
            ).hexdigest()

        self.update_time = date_time_obj.isoformat(timespec="seconds")
        self.update_ts = date_time_obj.timestamp()

    def __repr__(self):
        return f"{self.md5} {self.relative_path}"


class CloudStorageManager:
    def __init__(self, api_handler, authorization_manager):
        self.api = api_handler
        self.auth_manager = authorization_manager
        self.session = requests.Session()
        self.logger = logging.getLogger("SAVES")

        self.session.headers.update(
            {"User-Agent": "GOGGalaxyCommunicationService/2.0.13.27 (Windows_32bit) dont_sync_marker/true installation_source/gog",
             "X-Object-Meta-User-Agent": "GOGGalaxyCommunicationService/2.0.13.27 (Windows_32bit) dont_sync_marker/true installation_source/gog"}
        )

        self.credentials = {}
        self.client_id = ''
        self.client_secret = ''

    def create_directory_map(self, path: str) -> list:
        """
        Creates list of every file in directory to be synced
        """
        files = []
        directory_contents = os.listdir(path)

        for content in directory_contents:
            abs_path = os.path.join(path, content)
            if os.path.isdir(abs_path):
                files.extend(self.create_directory_map(abs_path))
            else:
                files.append(abs_path)
        return files

    @staticmethod
    def get_relative_path(root: str, path: str) -> str:
        if not root.endswith("/") and not root.endswith("\\"):
            root = root + os.sep
        return path.replace(root, "")

    def sync(self, arguments, unknown_args):
        prefered_action = arguments.prefered_action
        self.sync_path = os.path.normpath(arguments.path.strip('"'))
        self.sync_path = self.sync_path.replace("\\", os.sep)
        self.cloud_save_dir_name = arguments.dirname
        self.arguments = arguments
        self.unknown_args = unknown_args

        if not os.path.exists(self.sync_path):
            self.logger.warning("Provided path doesn't exist, creating")
            os.makedirs(self.sync_path, exist_ok=True)
        dir_list = self.create_directory_map(self.sync_path)
        if len(dir_list) == 0:
            self.logger.info("No files in directory")

        local_files = [
            SyncFile(self.get_relative_path(self.sync_path, f), f) for f in dir_list
        ]

        for f in local_files:
            f.get_file_metadata()

        self.logger.info(f"Local files: {len(dir_list)}")
        self.client_id, self.client_secret = self.get_auth_ids()
        self.get_auth_token()

        cloud_files = self.get_cloud_files_list()
        downloadable_cloud = [f for f in cloud_files if f.md5 != "aadd86936a80ee8a369579c3926f1b3c"]

        if len(local_files) > 0 and len(cloud_files) == 0:
            action = SyncAction.UPLOAD
            self.logger.info("No files in cloud, uploading")
            for f in local_files:
                self.upload_file(f)
            self.logger.info("Done")
            sys.stdout.write(str(datetime.datetime.now().timestamp()))
            sys.stdout.flush()
            return
        elif len(local_files) == 0 and len(cloud_files) > 0:
            self.logger.info("No files locally, downloading")
            action = SyncAction.DOWNLOAD
            for f in downloadable_cloud:
                self.download_file(f)
            self.logger.info("Done")
            sys.stdout.write(str(datetime.datetime.now().timestamp()))
            sys.stdout.flush()
            return

        timestamp = float(arguments.timestamp)
        classifier = SyncClassifier.classify(local_files, cloud_files, timestamp)

        action = classifier.get_action()

        if prefered_action:
            if prefered_action == "forceupload":
                self.logger.warning("Forcing upload")
                classifier.updated_local = local_files
                action = SyncAction.UPLOAD
            elif prefered_action == "forcedownload":
                self.logger.warning("Forcing download")
                classifier.updated_cloud = downloadable_cloud 
                action = SyncAction.DOWNLOAD
            if prefered_action == "upload" and action == SyncAction.DOWNLOAD:
                self.logger.warning("Refused to upload files, newer files in the cloud")
                print(self.arguments.timestamp)
                return
            elif prefered_action == "download" and action == SyncAction.UPLOAD:
                self.logger.warning("Refused to download files, newer files locally")
                print(self.arguments.timestamp)
                return

        if action == SyncAction.UPLOAD:
            self.logger.info("Uploading files")
            for f in classifier.updated_local:
                self.upload_file(f)
            for f in classifier.not_existing_locally:
                self.logger.info(f"DELETING IN CLOUD {f}")
                self.delete_file(f)
        elif action == SyncAction.DOWNLOAD:
            self.logger.info("Downloading files")
            for f in classifier.updated_cloud:
                self.download_file(f)
            for f in classifier.not_existing_remotely:
                self.logger.info(f"DELETING LOCALLY {f.absolute_path}")
                os.remove(f.absolute_path)

        elif action == SyncAction.CONFLICT:
            self.logger.warning(
                "Files in conflict force downloading or uploading of files"
            )
        elif action == SyncAction.NONE:
            self.logger.info("Nothing to do")

        sys.stdout.write(str(datetime.datetime.now().timestamp()))
        sys.stdout.flush()
        self.logger.info("Done")

    def clear(self, arguments, unknown_args):
        self.sync_path = os.path.normpath(arguments.path.strip('"'))
        self.sync_path = self.sync_path.replace("\\", os.sep)
        self.cloud_save_dir_name = arguments.dirname
        self.arguments = arguments
        self.unknown_args = unknown_args

        self.client_id, self.client_secret = self.get_auth_ids()
        self.get_auth_token()

        cloud_files = self.get_cloud_files_list()
        for f in cloud_files:
            self.delete_file(f)
        self.logger.info("Done")

    def get_auth_token(self):
        self.credentials = self.auth_manager.get_credentials(self.client_id, self.client_secret)
        self.session.headers.update(
            {"Authorization": f"Bearer {self.credentials['access_token']}"}
        )

    def is_in_our_dir(self, value):
        return value["name"].startswith(self.cloud_save_dir_name)

    def get_cloud_files_list(self):
        response = self.session.get(
            f"{constants.GOG_CLOUDSTORAGE}/v1/{self.credentials['user_id']}/{self.client_id}",
            headers={"Accept": "application/json"},
        )

        if response.status_code == 404:
            return []
        else:
            response.raise_for_status()

        json_res = response.json()
        # print(json_res)
        self.logger.info(f"Files in cloud: {len(json_res)}")
        self.logger.debug(f"Files: {json_res}")

        filtered = filter(self.is_in_our_dir, json_res)

        files = [
            SyncFile(
                sync_f["name"].replace(f"{self.cloud_save_dir_name}/", "", 1),
                os.path.join(
                    self.sync_path,
                    sync_f["name"].replace(f"{self.cloud_save_dir_name}/", "", 1),
                ),
                md5=sync_f["hash"],
                update_time=sync_f["last_modified"],
            )
            for sync_f in filtered
        ]

        return files

    def get_auth_ids(self):
        builds = dl_utils.get_json(
            self.api,
            f"{constants.GOG_CONTENT_SYSTEM}/products/{self.arguments.id}/os/{self.arguments.platform}/builds?generation=2",
        )
        meta_url = builds["items"][0]["link"]

        meta, _headers = dl_utils.get_zlib_encoded(self.api, meta_url)
        return meta["clientId"], meta["clientSecret"]

    def delete_file(self, file: SyncFile):
        self.logger.info(f"Deleting {file.relative_path}")
        fpath = urllib.parse.quote(file.relative_path)
        response = self.session.delete(
            f"{constants.GOG_CLOUDSTORAGE}/v1/{self.credentials['user_id']}/{self.client_id}/{self.cloud_save_dir_name}/{fpath}",
        )
        self.logger.debug(f"Delete response: {response}")

    def upload_file(self, file: SyncFile):
        with open(file.absolute_path, "rb") as save_file:
            compressed_data = gzip.compress(save_file.read(), 6, mtime=0)
        headers = {
            "X-Object-Meta-LocalLastModified": f"{file.update_time}",
            "Etag": hashlib.md5(compressed_data).hexdigest(),
            "Content-Encoding": "gzip",
        }

        fpath = urllib.parse.quote(file.relative_path)
        response = self.session.put(
            f"{constants.GOG_CLOUDSTORAGE}/v1/{self.credentials['user_id']}/{self.client_id}/{self.cloud_save_dir_name}/{fpath}",
            data=compressed_data,
            headers=headers,
        )

        if not response.ok:
            self.logger.error(
                f"There was an error uploading a file \n{response.status_code}\n{response.content}"
            )
            return

    def download_file(self, file: SyncFile, retries=3):
        try:
            fpath = urllib.parse.quote(file.relative_path)
            response = self.session.get(
                f"{constants.GOG_CLOUDSTORAGE}/v1/{self.credentials['user_id']}/{self.client_id}/{self.cloud_save_dir_name}/{fpath}",
                stream=True,
            )
        except requests.RequestException:
            if (retries > 1):
                self.logger.debug(f"Failed sync of {file}, retrying (retries left {retries - 1})")
                self.download_file(file, retries - 1)
                return
            else:
                response = {}

        if not response.ok:
            self.logger.error("Downloading file failed")
            self.logger.debug(f"Download error: {response}")
            return

        total = response.headers.get("Content-Length")
        os.makedirs(os.path.split(file.absolute_path)[0], exist_ok=True)
        with open(file.absolute_path, "wb") as f:
            # if not total:
            #     f.write(response.content)
            total = int(total)
            f.writelines(response.iter_content(
                    chunk_size=max(int(total / 1000), 1024 * 1024)
            ))

        try:
            f_timestamp = (
                datetime.datetime.fromisoformat(
                    response.headers.get("X-Object-Meta-LocalLastModified")
                )
                .astimezone()
                .timestamp()
            )
            os.utime(file.absolute_path, (f_timestamp, f_timestamp))
        except (ValueError, TypeError):
            self.logger.warning(f"Incorrect LastModified header for file {file.relative_path} {response.headers.get('X-Object-Meta-LocalLastModified')} ; Ignoring...")

    def commit_changes(self):
        response = self.session.post(f"{constants.GOG_CLOUDSTORAGE}/v1/{self.credentials['user_id']}/{self.client_id}")
        if not response.ok:
            self.logger.error("Failed to commit")
            self.logger.debug(f"Commit error: {response}")


class SyncClassifier:
    def __init__(self):
        self.action = None
        self.updated_local = []
        self.updated_cloud = []

        self.not_existing_locally = []
        self.not_existing_remotely = []

    def get_action(self):
        if len(self.updated_local) == 0 and len(self.updated_cloud) > 0:
            self.action = SyncAction.DOWNLOAD

        elif len(self.updated_local) > 0 and len(self.updated_cloud) == 0:
            self.action = SyncAction.UPLOAD

        elif len(self.updated_local) == 0 and len(self.updated_cloud) == 0:
            self.action = SyncAction.NONE

        else:
            self.action = SyncAction.CONFLICT

        return self.action

    @classmethod
    def classify(cls, local, cloud, timestamp):
        classifier = cls()

        local_paths = [f.relative_path for f in local]
        cloud_paths = [f.relative_path for f in cloud]

        for f in local:
            if f.relative_path not in cloud_paths:
                classifier.not_existing_remotely.append(f)
            if f.update_ts > timestamp:
                classifier.updated_local.append(f)

        for f in cloud:
            if f.md5 == "aadd86936a80ee8a369579c3926f1b3c":
                continue
            if f.relative_path not in local_paths:
                classifier.not_existing_locally.append(f)
            if f.update_ts > timestamp:
                classifier.updated_cloud.append(f)

        return classifier
