using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using SharpCompress.Compressors.Deflate64;
using SharpCompress.Compressors.LZMA;
using SharpCompress.Compressors.LZMA.Utilities;
using SharpCompress.IO;
using BlockType = SharpCompress.Compressors.LZMA.Utilities.BlockType;

namespace SharpCompress.Common.SevenZip;

internal partial class ArchiveReader
{
    internal Stream _stream = null!;
    internal Stack<DataReader> _readerStack = new();
    internal DataReader _currentReader = null!;
    internal long _streamOrigin;
    internal long _streamEnding;
    internal byte[] _header = null!;

    private readonly Dictionary<int, Stream> _cachedStreams = new();

    internal void AddByteStream(byte[] buffer, int offset, int length)
    {
        _readerStack.Push(_currentReader);
        _currentReader = new DataReader(buffer, offset, length);
    }

    internal void DeleteByteStream() => _currentReader = _readerStack.Pop();

    #region Private Methods - Data Reader

    internal byte ReadByte() => _currentReader.ReadByte();

    private void ReadBytes(byte[] buffer, int offset, int length) =>
        _currentReader.ReadBytes(buffer, offset, length);

    private ulong ReadNumber() => _currentReader.ReadNumber();

    internal int ReadNum() => _currentReader.ReadNum();

    private uint ReadUInt32() => _currentReader.ReadUInt32();

    private ulong ReadUInt64() => _currentReader.ReadUInt64();

    private BlockType? ReadId()
    {
        var id = _currentReader.ReadNumber();
        if (id > 25)
        {
            return null;
        }
        return (BlockType)id;
    }

    private void SkipData(long size) => _currentReader.SkipData(size);

    private void SkipData() => _currentReader.SkipData();

    private void WaitAttribute(BlockType attribute)
    {
        for (; ; )
        {
            var type = ReadId();
            if (type == attribute)
            {
                return;
            }
            if (type == BlockType.End)
            {
                throw new ArchiveOperationException();
            }
            SkipData();
        }
    }

    private void ReadArchiveProperties()
    {
        while (ReadId() != BlockType.End)
        {
            SkipData();
        }
    }

    #endregion

    #region Private Methods - Reader Utilities

    private BitVector ReadBitVector(int length)
    {
        _currentReader.RequireBytes(((long)length + 7) / 8);
        var bits = new BitVector(length);

        byte data = 0;
        byte mask = 0;

        for (var i = 0; i < length; i++)
        {
            if (mask == 0)
            {
                data = ReadByte();
                mask = 0x80;
            }

            if ((data & mask) != 0)
            {
                bits.SetBit(i);
            }

            mask >>= 1;
        }

        return bits;
    }

    private BitVector ReadOptionalBitVector(int length)
    {
        var allTrue = ReadByte();
        if (allTrue != 0)
        {
            return new BitVector(length, true);
        }

        return ReadBitVector(length);
    }

    private void ReadNumberVector(List<byte[]>? dataVector, int numFiles, Action<int, long?> action)
    {
        var defined = ReadOptionalBitVector(numFiles);

        using var streamSwitch = new CStreamSwitch();
        streamSwitch.Set(this, dataVector ?? []);

        for (var i = 0; i < numFiles; i++)
        {
            if (defined[i])
            {
                action(i, checked((long)ReadUInt64()));
            }
            else
            {
                action(i, null);
            }
        }
    }

    private DateTime TranslateTime(long time) =>
        // FILETIME = 100-nanosecond intervals since January 1, 1601 (UTC)
        DateTime.FromFileTimeUtc(time).ToLocalTime();

    private DateTime? TranslateTime(long? time)
    {
        if (time.HasValue && time.Value >= 0 && time.Value <= 2650467743999999999) //maximum Windows file time 31.12.9999
        {
            return TranslateTime(time.Value);
        }
        return null;
    }

    private void ReadDateTimeVector(
        List<byte[]>? dataVector,
        int numFiles,
        Action<int, DateTime?> action
    ) =>
        ReadNumberVector(
            dataVector,
            numFiles,
            (index, value) => action(index, TranslateTime(value))
        );

    private void ReadAttributeVector(
        List<byte[]>? dataVector,
        int numFiles,
        Action<int, uint?> action
    )
    {
        var boolVector = ReadOptionalBitVector(numFiles);
        using var streamSwitch = new CStreamSwitch();
        streamSwitch.Set(this, dataVector ?? []);
        for (var i = 0; i < numFiles; i++)
        {
            if (boolVector[i])
            {
                action(i, ReadUInt32());
            }
            else
            {
                action(i, null);
            }
        }
    }

    #endregion

    #region Private Methods

    private void GetNextFolderItem(CFolder folder)
    {
        try
        {
            var numCoders = ReadNum();
            // CFolder.CheckStructure supports at most 32 coders/bind pairs, but runs
            // after parsing. Enforce those limits before allocating their lists.
            if (numCoders == 0 || numCoders > CFolder.MaxCoders)
            {
                throw new InvalidFormatException("Invalid number of 7z coders.");
            }
            _currentReader.RequireBytes(numCoders);
            folder._coders = new List<CCoderInfo>(numCoders);
            long numInStreamsTotal = 0;
            long numOutStreamsTotal = 0;
            for (var i = 0; i < numCoders; i++)
            {
                try
                {
                    var coder = new CCoderInfo();
                    folder._coders.Add(coder);

                    var mainByte = ReadByte();
                    var idSize = (mainByte & 0xF);
                    var longId = new byte[idSize];
                    ReadBytes(longId, 0, idSize);
                    if (idSize > 8)
                    {
                        throw new NotSupportedException();
                    }
                    ulong id = 0;
                    for (var j = 0; j < idSize; j++)
                    {
                        id |= (ulong)longId[idSize - 1 - j] << (8 * j);
                    }
                    coder._methodId = new CMethodId(id);

                    if ((mainByte & 0x10) != 0)
                    {
                        coder._numInStreams = ReadNum();
                        coder._numOutStreams = ReadNum();
                    }
                    else
                    {
                        coder._numInStreams = 1;
                        coder._numOutStreams = 1;
                    }

                    if ((mainByte & 0x20) != 0)
                    {
                        var propsSize = ReadNum();
                        _currentReader.RequireBytes(propsSize);
                        coder._props = new byte[propsSize];
                        ReadBytes(coder._props, 0, propsSize);
                    }

                    if ((mainByte & 0x80) != 0)
                    {
                        throw new NotSupportedException();
                    }

                    if (coder._numInStreams == 0 || coder._numOutStreams == 0)
                    {
                        throw new InvalidFormatException("Invalid 7z coder stream count.");
                    }
                    numInStreamsTotal += coder._numInStreams;
                    numOutStreamsTotal += coder._numOutStreams;
                }
                finally { }
            }

            if (
                numOutStreamsTotal - 1 > CFolder.MaxBindPairs
                || numInStreamsTotal > int.MaxValue
                || numInStreamsTotal < numOutStreamsTotal
            )
            {
                throw new InvalidFormatException("Invalid 7z folder stream counts.");
            }
            var numInStreams = (int)numInStreamsTotal;
            var numOutStreams = (int)numOutStreamsTotal;
            var numBindPairs = numOutStreams - 1;
            _currentReader.RequireBytes(2L * numBindPairs);
            folder._bindPairs = new List<CBindPair>(numBindPairs);
            for (var i = 0; i < numBindPairs; i++)
            {
                var bp = new CBindPair();
                bp._inIndex = ReadNum();
                bp._outIndex = ReadNum();
                if (
                    bp._inIndex >= numInStreams
                    || bp._outIndex >= numOutStreams
                    || folder.FindBindPairForInStream(bp._inIndex) >= 0
                    || folder.FindBindPairForOutStream(bp._outIndex) >= 0
                )
                {
                    throw new InvalidFormatException("Invalid 7z bind pair.");
                }
                folder._bindPairs.Add(bp);
            }

            var numPackStreams = numInStreams - numBindPairs;

            if (numPackStreams == 1)
            {
                for (var i = 0; i < numInStreams; i++)
                {
                    if (folder.FindBindPairForInStream(i) < 0)
                    {
                        folder._packStreams.Add(i);
                        break;
                    }
                }

                if (folder._packStreams.Count != 1)
                {
                    throw new NotSupportedException();
                }
            }
            else
            {
                _currentReader.RequireBytes(numPackStreams);
                var packStreams = new HashSet<int>();
                for (var i = 0; i < numPackStreams; i++)
                {
                    var num = ReadNum();
                    if (
                        num >= numInStreams
                        || folder.FindBindPairForInStream(num) >= 0
                        || !packStreams.Add(num)
                    )
                    {
                        throw new InvalidFormatException("Invalid 7z packed stream index.");
                    }
                    folder._packStreams.Add(num);
                }
            }
        }
        finally { }
    }

    private List<uint?> ReadHashDigests(int count)
    {
        // An all-defined vector has no bitmap, but must have a CRC per item.
        // Check it before ReadOptionalBitVector allocates the implicit bitmap.
        var reader = _currentReader.Clone();
        if (reader.ReadByte() != 0)
        {
            reader.RequireBytes(4L * count);
        }
        var defined = ReadOptionalBitVector(count);
        long numDefined = 0;
        for (var i = 0; i < count; i++)
        {
            if (defined[i])
            {
                numDefined++;
            }
        }
        _currentReader.RequireBytes(4 * numDefined);
        var digests = new List<uint?>(count);
        for (var i = 0; i < count; i++)
        {
            if (defined[i])
            {
                var crc = ReadUInt32();
                digests.Add(crc);
            }
            else
            {
                digests.Add(null);
            }
        }
        return digests;
    }

    private void ReadPackInfo(
        out long dataOffset,
        out List<long> packSizes,
        out List<uint?> packCrCs
    )
    {
        try
        {
            packCrCs = null!;

            dataOffset = checked((long)ReadNumber());

            var numPackStreams = ReadNum();

            WaitAttribute(BlockType.Size);
            _currentReader.RequireBytes(numPackStreams);
            packSizes = new List<long>(numPackStreams);
            for (var i = 0; i < numPackStreams; i++)
            {
                var size = checked((long)ReadNumber());
                packSizes.Add(size);
            }

            BlockType? type;
            for (; ; )
            {
                type = ReadId();
                if (type == BlockType.End)
                {
                    break;
                }
                if (type == BlockType.Crc)
                {
                    packCrCs = ReadHashDigests(numPackStreams);
                    continue;
                }
                SkipData();
            }

            if (packCrCs is null)
            {
                packCrCs = new List<uint?>(numPackStreams);
                for (var i = 0; i < numPackStreams; i++)
                {
                    packCrCs.Add(null);
                }
            }
        }
        finally { }
    }

    private void ReadUnpackInfo(List<byte[]>? dataVector, out List<CFolder> folders)
    {
        try
        {
            WaitAttribute(BlockType.Folder);
            var numFolders = ReadNum();

            using (var streamSwitch = new CStreamSwitch())
            {
                streamSwitch.Set(this, dataVector ?? []);

                // Folder definitions may live in an external metadata stream.
                // Validate against the selected stream, not the outer header.
                _currentReader.RequireBytes(numFolders);
                folders = new List<CFolder>(numFolders);
                var index = 0;
                for (var i = 0; i < numFolders; i++)
                {
                    var f = new CFolder { _firstPackStreamId = index };
                    folders.Add(f);
                    GetNextFolderItem(f);
                    index += f._packStreams.Count;
                }
            }

            WaitAttribute(BlockType.CodersUnpackSize);
            for (var i = 0; i < numFolders; i++)
            {
                var folder = folders[i];
                var numOutStreams = folder.GetNumOutStreams();
                for (var j = 0; j < numOutStreams; j++)
                {
                    var size = checked((long)ReadNumber());
                    folder._unpackSizes.Add(size);
                }
                if (!folder.CheckStructure())
                {
                    throw new InvalidFormatException("Invalid 7z folder structure.");
                }
            }

            for (; ; )
            {
                var type = ReadId();
                if (type == BlockType.End)
                {
                    return;
                }

                if (type == BlockType.Crc)
                {
                    var crcs = ReadHashDigests(numFolders);
                    for (var i = 0; i < numFolders; i++)
                    {
                        folders[i]._unpackCrc = crcs[i];
                    }
                    continue;
                }

                SkipData();
            }
        }
        finally { }
    }

    private void ReadSubStreamsInfo(
        List<CFolder> folders,
        out List<int> numUnpackStreamsInFolders,
        out List<long> unpackSizes,
        out List<uint?> digests
    )
    {
        try
        {
            numUnpackStreamsInFolders = null!;

            BlockType? type;
            for (; ; )
            {
                type = ReadId();
                if (type == BlockType.NumUnpackStream)
                {
                    numUnpackStreamsInFolders = new List<int>(folders.Count);
                    for (var i = 0; i < folders.Count; i++)
                    {
                        var num = ReadNum();
                        numUnpackStreamsInFolders.Add(num);
                    }
                    continue;
                }
                if (type is BlockType.Crc or BlockType.Size)
                {
                    break;
                }
                if (type == BlockType.End)
                {
                    break;
                }
                SkipData();
            }

            if (numUnpackStreamsInFolders is null)
            {
                numUnpackStreamsInFolders = new List<int>(folders.Count);
                for (var i = 0; i < folders.Count; i++)
                {
                    numUnpackStreamsInFolders.Add(1);
                }
            }

            // Every substream except the last in each folder needs an explicit
            // size. Reject impossible counts before loops or digest allocations.
            long numExplicitSizes = 0;
            long numStreamsTotal = 0;
            foreach (var count in numUnpackStreamsInFolders)
            {
                numExplicitSizes += Math.Max(0, count - 1);
                numStreamsTotal += count;
            }
            if (numStreamsTotal > int.MaxValue || (numExplicitSizes != 0 && type != BlockType.Size))
            {
                throw new InvalidFormatException("Invalid 7z substream count.");
            }
            _currentReader.RequireBytes(numExplicitSizes);

            unpackSizes = new List<long>(folders.Count);
            for (var i = 0; i < numUnpackStreamsInFolders.Count; i++)
            {
                // v3.13 incorrectly worked with empty folders
                // v4.07: we check that folder is empty
                var numSubstreams = numUnpackStreamsInFolders[i];
                if (numSubstreams == 0)
                {
                    continue;
                }
                long sum = 0;
                for (var j = 1; j < numSubstreams; j++)
                {
                    if (type == BlockType.Size)
                    {
                        var size = checked((long)ReadNumber());
                        if (size > folders[i].GetUnpackSize() - sum)
                        {
                            throw new InvalidFormatException("Invalid 7z substream size.");
                        }
                        unpackSizes.Add(size);
                        sum += size;
                    }
                }
                unpackSizes.Add(folders[i].GetUnpackSize() - sum);
            }
            if (type == BlockType.Size)
            {
                type = ReadId();
            }

            var numDigests = 0;
            var numDigestsTotal = 0;
            for (var i = 0; i < folders.Count; i++)
            {
                var numSubstreams = numUnpackStreamsInFolders[i];
                if (numSubstreams != 1 || !folders[i].UnpackCrcDefined)
                {
                    numDigests += numSubstreams;
                }
                numDigestsTotal += numSubstreams;
            }

            digests = null!;

            for (; ; )
            {
                if (type == BlockType.Crc)
                {
                    digests = new List<uint?>(numDigestsTotal);

                    var digests2 = ReadHashDigests(numDigests);

                    var digestIndex = 0;
                    for (var i = 0; i < folders.Count; i++)
                    {
                        var numSubstreams = numUnpackStreamsInFolders[i];
                        var folder = folders[i];
                        if (numSubstreams == 1 && folder.UnpackCrcDefined)
                        {
                            digests.Add(folder._unpackCrc!.Value);
                        }
                        else
                        {
                            for (var j = 0; j < numSubstreams; j++, digestIndex++)
                            {
                                digests.Add(digests2[digestIndex]);
                            }
                        }
                    }

                    if (digestIndex != numDigests || numDigestsTotal != digests.Count)
                    {
                        Debugger.Break();
                    }
                }
                else if (type == BlockType.End)
                {
                    if (digests is null)
                    {
                        digests = new List<uint?>(numDigestsTotal);
                        for (var i = 0; i < numDigestsTotal; i++)
                        {
                            digests.Add(null);
                        }
                    }
                    return;
                }
                else
                {
                    SkipData();
                }

                type = ReadId();
            }
        }
        finally { }
    }

    private void ReadStreamsInfo(
        List<byte[]>? dataVector,
        out long dataOffset,
        out List<long> packSizes,
        out List<uint?> packCrCs,
        out List<CFolder> folders,
        out List<int> numUnpackStreamsInFolders,
        out List<long> unpackSizes,
        out List<uint?> digests
    )
    {
        try
        {
            dataOffset = long.MinValue;
            packSizes = null!;
            packCrCs = null!;
            folders = null!;
            numUnpackStreamsInFolders = null!;
            unpackSizes = null!;
            digests = null!;

            for (; ; )
            {
                switch (ReadId())
                {
                    case BlockType.End:
                        return;
                    case BlockType.PackInfo:
                        ReadPackInfo(out dataOffset, out packSizes, out packCrCs);
                        break;
                    case BlockType.UnpackInfo:
                        ReadUnpackInfo(dataVector, out folders);
                        break;
                    case BlockType.SubStreamsInfo:
                        ReadSubStreamsInfo(
                            folders!,
                            out numUnpackStreamsInFolders,
                            out unpackSizes,
                            out digests
                        );
                        break;
                    default:
                        throw new InvalidFormatException();
                }
            }
        }
        finally { }
    }

    private static int GetMetadataSize(CFolder folder)
    {
        var size = folder.GetUnpackSize();
        if (size < 0 || size > int.MaxValue)
        {
            throw new InvalidFormatException("7z metadata is too large.");
        }
        return (int)size;
    }

    private void ValidateFileCount(int numFiles, int numStreams)
    {
        // Nonempty files correspond to already parsed substreams. Empty files
        // require one bit each in kEmptyStream, not one byte per file. Preflight
        // that property before allocating CFileItem objects or implicit vectors.
        var reader = _currentReader.Clone();
        var numEmptyStreams = 0;
        var hasEmptyStreams = false;
        for (; ; )
        {
            var type = reader.ReadNumber();
            if (type == (ulong)BlockType.End)
            {
                break;
            }
            var size = reader.ReadNumber();
            if (size > (ulong)reader.Remaining)
            {
                throw new IncompleteArchiveException("Unexpected end of stream.");
            }
            var start = reader.Offset;
            if (type == (ulong)BlockType.EmptyStream)
            {
                var bitmapSize = ((long)numFiles + 7) / 8;
                if (hasEmptyStreams || size < (ulong)bitmapSize)
                {
                    throw new InvalidFormatException("Invalid 7z empty stream bitmap.");
                }
                hasEmptyStreams = true;
                byte bits = 0;
                for (var i = 0; i < numFiles; i++)
                {
                    if ((i & 7) == 0)
                    {
                        bits = reader.ReadByte();
                    }
                    if ((bits & 0x80) != 0)
                    {
                        numEmptyStreams++;
                    }
                    bits <<= 1;
                }
            }
            reader.SkipData((long)size - (reader.Offset - start));
        }
        if ((long)numStreams + numEmptyStreams != numFiles)
        {
            throw new InvalidFormatException("7z file count does not match the stream count.");
        }
    }

    private List<byte[]> ReadAndDecodePackedStreams(long baseOffset, IPasswordProvider pass)
    {
        try
        {
            ReadStreamsInfo(
                null,
                out var dataStartPos,
                out var packSizes,
                out var packCrCs,
                out var folders,
                out var numUnpackStreamsInFolders,
                out var unpackSizes,
                out var digests
            );

            dataStartPos += baseOffset;

            var dataVector = new List<byte[]>(folders.Count);
            var packIndex = 0;
            foreach (var folder in folders)
            {
                var unpackSize = GetMetadataSize(folder);
                var oldDataStartPos = dataStartPos;
                var myPackSizes = new long[folder._packStreams.Count];
                for (var i = 0; i < myPackSizes.Length; i++)
                {
                    var packSize = packSizes[packIndex + i];
                    myPackSizes[i] = packSize;
                    dataStartPos += packSize;
                }

                using var outStream = DecoderStreamHelper.CreateDecoderStream(
                    _stream,
                    oldDataStartPos,
                    myPackSizes,
                    folder,
                    pass
                );

                // Do not reserve the declared unpack size: malformed compressed
                // metadata can advertise GiB of output without producing a byte.
                using var decoded = new PooledMemoryStream();
                var buffer = new byte[8192];
                for (var remaining = unpackSize; remaining > 0; )
                {
                    var count = Math.Min(buffer.Length, remaining);
                    outStream.ReadExact(buffer, 0, count);
                    decoded.Write(buffer, 0, count);
                    remaining -= count;
                }
                if (outStream.ReadByte() >= 0)
                {
                    throw new InvalidFormatException("Decoded stream is longer than expected.");
                }
                var data = decoded.ToArray();
                dataVector.Add(data);

                if (folder.UnpackCrcDefined)
                {
                    if (
                        Crc.Finish(Crc.Update(Crc.INIT_CRC, data, 0, unpackSize))
                        != folder._unpackCrc
                    )
                    {
                        var exception = new InvalidFormatException(
                            "Decoded stream does not match expected CRC."
                        );
                        throw folder.IsEncrypted()
                            ? EncryptedDecoderStream.DecodingException(exception)
                            : exception;
                    }
                }
            }
            return dataVector;
        }
        finally { }
    }

    private void ReadHeader(ArchiveDatabase db, IPasswordProvider getTextPassword)
    {
        try
        {
            var type = ReadId();

            if (type == BlockType.ArchiveProperties)
            {
                ReadArchiveProperties();
                type = ReadId();
            }

            List<byte[]>? dataVector = null;
            if (type == BlockType.AdditionalStreamsInfo)
            {
                dataVector = ReadAndDecodePackedStreams(
                    db._startPositionAfterHeader,
                    getTextPassword
                );
                type = ReadId();
            }

            List<long> unpackSizes;
            List<uint?> digests;

            if (type == BlockType.MainStreamsInfo)
            {
                ReadStreamsInfo(
                    dataVector,
                    out db._dataStartPosition,
                    out db._packSizes,
                    out db._packCrCs,
                    out db._folders,
                    out db._numUnpackStreamsVector,
                    out unpackSizes,
                    out digests
                );

                db._dataStartPosition += db._startPositionAfterHeader;
                type = ReadId();
            }
            else
            {
                unpackSizes = new List<long>(db._folders.Count);
                digests = new List<uint?>(db._folders.Count);
                db._numUnpackStreamsVector = new List<int>(db._folders.Count);
                for (var i = 0; i < db._folders.Count; i++)
                {
                    var folder = db._folders[i];
                    unpackSizes.Add(folder.GetUnpackSize());
                    digests.Add(folder._unpackCrc);
                    db._numUnpackStreamsVector.Add(1);
                }
            }

            db._files.Clear();

            if (type == BlockType.End)
            {
                return;
            }

            if (type != BlockType.FilesInfo)
            {
                throw new ArchiveOperationException();
            }

            var numFiles = ReadNum();
            ValidateFileCount(numFiles, unpackSizes.Count);
            db._files = new List<CFileItem>(numFiles);
            for (var i = 0; i < numFiles; i++)
            {
                db._files.Add(new CFileItem());
            }

            var emptyStreamVector = new BitVector(numFiles);
            BitVector emptyFileVector = null!;
            BitVector antiFileVector = null!;
            var numEmptyStreams = 0;

            for (; ; )
            {
                type = ReadId();
                if (type == BlockType.End)
                {
                    break;
                }

                var size = checked((long)ReadNumber()); // TODO: throw invalid data on negative
                var oldPos = _currentReader.Offset;
                switch (type)
                {
                    case BlockType.Name:
                        using (var streamSwitch = new CStreamSwitch())
                        {
                            streamSwitch.Set(this, dataVector ?? []);
                            for (var i = 0; i < db._files.Count; i++)
                            {
                                db._files[i].Name = _currentReader.ReadString();
                            }
                        }
                        break;
                    case BlockType.WinAttributes:
                        ReadAttributeVector(
                            dataVector,
                            numFiles,
                            delegate(int i, uint? attr)
                            {
                                // Keep the original attribute value because it could potentially get
                                // modified in the logic that follows. Some callers of the library may
                                // find the original value useful.
                                db._files[i].ExtendedAttrib = attr;

                                // Some third party implementations established an unofficial extension
                                // of the 7z archive format by placing posix file attributes in the high
                                // bits of the windows file attributes. This makes use of the fact that
                                // the official implementation does not perform checks on this value.
                                //
                                // Newer versions of the official 7z GUI client will try to parse this
                                // extension, thus acknowledging the unofficial use of these bits.
                                //
                                // For us it is safe to just discard the upper bits if they are set and
                                // keep the windows attributes from the lower bits (which should be set
                                // properly even if posix file attributes are present, in order to be
                                // compatible with older 7z archive readers)
                                //
                                // Note that the 15th bit is used by some implementations to indicate
                                // presence of the extension, but not all implementations do that so
                                // we can't trust that bit and must ignore it.
                                //
                                if (attr.HasValue && (attr.Value >> 16) != 0)
                                {
                                    attr = attr.Value & 0x7FFFu;
                                }

                                db._files[i].Attrib = attr;
                            }
                        );
                        break;
                    case BlockType.EmptyStream:
                        emptyStreamVector = ReadBitVector(numFiles);
                        for (var i = 0; i < emptyStreamVector.Length; i++)
                        {
                            if (emptyStreamVector[i])
                            {
                                numEmptyStreams++;
                            }
                            else { }
                        }

                        emptyFileVector = new BitVector(numEmptyStreams);
                        antiFileVector = new BitVector(numEmptyStreams);
                        break;
                    case BlockType.EmptyFile:
                        emptyFileVector = ReadBitVector(numEmptyStreams);
                        break;
                    case BlockType.Anti:
                        antiFileVector = ReadBitVector(numEmptyStreams);
                        break;
                    case BlockType.StartPos:
                        ReadNumberVector(
                            dataVector,
                            numFiles,
                            delegate(int i, long? startPos)
                            {
                                db._files[i].StartPos = startPos;
                            }
                        );
                        break;
                    case BlockType.CTime:
                        ReadDateTimeVector(
                            dataVector,
                            numFiles,
                            delegate(int i, DateTime? time)
                            {
                                db._files[i].CTime = time;
                            }
                        );
                        break;
                    case BlockType.ATime:
                        ReadDateTimeVector(
                            dataVector,
                            numFiles,
                            delegate(int i, DateTime? time)
                            {
                                db._files[i].ATime = time;
                            }
                        );
                        break;
                    case BlockType.MTime:
                        ReadDateTimeVector(
                            dataVector,
                            numFiles,
                            delegate(int i, DateTime? time)
                            {
                                db._files[i].MTime = time;
                            }
                        );
                        break;
                    case BlockType.Dummy:
                        for (long j = 0; j < size; j++)
                        {
                            if (ReadByte() != 0)
                            {
                                throw new ArchiveOperationException();
                            }
                        }
                        break;
                    default:
                        SkipData(size);
                        break;
                }

                // since 0.3 record sizes must be correct
                var checkRecordsSize = (db._majorVersion > 0 || db._minorVersion > 2);
                if (checkRecordsSize && _currentReader.Offset - oldPos != size)
                {
                    throw new ArchiveOperationException();
                }
            }

            var emptyFileIndex = 0;
            var sizeIndex = 0;
            for (var i = 0; i < numFiles; i++)
            {
                var file = db._files[i];
                file.HasStream = !emptyStreamVector[i];
                if (file.HasStream)
                {
                    file.IsDir = false;
                    file.IsAnti = false;
                    file.Size = unpackSizes[sizeIndex];
                    file.Crc = digests[sizeIndex];
                    sizeIndex++;
                }
                else
                {
                    file.IsDir = !emptyFileVector[emptyFileIndex];
                    file.IsAnti = antiFileVector[emptyFileIndex];
                    emptyFileIndex++;
                    file.Size = 0;
                    file.Crc = null;
                }
            }
        }
        finally { }
    }

    #endregion

    #region Public Methods

    public void Open(Stream stream, bool lookForHeader)
    {
        Close();

        _streamOrigin = stream.Position;
        _streamEnding = stream.Length;

        var canScan = lookForHeader ? 0x80000 - 20 : 0;
        while (true)
        {
            // TODO: Check Signature!
            _header = new byte[0x20];
            for (var offset = 0; offset < 0x20; )
            {
                var delta = stream.Read(_header, offset, 0x20 - offset);
                if (delta == 0)
                {
                    throw new IncompleteArchiveException("Unexpected end of stream.");
                }

                offset += delta;
            }

            if (
                !lookForHeader
                || _header
                    .AsSpan(0, length: 6)
                    .SequenceEqual<byte>([0x37, 0x7A, 0xBC, 0xAF, 0x27, 0x1C])
            )
            {
                break;
            }

            if (canScan == 0)
            {
                throw new InvalidFormatException("Unable to find 7z signature");
            }

            canScan--;
            stream.Position = ++_streamOrigin;
        }

        _stream = stream;
    }

    // OpenAsync moved to ArchiveReader.Async.cs

    public void Close()
    {
        _stream?.Dispose();

        foreach (var stream in _cachedStreams.Values)
        {
            stream.Dispose();
        }

        _cachedStreams.Clear();
    }

    public ArchiveDatabase ReadDatabase(IPasswordProvider pass)
    {
        var db = new ArchiveDatabase(pass);
        db.Clear();

        db._majorVersion = _header[6];
        db._minorVersion = _header[7];

        if (db._majorVersion != 0)
        {
            throw new ArchiveOperationException();
        }

        var crcFromArchive = DataReader.Get32(_header, 8);
        var nextHeaderOffset = (long)DataReader.Get64(_header, 0xC);
        var nextHeaderSize = (long)DataReader.Get64(_header, 0x14);
        var nextHeaderCrc = DataReader.Get32(_header, 0x1C);

        var crc = Crc.INIT_CRC;
        crc = Crc.Update(crc, nextHeaderOffset);
        crc = Crc.Update(crc, nextHeaderSize);
        crc = Crc.Update(crc, nextHeaderCrc);
        crc = Crc.Finish(crc);

        if (crc != crcFromArchive)
        {
            throw new ArchiveOperationException();
        }

        db._startPositionAfterHeader = _streamOrigin + 0x20;

        // empty header is ok
        if (nextHeaderSize == 0)
        {
            db.Fill();
            return db;
        }

        if (nextHeaderOffset < 0 || nextHeaderSize < 0 || nextHeaderSize > int.MaxValue)
        {
            throw new ArchiveOperationException();
        }

        if (nextHeaderOffset > _streamEnding - db._startPositionAfterHeader)
        {
            throw new ArchiveOperationException("nextHeaderOffset is invalid");
        }

        // Validate the physical header range before allocating attacker-controlled sizes.
        // Subtract the validated offset instead of adding offset and size to avoid overflow.
        if (nextHeaderSize > _streamEnding - db._startPositionAfterHeader - nextHeaderOffset)
        {
            throw new IncompleteArchiveException("Next header extends beyond the end of stream.");
        }

        _stream.Seek(nextHeaderOffset, SeekOrigin.Current);

        var header = new byte[nextHeaderSize];
        _stream.ReadExact(header, 0, header.Length);

        if (Crc.Finish(Crc.Update(Crc.INIT_CRC, header, 0, header.Length)) != nextHeaderCrc)
        {
            throw new ArchiveOperationException();
        }

        using (var streamSwitch = new CStreamSwitch())
        {
            streamSwitch.Set(this, header);

            var type = ReadId();
            if (type != BlockType.Header)
            {
                if (type != BlockType.EncodedHeader)
                {
                    throw new ArchiveOperationException();
                }

                var dataVector = ReadAndDecodePackedStreams(
                    db._startPositionAfterHeader,
                    db.PasswordProvider
                );

                // compressed header without content is odd but ok
                if (dataVector.Count == 0)
                {
                    db.Fill();
                    return db;
                }

                if (dataVector.Count != 1)
                {
                    throw new ArchiveOperationException();
                }

                streamSwitch.Set(this, dataVector[0]);

                if (ReadId() != BlockType.Header)
                {
                    throw new ArchiveOperationException();
                }
            }

            ReadHeader(db, db.PasswordProvider);
        }
        db.Fill();
        return db;
    }

    // ReadDatabaseAsync moved to ArchiveReader.Async.cs

    internal class CExtractFolderInfo
    {
        internal int _fileIndex;
        internal int _folderIndex;
        internal List<bool> _extractStatuses = new();

        internal CExtractFolderInfo(int fileIndex, int folderIndex)
        {
            _fileIndex = fileIndex;
            _folderIndex = folderIndex;
            if (fileIndex != -1)
            {
                _extractStatuses.Add(true);
            }
        }
    }

    private class FolderUnpackStream : Stream
    {
        private readonly ArchiveDatabase _db;
        private readonly int _startIndex;
        private readonly List<bool> _extractStatuses;

        public FolderUnpackStream(ArchiveDatabase db, int p, int startIndex, List<bool> list)
        {
            _db = db;
            _startIndex = startIndex;
            _extractStatuses = list;
        }

        #region Stream

        public override bool CanRead => true;

        public override bool CanSeek => false;

        public override bool CanWrite => false;

        public override void Flush() { }

        public override long Length => throw new NotSupportedException();

        public override long Position
        {
            get => throw new NotSupportedException();
            set => throw new NotSupportedException();
        }

        public override int Read(byte[] buffer, int offset, int count) =>
            throw new NotSupportedException();

        public override long Seek(long offset, SeekOrigin origin) =>
            throw new NotSupportedException();

        public override void SetLength(long value) => throw new NotSupportedException();

        private Stream? _stream;
        private long _rem;
        private int _currentIndex;

        private void ProcessEmptyFiles()
        {
            while (
                _currentIndex < _extractStatuses.Count
                && _db._files[_startIndex + _currentIndex].Size == 0
            )
            {
                OpenFile();
                _stream.NotNull().Dispose();
                _stream = null;
                _currentIndex++;
            }
        }

        private void OpenFile()
        {
            var index = _startIndex + _currentIndex;
            var crc = _db._files[index].Crc;
            if (crc.HasValue)
            {
                _stream = new CrcCheckStream(crc.Value);
            }
            else
            {
                _stream = new PooledMemoryStream();
            }
            _rem = _db._files[index].Size;
        }

        public override void Write(byte[] buffer, int offset, int count)
        {
            while (count != 0)
            {
                if (_stream != null)
                {
                    var write = count;
                    if (write > _rem)
                    {
                        write = (int)_rem;
                    }
                    _stream.Write(buffer, offset, write);
                    count -= write;
                    _rem -= write;
                    offset += write;
                    if (_rem == 0)
                    {
                        _stream.Dispose();
                        _stream = null;
                        _currentIndex++;
                        ProcessEmptyFiles();
                    }
                }
                else
                {
                    ProcessEmptyFiles();
                    if (_currentIndex == _extractStatuses.Count)
                    {
                        // we support partial extracting
                        Debugger.Break();
                        throw new NotSupportedException();
                    }
                    OpenFile();
                }
            }
        }

        #endregion
    }

    private Stream GetCachedDecoderStream(ArchiveDatabase db, int folderIndex)
    {
        if (!_cachedStreams.TryGetValue(folderIndex, out var s))
        {
            var folderInfo = db._folders[folderIndex];
            var packStreamIndex = db._folders[folderIndex]._firstPackStreamId;
            var folderStartPackPos = db.GetFolderStreamPos(folderInfo, 0);
            var count = folderInfo._packStreams.Count;
            var packSizes = new long[count];
            for (var j = 0; j < count; j++)
            {
                packSizes[j] = db._packSizes[packStreamIndex + j];
            }

            s = DecoderStreamHelper.CreateDecoderStream(
                _stream,
                folderStartPackPos,
                packSizes,
                folderInfo,
                db.PasswordProvider
            );
            _cachedStreams.Add(folderIndex, s);
        }
        return s;
    }

    public Stream OpenStream(ArchiveDatabase db, int fileIndex)
    {
        var folderIndex = db._fileIndexToFolderIndexMap[fileIndex];
        var numFilesInFolder = db._numUnpackStreamsVector[folderIndex];
        var firstFileIndex = db._folderStartFileIndex[folderIndex];
        if (firstFileIndex > fileIndex || fileIndex - firstFileIndex >= numFilesInFolder)
        {
            throw new ArchiveOperationException();
        }

        var skipCount = fileIndex - firstFileIndex;
        long skipSize = 0;
        for (var i = 0; i < skipCount; i++)
        {
            skipSize += db._files[firstFileIndex + i].Size;
        }

        var s = GetCachedDecoderStream(db, folderIndex);
        s.Position = skipSize;
        return new ReadOnlySubStream(s, db._files[fileIndex].Size);
    }

    public void Extract(ArchiveDatabase db, int[]? indices)
    {
        var allFilesMode = indices is null;
        var numItems = allFilesMode ? db._files.Count : indices!.Length;

        if (numItems == 0)
        {
            return;
        }

        var extractFolderInfoVector = new List<CExtractFolderInfo>();
        for (var i = 0; i < numItems; i++)
        {
            var fileIndex = allFilesMode ? i : indices![i];

            var folderIndex = db._fileIndexToFolderIndexMap[fileIndex];
            if (folderIndex == -1)
            {
                extractFolderInfoVector.Add(new CExtractFolderInfo(fileIndex, -1));
                continue;
            }

            if (
                extractFolderInfoVector.Count == 0
                || folderIndex != extractFolderInfoVector.Last()._folderIndex
            )
            {
                extractFolderInfoVector.Add(new CExtractFolderInfo(-1, folderIndex));
            }

            var efi = extractFolderInfoVector.Last();

            var startIndex = db._folderStartFileIndex[folderIndex];
            for (var index = efi._extractStatuses.Count; index <= fileIndex - startIndex; index++)
            {
                efi._extractStatuses.Add(index == fileIndex - startIndex);
            }
        }

        byte[] buffer = null!;
        foreach (var efi in extractFolderInfoVector)
        {
            int startIndex;
            if (efi._fileIndex != -1)
            {
                startIndex = efi._fileIndex;
            }
            else
            {
                startIndex = db._folderStartFileIndex[efi._folderIndex];
            }

            var outStream = new FolderUnpackStream(db, 0, startIndex, efi._extractStatuses);

            if (efi._fileIndex != -1)
            {
                continue;
            }

            var folderIndex = efi._folderIndex;
            var folderInfo = db._folders[folderIndex];

            var packStreamIndex = db._folders[folderIndex]._firstPackStreamId;
            var folderStartPackPos = db.GetFolderStreamPos(folderInfo, 0);

            var count = folderInfo._packStreams.Count;
            var packSizes = new long[count];
            for (var j = 0; j < count; j++)
            {
                packSizes[j] = db._packSizes[packStreamIndex + j];
            }

            // TODO: If the decoding fails the last file may be extracted incompletely. Delete it?

            var s = DecoderStreamHelper.CreateDecoderStream(
                _stream,
                folderStartPackPos,
                packSizes,
                folderInfo,
                db.PasswordProvider
            );
            buffer ??= new byte[4 << 10];
            for (; ; )
            {
                var processed = s.Read(buffer, 0, buffer.Length);
                if (processed == 0)
                {
                    break;
                }
                outStream.Write(buffer, 0, processed);
            }
        }
    }

    public IEnumerable<CFileItem> GetFiles(ArchiveDatabase db) => db._files;

    public int GetFileIndex(ArchiveDatabase db, CFileItem item) => db._files.IndexOf(item);

    #endregion
}
