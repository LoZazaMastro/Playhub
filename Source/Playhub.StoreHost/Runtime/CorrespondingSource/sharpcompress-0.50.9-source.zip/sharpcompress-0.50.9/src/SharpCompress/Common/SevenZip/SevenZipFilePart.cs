using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using SharpCompress.IO;

namespace SharpCompress.Common.SevenZip;

internal class SevenZipFilePart : FilePart
{
    private CompressionType? _type;
    private readonly Stream _stream;
    private readonly ArchiveDatabase _database;

    internal SevenZipFilePart(
        Stream stream,
        ArchiveDatabase database,
        int index,
        CFileItem fileEntry,
        IArchiveEncoding archiveEncoding
    )
        : base(archiveEncoding)
    {
        _stream = stream;
        _database = database;
        Index = index;
        Header = fileEntry;
        if (Header.HasStream)
        {
            Folder = database._folders[database._fileIndexToFolderIndexMap[index]];
        }
    }

    internal CFileItem Header { get; }
    internal CFolder? Folder { get; }

    internal override string FilePartName => Header.Name;

    internal override Stream? GetRawStream() => null;

    internal override Stream GetCompressedStream()
    {
        if (!Header.HasStream)
        {
            return Stream.Null;
        }
        var folderStream = _database.GetFolderStream(_stream, Folder!, _database.PasswordProvider);

        var firstFileIndex = _database._folderStartFileIndex[_database._folders.IndexOf(Folder!)];
        var skipCount = Index - firstFileIndex;
        long skipSize = 0;
        for (var i = 0; i < skipCount; i++)
        {
            skipSize += _database._files[firstFileIndex + i].Size;
        }
        if (skipSize > 0)
        {
            folderStream.Skip(skipSize);
        }
        return new ReadOnlySubStream(folderStream, Header.Size, leaveOpen: false);
    }

    internal override async ValueTask<Stream?> GetCompressedStreamAsync(
        CancellationToken cancellationToken = default
    )
    {
        if (!Header.HasStream)
        {
            return Stream.Null;
        }
        var folderStream = await _database
            .GetFolderStreamAsync(_stream, Folder!, _database.PasswordProvider, cancellationToken)
            .ConfigureAwait(false);

        var firstFileIndex = _database._folderStartFileIndex[_database._folders.IndexOf(Folder!)];
        var skipCount = Index - firstFileIndex;
        long skipSize = 0;
        for (var i = 0; i < skipCount; i++)
        {
            skipSize += _database._files[firstFileIndex + i].Size;
        }
        if (skipSize > 0)
        {
            await folderStream.SkipAsync(skipSize, cancellationToken).ConfigureAwait(false);
        }
        return new ReadOnlySubStream(folderStream, Header.Size, leaveOpen: false);
    }

    public CompressionType CompressionType
    {
        get
        {
            _type ??= GetCompression();
            return _type.Value;
        }
    }

    private const uint K_COPY = 0x0;
    private const uint K_LZMA2 = 0x21;
    private const uint K_LZMA = 0x030101;
    private const uint K_PPMD = 0x030401;
    private const uint K_B_ZIP2 = 0x040202;

    private CompressionType GetCompression()
    {
        if (Header.IsDir)
        {
            return CompressionType.None;
        }

        var coder = Folder.NotNull()._coders.First();
        return coder._methodId._id switch
        {
            K_COPY => CompressionType.None,
            K_LZMA or K_LZMA2 => CompressionType.LZMA,
            K_PPMD => CompressionType.PPMd,
            K_B_ZIP2 => CompressionType.BZip2,
            _ => throw new InvalidFormatException(),
        };
    }

    internal bool IsEncrypted => !Header.IsDir && Folder?.IsEncrypted() == true;
}
