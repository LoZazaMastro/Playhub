using SharpCompress.Compressors;
using SharpCompress.Providers;

namespace SharpCompress.Common.Options;

public interface IReaderOptions : IStreamOptions, IEncodingOptions, IProgressOptions
{
    /// <summary>
    /// Look for RarArchive (Check for self-extracting archives or cases where RarArchive isn't at the start of the file)
    /// </summary>
    bool LookForHeader { get; set; }

    /// <summary>
    /// Password for encrypted archives.
    /// </summary>
    string? Password { get; set; }

    /// <summary>
    /// Disable checking for incomplete archives.
    /// </summary>
    bool DisableCheckIncomplete { get; set; }

    /// <summary>
    /// Buffer size for stream operations.
    /// </summary>
    int BufferSize { get; set; }

    /// <summary>
    /// Provide a hint for the extension of the archive being read, can speed up finding the correct decoder.
    /// </summary>
    string? ExtensionHint { get; set; }

    /// <summary>
    /// Size of the rewindable buffer for non-seekable streams.
    /// </summary>
    int? RewindableBufferSize { get; set; }

    /// <summary>
    /// Registry of compression providers.
    /// Defaults to <see cref="CompressionProviderRegistry.Default" /> but can be replaced with custom providers.
    /// Use this to provide alternative decompression implementations.
    /// </summary>
    CompressionProviderRegistry Providers { get; set; }
}
